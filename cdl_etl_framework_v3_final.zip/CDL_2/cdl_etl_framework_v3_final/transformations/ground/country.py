"""
transformations/ground/country.py
====================================
Country layer — OPCO GROUND.
Aggregates facility_daily → country grain.
"""

from datetime import date, datetime, timezone
from typing import Optional

from pyspark.sql import DataFrame, SparkSession
from pyspark.sql import functions as F

from config.env_config import get_data_db

DATA_DB = get_data_db()

COUNTRY_REF = {
    "US": ("United States",  "AMERICAS", "AM", "USD"),
    "GB": ("United Kingdom", "EUROPE",   "EU", "GBP"),
    "DE": ("Germany",        "EUROPE",   "EU", "EUR"),
    "AU": ("Australia",      "APAC",     "AP", "AUD"),
    "SG": ("Singapore",      "APAC",     "AP", "SGD"),
    "IN": ("India",          "APAC",     "AP", "INR"),
    "BR": ("Brazil",         "AMERICAS", "AM", "BRL"),
    "FR": ("France",         "EUROPE",   "EU", "EUR"),
    "CA": ("Canada",         "AMERICAS", "AM", "CAD"),
    "JP": ("Japan",          "APAC",     "AP", "JPY"),
}


def transform_daily(
    spark:      SparkSession,
    run_date:   date,
    opco:       str,
    start_date: Optional[date] = None,
    end_date:   Optional[date] = None,
) -> DataFrame:
    fac = spark.table(f"{DATA_DB}.facility_daily").filter(
        F.col("facility_status") == "ACTIVE"
    )

    if start_date and end_date:
        fac = fac.filter(
            (F.col("load_date") >= F.lit(str(start_date))) &
            (F.col("load_date") <= F.lit(str(end_date))) &
            (F.col("opco") == opco.upper())
        )
        date_col = F.col("effective_date")
    else:
        fac = fac.filter(
            (F.col("load_date") == F.lit(str(run_date))) &
            (F.col("opco") == opco.upper())
        )
        date_col = F.lit(str(run_date)).cast("date")

    agg = (fac
        .groupBy("country_code", "opco")
        .agg(
            date_col.alias("effective_date"),
            F.countDistinct("facility_id").alias("total_facilities"),
            F.countDistinct("account_id").alias("total_accounts"),
            F.sum("shipment_count").alias("shipment_count"),
            F.sum("volume_kg").alias("volume_kg"),
            F.sum("revenue").alias("revenue"),
            F.sum("cost").alias("cost"),
            F.avg("on_time_delivery_pct").alias("avg_on_time_pct"),
            F.avg("utilisation_pct").alias("avg_utilisation_pct"),
        )
        .withColumn("gross_margin", F.col("revenue") - F.col("cost"))
    )
    return _add_meta(_enrich(spark, agg), run_date, opco, "DELTA_LAKE")


def transform_monthly(
    spark:      SparkSession,
    run_date:   date,
    opco:       str,
    start_date: Optional[date] = None,
    end_date:   Optional[date] = None,
) -> DataFrame:
    daily = spark.table(f"{DATA_DB}.country_daily")

    if start_date and end_date:
        daily = daily.filter(
            (F.col("load_date") >= F.lit(str(start_date))) &
            (F.col("load_date") <= F.lit(str(end_date))) &
            (F.col("opco") == opco.upper())
        )
        month_col = F.date_format("effective_date", "yyyy-MM")
    else:
        month_str = run_date.strftime("%Y-%m")
        daily = daily.filter(
            (F.date_format("effective_date", "yyyy-MM") == month_str) &
            (F.col("opco") == opco.upper())
        )
        month_col = F.lit(month_str)

    # Prior-year revenue for YoY (only relevant in incremental / single-month)
    prior_ym = run_date.replace(year=run_date.year - 1).strftime("%Y-%m")
    prior = (spark.table(f"{DATA_DB}.country_monthly")
        .filter((F.col("month_year") == prior_ym) & (F.col("opco") == opco.upper()))
        .select("country_code", F.col("total_revenue").alias("prior_yr_rev"))
    )

    df = (daily
        .groupBy(
            "country_code", "opco", "country_name",
            "region_code", "region_name", "currency_code"
        )
        .agg(
            month_col.alias("month_year"),
            F.avg("total_facilities").cast("int").alias("total_facilities"),
            F.avg("total_accounts").cast("int").alias("total_accounts"),
            F.sum("shipment_count").alias("total_shipments"),
            F.sum("volume_kg").alias("total_volume_kg"),
            F.sum("revenue").alias("total_revenue"),
            F.sum("cost").alias("total_cost"),
            F.sum("gross_margin").alias("gross_margin"),
            F.avg("avg_on_time_pct").alias("avg_on_time_pct"),
            F.avg("avg_utilisation_pct").alias("avg_utilisation_pct"),
        )
        .join(prior, on="country_code", how="left")
        .withColumn("yoy_revenue_growth",
            F.when(F.col("prior_yr_rev").isNotNull() & (F.col("prior_yr_rev") > 0),
                ((F.col("total_revenue") - F.col("prior_yr_rev"))
                 / F.col("prior_yr_rev")) * 100
            ).otherwise(F.lit(None).cast("double")))
        .drop("prior_yr_rev")
    )
    return _add_meta(df, run_date, opco, "DELTA_LAKE")


def _enrich(spark: SparkSession, df: DataFrame) -> DataFrame:
    ref = spark.createDataFrame(
        [(cc, cn, rn, rc, cur) for cc, (cn, rn, rc, cur) in COUNTRY_REF.items()],
        "country_code STRING, country_name STRING, "
        "region_name STRING, region_code STRING, currency_code STRING"
    )
    return (df.join(ref, on="country_code", how="left")
        .withColumn("country_name",  F.coalesce("country_name",  F.col("country_code")))
        .withColumn("region_code",   F.coalesce("region_code",   F.lit("OTHER")))
        .withColumn("region_name",   F.coalesce("region_name",   F.lit("UNKNOWN")))
        .withColumn("currency_code", F.coalesce("currency_code", F.lit("USD")))
    )


def _add_meta(df: DataFrame, run_date: date, opco: str, source: str) -> DataFrame:
    now = datetime.now(timezone.utc).isoformat()
    return (df
        .withColumn("load_date",     F.lit(str(run_date)).cast("date"))
        .withColumn("opco",          F.lit(opco.upper()))
        .withColumn("source_system", F.lit(source))
        .withColumn("dq_passed",     F.lit(None).cast("boolean"))
        .withColumn("created_at",    F.lit(now).cast("timestamp"))
        .withColumn("updated_at",    F.lit(now).cast("timestamp"))
    )
