"""
transformations/ground/global.py
==================================
Global layer — OPCO GROUND.
Rolls up country_daily → global + regional view.
"""

from datetime import date, datetime, timedelta, timezone
from typing import Optional

from pyspark.sql import DataFrame, SparkSession
from pyspark.sql import functions as F

from config.env_config import get_data_db

DATA_DB = get_data_db()


def transform_daily(
    spark:      SparkSession,
    run_date:   date,
    opco:       str,
    start_date: Optional[date] = None,
    end_date:   Optional[date] = None,
) -> DataFrame:
    cntry = spark.table(f"{DATA_DB}.country_daily")

    if start_date and end_date:
        cntry = cntry.filter(
            (F.col("load_date") >= F.lit(str(start_date))) &
            (F.col("load_date") <= F.lit(str(end_date))) &
            (F.col("opco") == opco.upper())
        )
        eff_col  = F.col("effective_date")
        prev_rev = None  # DoD not computed for range loads
    else:
        cntry = cntry.filter(
            (F.col("load_date") == F.lit(str(run_date))) &
            (F.col("opco") == opco.upper())
        )
        eff_col = F.lit(str(run_date)).cast("date")
        # Prior day revenue for DoD
        prev_rows = (spark.table(f"{DATA_DB}.global_daily")
            .filter(
                (F.col("effective_date") == F.lit(str(run_date - timedelta(days=1)))) &
                (F.col("opco") == opco.upper()) &
                F.col("region_code").isNull()
            )
            .select("revenue").collect()
        )
        prev_rev = prev_rows[0]["revenue"] if prev_rows else None

    global_total = _rollup_daily(cntry, None,          eff_col, prev_rev)
    regional     = _rollup_daily(cntry, "region_code", eff_col, prev_rev)
    df           = global_total.unionByName(regional)
    return _add_meta(df, run_date, opco, "DELTA_LAKE")


def transform_monthly(
    spark:      SparkSession,
    run_date:   date,
    opco:       str,
    start_date: Optional[date] = None,
    end_date:   Optional[date] = None,
) -> DataFrame:
    cntry_m = spark.table(f"{DATA_DB}.country_monthly")

    if start_date and end_date:
        cntry_m = cntry_m.filter(
            (F.col("load_date") >= F.lit(str(start_date))) &
            (F.col("load_date") <= F.lit(str(end_date))) &
            (F.col("opco") == opco.upper())
        )
        month_col = F.date_format(F.col("load_date"), "yyyy-MM")
        prev_m_rev = prev_y_rev = None  # growth metrics skipped for range
    else:
        month_str = run_date.strftime("%Y-%m")
        cntry_m = cntry_m.filter(
            (F.col("month_year") == month_str) &
            (F.col("opco") == opco.upper())
        )
        month_col = F.lit(month_str)

        def _scalar(mth):
            rows = (spark.table(f"{DATA_DB}.global_monthly")
                .filter((F.col("month_year") == mth) & (F.col("opco") == opco.upper())
                        & F.col("region_code").isNull())
                .select("total_revenue").collect())
            return rows[0]["total_revenue"] if rows else None

        prev_m_rev = _scalar((run_date.replace(day=1) - timedelta(days=1)).strftime("%Y-%m"))
        prev_y_rev = _scalar(run_date.replace(year=run_date.year - 1).strftime("%Y-%m"))

    global_total = _rollup_monthly(cntry_m, None,          month_col, prev_m_rev, prev_y_rev)
    regional     = _rollup_monthly(cntry_m, "region_code", month_col, prev_m_rev, prev_y_rev)
    df           = global_total.unionByName(regional)
    return _add_meta(df, run_date, opco, "DELTA_LAKE")


# ── Private helpers ───────────────────────────────────────────────────────────

def _rollup_daily(df, region_col, eff_col, prev_rev) -> DataFrame:
    grp = ["opco"] + ([region_col] if region_col else [])
    agg = (df.groupBy(*grp)
        .agg(
            eff_col.alias("effective_date"),
            F.countDistinct("country_code").alias("total_countries"),
            F.sum("total_facilities").alias("total_facilities"),
            F.sum("total_accounts").alias("total_accounts"),
            F.sum("shipment_count").alias("shipment_count"),
            F.sum("volume_kg").alias("volume_kg"),
            F.sum("revenue").alias("revenue"),
            F.sum("cost").alias("cost"),
            F.sum("gross_margin").alias("gross_margin"),
            F.avg("avg_on_time_pct").alias("avg_on_time_pct"),
            F.avg("avg_utilisation_pct").alias("avg_utilisation_pct"),
        )
        .withColumn("gross_margin_pct",
            F.when(F.col("revenue") > 0,
                (F.col("gross_margin") / F.col("revenue")) * 100
            ).otherwise(F.lit(0.0)))
        .withColumn("prev_day_revenue", F.lit(prev_rev))
        .withColumn("dod_revenue_change",
            F.when(F.lit(prev_rev).isNotNull() & (F.lit(prev_rev) > 0),
                ((F.col("revenue") - F.lit(prev_rev)) / F.lit(prev_rev)) * 100
            ).otherwise(F.lit(None).cast("double")))
    )
    if region_col:
        return agg.withColumnRenamed(region_col, "region_code")
    return agg.withColumn("region_code", F.lit(None).cast("string"))


def _rollup_monthly(df, region_col, month_col, prev_m_rev, prev_y_rev) -> DataFrame:
    grp = ["opco"] + ([region_col] if region_col else [])
    agg = (df.groupBy(*grp)
        .agg(
            month_col.alias("month_year"),
            F.countDistinct("country_code").alias("total_countries"),
            F.avg("total_facilities").cast("int").alias("total_facilities"),
            F.avg("total_accounts").cast("int").alias("total_accounts"),
            F.sum("total_shipments").alias("total_shipments"),
            F.sum("total_volume_kg").alias("total_volume_kg"),
            F.sum("total_revenue").alias("total_revenue"),
            F.sum("total_cost").alias("total_cost"),
            F.sum("gross_margin").alias("gross_margin"),
            F.avg("avg_on_time_pct").alias("avg_on_time_pct"),
            F.avg("avg_utilisation_pct").alias("avg_utilisation_pct"),
        )
        .withColumn("gross_margin_pct",
            F.when(F.col("total_revenue") > 0,
                (F.col("gross_margin") / F.col("total_revenue")) * 100
            ).otherwise(F.lit(0.0)))
        .withColumn("mom_revenue_growth",
            F.when(F.lit(prev_m_rev).isNotNull() & (F.lit(prev_m_rev) > 0),
                ((F.col("total_revenue") - F.lit(prev_m_rev)) / F.lit(prev_m_rev)) * 100
            ).otherwise(F.lit(None).cast("double")))
        .withColumn("yoy_revenue_growth",
            F.when(F.lit(prev_y_rev).isNotNull() & (F.lit(prev_y_rev) > 0),
                ((F.col("total_revenue") - F.lit(prev_y_rev)) / F.lit(prev_y_rev)) * 100
            ).otherwise(F.lit(None).cast("double")))
    )
    if region_col:
        return agg.withColumnRenamed(region_col, "region_code")
    return agg.withColumn("region_code", F.lit(None).cast("string"))


def _add_meta(df: DataFrame, run_date: date, opco: str, source: str) -> DataFrame:
    now = datetime.now(timezone.utc).isoformat()
    return (df
        .withColumn("load_date",     F.lit(str(run_date)).cast("date"))
        .withColumn("opco",          F.lit(opco.upper()))
        .withColumn("source_system", F.lit(source))
        .withColumn("dq_passed",     F.lit(None).cast("boolean"))
        .withColumn("created_at",    F.lit(now).cast("timestamp"))
        .withColumn("updated_at",    F.lit(now).cast("timestamp"))
    )
