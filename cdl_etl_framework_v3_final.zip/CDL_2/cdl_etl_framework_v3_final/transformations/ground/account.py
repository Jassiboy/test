"""
transformations/ground/account.py
===================================
Account layer — OPCO GROUND.

Both functions accept start_date / end_date:
  start_date=None, end_date=None  → INCREMENTAL: filter by last_modified_ts = run_date
  start_date + end_date set       → RANGE: filter by last_modified_ts BETWEEN dates
"""

from datetime import date, datetime, timezone
from typing import Optional

from pyspark.sql import DataFrame, SparkSession
from pyspark.sql import functions as F
from pyspark.sql.window import Window

from config.env_config import get_data_db

DATA_DB = get_data_db()


def transform_daily(
    spark:      SparkSession,
    run_date:   date,
    opco:       str,
    start_date: Optional[date] = None,
    end_date:   Optional[date] = None,
) -> DataFrame:
    raw = spark.table(f"{DATA_DB}.raw_account_transactions")

    # ── Date filter ───────────────────────────────────────────────────────
    if start_date and end_date:
        # RANGE mode: load everything between start and end in one go
        raw = raw.filter(
            (F.col("last_modified_ts").cast("date") >= F.lit(str(start_date))) &
            (F.col("last_modified_ts").cast("date") <= F.lit(str(end_date)))
        )
    else:
        # INCREMENTAL mode: only today's records
        # (watermark filter is applied in ingestion, not here)
        raw = raw.filter(
            F.col("last_modified_ts").cast("date") == F.lit(str(run_date))
        )

    df = (raw
        .withColumn("account_id",    F.trim(F.upper(F.col("account_id"))))
        .withColumn("opco",          F.lit(opco.upper()))
        .withColumn("account_status",
            F.when(F.upper(F.col("account_status")).isin("A","ACTIVE"),    F.lit("ACTIVE"))
             .when(F.upper(F.col("account_status")).isin("I","INACTIVE"),  F.lit("INACTIVE"))
             .when(F.upper(F.col("account_status")).isin("S","SUSPENDED"), F.lit("SUSPENDED"))
             .otherwise(F.lit("INACTIVE")))
        .withColumn("effective_date", F.col("last_modified_ts").cast("date"))
        .withColumn("revenue",
            F.greatest(F.coalesce(F.col("revenue"),      F.lit(0.0)), F.lit(0.0)))
        .withColumn("cost",
            F.greatest(F.coalesce(F.col("cost"),         F.lit(0.0)), F.lit(0.0)))
        .withColumn("credit_limit",
            F.greatest(F.coalesce(F.col("credit_limit"), F.lit(0.0)), F.lit(0.0)))
        # Keep latest record per account per day
        .withColumn("_rn", F.row_number().over(
            Window.partitionBy("account_id", "opco", "effective_date")
                  .orderBy(F.col("last_modified_ts").desc())
        ))
        .filter(F.col("_rn") == 1)
        .drop("_rn")
    )
    return _add_meta(df, run_date, opco, "ACCOUNT_DB")


def transform_monthly(
    spark:      SparkSession,
    run_date:   date,
    opco:       str,
    start_date: Optional[date] = None,
    end_date:   Optional[date] = None,
) -> DataFrame:
    daily = spark.table(f"{DATA_DB}.account_daily")

    if start_date and end_date:
        # RANGE: aggregate all months in the range
        daily = daily.filter(
            (F.col("effective_date") >= F.lit(str(start_date))) &
            (F.col("effective_date") <= F.lit(str(end_date))) &
            (F.col("opco") == opco.upper())
        )
        month_col = F.date_format("effective_date", "yyyy-MM")
    else:
        # INCREMENTAL: aggregate current month only
        month_str = run_date.strftime("%Y-%m")
        daily = daily.filter(
            (F.date_format("effective_date", "yyyy-MM") == month_str) &
            (F.col("opco") == opco.upper())
        )
        month_col = F.lit(month_str)

    df = (daily
        .groupBy(
            "account_id", "opco", "account_name", "account_type",
            "account_status", "account_category",
            "region_code", "country_code", "currency_code"
        )
        .agg(
            month_col.alias("month_year"),
            F.avg("balance").alias("avg_daily_balance"),
            F.sum("revenue").alias("total_revenue"),
            F.sum("cost").alias("total_cost"),
            F.sum("transaction_count").alias("transaction_count"),
            F.countDistinct("effective_date").alias("active_days"),
        )
    )
    return _add_meta(df, run_date, opco, "DELTA_LAKE")


def _add_meta(df: DataFrame, run_date: date, opco: str, source: str) -> DataFrame:
    now = datetime.now(timezone.utc).isoformat()
    return (df
        .withColumn("load_date",     F.lit(str(run_date)).cast("date"))
        .withColumn("opco",          F.lit(opco.upper()))
        .withColumn("source_system", F.lit(source))
        .withColumn("dq_passed",     F.lit(None).cast("boolean"))
        .withColumn("created_at",    F.lit(now).cast("timestamp"))
        .withColumn("updated_at",    F.lit(now).cast("timestamp"))
    )
