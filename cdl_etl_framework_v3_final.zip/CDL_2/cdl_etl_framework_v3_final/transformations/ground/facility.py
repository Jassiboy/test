"""
transformations/ground/facility.py
=====================================
Facility layer — OPCO GROUND.
Reads account_daily, derives facility attributes and operational KPIs.
"""

from datetime import date, datetime, timezone
from typing import Optional

from pyspark.sql import DataFrame, SparkSession
from pyspark.sql import functions as F

from config.env_config import get_data_db

DATA_DB = get_data_db()


def transform_daily(
    spark:      SparkSession,
    run_date:   date,
    opco:       str,
    start_date: Optional[date] = None,
    end_date:   Optional[date] = None,
) -> DataFrame:
    acc = spark.table(f"{DATA_DB}.account_daily")

    if start_date and end_date:
        # RANGE: read all account_daily rows in the date window
        acc = acc.filter(
            (F.col("load_date") >= F.lit(str(start_date))) &
            (F.col("load_date") <= F.lit(str(end_date))) &
            (F.col("opco") == opco.upper())
        )
    else:
        # INCREMENTAL: today's load_date only
        acc = acc.filter(
            (F.col("load_date") == F.lit(str(run_date))) &
            (F.col("opco") == opco.upper())
        )

    df = (acc
        .withColumn("facility_id",
            F.concat_ws("_", F.lit("FAC"), F.col("account_id")))
        .withColumn("facility_name",
            F.concat_ws(" ", F.col("account_name"), F.lit("Facility")))
        .withColumn("facility_type",
            F.when(F.col("account_category") == "CORPORATE", F.lit("HUB"))
             .when(F.col("account_category") == "SME",       F.lit("DEPOT"))
             .otherwise(F.lit("WAREHOUSE")))
        .withColumn("facility_status",
            F.when(F.col("account_status") == "ACTIVE",   F.lit("ACTIVE"))
             .when(F.col("account_status") == "INACTIVE", F.lit("INACTIVE"))
             .otherwise(F.lit("UNDER_MAINTENANCE")))
        .withColumn("facility_category", F.col("account_category"))
        .withColumn("city",        F.lit("UNKNOWN"))
        .withColumn("postal_code", F.lit(None).cast("string"))
        .withColumn("shipment_count",
            (F.col("transaction_count") * F.lit(0.8)).cast("long"))
        .withColumn("volume_kg", F.col("revenue") * F.lit(0.15))
        .withColumn("on_time_delivery_pct",
            F.least(F.lit(100.0),
                F.greatest(F.lit(0.0),
                    F.lit(95.0) - (F.col("cost") /
                        (F.col("revenue") + F.lit(0.001))) * F.lit(10.0))))
        .withColumn("utilisation_pct",
            F.when(F.col("credit_limit") > 0,
                F.least(F.lit(100.0),
                    (F.col("balance") / F.col("credit_limit")) * F.lit(100.0))
            ).otherwise(F.lit(0.0)))
        .select(
            "facility_id", "account_id", "opco",
            "facility_name", "facility_type", "facility_status", "facility_category",
            "country_code", "region_code", "city", "postal_code",
            "account_name", "account_type", "account_status",
            "shipment_count", "volume_kg", "revenue", "cost",
            "on_time_delivery_pct", "utilisation_pct",
            "effective_date", "last_modified_ts",
        )
    )
    return _add_meta(df, run_date, opco, "DELTA_LAKE")


def transform_monthly(
    spark:      SparkSession,
    run_date:   date,
    opco:       str,
    start_date: Optional[date] = None,
    end_date:   Optional[date] = None,
) -> DataFrame:
    daily = spark.table(f"{DATA_DB}.facility_daily")

    if start_date and end_date:
        daily = daily.filter(
            (F.col("load_date") >= F.lit(str(start_date))) &
            (F.col("load_date") <= F.lit(str(end_date))) &
            (F.col("opco") == opco.upper())
        )
        month_col = F.date_format("effective_date", "yyyy-MM")
    else:
        month_str = run_date.strftime("%Y-%m")
        daily = daily.filter(
            (F.date_format("effective_date", "yyyy-MM") == month_str) &
            (F.col("opco") == opco.upper())
        )
        month_col = F.lit(month_str)

    df = (daily
        .groupBy(
            "facility_id", "account_id", "opco",
            "facility_name", "facility_type", "facility_status",
            "country_code", "region_code"
        )
        .agg(
            month_col.alias("month_year"),
            F.sum("shipment_count").alias("total_shipments"),
            F.sum("volume_kg").alias("total_volume_kg"),
            F.sum("revenue").alias("total_revenue"),
            F.sum("cost").alias("total_cost"),
            F.avg("on_time_delivery_pct").alias("avg_on_time_pct"),
            F.avg("utilisation_pct").alias("avg_utilisation_pct"),
            F.countDistinct("effective_date").alias("active_days"),
        )
    )
    return _add_meta(df, run_date, opco, "DELTA_LAKE")


def _add_meta(df: DataFrame, run_date: date, opco: str, source: str) -> DataFrame:
    now = datetime.now(timezone.utc).isoformat()
    return (df
        .withColumn("load_date",     F.lit(str(run_date)).cast("date"))
        .withColumn("opco",          F.lit(opco.upper()))
        .withColumn("source_system", F.lit(source))
        .withColumn("dq_passed",     F.lit(None).cast("boolean"))
        .withColumn("created_at",    F.lit(now).cast("timestamp"))
        .withColumn("updated_at",    F.lit(now).cast("timestamp"))
    )
