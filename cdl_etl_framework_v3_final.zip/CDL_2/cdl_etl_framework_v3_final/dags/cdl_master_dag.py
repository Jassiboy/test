"""
dags/cdl_master_dag.py
========================
Airflow DAG for the CDL ETL pipeline.

All config lives in run_config.json.
The DAG simply calls 04_pipeline_runner.py with the config file path.
One DAG run = one execution of all run blocks in the config file.

Deploy : cp dags/cdl_master_dag.py $AIRFLOW_HOME/dags/
Trigger:
    airflow dags trigger cdl_master_pipeline \
        --conf '{"config_path": "/opt/cdl_etl_framework/config/run_config.json"}'
"""

from __future__ import annotations

from datetime import datetime, timedelta

from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.operators.empty import EmptyOperator
from airflow.utils.trigger_rule import TriggerRule

DEFAULT_ARGS = {
    "owner":            "cdl-data-engineering",
    "depends_on_past":  False,
    "email":            ["cdl-alerts@company.com"],
    "email_on_failure": True,
    "retries":          0,
    "execution_timeout": timedelta(hours=6),
}


def _run_pipeline(config_path: str, env: str, **ctx):
    """PythonOperator callable — delegates to run_from_config()."""
    import os, sys
    framework = os.getenv("CDL_FRAMEWORK_PATH", "/opt/cdl_etl_framework")
    sys.path.insert(0, framework)
    os.environ["CDL_ENV"] = env

    from notebooks.04_pipeline_runner import build_spark, run_from_config
    spark   = build_spark(env)
    success = run_from_config(spark, config_path, env_override=env)
    if not success:
        raise RuntimeError("CDL pipeline completed with failures — check run log.")


with DAG(
    dag_id="cdl_master_pipeline",
    description="CDL Metadata-Driven ETL: Account → Facility → Country → Global",
    default_args=DEFAULT_ARGS,
    schedule_interval="0 3 * * *",
    start_date=datetime(2024, 1, 1),
    catchup=False,
    max_active_runs=1,
    tags=["cdl", "etl", "medallion"],
    params={
        "config_path": "/opt/cdl_etl_framework/config/run_config.json",
        "env":         "azure",
    },
) as dag:

    start = EmptyOperator(task_id="start")

    run_pipeline = PythonOperator(
        task_id="run_cdl_pipeline",
        python_callable=_run_pipeline,
        op_kwargs={
            "config_path": "{{ params.config_path }}",
            "env":         "{{ params.env }}",
        },
        provide_context=True,
    )

    end = EmptyOperator(
        task_id="end",
        trigger_rule=TriggerRule.ALL_DONE,
    )

    start >> run_pipeline >> end
