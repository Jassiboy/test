# Databricks notebook source
# DBTITLE 1,Import framework_core module
import importlib
import sys
import os

# Add parent directory to path for imports
sys.path.insert(0, os.path.join(os.getcwd(), ".."))

# Import framework_core module using importlib
framework_core = importlib.import_module('notebooks.01_framework_core')
ingestion_core = importlib.import_module('notebooks.02_ingestion')
transformation_core = importlib.import_module('notebooks.03_transformation')
PIPELINE_CONFIG = importlib.import_module('config.env_config')
# Extract commonly used functions
log = framework_core.log
read_table_configs = framework_core.read_table_configs
check_dq_gate = framework_core.check_dq_gate
make_run_id = framework_core.make_run_id
log_failure = framework_core.log_failure
TableConfig = framework_core.TableConfig
run_ingestion = ingestion_core.run_ingestion
get_transformed_df = transformation_core.get_transformed_df



# COMMAND ----------

try:
    from pyspark.sql import SparkSession
except ImportError:
    pass

from datetime import date, datetime, timezone
from typing import Optional
import json

ALL_LAYERS = ["ACCOUNT", "FACILITY", "COUNTRY", "GLOBAL"]


# ─────────────────────────────────────────────────────────────────────────────
# Spark
# ─────────────────────────────────────────────────────────────────────────────
def build_spark(env: str):
    builder = (
        SparkSession.builder
        .appName("CDL_ETL_Pipeline")
        .config("spark.sql.shuffle.partitions",
                str(PIPELINE_CONFIG.spark_shuffle_partitions))
        .config("spark.sql.adaptive.enabled", "true")
        .config("spark.sql.adaptive.coalescePartitions.enabled", "true")
        .config("spark.databricks.delta.optimizeWrite.enabled", "true")
        .config("spark.databricks.delta.autoCompact.enabled", "true")
        .config("spark.sql.extensions",
                "io.delta.sql.DeltaSparkSessionExtension")
        .config("spark.sql.catalog.spark_catalog",
                "org.apache.spark.sql.delta.catalog.DeltaCatalog")
    )
    if env == "gcp":
        builder = builder.config(
            "spark.hadoop.fs.gs.impl",
            "com.google.cloud.hadoop.fs.gcs.GoogleHadoopFileSystem"
        )
    return builder.getOrCreate()


# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────
def layers_from(start_layer: str) -> list[str]:
    """Return ALL_LAYERS starting from start_layer (inclusive)."""
    sl = start_layer.upper()
    if sl not in ALL_LAYERS:
        raise ValueError(f"Invalid start_layer '{sl}'. Choose from {ALL_LAYERS}")
    return ALL_LAYERS[ALL_LAYERS.index(sl):]


def _halt_downstream(spark, layers: list[str], opco: str, ref_date: date, dag_id: str):
    """Log HALTED status for layers that were skipped due to upstream failure."""
    for layer in layers:
        configs = read_table_configs(spark, opco, layer)
        for cfg in configs:
            run_id = make_run_id(dag_id, cfg.table_id, ref_date, 1)
            log_failure(spark, run_id, None, "UPSTREAM_DQ_FAILED",
                        f"Halted: upstream failed — layer {layer} ref={ref_date}",
                        status="HALTED")


# ─────────────────────────────────────────────────────────────────────────────
# Core: run one layer (shared by both modes)
# ─────────────────────────────────────────────────────────────────────────────
def run_layer(
    spark:      "SparkSession",
    opco:       str,
    layer:      str,
    frequency:  str,
    dag_id:     str,
    run_date:   date,
    skip_gate:  bool,
    start_date: Optional[date] = None,
    end_date:   Optional[date] = None,
) -> bool:
    """
    Process one layer — works for both incremental and range mode.

    skip_gate  : True for the first layer in a run (no upstream to check).
    start_date : None = incremental, set = range load.
    end_date   : None = incremental, set = range load.
    run_date   : used for run log and DQ gate lookup.
    """
    grains = ["DAILY", "MONTHLY"] if frequency.upper() == "BOTH" else [frequency.upper()]
    all_ok = True

    for grain in grains:
        configs = read_table_configs(spark, opco, layer, grain)
        if not configs:
            log("WARN", f"No active configs", layer=layer, grain=grain, opco=opco)
            continue

        # DQ gate: all upstream table_ids must have passed in today's run log
        if not skip_gate:
            gate_ok, blocked_by = check_dq_gate(spark, configs, run_date, opco)
            if not gate_ok:
                log("ERROR", f"DQ gate blocked {layer}: upstream not ready {blocked_by}")
                return False

        for cfg in configs:
            log("INFO", f"  ► {cfg.table_id}  [{grain}]")

            # Get transformed DataFrame from OPCO-specific transformation module
            df = get_transformed_df(
                spark, opco, layer, grain,
                run_date   = run_date,
                start_date = start_date,
                end_date   = end_date,
            )

            # Write + DQ + retry + audit log
            ok = run_ingestion(
                spark,
                df,
                cfg,
                run_date   = run_date,
                dag_id     = dag_id,
                start_date = start_date,
                end_date   = end_date,
            )

            if ok:
                log("INFO",  f"  ✓ {cfg.table_id}")
            else:
                log("ERROR", f"  ✗ {cfg.table_id} FAILED")
                all_ok = False

    return all_ok


# ─────────────────────────────────────────────────────────────────────────────
# MODE 1 — INCREMENTAL
# ─────────────────────────────────────────────────────────────────────────────
def run_incremental(
    spark:     "SparkSession",
    opco:      str,
    layers:    list[str],
    frequency: str,
    dag_id:    str,
) -> dict:
    """
    Loads only records newer than the stored watermark (last_watermark_value
    in cdl_table_config). One Spark job for the whole pipeline.
    Watermark is updated after each successful table write.
    """
    run_date = date.today()
    log("INFO", f"{'═'*55}")
    log("INFO", f"INCREMENTAL | OPCO={opco} | as of {run_date} | layers={layers}")

    for i, layer in enumerate(layers):
        log("INFO", f"{'─'*45}")
        log("INFO", f"Layer: {layer}")
        ok = run_layer(
            spark      = spark,
            opco       = opco,
            layer      = layer,
            frequency  = frequency,
            dag_id     = dag_id,
            run_date   = run_date,
            skip_gate  = (i == 0),
            start_date = None,    # ← signals incremental mode to ingestion
            end_date   = None,
        )
        if not ok:
            remaining = layers[i + 1:]
            log("ERROR", f"Layer {layer} FAILED — halting {remaining}")
            _halt_downstream(spark, remaining, opco, run_date, dag_id)
            return {"period": f"incr:{run_date}", "mode": "incremental", "ok": False}

    return {"period": f"incr:{run_date}", "mode": "incremental", "ok": True}


# ─────────────────────────────────────────────────────────────────────────────
# MODE 2 — RANGE (full date window, one Spark job per layer)
# ─────────────────────────────────────────────────────────────────────────────
def run_range(
    spark:      "SparkSession",
    opco:       str,
    start_date: date,
    end_date:   date,
    layers:     list[str],
    frequency:  str,
    dag_id:     str,
) -> dict:
    """
    Reads start_date → end_date in ONE Spark job per layer.
    No month looping. Delta replaceWhere atomically covers the full range.
    Watermark is NOT updated (range = backfill / reprocess).
    """
    # run_date = end_date for logging and DQ gate reference
    run_date = end_date

    log("INFO", f"{'═'*55}")
    log("INFO", f"RANGE | OPCO={opco} | {start_date} → {end_date} | layers={layers}")

    for i, layer in enumerate(layers):
        log("INFO", f"{'─'*45}")
        log("INFO", f"Layer: {layer}")
        ok = run_layer(
            spark      = spark,
            opco       = opco,
            layer      = layer,
            frequency  = frequency,
            dag_id     = dag_id,
            run_date   = run_date,
            skip_gate  = (i == 0),
            start_date = start_date,   # ← signals range mode to ingestion
            end_date   = end_date,
        )
        if not ok:
            remaining = layers[i + 1:]
            log("ERROR", f"Layer {layer} FAILED — halting {remaining} for entire range")
            _halt_downstream(spark, remaining, opco, run_date, dag_id)
            return {
                "period": f"{start_date}→{end_date}",
                "mode":   "range",
                "ok":     False,
            }

    return {"period": f"{start_date}→{end_date}", "mode": "range", "ok": True}


# ─────────────────────────────────────────────────────────────────────────────
# Orchestrator — reads run_config.json, dispatches to correct mode
# ─────────────────────────────────────────────────────────────────────────────
def run_from_config(
    spark:        "SparkSession",
    config_path:  str,
    env_override: Optional[str] = None,
) -> bool:
    with open(config_path) as f:
        cfg = json.load(f)

    env    = env_override or cfg.get("env", "azure")
    dag_id = cfg.get("dag_id", "cdl_master_pipeline")
    os.environ["CDL_ENV"] = env

    all_results  = []
    global_start = datetime.now(timezone.utc)

    for run in cfg.get("runs", []):
        if set(run.keys()) == {"_comment"}:
            continue

        opco        = run["opco"].upper()
        start_layer = run.get("start_layer", "ACCOUNT")
        frequency   = run.get("frequency",   "BOTH")
        layers      = layers_from(start_layer)

        has_dates  = "start_date" in run and "end_date" in run

        if has_dates:
            # ── RANGE MODE ────────────────────────────────────────────────
            start_date = date.fromisoformat(run["start_date"])
            end_date   = date.fromisoformat(run["end_date"])
            result = run_range(spark, opco, start_date, end_date,
                               layers, frequency, dag_id)
        else:
            # ── INCREMENTAL MODE ──────────────────────────────────────────
            result = run_incremental(spark, opco, layers, frequency, dag_id)

        all_results.append({"opco": opco, "layers": "→".join(l[0] for l in layers), **result})

    _print_summary(all_results, global_start)
    return all(r["ok"] for r in all_results)


# ─────────────────────────────────────────────────────────────────────────────
# Summary
# ─────────────────────────────────────────────────────────────────────────────
def _print_summary(results: list[dict], started: datetime):
    elapsed = (datetime.now(timezone.utc) - started).total_seconds()
    total   = len(results)
    passed  = sum(1 for r in results if r["ok"])

    log("INFO", "╔" + "═"*60 + "╗")
    log("INFO", "║        CDL ETL — GRAND SUMMARY" + " "*29 + "║")
    log("INFO", f"║  Runs:{total}  Pass:{passed}  Fail:{total-passed}  Elapsed:{elapsed:.0f}s" + " "*24 + "║")
    log("INFO", "╠" + "═"*60 + "╣")
    log("INFO", "║  OPCO        Period                     Mode          Layers  ║")
    log("INFO", "╠" + "═"*60 + "╣")
    for r in results:
        icon = "✓" if r["ok"] else "✗"
        log("INFO",
            f"║  {r['opco']:<10}  {r['period']:<25}  "
            f"{r['mode']:<12}  {r['layers']:<6}  {icon}  ║")
    log("INFO", "╚" + "═"*60 + "╝")


# ─────────────────────────────────────────────────────────────────────────────
# Entry point
# ─────────────────────────────────────────────────────────────────────────────
def main():
    # Configuration file
    config_path = "../config/run_config.json"

    # Read environment from config
    with open(config_path, "r") as f:
        config = json.load(f)

    print(config)
    return
    env = config.get("env", "azure")
    os.environ["CDL_ENV"] = env

    # Build Spark session
    spark = build_spark(env)
    spark.sparkContext.setLogLevel("WARN")

    try:
        # Execute the pipeline
        success = run_from_config(spark, config_path)
        sys.exit(0 if success else 1)

    finally:
        spark.stop()


if __name__ == "__main__":
    main()


