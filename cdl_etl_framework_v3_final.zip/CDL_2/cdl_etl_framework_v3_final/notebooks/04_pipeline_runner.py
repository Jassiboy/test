"""
notebooks/04_pipeline_runner.py
=================================
Main entry point. Reads run_config.json and runs the pipeline.

TWO MODES — decided automatically from run_config.json:
──────────────────────────────────────────────────────────────
MODE 1 — INCREMENTAL  (no start_date / end_date in config)
  Reads from last_watermark_value stored in cdl_table_config.
  Loads only new/changed records since the last successful run.
  Watermark is updated after each successful layer.
  Best for: daily scheduled runs.

  Example config block:
    { "opco": "GROUND", "start_layer": "ACCOUNT", "frequency": "BOTH" }

MODE 2 — RANGE  (start_date + end_date provided in config)
  Reads ALL data between start_date and end_date in ONE Spark job per layer.
  Delta replaceWhere atomically overwrites only the affected partitions.
  If the write fails, nothing is committed (full rollback).
  Watermark is NOT updated (this is a backfill / reprocess run).
  Best for: historical loads, reprocessing a date window.

  Example config block:
    { "opco": "GROUND", "start_date": "2026-01-01", "end_date": "2026-05-31",
      "start_layer": "ACCOUNT", "frequency": "BOTH" }
──────────────────────────────────────────────────────────────

start_layer → which layers execute:
  ACCOUNT  → ACCOUNT, FACILITY, COUNTRY, GLOBAL
  FACILITY → FACILITY, COUNTRY, GLOBAL
  COUNTRY  → COUNTRY, GLOBAL
  GLOBAL   → GLOBAL only

Usage:
  python notebooks/04_pipeline_runner.py --config config/run_config.json
"""

import argparse
import json
import os
import sys
from datetime import date, datetime, timezone
from typing import Optional

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from config.env_config import PIPELINE_CONFIG
from notebooks.01_framework_core import (
    log, read_table_configs, check_dq_gate,
    make_run_id, log_failure,
)
from notebooks.02_ingestion import run_ingestion
from notebooks.03_transformation import get_transformed_df

try:
    from pyspark.sql import SparkSession
except ImportError:
    pass

ALL_LAYERS = ["ACCOUNT", "FACILITY", "COUNTRY", "GLOBAL"]


# ─────────────────────────────────────────────────────────────────────────────
# Spark
# ─────────────────────────────────────────────────────────────────────────────
def build_spark(env: str):
    builder = (
        SparkSession.builder
        .appName("CDL_ETL_Pipeline")
        .config("spark.sql.shuffle.partitions",
                str(PIPELINE_CONFIG.spark_shuffle_partitions))
        .config("spark.sql.adaptive.enabled", "true")
        .config("spark.sql.adaptive.coalescePartitions.enabled", "true")
        .config("spark.databricks.delta.optimizeWrite.enabled", "true")
        .config("spark.databricks.delta.autoCompact.enabled", "true")
        .config("spark.sql.extensions",
                "io.delta.sql.DeltaSparkSessionExtension")
        .config("spark.sql.catalog.spark_catalog",
                "org.apache.spark.sql.delta.catalog.DeltaCatalog")
    )
    if env == "gcp":
        builder = builder.config(
            "spark.hadoop.fs.gs.impl",
            "com.google.cloud.hadoop.fs.gcs.GoogleHadoopFileSystem"
        )
    return builder.getOrCreate()


# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────
def layers_from(start_layer: str) -> list[str]:
    """Return ALL_LAYERS starting from start_layer (inclusive)."""
    sl = start_layer.upper()
    if sl not in ALL_LAYERS:
        raise ValueError(f"Invalid start_layer '{sl}'. Choose from {ALL_LAYERS}")
    return ALL_LAYERS[ALL_LAYERS.index(sl):]


def _halt_downstream(spark, layers: list[str], opco: str, ref_date: date, dag_id: str):
    """Log HALTED status for layers that were skipped due to upstream failure."""
    for layer in layers:
        configs = read_table_configs(spark, opco, layer)
        for cfg in configs:
            run_id = make_run_id(dag_id, cfg.table_id, ref_date, 1)
            log_failure(spark, run_id, None, "UPSTREAM_DQ_FAILED",
                        f"Halted: upstream failed — layer {layer} ref={ref_date}",
                        status="HALTED")


# ─────────────────────────────────────────────────────────────────────────────
# Core: run one layer (shared by both modes)
# ─────────────────────────────────────────────────────────────────────────────
def run_layer(
    spark:      "SparkSession",
    opco:       str,
    layer:      str,
    frequency:  str,
    dag_id:     str,
    run_date:   date,
    skip_gate:  bool,
    start_date: Optional[date] = None,
    end_date:   Optional[date] = None,
) -> bool:
    """
    Process one layer — works for both incremental and range mode.

    skip_gate  : True for the first layer in a run (no upstream to check).
    start_date : None = incremental, set = range load.
    end_date   : None = incremental, set = range load.
    run_date   : used for run log and DQ gate lookup.
    """
    grains = ["DAILY", "MONTHLY"] if frequency.upper() == "BOTH" else [frequency.upper()]
    all_ok = True

    for grain in grains:
        configs = read_table_configs(spark, opco, layer, grain)
        if not configs:
            log("WARN", f"No active configs", layer=layer, grain=grain, opco=opco)
            continue

        # DQ gate: all upstream table_ids must have passed in today's run log
        if not skip_gate:
            gate_ok, blocked_by = check_dq_gate(spark, configs, run_date, opco)
            if not gate_ok:
                log("ERROR", f"DQ gate blocked {layer}: upstream not ready {blocked_by}")
                return False

        for cfg in configs:
            log("INFO", f"  ► {cfg.table_id}  [{grain}]")

            # Get transformed DataFrame from OPCO-specific transformation module
            df = get_transformed_df(
                spark, opco, layer, grain,
                run_date   = run_date,
                start_date = start_date,
                end_date   = end_date,
            )

            # Write + DQ + retry + audit log
            ok = run_ingestion(
                spark,
                df,
                cfg,
                run_date   = run_date,
                dag_id     = dag_id,
                start_date = start_date,
                end_date   = end_date,
            )

            if ok:
                log("INFO",  f"  ✓ {cfg.table_id}")
            else:
                log("ERROR", f"  ✗ {cfg.table_id} FAILED")
                all_ok = False

    return all_ok


# ─────────────────────────────────────────────────────────────────────────────
# MODE 1 — INCREMENTAL
# ─────────────────────────────────────────────────────────────────────────────
def run_incremental(
    spark:     "SparkSession",
    opco:      str,
    layers:    list[str],
    frequency: str,
    dag_id:    str,
) -> dict:
    """
    Loads only records newer than the stored watermark (last_watermark_value
    in cdl_table_config). One Spark job for the whole pipeline.
    Watermark is updated after each successful table write.
    """
    run_date = date.today()
    log("INFO", f"{'═'*55}")
    log("INFO", f"INCREMENTAL | OPCO={opco} | as of {run_date} | layers={layers}")

    for i, layer in enumerate(layers):
        log("INFO", f"{'─'*45}")
        log("INFO", f"Layer: {layer}")
        ok = run_layer(
            spark      = spark,
            opco       = opco,
            layer      = layer,
            frequency  = frequency,
            dag_id     = dag_id,
            run_date   = run_date,
            skip_gate  = (i == 0),
            start_date = None,    # ← signals incremental mode to ingestion
            end_date   = None,
        )
        if not ok:
            remaining = layers[i + 1:]
            log("ERROR", f"Layer {layer} FAILED — halting {remaining}")
            _halt_downstream(spark, remaining, opco, run_date, dag_id)
            return {"period": f"incr:{run_date}", "mode": "incremental", "ok": False}

    return {"period": f"incr:{run_date}", "mode": "incremental", "ok": True}


# ─────────────────────────────────────────────────────────────────────────────
# MODE 2 — RANGE (full date window, one Spark job per layer)
# ─────────────────────────────────────────────────────────────────────────────
def run_range(
    spark:      "SparkSession",
    opco:       str,
    start_date: date,
    end_date:   date,
    layers:     list[str],
    frequency:  str,
    dag_id:     str,
) -> dict:
    """
    Reads start_date → end_date in ONE Spark job per layer.
    No month looping. Delta replaceWhere atomically covers the full range.
    Watermark is NOT updated (range = backfill / reprocess).
    """
    # run_date = end_date for logging and DQ gate reference
    run_date = end_date

    log("INFO", f"{'═'*55}")
    log("INFO", f"RANGE | OPCO={opco} | {start_date} → {end_date} | layers={layers}")

    for i, layer in enumerate(layers):
        log("INFO", f"{'─'*45}")
        log("INFO", f"Layer: {layer}")
        ok = run_layer(
            spark      = spark,
            opco       = opco,
            layer      = layer,
            frequency  = frequency,
            dag_id     = dag_id,
            run_date   = run_date,
            skip_gate  = (i == 0),
            start_date = start_date,   # ← signals range mode to ingestion
            end_date   = end_date,
        )
        if not ok:
            remaining = layers[i + 1:]
            log("ERROR", f"Layer {layer} FAILED — halting {remaining} for entire range")
            _halt_downstream(spark, remaining, opco, run_date, dag_id)
            return {
                "period": f"{start_date}→{end_date}",
                "mode":   "range",
                "ok":     False,
            }

    return {"period": f"{start_date}→{end_date}", "mode": "range", "ok": True}


# ─────────────────────────────────────────────────────────────────────────────
# Orchestrator — reads run_config.json, dispatches to correct mode
# ─────────────────────────────────────────────────────────────────────────────
def run_from_config(
    spark:        "SparkSession",
    config_path:  str,
    env_override: Optional[str] = None,
) -> bool:
    with open(config_path) as f:
        cfg = json.load(f)

    env    = env_override or cfg.get("env", "azure")
    dag_id = cfg.get("dag_id", "cdl_master_pipeline")
    os.environ["CDL_ENV"] = env

    all_results  = []
    global_start = datetime.now(timezone.utc)

    for run in cfg.get("runs", []):
        if set(run.keys()) == {"_comment"}:
            continue

        opco        = run["opco"].upper()
        start_layer = run.get("start_layer", "ACCOUNT")
        frequency   = run.get("frequency",   "BOTH")
        layers      = layers_from(start_layer)

        has_dates  = "start_date" in run and "end_date" in run

        if has_dates:
            # ── RANGE MODE ────────────────────────────────────────────────
            start_date = date.fromisoformat(run["start_date"])
            end_date   = date.fromisoformat(run["end_date"])
            result = run_range(spark, opco, start_date, end_date,
                               layers, frequency, dag_id)
        else:
            # ── INCREMENTAL MODE ──────────────────────────────────────────
            result = run_incremental(spark, opco, layers, frequency, dag_id)

        all_results.append({"opco": opco, "layers": "→".join(l[0] for l in layers), **result})

    _print_summary(all_results, global_start)
    return all(r["ok"] for r in all_results)


# ─────────────────────────────────────────────────────────────────────────────
# Summary
# ─────────────────────────────────────────────────────────────────────────────
def _print_summary(results: list[dict], started: datetime):
    elapsed = (datetime.now(timezone.utc) - started).total_seconds()
    total   = len(results)
    passed  = sum(1 for r in results if r["ok"])

    log("INFO", "╔" + "═"*60 + "╗")
    log("INFO", "║        CDL ETL — GRAND SUMMARY" + " "*29 + "║")
    log("INFO", f"║  Runs:{total}  Pass:{passed}  Fail:{total-passed}  Elapsed:{elapsed:.0f}s" + " "*24 + "║")
    log("INFO", "╠" + "═"*60 + "╣")
    log("INFO", "║  OPCO        Period                     Mode          Layers  ║")
    log("INFO", "╠" + "═"*60 + "╣")
    for r in results:
        icon = "✓" if r["ok"] else "✗"
        log("INFO",
            f"║  {r['opco']:<10}  {r['period']:<25}  "
            f"{r['mode']:<12}  {r['layers']:<6}  {icon}  ║")
    log("INFO", "╚" + "═"*60 + "╝")


# ─────────────────────────────────────────────────────────────────────────────
# Entry point
# ─────────────────────────────────────────────────────────────────────────────
def main():
    parser = argparse.ArgumentParser(description="CDL ETL Pipeline Runner")
    parser.add_argument("--config", required=True, help="Path to run_config.json")
    parser.add_argument("--env",    default=None,  choices=["azure", "gcp"])
    args = parser.parse_args()

    with open(args.config) as f:
        raw = json.load(f)
    env = args.env or raw.get("env", "azure")
    os.environ["CDL_ENV"] = env

    spark   = build_spark(env)
    spark.sparkContext.setLogLevel("WARN")
    success = run_from_config(spark, args.config, args.env)
    sys.exit(0 if success else 1)


if __name__ == "__main__":
    main()
