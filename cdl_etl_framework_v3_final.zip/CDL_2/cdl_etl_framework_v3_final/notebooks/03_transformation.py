"""
notebooks/03_transformation.py
================================
Loads the correct transformation module for a given OPCO + layer
and calls transform_daily() or transform_monthly().

The mode (incremental vs range) is communicated via start_date/end_date:
  start_date=None, end_date=None  → transformation reads "today's" data
  start_date + end_date provided  → transformation reads the full date range

Each transformation module (e.g. transformations/ground/account.py) receives
these parameters and decides how to filter the source accordingly.
"""

import importlib
from datetime import date
from typing import Optional

from pyspark.sql import DataFrame, SparkSession

# Dynamic import to handle module names starting with digits
_framework_core = importlib.import_module('notebooks.01_framework_core')
log = _framework_core.log


def get_transformed_df(
    spark:      SparkSession,
    opco:       str,
    layer:      str,
    frequency:  str,
    run_date:   date,
    start_date: Optional[date] = None,
    end_date:   Optional[date] = None,
) -> DataFrame:
    """
    Import transformations/{opco}/{layer}.py and call the right function.

    Parameters
    ----------
    opco       : "GROUND" | "FREIGHT" | ...
    layer      : "ACCOUNT" | "FACILITY" | "COUNTRY" | "GLOBAL"
    frequency  : "DAILY" | "MONTHLY"
    run_date   : reference date (today for incremental, end_date for range)
    start_date : None = incremental mode; set = range mode
    end_date   : None = incremental mode; set = range mode

    Returns a DataFrame ready to pass to run_ingestion().
    """
    module_path = f"transformations.{opco.lower()}.{layer.lower()}"
    log("INFO", f"Loading transformer", module=module_path, frequency=frequency)

    try:
        module = importlib.import_module(module_path)
    except ModuleNotFoundError:
        raise ValueError(
            f"No transformation module at '{module_path}'.\n"
            f"Create transformations/{opco.lower()}/{layer.lower()}.py "
            f"with transform_daily() and transform_monthly() functions."
        )

    fn_name = "transform_monthly" if frequency.upper() == "MONTHLY" else "transform_daily"
    fn      = getattr(module, fn_name, None)

    if fn is None:
        raise ValueError(
            f"Module '{module_path}' is missing function '{fn_name}'"
        )

    # Pass start_date/end_date so transformations can apply range filters
    return fn(spark, run_date, opco, start_date=start_date, end_date=end_date)
