# CDL Metadata-Driven ETL Framework  (v3)

## What's new in v3

- **OPCO-specific transformation folders** — each OPCO has its own folder with one file per layer
- **Simplified notebooks** — no class hierarchy, no base classes; plain functions only
- **Single config file** — `run_config.json` drives everything: OPCO, date range, start layer, frequency

---

## Project Structure

```
cdl_etl_framework/
│
├── config/
│   ├── env_config.py           ← Azure / GCP switch (set CDL_ENV=azure|gcp)
│   ├── seed_metadata.py        ← Seeds cdl_table_config for one OPCO
│   └── run_config.json         ← ★ What you edit to run the pipeline
│
├── transformations/            ← ★ One folder per OPCO
│   └── ground/
│       ├── account.py          ← transform_daily() + transform_monthly()
│       ├── facility.py
│       ├── country.py
│       └── global.py
│   (add freight/, international/ etc. here for new OPCOs)
│
├── notebooks/
│   ├── 01_framework_core.py   ← log, read_table_configs, run_dq, log_start/success/failure
│   ├── 02_ingestion.py        ← run_ingestion() — write to Delta, retry, watermark
│   ├── 03_transformation.py   ← get_transformed_df() — dynamic module loader
│   └── 04_pipeline_runner.py  ← main entry point, reads run_config.json
│
├── ddl/
│   ├── azure/
│   │   ├── 01_control_tables.sql   ← cdl_table_config + cdl_table_run_log
│   │   └── 02_data_tables.sql      ← 8 pipeline tables
│   └── gcp/
│       ├── 01_control_tables.sql
│       └── 02_data_tables.sql
│
├── dags/
│   └── cdl_master_dag.py      ← Airflow DAG (calls pipeline_runner)
│
├── utils/
│   ├── alert_manager.py       ← Email / Teams / Slack
│   ├── cloud_adapter.py       ← ADLS / GCS / JDBC abstraction
│   └── retry_handler.py       ← Exponential backoff decorator
│
├── init_scripts/
│   ├── cluster_init_azure.sh
│   └── cluster_init_gcp.sh
│
└── tests/
    └── test_framework.py      ← pytest suite
```

---

## 2 Control Tables

| Table | Purpose |
|-------|---------|
| `cdl_table_config` | Everything per pipeline mapping: source/target, DQ rules, retry policy, alert config, watermark, dependency gate |
| `cdl_table_run_log` | Every task attempt: status, row counts, DQ results, error details |

---

## run_config.json — All you need to edit

```json
{
  "env":    "azure",
  "dag_id": "cdl_master_pipeline",
  "runs": [
    {
      "opco":        "GROUND",
      "start_date":  "2026-01-01",
      "end_date":    "2026-05-31",
      "start_layer": "ACCOUNT",
      "frequency":   "BOTH"
    }
  ]
}
```

| Field | Options | Meaning |
|-------|---------|---------|
| `opco` | `GROUND`, `FREIGHT`, … | Which OPCO to run |
| `start_date` | `YYYY-MM-DD` | First day of range |
| `end_date` | `YYYY-MM-DD` | Last day of range |
| `start_layer` | `ACCOUNT` `FACILITY` `COUNTRY` `GLOBAL` | Which layer to start from (runs this + all downstream) |
| `frequency` | `DAILY` `MONTHLY` `BOTH` | Which table grain to process |

### start_layer → which layers run

| start_layer | Layers executed |
|-------------|----------------|
| `ACCOUNT` | ACCOUNT → FACILITY → COUNTRY → GLOBAL |
| `FACILITY` | FACILITY → COUNTRY → GLOBAL |
| `COUNTRY` | COUNTRY → GLOBAL |
| `GLOBAL` | GLOBAL only |

---

## How to run

```bash
# Step 1 — Apply DDL
# Azure:
databricks workspace run-sql ddl/azure/01_control_tables.sql
databricks workspace run-sql ddl/azure/02_data_tables.sql

# Step 2 — Seed metadata
python config/seed_metadata.py --env azure --opco GROUND

# Step 3 — Edit run_config.json with your OPCO / date range / start_layer

# Step 4 — Run pipeline
python notebooks/04_pipeline_runner.py --config config/run_config.json

# Step 5 — Run tests
pytest tests/test_framework.py -v
```

---

## Adding a new OPCO (e.g. FREIGHT)

1. Create folder: `transformations/freight/`
2. Copy from ground as a starting point:
   ```bash
   cp -r transformations/ground/ transformations/freight/
   ```
3. Edit the business logic in each file to match FREIGHT's source system
4. Seed metadata:
   ```bash
   python config/seed_metadata.py --env azure --opco FREIGHT
   ```
5. Add a run block to `run_config.json`:
   ```json
   { "opco": "FREIGHT", "start_date": "2026-01-01", "end_date": "2026-01-31",
     "start_layer": "ACCOUNT", "frequency": "BOTH" }
   ```
6. Run — **zero changes to any notebook required**

---

## Execution flow (example: GROUND, FACILITY→, Jan–May 2026)

```
run_config.json
│
└── Run block: GROUND | 2026-01-01 → 2026-05-31 | start_layer=FACILITY
    │
    ├── Month: 2026-01-31
    │     FACILITY (DQ gate ✓) → COUNTRY (DQ gate ✓) → GLOBAL ✓
    │
    ├── Month: 2026-02-28
    │     FACILITY ✓ → COUNTRY ✓ → GLOBAL ✓
    │
    ├── Month: 2026-03-31
    │     FACILITY ✗ DQ FAIL → COUNTRY HALTED → GLOBAL HALTED
    │     (next month still runs — failures are month-isolated)
    │
    ├── Month: 2026-04-30
    │     FACILITY ✓ → COUNTRY ✓ → GLOBAL ✓
    │
    └── Month: 2026-05-31
          FACILITY ✓ → COUNTRY ✓ → GLOBAL ✓

Grand Summary printed at end: pass/fail per OPCO × month
```

---

## Monitoring

```sql
-- Today's run status
SELECT dataset_layer, table_name, status, attempt_number,
       rows_read, rows_written, rows_rejected, dq_passed, duration_seconds
FROM   cdl_metadata.cdl_table_run_log
WHERE  dag_run_date = CURRENT_DATE() AND opco = 'GROUND'
ORDER  BY dataset_layer, started_at;

-- Failed runs with error detail
SELECT table_name, error_code, error_message
FROM   cdl_metadata.cdl_table_run_log
WHERE  dag_run_date = CURRENT_DATE() AND status = 'FAILED';

-- Current watermark per table
SELECT table_id, last_watermark_value, last_successful_run
FROM   cdl_metadata.cdl_table_config
WHERE  opco = 'GROUND' AND ingestion_mode = 'INCR';
```
