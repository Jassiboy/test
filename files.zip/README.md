# Multi-Layer Data Pipeline — Azure Databricks + Delta Lake

Object-oriented PySpark pipeline transforming data through four hierarchical
layers, each producing daily + monthly Delta tables:

```
Account (existing)  →  Facility  →  Country  →  Global
```

Config-driven, idempotent (Delta `replaceWhere` partition overwrite),
unit-tested, with a generic restatement framework, severity-graduated data
quality/quarantine policy, and centralized Delta-backed audit logging.

## Project structure

```
pipeline/
├── config_loader.py     # YAML config + ${a.b.c} reference resolution
├── core.py               # BaseTransformation (Template Method), SparkSessionFactory, DeltaIOHelper
├── transformations.py    # AccountToFacility, FacilityToCountry, CountryToGlobal
├── dq.py                  # Schema validation, RuleEngine, QuarantineHandler, DQMetricsWriter
├── watermark.py           # WatermarkManager — incremental state + inter-layer DQ gate
├── restatement.py         # RestatementEngine — selective reprocessing
├── logging_utils.py       # PipelineLogger (Delta audit logging context manager)
├── utils.py               # SecretResolver, date helpers
└── jobs.py                # CLI entry points: daily / monthly / restate

config/
├── dev|test|prod/pipeline_config.yaml   # tables, joins, aggregations, DQ thresholds, perf tuning, watermark path
└── schemas.yaml                          # shared schema definitions

tests/
├── test_pipeline.py       # unit tests — ConfigLoader, RuleEngine, SchemaValidator, transform() logic, watermark hooks
├── test_integration.py    # Delta I/O tests — write idempotency, restatement partition deletion
└── test_watermark.py      # Delta I/O tests — monotonic guard, upstream DQ gating, explicit reset

scripts/ddl_audit_tables.sql   # DDL for pipeline_execution_log, dq_execution_log, restatement_log, watermark_control
docs/class_diagram.mermaid     # full class diagram
```

## Quickstart

```bash
pip install -r requirements.txt
pip install -e .

# Unit tests (fast, no Delta/network needed)
pytest tests/test_pipeline.py

# Integration tests (require Delta Lake / Maven network access)
pytest tests/test_integration.py tests/test_watermark.py -m integration

# Run the daily chain for an exact date (manual/backfill path — bypasses the watermark)
python -m pipeline.jobs daily --env dev --run-date 2025-01-15

# Restate a date range, cascading to downstream layers
python -m pipeline.jobs restate --env prod --layer facility --table-type daily \
    --start-date 2025-01-01 --end-date 2025-01-31 --cascade
```

For the scheduled/incremental path (no explicit date — reads everything new
since the last successful watermark), invoke the transformation classes
directly rather than through the CLI's explicit `--run-date`:

```python
from pipeline import AccountToFacility, ConfigLoader, SparkSessionFactory

config = ConfigLoader(environment="prod")
spark = SparkSessionFactory.get_or_create(config)
AccountToFacility(spark, config, table_type="daily").run()  # no run_date kwarg -> watermark-driven
```

## Incremental processing & inter-layer DQ gating

Two things every layer participates in, both backed by one Delta control
table (`watermark_control`, one row per `(pipeline_name, layer, table_type)`,
upserted via `WatermarkManager`):

**Watermark-driven incremental reads.** Account is append-only — every
scheduled run lands new `business_date`/`year_month` partitions. When no
explicit `--run-date`/`--year-month` is passed (the scheduled path, as
opposed to manual/restatement), each layer's `read()` pulls its own last
successfully processed watermark and reads everything strictly newer than
it — correctly handling a missed run that left multiple new partitions
unprocessed, not just "exactly one new date landed."

```python
# AccountToFacility.read(), scheduled path (no run_date passed):
record = watermark_mgr.get_watermark("account_to_facility", "facility", "daily")
account_df = io.read_layer_table_since_watermark("account", "daily", "business_date", record.last_watermark)
```

**Inter-layer DQ gating.** `FacilityToCountry` and `CountryToGlobal` each
declare `upstream_dependency` (e.g. `("account_to_facility", "facility")`).
Before `BaseTransformation.run()` calls `read()` at all, it checks the
upstream pipeline's last recorded `dq_status` in the control table and
raises `UpstreamDataQualityError` if it isn't `"PASSED"` — refusing to
aggregate from a layer that didn't pass its own validation. This replaces
what used to be a print-only warning that the chain ignored.

```python
if self.upstream_dependency is not None:
    upstream_pipeline_name, upstream_layer = self.upstream_dependency
    status = watermark_mgr.get_upstream_dq_status(upstream_pipeline_name, upstream_layer, self.table_type)
    if status != "PASSED":
        raise UpstreamDataQualityError(...)  # stops here — read() is never called
```

The watermark only ever advances *forward* (a monotonic guard in
`WatermarkManager.advance_watermark`) — restating a historical date that's
behind the current frontier is a deliberate no-op on the control row, so a
backfill never regresses incremental processing or causes already-processed
dates to be re-read as "new." Explicit resets (`reset_watermark()`) are the
one path allowed to move the frontier backward, for deliberate recovery.

## Design in one paragraph

`BaseTransformation.run()` fixes the orchestration skeleton (gate check on
upstream DQ → read → transform → validate → quarantine → write → advance
watermark → log) once; `AccountToFacility`, `FacilityToCountry`, and
`CountryToGlobal` override only `read()`, `transform()`, `validate()`, and
declare their `upstream_dependency`. `transform()` is a pure DataFrame-in/
DataFrame-out function — no I/O — so the aggregation logic is unit tested
directly with a local Spark session (`tests/test_pipeline.py`). DQ failures
are handled by severity: CRITICAL halts the pipeline, HIGH quarantines
offending rows to Delta and continues, MEDIUM flags rows but writes them.
The DQ outcome and the new watermark are persisted together, atomically, in
one control-table row — which is what the next layer's gate check reads
before it's allowed to start. `RestatementEngine` reuses the exact same
transformation classes for ad-hoc reprocessing — never a parallel code path
that could drift — and the watermark's monotonic guard ensures restating a
historical date never disrupts ongoing incremental processing. Every run
writes exactly one audit row to `pipeline_execution_log` via the
`PipelineLogger` context manager, success or failure.

## Platform portability (GCP / AWS)

Only three modules touch cloud-specific APIs: `core.py` (Delta read/write
paths — swap `abfss://` for `gs://`/`s3://`, a config change not a code
change), `core.SparkSessionFactory` (Databricks-specific Spark confs), and
`utils.SecretResolver` (`dbutils.secrets` → Secret Manager / Secrets
Manager). `transformations.py`, `dq.py`, `restatement.py`, and
`logging_utils.py` import nothing cloud-specific and port unchanged.
