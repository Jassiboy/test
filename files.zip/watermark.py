"""
pipeline.watermark
====================
Two responsibilities that were missing from the original design and are
both backed by the same Delta control table (`watermark_control`):

1. **Incremental watermark tracking** — Account is an append-only/
   incremental table: every scheduled run appends new rows (new
   business_date partitions for daily, new year_month for monthly). Without
   a persisted "last successfully processed" marker, `read()` has no way
   to know which rows are new since the last run other than being told
   explicitly via `--run-date`, which doesn't scale to "catch up after a
   missed run" or "process whatever's new" scheduling.

2. **Inter-layer DQ gating** — a layer's DQ outcome (PASSED/FAILED) is
   recorded in the *same* control-table row as its watermark, atomically,
   at the moment the watermark advances. The next layer downstream reads
   this row *before* reading its source data and refuses to proceed if
   the upstream run didn't pass DQ — closing the gap where Country could
   previously read Facility's output even when Facility's DQ failed.

Why one table for both concerns rather than two: the watermark and the DQ
status of the run that produced it are inherently the same fact ("as of
this run, the table is known-good up to this point, or it isn't") — storing
them separately would let them drift out of sync (e.g. watermark advances
but a concurrent process reads a stale DQ status). One row, updated in one
transaction, makes that drift impossible.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Optional

from pyspark.sql.types import StringType, StructField, StructType, TimestampType

# Explicit schema for the control-table row — required because a single-row
# DataFrame built from a dict with a None value (e.g. resetting
# last_watermark to NULL) would otherwise infer that column as NullType,
# which Delta's MERGE cannot reconcile against the existing StringType
# column in the target table.
_WATERMARK_SCHEMA = StructType(
    [
        StructField("pipeline_name", StringType(), nullable=False),
        StructField("layer", StringType(), nullable=False),
        StructField("table_type", StringType(), nullable=False),
        StructField("last_watermark", StringType(), nullable=True),
        StructField("last_run_id", StringType(), nullable=True),
        StructField("last_dq_status", StringType(), nullable=True),
        StructField("updated_at", TimestampType(), nullable=True),
    ]
)


class UpstreamDataQualityError(Exception):
    """Raised when a layer's read() finds that its upstream dependency's
    most recent run did not pass DQ validation. This is the actual
    enforcement of "don't move to the next layer until the previous
    layer's data quality is verified" — previously this was only a log
    warning, never a hard stop."""


@dataclass
class WatermarkRecord:
    pipeline_name: str
    layer: str
    table_type: str
    last_watermark: Optional[str]  # business_date (YYYY-MM-DD) or year_month (YYYY-MM)
    last_run_id: Optional[str]
    last_dq_status: Optional[str]  # "PASSED" | "FAILED" | None (no run yet)
    updated_at: Optional[datetime]

    def to_row_dict(self) -> dict:
        return {
            "pipeline_name": self.pipeline_name,
            "layer": self.layer,
            "table_type": self.table_type,
            "last_watermark": self.last_watermark,
            "last_run_id": self.last_run_id,
            "last_dq_status": self.last_dq_status,
            "updated_at": self.updated_at,
        }


class WatermarkManager:
    """
    Reads/writes the `watermark_control` Delta table. One row per
    (pipeline_name, layer, table_type) — upserted via Delta MERGE so
    concurrent/retried runs never produce duplicate control rows.

    Parameters
    ----------
    spark, config: standard injected dependencies, consistent with every
        other class in this package.
    """

    def __init__(self, spark, config):
        self.spark = spark
        self.config = config
        self.path = config.get("watermark.path")

    # ------------------------------------------------------------------ #
    # Reads
    # ------------------------------------------------------------------ #
    def get_watermark(self, pipeline_name: str, layer: str, table_type: str) -> WatermarkRecord:
        """Returns the current control row, or an empty WatermarkRecord
        (all Nones) if this pipeline/layer/table_type has never run
        successfully before — that's the legitimate "first ever run"
        state, not an error."""
        df = self._read_control_table()
        if df is None:
            return WatermarkRecord(pipeline_name, layer, table_type, None, None, None, None)

        match = df.filter(
            (df.pipeline_name == pipeline_name) & (df.layer == layer) & (df.table_type == table_type)
        ).collect()

        if not match:
            return WatermarkRecord(pipeline_name, layer, table_type, None, None, None, None)

        row = match[0]
        return WatermarkRecord(
            pipeline_name=row["pipeline_name"],
            layer=row["layer"],
            table_type=row["table_type"],
            last_watermark=row["last_watermark"],
            last_run_id=row["last_run_id"],
            last_dq_status=row["last_dq_status"],
            updated_at=row["updated_at"],
        )

    def get_upstream_dq_status(
        self, upstream_pipeline_name: str, upstream_layer: str, table_type: str
    ) -> str:
        """Convenience wrapper used by a layer's read() to check whether
        its upstream dependency's most recent run passed DQ. Returns
        "NEVER_RUN" if there's no control row yet (distinct from
        "FAILED" — an upstream that has simply never executed is a
        different failure mode than one that ran and failed)."""
        record = self.get_watermark(upstream_pipeline_name, upstream_layer, table_type)
        if record.last_dq_status is None:
            return "NEVER_RUN"
        return record.last_dq_status

    # ------------------------------------------------------------------ #
    # Writes
    # ------------------------------------------------------------------ #
    def advance_watermark(
        self,
        pipeline_name: str,
        layer: str,
        table_type: str,
        new_watermark: str,
        run_id: str,
        dq_status: str,
        monotonic: bool = True,
    ) -> None:
        """
        Upserts the control row for (pipeline_name, layer, table_type).
        Called by BaseTransformation.run() ONLY after write() succeeds —
        the watermark and DQ status move together, on a completed run. A
        failed run (exception before this point) leaves the watermark
        exactly where it was, so the next run will correctly re-attempt
        the same un-advanced range.

        dq_status should be "PASSED" or "FAILED" — even a HIGH-severity
        DQ failure that quarantines rows but still completes the write
        records "FAILED" here, which is what makes the downstream gate
        in get_upstream_dq_status() meaningful.

        monotonic (default True) prevents the watermark from ever moving
        *backward*. This matters for restatement: restating a historical
        date that is behind the current watermark (e.g. re-running Jan 5
        when the incremental frontier is already at Jan 20) must not
        regress the watermark to Jan 5 — doing so would make the next
        scheduled run re-read Jan 6-20 as if they were new, double
        counting already-processed data downstream. When `new_watermark`
        is not strictly greater than the existing value, the watermark
        and dq_status columns are left untouched; only last_run_id is
        still worth knowing, so callers needing that detail should consult
        pipeline_execution_log instead, which is unconditionally per-run.
        Pass monotonic=False only for explicit operator-driven resets
        (see reset_watermark below).
        """
        if monotonic:
            existing = self.get_watermark(pipeline_name, layer, table_type)
            if existing.last_watermark is not None and str(new_watermark) <= str(existing.last_watermark):
                return  # restating a date at/behind the frontier — leave the frontier alone

        new_row = self.spark.createDataFrame(
            [
                WatermarkRecord(
                    pipeline_name=pipeline_name,
                    layer=layer,
                    table_type=table_type,
                    last_watermark=new_watermark,
                    last_run_id=run_id,
                    last_dq_status=dq_status,
                    updated_at=datetime.now(timezone.utc),
                ).to_row_dict()
            ],
            schema=_WATERMARK_SCHEMA,
        )

        if not self._table_exists():
            new_row.write.format("delta").mode("overwrite").save(self.path)
            return

        from delta.tables import DeltaTable

        delta_table = DeltaTable.forPath(self.spark, self.path)
        (
            delta_table.alias("target")
            .merge(
                new_row.alias("source"),
                "target.pipeline_name = source.pipeline_name "
                "AND target.layer = source.layer "
                "AND target.table_type = source.table_type",
            )
            .whenMatchedUpdateAll()
            .whenNotMatchedInsertAll()
            .execute()
        )

    def reset_watermark(
        self, pipeline_name: str, layer: str, table_type: str, watermark_value: Optional[str] = None
    ) -> None:
        """
        Explicitly resets (or clears) a watermark — used by operators
        recovering from a bad deployment who need to deliberately rewind
        processing, or to intentionally widen the incremental frontier
        backward after discovering a systemic upstream issue. Always
        bypasses the monotonic guard (monotonic=False) since "reset" by
        definition means moving to an arbitrary value, including backward.
        """
        self.advance_watermark(
            pipeline_name=pipeline_name,
            layer=layer,
            table_type=table_type,
            new_watermark=watermark_value,
            run_id="manual_reset",
            dq_status="RESET",
            monotonic=False,
        )

    # ------------------------------------------------------------------ #
    # Internal helpers
    # ------------------------------------------------------------------ #
    def _table_exists(self) -> bool:
        try:
            from delta.tables import DeltaTable

            DeltaTable.forPath(self.spark, self.path)
            return True
        except Exception:
            return False

    def _read_control_table(self):
        if not self._table_exists():
            return None
        return self.spark.read.format("delta").load(self.path)
