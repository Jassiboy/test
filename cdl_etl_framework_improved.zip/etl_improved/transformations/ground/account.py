"""
transformations/ground/account.py
====================================
Account layer transformation for the GROUND opco.

Convention used by 03_transformation.py:
    fn(spark, source_tables: list[str], load_mnth: str) -> DataFrame

Each function name must match the load_process value in cdl_table_config.
"""

from __future__ import annotations

from pyspark.sql import DataFrame, SparkSession


# ---------------------------------------------------------------------------
# load_fxg_acct_bill_mth_hist  — standard (non-SP) account monthly history
# ---------------------------------------------------------------------------
def load_fxg_acct_bill_mth_hist(
    spark:         SparkSession,
    source_tables: list[str],
    load_mnth:     str,
) -> DataFrame:
    """
    Reads FXG account billing monthly history for non-SP service categories,
    joins SE and CE segment mapping tables, and returns the enriched DataFrame.

    source_tables[0] : FXG_ACCT_BILL_MTH_HIST
    source_tables[1] : CUST_SE_SEG_MAP
    source_tables[2] : CUST_CE_SEG_MAP
    source_tables[3] : CDL_MTR_GROUP_DEFINITION   (optional; LEFT JOIN)
    """
    if len(source_tables) < 3:
        raise ValueError(
            "load_fxg_acct_bill_mth_hist requires at least 3 source tables: "
            "base_history, se_seg_map, ce_seg_map"
        )

    base_tbl   = source_tables[0]
    se_map_tbl = source_tables[1]
    ce_map_tbl = source_tables[2]
    mtr_tbl    = source_tables[3] if len(source_tables) > 3 else None
    mtr_join   = (
        f"LEFT OUTER JOIN {mtr_tbl} mtr ON ship.SW_PGM = mtr.SW_PGM"
        if mtr_tbl else ""
    )

    query = f"""
        SELECT
            ratemnth, shipmnth, dlvrmnth,
            ses.glbl_enti_nbr  AS se_shpr_glbl_enti_nbr,
            ses.ctry_enti_nbr  AS se_shpr_ctry_enti_nbr,
            ses.fac_enti_nbr   AS se_shpr_fac_enti_nbr,
            ses.ctry_seg_cd    AS se_shpr_sls_seg_cd,
            ses.sub_industry_cd AS se_shpr_sub_industry_cd,
            sep.glbl_enti_nbr  AS se_payr_glbl_enti_nbr,
            sep.ctry_enti_nbr  AS se_payr_ctry_enti_nbr,
            sep.fac_enti_nbr   AS se_payr_fac_enti_nbr,
            sep.ctry_seg_cd    AS se_payr_sls_seg_cd,
            sep.sub_industry_cd AS se_payr_sub_industry_cd,
            cep.glbl_enti_nbr  AS ce_payr_glbl_enti_nbr,
            cep.ctry_enti_nbr  AS ce_payr_ctry_enti_nbr,
            cep.fac_enti_nbr   AS ce_payr_fac_enti_nbr,
            cep.seg_cd         AS ce_payr_sls_seg_cd,
            svc_cat_cd, product,
            orig_ctry_cd, orig_st_cd, orig_msa,
            dest_ctry_cd, dest_st_cd, dest_msa,
            zone_cd, wgtcat, rsd_flg, lrnn_flg,
            CASE
                WHEN (ses.ec_flg = 'Y' OR sep.ec_flg = 'Y') AND rsd_flg = 'Y'
                 AND NOT (svc_cat_cd = '09'
                      OR  (svc_cat_cd = 'SP' AND product IN ('918','919')))
                THEN 'Y'
                ELSE 'N'
            END AS ec_flg,
            dim_avail_flg, revmnth, autogrp, orig_cbsa, dest_cbsa,
            SUM(packages)       AS packages,
            SUM(netrev)         AS netrev,
            SUM(fgtchrg)        AS fgtchrg,
            SUM(discount)       AS discount,
            SUM(fuelsch)        AS fuelsch,
            SUM(totalsch)       AS totalsch,
            SUM(apounds)        AS apounds,
            SUM(rpounds)        AS rpounds,
            SUM(pkg_cubic_size) AS pkg_cubic_size,
            SUM(adh_amt)        AS adh_amt,
            SUM(das_amt)        AS das_amt,
            SUM(oth_amt)        AS oth_amt,
            SUM(ovs_amt)        AS ovs_amt,
            SUM(dlg_amt)        AS dlg_amt,
            SUM(dresi_amt)      AS dresi_amt,
            SUM(resi_amt)       AS resi_amt,
            SUM(adh_qty)        AS adh_qty,
            SUM(das_qty)        AS das_qty,
            SUM(oth_qty)        AS oth_qty,
            SUM(ovs_qty)        AS ovs_qty,
            SUM(dlg_qty)        AS dlg_qty,
            SUM(dresi_qty)      AS dresi_qty,
            SUM(resi_qty)       AS resi_qty
        FROM {base_tbl} ship
        LEFT OUTER JOIN (
            SELECT * FROM {se_map_tbl} WHERE assoc_company_cd = 'FXG'
        ) ses ON ship.shpr_ean = ses.ent_acct_nbr
        LEFT OUTER JOIN (
            SELECT * FROM {se_map_tbl} WHERE assoc_company_cd = 'FXG'
        ) sep ON ship.payr_ean = sep.ent_acct_nbr
        LEFT OUTER JOIN {ce_map_tbl} cep ON ship.payr_ean = cep.ent_acct_nbr
        {mtr_join}
        WHERE ship.ratemnth = '{load_mnth}'
          AND ship.svc_cat_cd <> 'SP'
        GROUP BY
            ratemnth, shipmnth, dlvrmnth,
            se_shpr_glbl_enti_nbr, se_shpr_ctry_enti_nbr, se_shpr_fac_enti_nbr,
            se_shpr_sls_seg_cd, se_shpr_sub_industry_cd,
            se_payr_glbl_enti_nbr, se_payr_ctry_enti_nbr, se_payr_fac_enti_nbr,
            se_payr_sls_seg_cd, se_payr_sub_industry_cd,
            ce_payr_glbl_enti_nbr, ce_payr_ctry_enti_nbr, ce_payr_fac_enti_nbr,
            ce_payr_sls_seg_cd,
            svc_cat_cd, product,
            orig_ctry_cd, orig_st_cd, orig_msa,
            dest_ctry_cd, dest_st_cd, dest_msa,
            zone_cd, wgtcat, rsd_flg, lrnn_flg, ec_flg,
            dim_avail_flg, revmnth, autogrp, orig_cbsa, dest_cbsa
    """
    return spark.sql(query)


# ---------------------------------------------------------------------------
# load_fxg_acct_bill_mth_hist_sp  — SP (SmartPost) variant
# ---------------------------------------------------------------------------
def load_fxg_acct_bill_mth_hist_sp(
    spark:         SparkSession,
    source_tables: list[str],
    load_mnth:     str,
) -> DataFrame:
    """
    Same as load_fxg_acct_bill_mth_hist but for svc_cat_cd = 'SP'.
    Uses BROADCAST hint on segment maps (typically small dimension tables).

    source_tables: same order as non-SP variant.
    """
    if len(source_tables) < 3:
        raise ValueError(
            "load_fxg_acct_bill_mth_hist_sp requires at least 3 source tables."
        )

    base_tbl   = source_tables[0]
    se_map_tbl = source_tables[1]
    ce_map_tbl = source_tables[2]
    mtr_tbl    = source_tables[3] if len(source_tables) > 3 else None
    mtr_join   = (
        f"LEFT OUTER JOIN {mtr_tbl} mtr ON ship.SW_PGM = mtr.SW_PGM"
        if mtr_tbl else ""
    )

    query = f"""
        SELECT
            ratemnth, shipmnth, dlvrmnth,
            ses.glbl_enti_nbr  AS se_shpr_glbl_enti_nbr,
            ses.ctry_enti_nbr  AS se_shpr_ctry_enti_nbr,
            ses.fac_enti_nbr   AS se_shpr_fac_enti_nbr,
            ses.ctry_seg_cd    AS se_shpr_sls_seg_cd,
            ses.sub_industry_cd AS se_shpr_sub_industry_cd,
            sep.glbl_enti_nbr  AS se_payr_glbl_enti_nbr,
            sep.ctry_enti_nbr  AS se_payr_ctry_enti_nbr,
            sep.fac_enti_nbr   AS se_payr_fac_enti_nbr,
            sep.ctry_seg_cd    AS se_payr_sls_seg_cd,
            sep.sub_industry_cd AS se_payr_sub_industry_cd,
            cep.glbl_enti_nbr  AS ce_payr_glbl_enti_nbr,
            cep.ctry_enti_nbr  AS ce_payr_ctry_enti_nbr,
            cep.fac_enti_nbr   AS ce_payr_fac_enti_nbr,
            cep.seg_cd         AS ce_payr_sls_seg_cd,
            svc_cat_cd, product,
            orig_ctry_cd, orig_st_cd, orig_msa,
            dest_ctry_cd, dest_st_cd, dest_msa,
            zone_cd, wgtcat, rsd_flg, lrnn_flg, dim_avail_flg, autogrp,
            orig_cbsa, dest_cbsa,
            CASE
                WHEN (ses.ec_flg = 'Y' OR sep.ec_flg = 'Y')
                 AND product NOT IN ('918','919')
                THEN 'Y'
                ELSE 'N'
            END AS ec_flg,
            SUM(packages)       AS packages,
            SUM(netrev)         AS netrev,
            SUM(fgtchrg)        AS fgtchrg,
            SUM(discount)       AS discount,
            SUM(fuelsch)        AS fuelsch,
            SUM(totalsch)       AS totalsch,
            SUM(apounds)        AS apounds,
            SUM(rpounds)        AS rpounds,
            SUM(pkg_cubic_size) AS pkg_cubic_size,
            SUM(adh_amt)        AS adh_amt,
            SUM(das_amt)        AS das_amt,
            SUM(oth_amt)        AS oth_amt,
            SUM(ovs_amt)        AS ovs_amt,
            SUM(dlg_amt)        AS dlg_amt,
            SUM(dresi_amt)      AS dresi_amt,
            SUM(resi_amt)       AS resi_amt,
            SUM(adh_qty)        AS adh_qty,
            SUM(das_qty)        AS das_qty,
            SUM(oth_qty)        AS oth_qty,
            SUM(ovs_qty)        AS ovs_qty,
            SUM(dlg_qty)        AS dlg_qty,
            SUM(dresi_qty)      AS dresi_qty,
            SUM(resi_qty)       AS resi_qty
        FROM {base_tbl} ship
        LEFT OUTER JOIN /*+ BROADCAST(ses) */ (
            SELECT * FROM {se_map_tbl} WHERE assoc_company_cd = 'FXG'
        ) ses ON ship.shpr_ean = ses.ent_acct_nbr
        LEFT OUTER JOIN /*+ BROADCAST(sep) */ (
            SELECT * FROM {se_map_tbl} WHERE assoc_company_cd = 'FXG'
        ) sep ON ship.payr_ean = sep.ent_acct_nbr
        LEFT OUTER JOIN /*+ BROADCAST(cep) */ {ce_map_tbl} cep
            ON ship.payr_ean = cep.ent_acct_nbr
        {mtr_join}
        WHERE ship.ratemnth = '{load_mnth}'
          AND ship.svc_cat_cd = 'SP'
        GROUP BY
            ratemnth, shipmnth, dlvrmnth,
            se_shpr_glbl_enti_nbr, se_shpr_ctry_enti_nbr, se_shpr_fac_enti_nbr,
            se_shpr_sls_seg_cd, se_shpr_sub_industry_cd,
            se_payr_glbl_enti_nbr, se_payr_ctry_enti_nbr, se_payr_fac_enti_nbr,
            se_payr_sls_seg_cd, se_payr_sub_industry_cd,
            ce_payr_glbl_enti_nbr, ce_payr_ctry_enti_nbr, ce_payr_fac_enti_nbr,
            ce_payr_sls_seg_cd,
            svc_cat_cd, product,
            orig_ctry_cd, orig_st_cd, orig_msa,
            dest_ctry_cd, dest_st_cd, dest_msa,
            zone_cd, wgtcat, rsd_flg, lrnn_flg, ec_flg,
            dim_avail_flg, autogrp, orig_cbsa, dest_cbsa
    """
    return spark.sql(query)
