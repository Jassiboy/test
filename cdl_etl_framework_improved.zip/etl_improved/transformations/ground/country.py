"""
transformations/ground/country.py
=====================================
Country layer transformation for the GROUND opco.
Reads from Facility layer and rolls up to country-level entity grain.

Convention: fn(spark, source_tables: list[str], load_mnth: str) -> DataFrame
"""

from __future__ import annotations

from pyspark.sql import DataFrame, SparkSession


def load_fxg_ctry_enti_bill_mth_hist(
    spark:         SparkSession,
    source_tables: list[str],
    load_mnth:     str,
) -> DataFrame:
    """
    Aggregates facility-level billing monthly history to country-level
    entity billing history for non-SP service categories.

    source_tables[0] : FXG_FAC_ENTI_BILL_MTH_HIST  (facility layer output)
    """
    if not source_tables:
        raise ValueError("load_fxg_ctry_enti_bill_mth_hist requires source_tables[0].")

    src = source_tables[0]

    query = f"""
        SELECT
            ratemnth, shipmnth, dlvrmnth,
            se_shpr_glbl_enti_nbr, se_shpr_ctry_enti_nbr,
            se_shpr_sls_seg_cd, se_shpr_sub_industry_cd,
            se_payr_glbl_enti_nbr, se_payr_ctry_enti_nbr,
            se_payr_sls_seg_cd, se_payr_sub_industry_cd,
            ce_payr_glbl_enti_nbr, ce_payr_ctry_enti_nbr, ce_payr_sls_seg_cd,
            svc_cat_cd, product,
            orig_ctry_cd, orig_st_cd, orig_msa,
            dest_ctry_cd, dest_st_cd, dest_msa,
            zone_cd, wgtcat, rsd_flg, lrnn_flg, ec_flg,
            dim_avail_flg, revmnth, autogrp,
            SUM(packages)       AS packages,
            SUM(netrev)         AS netrev,
            SUM(fgtchrg)        AS fgtchrg,
            SUM(discount)       AS discount,
            SUM(fuelsch)        AS fuelsch,
            SUM(totalsch)       AS totalsch,
            SUM(apounds)        AS apounds,
            SUM(rpounds)        AS rpounds,
            SUM(pkg_cubic_size) AS pkg_cubic_size,
            SUM(adh_amt)        AS adh_amt,
            SUM(das_amt)        AS das_amt,
            SUM(oth_amt)        AS oth_amt,
            SUM(ovs_amt)        AS ovs_amt,
            SUM(dlg_amt)        AS dlg_amt,
            SUM(dresi_amt)      AS dresi_amt,
            SUM(resi_amt)       AS resi_amt,
            SUM(adh_qty)        AS adh_qty,
            SUM(das_qty)        AS das_qty,
            SUM(oth_qty)        AS oth_qty,
            SUM(ovs_qty)        AS ovs_qty,
            SUM(dlg_qty)        AS dlg_qty,
            SUM(dresi_qty)      AS dresi_qty,
            SUM(resi_qty)       AS resi_qty
        FROM {src} ship
        WHERE ship.ratemnth = '{load_mnth}'
          AND ship.svc_cat_cd <> 'SP'
        GROUP BY
            ratemnth, shipmnth, dlvrmnth,
            se_shpr_glbl_enti_nbr, se_shpr_ctry_enti_nbr,
            se_shpr_sls_seg_cd, se_shpr_sub_industry_cd,
            se_payr_glbl_enti_nbr, se_payr_ctry_enti_nbr,
            se_payr_sls_seg_cd, se_payr_sub_industry_cd,
            ce_payr_glbl_enti_nbr, ce_payr_ctry_enti_nbr, ce_payr_sls_seg_cd,
            svc_cat_cd, product,
            orig_ctry_cd, orig_st_cd, orig_msa,
            dest_ctry_cd, dest_st_cd, dest_msa,
            zone_cd, wgtcat, rsd_flg, lrnn_flg, ec_flg,
            dim_avail_flg, revmnth, autogrp
    """
    return spark.sql(query)


def load_fxg_ctry_enti_bill_mth_hist_sp(
    spark:         SparkSession,
    source_tables: list[str],
    load_mnth:     str,
) -> DataFrame:
    """SP variant of country aggregation."""
    if not source_tables:
        raise ValueError("load_fxg_ctry_enti_bill_mth_hist_sp requires source_tables[0].")

    src = source_tables[0]

    query = f"""
        SELECT
            ratemnth, shipmnth, dlvrmnth,
            se_shpr_glbl_enti_nbr, se_shpr_ctry_enti_nbr,
            se_shpr_sls_seg_cd, se_shpr_sub_industry_cd,
            se_payr_glbl_enti_nbr, se_payr_ctry_enti_nbr,
            se_payr_sls_seg_cd, se_payr_sub_industry_cd,
            ce_payr_glbl_enti_nbr, ce_payr_ctry_enti_nbr, ce_payr_sls_seg_cd,
            svc_cat_cd, product,
            orig_ctry_cd, orig_st_cd, orig_msa,
            dest_ctry_cd, dest_st_cd, dest_msa,
            zone_cd, wgtcat, rsd_flg, lrnn_flg, ec_flg,
            dim_avail_flg, autogrp,
            SUM(packages)       AS packages,
            SUM(netrev)         AS netrev,
            SUM(fgtchrg)        AS fgtchrg,
            SUM(discount)       AS discount,
            SUM(fuelsch)        AS fuelsch,
            SUM(totalsch)       AS totalsch,
            SUM(apounds)        AS apounds,
            SUM(rpounds)        AS rpounds,
            SUM(pkg_cubic_size) AS pkg_cubic_size,
            SUM(adh_amt)        AS adh_amt,
            SUM(das_amt)        AS das_amt,
            SUM(oth_amt)        AS oth_amt,
            SUM(ovs_amt)        AS ovs_amt,
            SUM(dlg_amt)        AS dlg_amt,
            SUM(dresi_amt)      AS dresi_amt,
            SUM(resi_amt)       AS resi_amt,
            SUM(adh_qty)        AS adh_qty,
            SUM(das_qty)        AS das_qty,
            SUM(oth_qty)        AS oth_qty,
            SUM(ovs_qty)        AS ovs_qty,
            SUM(dlg_qty)        AS dlg_qty,
            SUM(dresi_qty)      AS dresi_qty,
            SUM(resi_qty)       AS resi_qty
        FROM {src} ship
        WHERE ship.ratemnth = '{load_mnth}'
          AND ship.svc_cat_cd = 'SP'
        GROUP BY
            ratemnth, shipmnth, dlvrmnth,
            se_shpr_glbl_enti_nbr, se_shpr_ctry_enti_nbr,
            se_shpr_sls_seg_cd, se_shpr_sub_industry_cd,
            se_payr_glbl_enti_nbr, se_payr_ctry_enti_nbr,
            se_payr_sls_seg_cd, se_payr_sub_industry_cd,
            ce_payr_glbl_enti_nbr, ce_payr_ctry_enti_nbr, ce_payr_sls_seg_cd,
            svc_cat_cd, product,
            orig_ctry_cd, orig_st_cd, orig_msa,
            dest_ctry_cd, dest_st_cd, dest_msa,
            zone_cd, wgtcat, rsd_flg, lrnn_flg, ec_flg,
            dim_avail_flg, autogrp
    """
    return spark.sql(query)
