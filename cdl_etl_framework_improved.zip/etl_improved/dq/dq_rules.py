"""
dq/dq_rules.py
===============
One function per dq_rule name referenced in cdl_table_config.data_quality_rules.

CONTRACT every rule function must follow:
    fn(spark, stage_table: str, source_table: str, opco: str, load_mnth: str) -> float

Returns diff_pct (0.0 = identical / perfect). The DQEngine compares this
to error_threshold_pct from the rule config — the function only measures,
it never decides pass/fail.

Return 0.0 if both stage and source are empty (not a failure — nothing to compare).
Return 100.0 if source has data but stage has none.

Adding a new rule:
  1. Define a function here with the matching name.
  2. Add the rule to cdl_table_config.data_quality_rules for the relevant table.
  No framework changes needed.
"""

from __future__ import annotations

from pyspark.sql import SparkSession


# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------
def _scalar(spark: SparkSession, sql: str):
    """Execute a scalar SQL expression and return the single result value."""
    rows = spark.sql(sql).collect()
    return rows[0][0] if rows else None


def _pct_diff(expected, actual) -> float:
    """
    Percentage difference between expected (source) and actual (stage).
    Returns 0.0 when both are zero or None (nothing to compare).
    Returns 100.0 when expected > 0 but actual is 0 or None.
    """
    if expected in (None, 0):
        return 0.0 if actual in (None, 0) else 100.0
    return abs(float(expected) - float(actual)) / float(expected) * 100.0


def _scope(opco: str, load_mnth: str, mnth_col: str = "ratemnth") -> str:
    """Build a standard WHERE clause for opco + month filters."""
    parts = []
    if opco:
        parts.append(f"opco = '{opco}'")
    if load_mnth:
        parts.append(f"{mnth_col} = '{load_mnth}'")
    return " AND ".join(parts) if parts else "1=1"


# ---------------------------------------------------------------------------
# Rule: row count comparison
# ---------------------------------------------------------------------------
def dq_row_count(
    spark:        SparkSession,
    stage_table:  str,
    source_table: str,
    opco:         str,
    load_mnth:    str,
) -> float:
    """
    Compare record counts between stage and source for (opco, load_mnth).
    Returns the percentage difference.  0.0 = identical counts.
    """
    where       = _scope(opco, load_mnth)
    stage_cnt   = _scalar(spark, f"SELECT COUNT(*) FROM {stage_table}  WHERE {where}") or 0
    source_cnt  = _scalar(spark, f"SELECT COUNT(*) FROM {source_table} WHERE {where}") or 0
    return _pct_diff(source_cnt, stage_cnt)


# ---------------------------------------------------------------------------
# Rule: net revenue sum comparison
# ---------------------------------------------------------------------------
def dq_net_rev(
    spark:        SparkSession,
    stage_table:  str,
    source_table: str,
    opco:         str,
    load_mnth:    str,
) -> float:
    """
    Compare SUM(netrev) between stage and source.
    Returns percentage difference.
    """
    where      = _scope(opco, load_mnth)
    stage_rev  = _scalar(spark, f"SELECT SUM(netrev) FROM {stage_table}  WHERE {where}") or 0
    source_rev = _scalar(spark, f"SELECT SUM(netrev) FROM {source_table} WHERE {where}") or 0
    return _pct_diff(source_rev, stage_rev)


# ---------------------------------------------------------------------------
# Rule: weight comparison
# ---------------------------------------------------------------------------
def dq_weight(
    spark:        SparkSession,
    stage_table:  str,
    source_table: str,
    opco:         str,
    load_mnth:    str,
) -> float:
    """
    Compare SUM(apounds) between stage and source.
    """
    where         = _scope(opco, load_mnth)
    stage_wt      = _scalar(spark, f"SELECT SUM(apounds) FROM {stage_table}  WHERE {where}") or 0
    source_wt     = _scalar(spark, f"SELECT SUM(apounds) FROM {source_table} WHERE {where}") or 0
    return _pct_diff(source_wt, stage_wt)


# ---------------------------------------------------------------------------
# Rule: package count comparison
# ---------------------------------------------------------------------------
def dq_packages(
    spark:        SparkSession,
    stage_table:  str,
    source_table: str,
    opco:         str,
    load_mnth:    str,
) -> float:
    """
    Compare SUM(packages) between stage and source.
    """
    where      = _scope(opco, load_mnth)
    stage_pkg  = _scalar(spark, f"SELECT SUM(packages) FROM {stage_table}  WHERE {where}") or 0
    source_pkg = _scalar(spark, f"SELECT SUM(packages) FROM {source_table} WHERE {where}") or 0
    return _pct_diff(source_pkg, stage_pkg)


# ---------------------------------------------------------------------------
# Rule: null check on a key column
# ---------------------------------------------------------------------------
def dq_null_key(
    spark:        SparkSession,
    stage_table:  str,
    source_table: str,
    opco:         str,
    load_mnth:    str,
    key_col:      str = "se_payr_glbl_enti_nbr",
) -> float:
    """
    Check percentage of null values in a key column in stage.
    Returns null_pct (0.0 = no nulls).
    Note: source_table is unused here — this is a stage-only check.
    """
    where     = _scope(opco, load_mnth)
    total     = _scalar(spark, f"SELECT COUNT(*)              FROM {stage_table} WHERE {where}") or 0
    null_cnt  = _scalar(spark, f"SELECT COUNT(*) FROM {stage_table} WHERE {where} AND {key_col} IS NULL") or 0
    if total == 0:
        return 0.0
    return (null_cnt / total) * 100.0


# ---------------------------------------------------------------------------
# Rule: distinct entity count comparison
# ---------------------------------------------------------------------------
def dq_distinct_entities(
    spark:        SparkSession,
    stage_table:  str,
    source_table: str,
    opco:         str,
    load_mnth:    str,
    entity_col:   str = "se_payr_glbl_enti_nbr",
) -> float:
    """
    Compare COUNT(DISTINCT entity_col) between stage and source.
    Large differences suggest join/filter issues in the transformation.
    """
    where      = _scope(opco, load_mnth)
    stage_ct   = _scalar(spark, f"SELECT COUNT(DISTINCT {entity_col}) FROM {stage_table}  WHERE {where}") or 0
    source_ct  = _scalar(spark, f"SELECT COUNT(DISTINCT {entity_col}) FROM {source_table} WHERE {where}") or 0
    return _pct_diff(source_ct, stage_ct)


# ---------------------------------------------------------------------------
# Rule: duplicate row check
# ---------------------------------------------------------------------------
def dq_no_duplicates(
    spark:        SparkSession,
    stage_table:  str,
    source_table: str,
    opco:         str,
    load_mnth:    str,
    key_cols:     str = "ratemnth,se_payr_glbl_enti_nbr,svc_cat_cd",
) -> float:
    """
    Check whether stage contains any duplicate rows on key_cols.
    Returns the duplicate percentage (0.0 = no duplicates).
    source_table is unused — this is a stage-only integrity check.
    """
    where = _scope(opco, load_mnth)
    cols  = ", ".join(c.strip() for c in key_cols.split(","))
    total = _scalar(spark, f"SELECT COUNT(*) FROM {stage_table} WHERE {where}") or 0
    if total == 0:
        return 0.0
    distinct = _scalar(spark, f"SELECT COUNT(*) FROM (SELECT DISTINCT {cols} FROM {stage_table} WHERE {where})") or 0
    return _pct_diff(total, distinct)   # 0 if total == distinct


# ---------------------------------------------------------------------------
# Rule: fuel surcharge comparison
# ---------------------------------------------------------------------------
def dq_fuel_surcharge(
    spark:        SparkSession,
    stage_table:  str,
    source_table: str,
    opco:         str,
    load_mnth:    str,
) -> float:
    """Compare SUM(fuelsch) between stage and source."""
    where     = _scope(opco, load_mnth)
    stage_fs  = _scalar(spark, f"SELECT SUM(fuelsch) FROM {stage_table}  WHERE {where}") or 0
    source_fs = _scalar(spark, f"SELECT SUM(fuelsch) FROM {source_table} WHERE {where}") or 0
    return _pct_diff(source_fs, stage_fs)


# ---------------------------------------------------------------------------
# Rule: discount amount comparison
# ---------------------------------------------------------------------------
def dq_discount(
    spark:        SparkSession,
    stage_table:  str,
    source_table: str,
    opco:         str,
    load_mnth:    str,
) -> float:
    """Compare SUM(discount) between stage and source."""
    where      = _scope(opco, load_mnth)
    stage_dis  = _scalar(spark, f"SELECT SUM(discount) FROM {stage_table}  WHERE {where}") or 0
    source_dis = _scalar(spark, f"SELECT SUM(discount) FROM {source_table} WHERE {where}") or 0
    return _pct_diff(source_dis, stage_dis)
