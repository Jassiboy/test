"""
notebooks/04_main_core.py
===========================
Master orchestration entry point for the CDL ETL framework.

Flow:
    main()
      └── for each opco in distinct opcos from configs
            run_opco()
              └── resolve_groups()  — groups table_ids by (opco, layer)
                    run_layer()     — stages + ingests all months for one (opco, layer)
                      for each cfg:
                        for each attempt (retry loop):
                          1. stage every month into temp table
                          2. run_ingestion() per month  (DQ + promote, always loads)
                        log_end_success / log_end_failure

Key design choices:
  - retry_max_attempts and backoff come from cfg, not hardcoded here.
  - Already-staged months are tracked in `staged_months` so retries
    do not re-run the (potentially expensive) transformation.
  - Already-ingested months are tracked in `ingested_months` so a
    retry after partial success only processes the months that failed.
  - DQ failure is NON-BLOCKING — data always loads; DQ result is logged.
  - run_opco() returns a result dict consumed by print_summary().
  - All exceptions are caught; the framework moves to the next table
    rather than crashing the whole batch.
"""

from __future__ import annotations

import json
import math
import os
import sys
import time
import traceback
import uuid
from collections import defaultdict
from datetime import date, datetime, timezone
from typing import Optional

from dateutil.relativedelta import relativedelta
from pyspark.sql import SparkSession

# ---------------------------------------------------------------------------
# Imports from framework modules
# ---------------------------------------------------------------------------
import importlib
import importlib.util

def _load_module(name: str, path: str):
    spec   = importlib.util.spec_from_file_location(name, path)
    mod    = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod

_BASE = os.path.dirname(os.path.abspath(__file__))

_core   = _load_module("_01_framework_core",  os.path.join(_BASE, "01_framework_core.py"))
_ingest = _load_module("_02_ingestion",       os.path.join(_BASE, "02_ingestion.py"))
_trans  = _load_module("_03_transformation",  os.path.join(_BASE, "03_transformation.py"))

# Expose names used in this module
log                = _core.log
read_table_configs = _core.read_table_configs
check_dq_gate      = _core.check_dq_gate
RunLogger          = _core.RunLogger
TableConfig        = _core.TableConfig

run_ingestion      = _ingest.run_ingestion
reset_stage        = _ingest.reset_stage
get_transformed_df = _trans.get_transformed_df

# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------
sys.path.insert(0, os.path.join(_BASE, ".."))
from config.env_config import PIPELINE_CONFIG, get_data_db, get_metadata_db

DATA_DB     = get_data_db()
METADATA_DB = get_metadata_db()
LAYER_ORDER = PIPELINE_CONFIG.layer_order   # ["ACCOUNT","FACILITY","COUNTRY","GLOBAL"]
CONFIG_PATH = os.path.join(_BASE, "../config/run_config.json")


# ---------------------------------------------------------------------------
# Month window helpers
# ---------------------------------------------------------------------------
def month_chunks(start_yyyymm: int, end_yyyymm: int) -> list[str]:
    """
    Return list of YYYYMM strings from start to end inclusive.
    Accepts either int (202501) or str ("202501") inputs.
    """
    start_yyyymm = int(start_yyyymm)
    end_yyyymm   = int(end_yyyymm)
    chunks = []
    y, m   = divmod(start_yyyymm, 100)
    ey, em = divmod(end_yyyymm,   100)
    while (y, m) <= (ey, em):
        chunks.append(f"{y:04d}{m:02d}")
        m += 1
        if m > 12:
            m  = 1
            y += 1
    return chunks


def resolve_windows(cfg: TableConfig, run_date: date,
                    start_date: Optional[str],
                    end_date:   Optional[str]) -> list[str]:
    """
    Determine which YYYYMM windows to process for a given config.

    Backfill:    start_date and end_date are supplied → enumerate months.
    Incremental: start_date is None.
                 If today ≤ incremental_cutoff_day, process prev + current month.
                 Otherwise, process current month only.
    """
    if start_date and end_date:
        return month_chunks(int(start_date), int(end_date))

    # Incremental
    current = run_date.strftime("%Y%m")
    if run_date.day <= cfg.incremental_cutoff_day:
        prev = (run_date - relativedelta(months=1)).strftime("%Y%m")
        return [prev, current]
    return [current]


def _backoff_wait(attempt: int, cfg: TableConfig) -> float:
    """Compute exponential backoff wait seconds, capped at cfg.retry_max_wait_sec."""
    wait = cfg.retry_initial_wait_sec * (cfg.retry_backoff_multiplier ** (attempt - 1))
    return min(wait, cfg.retry_max_wait_sec)


# ---------------------------------------------------------------------------
# Layer runner
# ---------------------------------------------------------------------------
def run_layer(
    run_batch_id: str,
    opco:         str,
    layer:        str,
    table_ids:    list[str],
    run_date:     date,
    start_date:   Optional[str] = None,
    end_date:     Optional[str] = None,
) -> bool:
    """
    Process all tables for one (opco, layer) in the correct order.

    For each table:
      - Stage all months (skipping already-staged months on retry).
      - run_ingestion() per month (DQ + promote; always loads data).
      - Log one row per attempt covering the full window.
      - Retry only on unhandled exceptions; DQ failure is not retried.

    Returns True if all tables completed without unhandled exceptions.
    """
    configs = read_table_configs(table_id=table_ids, schedule_group=None)
    if not configs:
        log("WARN", "No active configs found", layer=layer, opco=opco)
        return True   # nothing to do is not a failure

    all_ok = True
    log("INFO", "═" * 60, layer=layer, opco=opco)

    for cfg in configs:
        windows = resolve_windows(cfg, run_date, start_date, end_date)
        if not windows:
            log("WARN", f"No months to process", table_id=cfg.table_id)
            continue

        stage_table     = f"{DATA_DB}.{cfg.target_table}_temp"
        staged_months   = set()   # months successfully written to stage
        ingested_months = set()   # months successfully promoted to target

        log("INFO", f"Processing {cfg.table_id} | windows={windows}",
            stage=stage_table, attempts=cfg.retry_max_attempts)

        for attempt in range(1, cfg.retry_max_attempts + 1):
            logger = RunLogger(
                run_batch_id    = run_batch_id,
                cfg             = cfg,
                opco            = opco,
                load_mnth_start = windows[0],
                load_mnth_end   = windows[-1],
                attempt         = attempt,
            )
            started_at      = logger.start()
            month_summaries = []
            total_written   = 0

            try:
                # ── Stage: only months not yet staged ─────────────────────
                if attempt == 1:
                    reset_stage(stage_table)

                for mnth in windows:
                    if mnth in staged_months:
                        log("INFO", f"Skip stage (already done): {mnth}",
                            table_id=cfg.table_id)
                        continue
                    tdf = get_transformed_df(
                        opco          = opco,
                        layer         = layer,
                        target_table  = cfg.target_table,
                        source_tables = cfg.source_table,
                        load_process  = cfg.load_process,
                        load_mnth     = mnth,
                    )
                    tdf.write.format("delta").mode("append").saveAsTable(stage_table)
                    staged_months.add(mnth)
                    log("INFO", f"Staged {mnth}", table_id=cfg.table_id)

                # ── Ingest: only months not yet promoted ──────────────────
                for mnth in windows:
                    if mnth in ingested_months:
                        log("INFO", f"Skip ingest (already done): {mnth}",
                            table_id=cfg.table_id)
                        continue
                    summary = run_ingestion(
                        run_batch_id = run_batch_id,
                        cfg          = cfg,
                        opco         = opco,
                        load_mnth    = mnth,
                        stage_table  = stage_table,
                    )
                    month_summaries.append(summary)
                    total_written += summary.get("rows_written", 0)
                    # Track promoted months even on DQ failure
                    # (data is always loaded; only DQ status differs)
                    if summary.get("loaded"):
                        ingested_months.add(mnth)

                # ── Log success for this attempt ──────────────────────────
                logger.end_success(
                    rows_read       = total_written,
                    rows_written    = total_written,
                    month_summaries = month_summaries,
                )
                log("INFO",
                    f"{cfg.table_id}: attempt {attempt} complete. "
                    f"Loaded {len(ingested_months)}/{len(windows)} months.",
                    total_rows=total_written)
                break   # success — exit retry loop

            except Exception as exc:
                tb       = traceback.format_exc()
                msg      = f"{type(exc).__name__}: {exc}"
                is_final = (attempt == cfg.retry_max_attempts)

                log("ERROR", f"Attempt {attempt}/{cfg.retry_max_attempts} failed: {msg}",
                    table_id=cfg.table_id)

                logger.end_failure(
                    error_code      = type(exc).__name__,
                    error_message   = f"{msg}\n{tb}",
                    is_final        = is_final,
                    month_summaries = month_summaries or None,
                )

                if is_final:
                    log("ERROR",
                        f"{cfg.table_id} exhausted all {cfg.retry_max_attempts} attempts.",
                        table_id=cfg.table_id)
                    all_ok = False
                    break

                wait = _backoff_wait(attempt, cfg)
                log("INFO", f"Retrying in {wait:.0f}s …", attempt=attempt)
                time.sleep(wait)

    return all_ok


# ---------------------------------------------------------------------------
# Group resolver — (opco, layer) → [table_ids]
# ---------------------------------------------------------------------------
def resolve_groups(
    opco:      str,
    table_ids: list[str],
) -> list[tuple[str, str, list[str]]]:
    """
    Return list of (opco, layer, [table_ids]) sorted by LAYER_ORDER.
    Preserves the original table_id order within each group.
    """
    configs = read_table_configs(table_id=table_ids, schedule_group=None)
    if not configs:
        return []

    id_order = {tid: i for i, tid in enumerate(table_ids)}
    configs.sort(key=lambda c: id_order.get(c.table_id, 9999))

    grouped: dict[tuple[str, str], list[str]] = defaultdict(list)
    for cfg in configs:
        key = (cfg.opco, cfg.target_dataset_layer)
        grouped[key].append(cfg.table_id)

    layer_rank = {lyr: i for i, lyr in enumerate(LAYER_ORDER)}
    return sorted(
        [(opco, layer, ids) for (opco, layer), ids in grouped.items()],
        key=lambda g: layer_rank.get(g[1], 99),
    )


# ---------------------------------------------------------------------------
# OPCO runner
# ---------------------------------------------------------------------------
def run_opco(
    batch_run_id: str,
    opco:         str,
    table_ids:    list[str],
    start_date:   Optional[str] = None,
    end_date:     Optional[str] = None,
) -> dict:
    """
    Run all (opco, layer) groups for this opco in layer-dependency order.
    Returns a result dict for print_summary().
    """
    run_date = date.today()
    groups   = resolve_groups(opco, table_ids)

    if not groups:
        log("WARN", "No matching tables", opco=opco)
        return {"opco": opco, "ok": False, "layers": []}

    overall_ok   = True
    layer_results = []

    for i, (g_opco, g_layer, g_table_ids) in enumerate(groups):
        log("INFO", "─" * 50,
            opco=g_opco, layer=g_layer, tables=g_table_ids)

        ok = run_layer(
            run_batch_id = batch_run_id,
            opco         = g_opco,
            layer        = g_layer,
            table_ids    = g_table_ids,
            run_date     = run_date,
            start_date   = start_date,
            end_date     = end_date,
        )
        overall_ok = overall_ok and ok
        layer_results.append({"layer": g_layer, "ok": ok})

    return {
        "opco":   opco,
        "ok":     overall_ok,
        "layers": layer_results,
    }


# ---------------------------------------------------------------------------
# Widget / config reader
# ---------------------------------------------------------------------------
def _params_from_widgets(dbutils) -> Optional[dict]:
    """
    Read run parameters from Databricks widgets.
    Returns None when no widgets are set → caller falls back to run_config.json.
    """
    try:
        for name, default in [
            ("table_id",       ""),
            ("schedule_group", ""),
            ("start_month",    ""),
            ("end_month",      ""),
        ]:
            dbutils.widgets.text(name, default)

        table_id       = [t.strip() for t in dbutils.widgets.get("table_id").split(",") if t.strip()]
        schedule_group = dbutils.widgets.get("schedule_group").strip() or None

        if not table_id and not schedule_group:
            return None

        start_month = dbutils.widgets.get("start_month").strip() or None
        end_month   = dbutils.widgets.get("end_month").strip()   or None

        return {
            "table_id":       table_id,
            "schedule_group": schedule_group,
            "start_date":     start_month,
            "end_date":       end_month,
        }
    except Exception as exc:
        log("WARN", f"Widgets unavailable, falling back to run_config.json: {exc}")
        return None


# ---------------------------------------------------------------------------
# Summary printer
# ---------------------------------------------------------------------------
def print_summary(results: list[dict], started: datetime) -> None:
    elapsed = (datetime.now(timezone.utc) - started).total_seconds()
    total   = len(results)
    passed  = sum(1 for r in results if r.get("ok"))

    log("INFO", "╔" + "═" * 62 + "╗")
    log("INFO", "║          CDL ETL — GRAND SUMMARY" + " " * 29 + "║")
    log("INFO", f"║  Runs: {total}   Pass: {passed}   Fail: {total - passed}"
                f"   Elapsed: {elapsed:.0f}s" + " " * 20 + "║")
    log("INFO", "╠" + "═" * 62 + "╣")
    for r in results:
        icon = "✓" if r.get("ok") else "✗"
        for lr in r.get("layers", []):
            licon = "✓" if lr["ok"] else "✗"
            log("INFO", f"║  {r['opco']:<12}  {lr['layer']:<12}  {licon}  "
                        + " " * 30 + "║")
    log("INFO", "╚" + "═" * 62 + "╝")


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------
def main() -> bool:
    started  = datetime.now(timezone.utc)
    dbutils  = globals().get("dbutils")
    params   = _params_from_widgets(dbutils) if dbutils else None

    if params:
        log("INFO", "Parameters from widgets")
    else:
        log("INFO", "No widgets — reading config/run_config.json")
        with open(CONFIG_PATH) as f:
            file_cfg = json.load(f)
        params = file_cfg.get("runs", [{}])[0]

    # Build batch run ID: BATCH_YYYYMMDD_HHMMSS_XXXXXX_ENV
    ts             = datetime.now().strftime("%Y%m%d_%H%M%S")
    short_uuid     = uuid.uuid4().hex[:6].upper()
    env            = getattr(PIPELINE_CONFIG, "environment", "dev")
    batch_run_id   = f"BATCH_{ts}_{short_uuid}_{env}"
    log("INFO", f"Batch run ID: {batch_run_id}")

    # Load all relevant configs to discover distinct OPCOs
    configs = read_table_configs(
        table_id       = params.get("table_id")       or None,
        schedule_group = params.get("schedule_group") or None,
    )
    if not configs:
        log("WARN", "No active configs found — nothing to run")
        return True

    distinct_opcos    = list(dict.fromkeys(c.opco       for c in configs))
    distinct_table_ids = list(dict.fromkeys(c.table_id  for c in configs))

    results = []
    for opco in distinct_opcos:
        result = run_opco(
            batch_run_id = batch_run_id,
            opco         = opco,
            table_ids    = distinct_table_ids,
            start_date   = params.get("start_date"),
            end_date     = params.get("end_date"),
        )
        results.append(result)

    print_summary(results, started)
    return all(r.get("ok") for r in results)


if __name__ == "__main__":
    main()
