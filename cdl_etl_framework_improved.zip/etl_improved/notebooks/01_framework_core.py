"""
notebooks/01_framework_core.py
================================
Shared foundation for the entire CDL ETL framework.

Design choices:
  - TableConfig is a proper dataclass with typed fields and validation.
  - RunLogger is a class that owns the full lifecycle of one log row
    (start → end_success / end_failure). Callers never build raw dicts.
  - DQEngine is a class so the dq_rules module is loaded once and cached
    on the instance, not via a mutable global.
  - All log-sink writes are non-fatal (errors caught + printed).
  - _build_execution_summary produces a structured JSON that collapses
    all month-level DQ results into a single human-readable column.
  - No hardcoded database names: METADATA_DB comes from env_config.
"""

from __future__ import annotations

import hashlib
import importlib
import json
import os
import traceback
from dataclasses import dataclass, field
from datetime import date, datetime, timezone
from typing import Any, Optional

from delta.tables import DeltaTable
from pyspark.sql import DataFrame, SparkSession
from pyspark.sql import functions as F
from pyspark.sql.types import (
    IntegerType,
    LongType,
    StringType,
    StructField,
    StructType,
    TimestampType,
)

# ---------------------------------------------------------------------------
# Database references  (override via env if needed)
# ---------------------------------------------------------------------------
METADATA_DB    = os.getenv("CDL_METADATA_DB", "cdl_metadata")
RUN_LOG_TABLE  = f"{METADATA_DB}.cdl_table_run_log"
TABLE_CFG_TBL  = f"{METADATA_DB}.cdl_table_config"


# ---------------------------------------------------------------------------
# Structured logger
# ---------------------------------------------------------------------------
def log(level: str, msg: str, **ctx) -> None:
    now   = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
    extra = "  ".join(f"{k}={v}" for k, v in ctx.items())
    print(f"[{now}] [{level.upper()}]  {msg}  {extra}".strip())


# ---------------------------------------------------------------------------
# TableConfig — typed representation of one cdl_table_config row
# ---------------------------------------------------------------------------
@dataclass
class TableConfig:
    table_id:               str
    opco:                   str
    target_dataset_layer:   str
    source_system:          str
    source_table:           list[str]          # may have multiple sources
    source_filter:          Optional[str]
    target_system:          str
    target_table:           str
    load_process:           str
    schedule_group:         Optional[str]
    ingestion_mode:         str                # FULL | INCR | CDC
    incremental_cutoff_day: int                # day-of-month; e.g. 5
    load_frequency:         str                # DAILY | MONTHLY | BOTH
    watermark_column:       Optional[str]
    last_watermark_value:   Optional[datetime]
    partition_col:          Optional[str]
    merge_keys:             list[str]
    dq_rules:               list[dict]
    dq_status:              bool
    dq_threshold_pct:       float              # min % of rows that must pass
    depends_on_table_ids:   list[str]
    retry_max_attempts:     int
    retry_initial_wait_sec: int
    retry_backoff_multiplier: float
    retry_max_wait_sec:     int
    alert_config:           list[dict]
    is_active:              bool

    def __post_init__(self):
        # Normalise opco and layer to uppercase for consistent comparisons
        self.opco                 = self.opco.upper()
        self.target_dataset_layer = self.target_dataset_layer.upper()
        self.ingestion_mode       = self.ingestion_mode.upper()


# ---------------------------------------------------------------------------
# Config reader
# ---------------------------------------------------------------------------
def read_table_configs(
    table_id: Optional[list[str]] = None,
    schedule_group: Optional[str] = None,
) -> list[TableConfig]:
    """
    Query cdl_table_config for active rows matching either schedule_group
    (takes precedence) or an explicit list of table_ids.
    Returns TableConfig objects in the same order as table_id when supplied.
    """
    if not table_id and not schedule_group:
        raise ValueError("Either schedule_group or table_id must be provided.")

    spark   = SparkSession.getActiveSession()
    clauses = ["is_active = true"]

    if schedule_group:
        clauses.append(f"schedule_group = '{schedule_group}'")
    elif table_id:
        ids = ",".join(f"'{t}'" for t in table_id)
        clauses.append(f"table_id IN ({ids})")

    where = " AND ".join(clauses)
    rows  = spark.sql(f"SELECT * FROM {TABLE_CFG_TBL} WHERE {where}").collect()

    # Preserve caller-supplied order when querying by table_id
    if table_id and not schedule_group:
        order = {tid: i for i, tid in enumerate(table_id)}
        rows  = sorted(rows, key=lambda r: order.get(r.table_id, 9999))

    configs = [_row_to_config(r) for r in rows]
    log("INFO", f"Loaded {len(configs)} config(s)",
        schedule_group=schedule_group, table_ids=table_id)
    return configs


def _row_to_config(row) -> TableConfig:
    d = row.asDict()

    def parse_json_list(v, default=None):
        if default is None:
            default = []
        if not v:
            return default
        v = v.strip()
        if v.startswith(("[", "{")):
            parsed = json.loads(v)
            return parsed if isinstance(parsed, list) else [parsed]
        return [x.strip() for x in v.split(",") if x.strip()]

    def parse_json_dict_list(v) -> list[dict]:
        if not v:
            return []
        v = v.strip()
        if v.startswith("["):
            return json.loads(v)
        if v.startswith("{"):
            return [json.loads(v)]
        return []

    return TableConfig(
        table_id               = d["table_id"],
        opco                   = d["opco"],
        target_dataset_layer   = d["target_dataset_layer"],
        source_system          = d["source_system"],
        source_table           = parse_json_list(d.get("source_table_name"), []),
        source_filter          = d.get("source_filter"),
        target_system          = d["target_system"],
        target_table           = d["target_table_name"],
        load_process           = d["load_process"],
        schedule_group         = d.get("schedule_group"),
        ingestion_mode         = d.get("ingestion_mode", "FULL"),
        incremental_cutoff_day = int(d.get("incremental_cutoff_day") or 5),
        load_frequency         = d.get("load_frequency", "MONTHLY"),
        watermark_column       = d.get("watermark_column"),
        last_watermark_value   = d.get("last_watermark_value"),
        partition_col          = d.get("partition_col"),
        merge_keys             = parse_json_list(d.get("merge_keys"), []),
        dq_rules               = parse_json_dict_list(d.get("data_quality_rules")),
        dq_status              = bool(d.get("dq_status", True)),
        dq_threshold_pct       = float(d.get("dq_threshold_pct") or 0.0),
        depends_on_table_ids   = parse_json_list(d.get("depends_on_table_ids"), []),
        retry_max_attempts     = int(d.get("retry_max_attempts") or 2),
        retry_initial_wait_sec = int(d.get("retry_initial_wait_sec") or 30),
        retry_backoff_multiplier = float(d.get("retry_backoff_multiplier") or 2.0),
        retry_max_wait_sec     = int(d.get("retry_max_wait_sec") or 300),
        alert_config           = parse_json_dict_list(d.get("alert_config")),
        is_active              = bool(d.get("is_active", True)),
    )


# ---------------------------------------------------------------------------
# DQ engine — class so the rules module is loaded once per instance
# ---------------------------------------------------------------------------
class DQEngine:
    """
    Runs DQ rules from cfg.dq_rules against a stage table for one month.

    Always returns results (never raises). DQ failure does NOT block loading —
    data is always promoted; failures are only recorded in the log.
    """

    def __init__(self):
        self._rules_module = None

    def _load_rules_module(self):
        if self._rules_module is None:
            self._rules_module = importlib.import_module("dq.dq_rules")
        return self._rules_module

    def run(
        self,
        cfg:         TableConfig,
        opco:        str,
        load_mnth:   str,
        stage_table: str,
        source_table: str,
    ) -> tuple[bool, list[dict]]:
        """
        Execute every rule in cfg.dq_rules.

        Returns:
            (overall_passed, list_of_rule_result_dicts)

        overall_passed is True only when ALL rules pass (diff_pct ≤ threshold).
        Data is ALWAYS loaded regardless — callers must not use this to gate
        the write.  The result is recorded in the run log for observability.
        """
        if not cfg.dq_status or not cfg.dq_rules:
            return True, [{"status": "SKIPPED", "reason": "DQ disabled or no rules"}]

        spark   = SparkSession.getActiveSession()
        mod     = self._load_rules_module()
        results = []
        all_ok  = True

        for rule in cfg.dq_rules:
            rule_name = rule.get("dq_rule") or rule.get("rule_id", "")
            threshold = float(rule.get("error_threshold_pct", 0.0))
            severity  = rule.get("severity", "WARNING")

            fn = getattr(mod, rule_name, None)
            if fn is None:
                log("WARN", f"DQ rule '{rule_name}' not found in dq_rules.py",
                    table=cfg.table_id)
                results.append({
                    "rule_id":    rule_name,
                    "severity":   severity,
                    "threshold":  threshold,
                    "diff_pct":   None,
                    "passed":     False,
                    "error":      "rule_not_found",
                })
                all_ok = False
                continue

            try:
                diff_pct = fn(spark, stage_table, source_table, opco, load_mnth)
                passed   = (diff_pct is not None) and (diff_pct <= threshold)
            except Exception as exc:
                log("ERROR", f"DQ rule '{rule_name}' raised: {exc}",
                    table=cfg.table_id)
                diff_pct, passed = None, False

            results.append({
                "rule_id":   rule_name,
                "severity":  severity,
                "threshold": threshold,
                "diff_pct":  round(diff_pct, 4) if diff_pct is not None else None,
                "passed":    passed,
            })
            # Only CRITICAL failures roll up to overall_passed = False
            if not passed and severity == "CRITICAL":
                all_ok = False

        return all_ok, results


# ---------------------------------------------------------------------------
# RunLogger — owns one row in cdl_table_run_log
# ---------------------------------------------------------------------------
class RunLogger:
    """
    Manages the lifecycle of one run-log row.

    One instance = one (run_batch_id, table_id, load_mnth_start, attempt).
    Call order:   logger.start()  →  logger.end_success() or logger.end_failure()
    """

    # Target column types for the run log table
    _TYPES: dict[str, Any] = {
        "run_batch_id":     StringType(),
        "log_time":         TimestampType(),
        "opco":             StringType(),
        "dataset_layer":    StringType(),
        "table_name":       StringType(),
        "table_id":         StringType(),
        "load_process":     StringType(),
        "load_mnth_start":  StringType(),
        "load_mnth_end":    StringType(),
        "status":           StringType(),
        "message":          StringType(),
        "attempt_number":   IntegerType(),
        "watermark_start":  TimestampType(),
        "watermark_end":    TimestampType(),
        "started_at":       TimestampType(),
        "completed_at":     TimestampType(),
        "duration_seconds": IntegerType(),
        "rows_read":        LongType(),
        "rows_written":     LongType(),
        "dq_result":        StringType(),
        "execution_summary": StringType(),
    }

    def __init__(
        self,
        run_batch_id:    str,
        cfg:             TableConfig,
        opco:            str,
        load_mnth_start: str,
        load_mnth_end:   str,
        attempt:         int,
        watermark_start: Optional[datetime] = None,
    ):
        self.run_batch_id    = run_batch_id
        self.cfg             = cfg
        self.opco            = opco
        self.load_mnth_start = load_mnth_start
        self.load_mnth_end   = load_mnth_end
        self.attempt         = attempt
        self.watermark_start = watermark_start
        self.started_at: Optional[datetime] = None

    # ── Public API ──────────────────────────────────────────────────────
    def start(self) -> datetime:
        """Insert the initial RUNNING row. Returns started_at."""
        self.started_at = datetime.now(timezone.utc)
        self._write({
            "status":    "RUNNING",
            "message":   None,
            "started_at": self.started_at.isoformat(),
        })
        return self.started_at

    def end_success(
        self,
        rows_read:       int,
        rows_written:    int,
        month_summaries: list[dict],
        watermark_end:   Optional[datetime] = None,
    ) -> None:
        """Update the row to SUCCESS / PARTIAL_SUCCESS."""
        now      = datetime.now(timezone.utc)
        duration = self._duration(now)
        dq_result, exec_summary, status = _build_execution_summary(month_summaries)

        self._write({
            "status":           status,
            "message":          "Completed",
            "completed_at":     now.isoformat(),
            "duration_seconds": duration,
            "rows_read":        rows_read,
            "rows_written":     rows_written,
            "watermark_end":    watermark_end.isoformat() if watermark_end else None,
            "dq_result":        dq_result,
            "execution_summary": exec_summary,
        })

    def end_failure(
        self,
        error_code:      str,
        error_message:   str,
        is_final:        bool,
        month_summaries: Optional[list[dict]] = None,
    ) -> None:
        """Update the row to FAILED or RETRYING."""
        now      = datetime.now(timezone.utc)
        duration = self._duration(now)
        status   = "FAILED" if is_final else "RETRYING"

        dq_result, exec_summary = "SKIPPED", json.dumps({"error": "DQ did not complete"})
        if month_summaries:
            dq_result, exec_summary, _ = _build_execution_summary(month_summaries)

        self._write({
            "status":            status,
            "message":           f"{error_code}: {error_message[:800]}",
            "completed_at":      now.isoformat(),
            "duration_seconds":  duration,
            "dq_result":         dq_result,
            "execution_summary": exec_summary,
        })

    # ── Private ─────────────────────────────────────────────────────────
    def _base_row(self) -> dict:
        return {
            "run_batch_id":    self.run_batch_id,
            "log_time":        datetime.now(timezone.utc).isoformat(),
            "opco":            self.opco,
            "dataset_layer":   self.cfg.target_dataset_layer,
            "table_name":      self.cfg.target_table,
            "table_id":        self.cfg.table_id,
            "load_process":    self.cfg.load_process,
            "load_mnth_start": self.load_mnth_start,
            "load_mnth_end":   self.load_mnth_end,
            "attempt_number":  self.attempt,
            "watermark_start": (
                self.watermark_start.isoformat() if self.watermark_start else None
            ),
            # Fields set later; placeholders so schema is consistent
            "status":            None,
            "message":           None,
            "watermark_end":     None,
            "started_at":        self.started_at.isoformat() if self.started_at else None,
            "completed_at":      None,
            "duration_seconds":  None,
            "rows_read":         None,
            "rows_written":      None,
            "dq_result":         None,
            "execution_summary": None,
        }

    def _write(self, updates: dict) -> None:
        row = {**self._base_row(), **updates}
        _upsert_log(
            run_batch_id    = self.run_batch_id,
            table_id        = self.cfg.table_id,
            load_mnth_start = self.load_mnth_start,
            attempt         = self.attempt,
            row             = row,
        )

    def _duration(self, now: datetime) -> int:
        if self.started_at is None:
            return 0
        return int((now - self.started_at).total_seconds())


# ---------------------------------------------------------------------------
# Execution summary builder
# ---------------------------------------------------------------------------
def _build_execution_summary(
    month_summaries: list[dict],
) -> tuple[str, str, str]:
    """
    Collapse per-month DQ results into three values written to the run log:
      dq_result        → PASS | FAIL | PARTIAL
      execution_summary → JSON blob with full detail per month
      pipeline_status  → SUCCESS | PARTIAL_SUCCESS | FAILED

    The JSON structure stored in execution_summary:
    {
      "months_passed": ["202501", "202502"],
      "months_failed": ["202503"],
      "month_details": [
        {
          "month": "202501",
          "dq_status": "PASS",
          "loaded": true,
          "rows_written": 12345,
          "rules": [{"rule_id": "dq_row_count", "passed": true, "diff_pct": 0.0}]
        },
        ...
      ]
    }
    """
    if not month_summaries:
        return "N/A", json.dumps({"months_passed": [], "months_failed": [], "month_details": []}), "RUNNING"

    passed = [s["month"] for s in month_summaries if s.get("dq_status") == "PASS"]
    failed = [s["month"] for s in month_summaries if s.get("dq_status") != "PASS"]

    summary = {
        "months_passed": passed,
        "months_failed": failed,
        "month_details": month_summaries,
    }

    if not failed:
        return "PASS",    json.dumps(summary), "SUCCESS"
    elif passed:
        return "PARTIAL", json.dumps(summary), "PARTIAL_SUCCESS"
    else:
        return "FAIL",    json.dumps(summary), "FAILED"


# ---------------------------------------------------------------------------
# Upsert helper — non-fatal, typed
# ---------------------------------------------------------------------------
def _upsert_log(
    run_batch_id:    str,
    table_id:        str,
    load_mnth_start: str,
    attempt:         int,
    row:             dict,
) -> None:
    """
    MERGE on (run_batch_id, table_id, load_mnth_start, attempt_number).
    Converts all values via StringType first, then casts to target types.
    Any exception is caught and printed — the pipeline must not fail here.
    """
    spark = SparkSession.getActiveSession()
    try:
        str_schema = StructType([
            StructField(k, StringType(), True) for k in row
        ])
        str_row = {k: (str(v) if v is not None else None) for k, v in row.items()}
        df = spark.createDataFrame([str_row], schema=str_schema)

        # Cast to actual target types
        for col_name, target_type in RunLogger._TYPES.items():
            if col_name in df.columns and not isinstance(target_type, StringType):
                df = df.withColumn(col_name, F.col(col_name).cast(target_type))

        (
            DeltaTable
            .forName(spark, RUN_LOG_TABLE)
            .alias("t")
            .merge(
                df.alias("s"),
                """t.run_batch_id    = s.run_batch_id
               AND t.table_id        = s.table_id
               AND t.load_mnth_start = s.load_mnth_start
               AND t.attempt_number  = s.attempt_number""",
            )
            .whenMatchedUpdateAll()
            .whenNotMatchedInsertAll()
            .execute()
        )
    except Exception as exc:
        # Logging failures must never crash the pipeline
        print(f"[WARN] _upsert_log failed (non-fatal): {exc}")


# ---------------------------------------------------------------------------
# DQ gate — check upstream tables passed before running this layer
# ---------------------------------------------------------------------------
def check_dq_gate(
    configs:  list[TableConfig],
    run_date: date,
    opco:     str,
) -> tuple[bool, list[str]]:
    """
    Returns (all_clear, list_of_blocking_table_ids).
    Checks that every depends_on_table_id has status=SUCCESS in today's log.
    """
    spark  = SparkSession.getActiveSession()
    needed = {tid for cfg in configs for tid in cfg.depends_on_table_ids}
    if not needed:
        return True, []

    ids  = ",".join(f"'{x}'" for x in needed)
    rows = spark.sql(f"""
        SELECT table_id, MAX(CASE WHEN status = 'SUCCESS' THEN 1 ELSE 0 END) AS ok
        FROM   {RUN_LOG_TABLE}
        WHERE  DATE(started_at) = '{run_date}'
          AND  opco              = '{opco.upper()}'
          AND  table_id          IN ({ids})
        GROUP BY table_id
    """).collect()

    passed  = {r["table_id"] for r in rows if r["ok"] == 1}
    blocked = [x for x in needed if x not in passed]
    if blocked:
        log("WARN", "DQ gate blocked", blocked_by=str(blocked))
    return (not blocked), blocked


# ---------------------------------------------------------------------------
# Watermark update
# ---------------------------------------------------------------------------
def update_watermark(table_id: str, new_value: datetime, run_date: date) -> None:
    spark = SparkSession.getActiveSession()
    now   = datetime.now(timezone.utc).isoformat()
    spark.sql(f"""
        UPDATE {TABLE_CFG_TBL}
        SET    last_watermark_value = '{new_value.isoformat()}',
               last_successful_run  = '{run_date}',
               updated_at           = '{now}'
        WHERE  table_id = '{table_id}'
    """)
    log("INFO", f"Watermark updated → {new_value}", table_id=table_id)
