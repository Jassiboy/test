"""
notebooks/02_ingestion.py
===========================
Handles one unit of work: DQ-check + promote one month from stage → target.

Key design decisions:
  - DQ failure does NOT block the write. Data is always loaded.
    The DQ result is recorded in the run log for observability only.
  - run_ingestion() returns a month_summary dict — callers collect these
    across all months and pass the full list to RunLogger.end_success().
  - Retry wraps the full (DQ + promote) operation for transient errors.
    Exponential backoff uses cfg.retry_* fields.
  - _promote_to_target uses replaceWhere for an atomic, idempotent partition swap.
  - _reset_stage truncates the temp table; first attempt only.
"""

from __future__ import annotations

import time
import traceback
from datetime import datetime, timezone
from typing import Optional

from delta.tables import DeltaTable
from pyspark.sql import DataFrame, SparkSession

# Re-export from framework_core so callers only need to import from here
from notebooks._framework_import import (
    DQEngine,
    RunLogger,
    TableConfig,
    log,
)

import os

DATA_DB = os.getenv("CDL_DATA_DB", "cdl_data")

# Module-level DQEngine instance (rules module loaded once per driver lifetime)
_dq_engine = DQEngine()


# ---------------------------------------------------------------------------
# Public entry point — one month
# ---------------------------------------------------------------------------
def run_ingestion(
    run_batch_id: str,
    cfg:          TableConfig,
    opco:         str,
    load_mnth:    str,
    stage_table:  str,
) -> dict:
    """
    Run DQ checks and promote one month's data from stage → target.

    Always promotes the data (DQ failure is non-blocking).
    Returns a month_summary dict consumed by the caller to build
    the execution_summary JSON in the run log.

    month_summary schema:
    {
      "month":        "202501",
      "dq_status":    "PASS" | "FAIL",
      "loaded":       True | False,
      "rows_written": int,
      "rules":        [{"rule_id": ..., "passed": ..., "diff_pct": ...}]
      "message":      str
    }
    """
    target = f"{DATA_DB}.{cfg.target_table}"
    scope  = f"{cfg.watermark_column or 'ratemnth'} = '{load_mnth}'"

    # ── Step 1: DQ — non-blocking, always runs ────────────────────────────
    try:
        source_ref   = (
            f"{cfg.source_system}.{cfg.source_table[0]}"
            if cfg.source_table else stage_table
        )
        dq_ok, rules = _dq_engine.run(cfg, opco, load_mnth, stage_table, source_ref)
        dq_status    = "PASS" if dq_ok else "FAIL"
    except Exception as exc:
        log("ERROR", f"DQ engine raised unexpectedly: {exc}", month=load_mnth,
            table=cfg.table_id)
        dq_ok, dq_status = False, "FAIL"
        rules = [{"rule_id": "dq_engine_error", "passed": False, "error": str(exc)}]

    # ── Step 2: Promote — always, regardless of DQ outcome ───────────────
    rows_written = 0
    loaded       = False
    message      = ""
    try:
        rows_written = _promote_to_target(cfg, target, stage_table, scope)
        loaded       = True
        message      = "Data loaded. DQ: " + dq_status
        log(
            "INFO" if dq_ok else "WARN",
            f"Promoted {load_mnth} → {target} ({rows_written} rows). DQ={dq_status}",
            table=cfg.table_id,
        )
    except Exception as exc:
        message = f"PROMOTE_ERROR: {exc}"
        log("ERROR", f"Promote failed for {load_mnth}: {exc}", table=cfg.table_id)

    return {
        "month":        load_mnth,
        "dq_status":    dq_status,
        "loaded":       loaded,
        "rows_written": rows_written,
        "rules":        rules,
        "message":      message,
    }


# ---------------------------------------------------------------------------
# Stage helpers
# ---------------------------------------------------------------------------
def reset_stage(stage_table: str) -> None:
    """Truncate the stage / temp table before loading a new batch."""
    spark = SparkSession.getActiveSession()
    try:
        spark.sql(f"TRUNCATE TABLE {stage_table}")
        log("INFO", f"Stage table truncated: {stage_table}")
    except Exception as exc:
        # If the table doesn't exist yet this is fine — first run
        log("WARN", f"Truncate skipped for {stage_table}: {exc}")


def _promote_to_target(
    cfg:         TableConfig,
    target:      str,
    stage_table: str,
    scope:       str,
) -> int:
    """
    Atomically replace the partition matching `scope` in the target table
    with rows from stage_table.  Uses replaceWhere — no separate DELETE.
    Returns the number of rows written.
    """
    spark    = SparkSession.getActiveSession()
    stage_df = spark.table(stage_table).where(scope)
    (
        stage_df.write
        .format("delta")
        .mode("overwrite")
        .option("replaceWhere", scope)
        .saveAsTable(target)
    )
    ct = stage_df.count()
    log("INFO", f"replaceWhere [{scope}] → {target}: {ct} rows", table=cfg.table_id)
    return ct


# ---------------------------------------------------------------------------
# Metadata columns (added before writing to stage or target)
# ---------------------------------------------------------------------------
def add_audit_columns(df: DataFrame, run_batch_id: str, cfg: TableConfig) -> DataFrame:
    """Attach standard audit columns to a DataFrame before writing."""
    from pyspark.sql import functions as F
    now = datetime.now(timezone.utc).isoformat()
    return (
        df
        .withColumn("_run_batch_id",  F.lit(run_batch_id))
        .withColumn("_source_system", F.lit(cfg.source_system))
        .withColumn("_loaded_at",     F.lit(now).cast("timestamp"))
    )
