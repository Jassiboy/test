"""
notebooks/_framework_import.py
================================
Thin re-export shim so every notebook can do:

    from notebooks._framework_import import DQEngine, RunLogger, TableConfig, log

instead of duplicating the dynamic importlib.util dance for the
'01_framework_core' module whose name starts with a digit.
"""

import importlib
import importlib.util
import os

_CORE_PATH = os.path.join(
    os.path.dirname(__file__),
    "01_framework_core.py",
)

_spec   = importlib.util.spec_from_file_location("_01_framework_core", _CORE_PATH)
_module = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(_module)

# Re-export everything callers need
TableConfig           = _module.TableConfig
DQEngine              = _module.DQEngine
RunLogger             = _module.RunLogger
log                   = _module.log
read_table_configs    = _module.read_table_configs
check_dq_gate         = _module.check_dq_gate
update_watermark      = _module.update_watermark
_build_execution_summary = _module._build_execution_summary
