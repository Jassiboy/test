"""
notebooks/03_transformation.py
================================
Loads the correct transformation module for a given (opco, layer) pair
and calls the function named by cfg.load_process.

Transformation modules live at:
    transformations/{opco_lower}/{layer_lower}.py

Each module exposes one or more functions matching load_process names.
The framework calls:
    fn(spark, source_tables: list[str], load_mnth: str) -> DataFrame

The returned DataFrame is written to the stage table by the caller.
"""

from __future__ import annotations

import importlib
from typing import Optional

from pyspark.sql import DataFrame, SparkSession

from notebooks._framework_import import log


def get_transformed_df(
    opco:          str,
    layer:         str,
    target_table:  str,
    source_tables: list[str],
    load_process:  str,
    load_mnth:     str,
) -> DataFrame:
    """
    Dynamically import transformations/{opco}/{layer}.py and call
    the function matching load_process.

    Parameters
    ----------
    opco          : Operating company in any case e.g. "GROUND"
    layer         : Pipeline layer e.g. "ACCOUNT", "FACILITY"
    target_table  : Target table name (informational, passed to module)
    source_tables : List of source table names (may be multi-source)
    load_process  : Function name to call in the transformation module
    load_mnth     : Rate-month string in YYYYMM format e.g. "202501"

    Returns a DataFrame ready to append into the stage table.
    """
    module_path = f"transformations.{opco.lower()}.{layer.lower()}"
    log("INFO", "Loading transformer", module=module_path,
        load_process=load_process, load_mnth=load_mnth)

    try:
        module = importlib.import_module(module_path)
    except ModuleNotFoundError as exc:
        raise ValueError(
            f"No transformation module found at '{module_path}'. "
            f"Create transformations/{opco.lower()}/{layer.lower()}.py "
            f"with a function named '{load_process}'."
        ) from exc

    fn = getattr(module, load_process, None)
    if fn is None:
        available = [
            name for name in dir(module)
            if not name.startswith("_") and callable(getattr(module, name))
        ]
        raise ValueError(
            f"Function '{load_process}' not found in '{module_path}'. "
            f"Available: {available}"
        )

    spark = SparkSession.getActiveSession()
    # Convention: fn(spark, source_tables, load_mnth) -> DataFrame
    # Transformation modules can ignore spark if they use getActiveSession internally.
    df = fn(spark, source_tables, load_mnth)

    if df is None:
        raise ValueError(
            f"Transformation '{load_process}' in '{module_path}' returned None. "
            f"It must return a DataFrame."
        )

    log("INFO", "Transformer returned DataFrame", module=module_path,
        load_mnth=load_mnth)
    return df
