"""
config/env_config.py
======================
Environment-aware configuration for the CDL ETL framework.

Switch cloud platform via CLOUD_ENV env var (default: azure).
All secrets are read from env vars or secret stores — nothing hardcoded.

Usage:
    from config.env_config import PIPELINE_CONFIG, get_data_db, get_metadata_db
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from typing import Optional


# ---------------------------------------------------------------------------
# Cloud selection
# ---------------------------------------------------------------------------
CLOUD_ENV: str = os.getenv("CDL_ENV", "azure").lower()   # "azure" | "gcp"


# ---------------------------------------------------------------------------
# Base pipeline config (shared across clouds)
# ---------------------------------------------------------------------------
@dataclass
class PipelineConfig:
    """Settings shared by both Azure and GCP deployments."""

    environment: str = os.getenv("CDL_ENVIRONMENT", "dev")   # dev | test | prod

    # Layer execution order — downstream layers depend on upstream
    layer_order: list = field(default_factory=lambda: [
        "ACCOUNT", "FACILITY", "COUNTRY", "GLOBAL",
    ])

    # Default retry policy (overridden per-table by cdl_table_config)
    default_max_attempts:     int   = int(os.getenv("CDL_RETRY_MAX",         "2"))
    default_initial_wait_sec: int   = int(os.getenv("CDL_RETRY_INITIAL_WAIT","30"))
    default_max_wait_sec:     int   = int(os.getenv("CDL_RETRY_MAX_WAIT",    "300"))
    default_backoff_mult:     float = float(os.getenv("CDL_RETRY_MULT",      "2.0"))

    # Spark tuning
    spark_shuffle_partitions: int  = int(os.getenv("CDL_SHUFFLE_PARTITIONS", "200"))
    spark_adaptive_enabled:   bool = True

    # Log retention
    run_log_retention_days: int = int(os.getenv("CDL_LOG_RETENTION_DAYS", "90"))


# ---------------------------------------------------------------------------
# Azure configuration
# ---------------------------------------------------------------------------
@dataclass
class AzureConfig(PipelineConfig):
    """Azure-specific settings."""

    # Unity Catalog identifiers
    catalog:         str = os.getenv("CDL_CATALOG",          "cdl_catalog")
    metadata_schema: str = os.getenv("CDL_METADATA_SCHEMA",  "cdl_metadata")
    data_schema:     str = os.getenv("CDL_DATA_SCHEMA",       "cdl_data")

    # ADLS Gen2
    storage_account: str = os.getenv("AZURE_STORAGE_ACCOUNT", "cdlstorageprod")
    container_name:  str = os.getenv("AZURE_CONTAINER",        "cdl-data")

    @property
    def adls_base_path(self) -> str:
        return (f"abfss://{self.container_name}"
                f"@{self.storage_account}.dfs.core.windows.net")

    # Key Vault
    key_vault_name: str = os.getenv("AZURE_KEY_VAULT", "cdl-kv-prod")

    @property
    def key_vault_uri(self) -> str:
        return f"https://{self.key_vault_name}.vault.azure.net/"

    # Alerting
    smtp_host:       str = os.getenv("SMTP_HOST",           "smtp.office365.com")
    smtp_port:       int = int(os.getenv("SMTP_PORT",       "587"))
    teams_webhook:   str = os.getenv("TEAMS_WEBHOOK_URL",   "")
    alert_from:      str = os.getenv("ALERT_FROM_EMAIL",    "cdl-etl@company.com")

    # Azure App Config — loaded lazily; None if unavailable
    _app_config_cache: Optional[dict] = field(default=None, repr=False, init=False)

    def get_app_config(self, keys: list[str], label: str = "COE-DE") -> dict:
        """Fetch values from Azure App Configuration (cached after first call)."""
        if self._app_config_cache is not None:
            return {k: self._app_config_cache.get(k) for k in keys}
        try:
            from azure.appconfiguration import AzureAppConfigurationClient
            from pyspark.dbutils import DBUtils
            from pyspark.sql import SparkSession
            dbutils = DBUtils(SparkSession.builder.getOrCreate())
            conn_str = dbutils.secrets.get("vault-scope",
                                           "app-configuration-connection-string")
            client = AzureAppConfigurationClient.from_connection_string(conn_str)
            self._app_config_cache = {
                k: client.get_configuration_setting(
                    key=k, label=label.replace("_", "-")
                ).value
                for k in keys
            }
        except Exception as exc:
            print(f"[WARN] Azure App Config unavailable: {exc}")
            self._app_config_cache = {}
        return {k: self._app_config_cache.get(k) for k in keys}


# ---------------------------------------------------------------------------
# GCP configuration
# ---------------------------------------------------------------------------
@dataclass
class GCPConfig(PipelineConfig):
    """GCP-specific settings."""

    project_id:      str = os.getenv("GCP_PROJECT_ID",      "cdl-prod-project")
    gcs_bucket:      str = os.getenv("GCS_BUCKET",           "cdl-data-prod")
    metadata_dataset:str = os.getenv("CDL_METADATA_SCHEMA",  "cdl_metadata")
    data_dataset:    str = os.getenv("CDL_DATA_SCHEMA",       "cdl_data")
    bq_location:     str = os.getenv("BQ_LOCATION",           "US")
    dataproc_region: str = os.getenv("DATAPROC_REGION",      "us-central1")
    dataproc_cluster:str = os.getenv("DATAPROC_CLUSTER",     "cdl-spark-cluster")
    alert_from:      str = os.getenv("ALERT_FROM_EMAIL",     "cdl-etl@company.com")

    @property
    def gcs_base_path(self) -> str:
        return f"gs://{self.gcs_bucket}"

    @property
    def secret_manager_prefix(self) -> str:
        return f"projects/{self.project_id}/secrets"


# ---------------------------------------------------------------------------
# Factory + helpers
# ---------------------------------------------------------------------------
def get_cloud_config() -> PipelineConfig:
    if CLOUD_ENV == "gcp":
        return GCPConfig()
    return AzureConfig()


def get_metadata_db(cfg: Optional[PipelineConfig] = None) -> str:
    cfg = cfg or PIPELINE_CONFIG
    if isinstance(cfg, GCPConfig):
        return f"{cfg.project_id}.{cfg.metadata_dataset}"
    if isinstance(cfg, AzureConfig):
        return f"{cfg.catalog}.{cfg.metadata_schema}"
    raise TypeError(f"Unsupported config type: {type(cfg)}")


def get_data_db(cfg: Optional[PipelineConfig] = None) -> str:
    cfg = cfg or PIPELINE_CONFIG
    if isinstance(cfg, GCPConfig):
        return f"{cfg.project_id}.{cfg.data_dataset}"
    if isinstance(cfg, AzureConfig):
        return f"{cfg.catalog}.{cfg.data_schema}"
    raise TypeError(f"Unsupported config type: {type(cfg)}")


def get_storage_base(cfg: Optional[PipelineConfig] = None) -> str:
    cfg = cfg or PIPELINE_CONFIG
    if isinstance(cfg, GCPConfig):
        return cfg.gcs_base_path
    if isinstance(cfg, AzureConfig):
        return cfg.adls_base_path
    raise TypeError(f"Unsupported config type: {type(cfg)}")


# Singleton — import and use this everywhere
PIPELINE_CONFIG: PipelineConfig = get_cloud_config()
