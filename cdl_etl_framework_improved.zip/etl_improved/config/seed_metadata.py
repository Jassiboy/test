"""
config/seed_metadata.py
=========================
Seeds cdl_table_config with all pipeline table mappings for the GROUND opco.

Every DQ rule, retry policy, alert routing, watermark column, and dependency
gate is encoded inline in each row — no auxiliary tables needed.

Usage:
    python seed_metadata.py --env azure --opco GROUND
    python seed_metadata.py --env gcp   --opco GROUND --dry-run
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from datetime import datetime, timezone

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

NOW = datetime.now(timezone.utc).isoformat()

MKVW_SCHEMA = "MKVW_COMN_SCHEMA"

# ---------------------------------------------------------------------------
# Shared alert config
# ---------------------------------------------------------------------------
ALERT_CFG = json.dumps([
    {
        "channel":    "EMAIL",
        "recipients": "cdl-alerts@company.com,data-eng-oncall@company.com",
        "on_status":  ["FAILED", "HALTED"],
    },
    {
        "channel":    "TEAMS",
        "recipients": "https://company.webhook.office.com/webhookb2/cdl-alerts",
        "on_status":  ["FAILED"],
    },
])

# ---------------------------------------------------------------------------
# DQ rule sets — one per layer
# ---------------------------------------------------------------------------
def _dq_account() -> str:
    return json.dumps([
        {"rule_id": "dq_row_count",   "rule_type": "ROW_COUNT",
         "target_column": None,       "rule_expression": "ratemnth",
         "severity": "CRITICAL",      "error_threshold_pct": 0.0},
        {"rule_id": "dq_net_rev",     "rule_type": "SUM_COMPARE",
         "target_column": "netrev",   "rule_expression": "netrev",
         "severity": "CRITICAL",      "error_threshold_pct": 1.0},
        {"rule_id": "dq_weight",      "rule_type": "SUM_COMPARE",
         "target_column": "apounds",  "rule_expression": "apounds",
         "severity": "WARNING",       "error_threshold_pct": 2.0},
        {"rule_id": "dq_packages",    "rule_type": "SUM_COMPARE",
         "target_column": "packages", "rule_expression": "packages",
         "severity": "WARNING",       "error_threshold_pct": 2.0},
    ])

def _dq_facility() -> str:
    return json.dumps([
        {"rule_id": "dq_row_count",     "rule_type": "ROW_COUNT",
         "target_column": None,         "rule_expression": "ratemnth",
         "severity": "CRITICAL",        "error_threshold_pct": 0.0},
        {"rule_id": "dq_net_rev",       "rule_type": "SUM_COMPARE",
         "target_column": "netrev",     "rule_expression": "netrev",
         "severity": "CRITICAL",        "error_threshold_pct": 1.0},
        {"rule_id": "dq_no_duplicates", "rule_type": "UNIQUENESS",
         "target_column": None,         "rule_expression": "ratemnth,se_payr_glbl_enti_nbr,svc_cat_cd",
         "severity": "CRITICAL",        "error_threshold_pct": 0.0},
    ])

def _dq_country() -> str:
    return json.dumps([
        {"rule_id": "dq_row_count", "rule_type": "ROW_COUNT",
         "target_column": None,     "rule_expression": "ratemnth",
         "severity": "CRITICAL",    "error_threshold_pct": 0.0},
        {"rule_id": "dq_net_rev",   "rule_type": "SUM_COMPARE",
         "target_column": "netrev", "rule_expression": "netrev",
         "severity": "CRITICAL",    "error_threshold_pct": 1.0},
    ])

def _dq_global() -> str:
    return json.dumps([
        {"rule_id": "dq_row_count", "rule_type": "ROW_COUNT",
         "target_column": None,     "rule_expression": "ratemnth",
         "severity": "CRITICAL",    "error_threshold_pct": 0.0},
        {"rule_id": "dq_net_rev",   "rule_type": "SUM_COMPARE",
         "target_column": "netrev", "rule_expression": "netrev",
         "severity": "CRITICAL",    "error_threshold_pct": 1.0},
    ])


# ---------------------------------------------------------------------------
# Row builders
# ---------------------------------------------------------------------------
def _row(
    table_id:            str,
    source_table_name:   str,
    target_table_name:   str,
    target_layer:        str,
    load_process:        str,
    dq_rules:            str,
    depends_on:          str | None = None,
    source_filter:       str | None = None,
    schedule_group:      str = "GROUND_MONTHLY",
) -> dict:
    return {
        "table_id":              table_id,
        "source_system":         "DELTA_LAKE",
        "source_table_name":     source_table_name,
        "source_filter":         source_filter,
        "target_system":         "DELTA_LAKE",
        "target_table_name":     target_table_name,
        "target_dataset_layer":  target_layer,
        "opco":                  "GROUND",
        "schedule_group":        schedule_group,
        "ingestion_mode":        "INCR",
        "load_frequency":        "MONTHLY",
        "watermark_column":      "ratemnth",
        "last_watermark_value":  None,
        "last_successful_run":   None,
        "partition_col":         "ratemnth",
        "merge_keys":            "ratemnth,se_payr_glbl_enti_nbr,svc_cat_cd",
        "load_process":          load_process,
        "data_quality_rules":    dq_rules,
        "dq_status":             True,
        "dq_threshold_pct":      95.0,
        "depends_on_table_ids":  depends_on,
        "retry_max_attempts":    3,
        "retry_initial_wait_sec":  30,
        "retry_backoff_multiplier": 2.0,
        "retry_max_wait_sec":    300,
        "alert_config":          ALERT_CFG,
        "is_active":             True,
        "created_at":            NOW,
        "updated_at":            NOW,
        "created_by":            "seed_script",
    }


def build_rows() -> list[dict]:
    acct_tbl    = f"{MKVW_SCHEMA}.FXG_ACCT_BILL_MTH_HIST"
    fac_tbl     = f"{MKVW_SCHEMA}.FXG_FAC_ENTI_BILL_MTH_HIST"
    ctry_tbl    = f"{MKVW_SCHEMA}.FXG_CTRY_ENTI_BILL_MTH_HIST"

    return [
        # ── ACCOUNT → FACILITY ────────────────────────────────────────────
        _row("fxg_fac_enti_bill_mth_hist_non_sp",
             source_table_name = f"['{acct_tbl}','{MKVW_SCHEMA}.CUST_SE_SEG_MAP','{MKVW_SCHEMA}.CUST_CE_SEG_MAP','{MKVW_SCHEMA}.CDL_MTR_GROUP_DEFINITION']",
             target_table_name = f"{MKVW_SCHEMA}.FXG_FAC_ENTI_BILL_MTH_HIST",
             target_layer      = "FACILITY",
             load_process      = "load_fxg_fac_enti_bill_mth_hist",
             dq_rules          = _dq_facility(),
             depends_on        = None),

        _row("fxg_fac_enti_bill_mth_hist_sp",
             source_table_name = f"['{acct_tbl}','{MKVW_SCHEMA}.CUST_SE_SEG_MAP','{MKVW_SCHEMA}.CUST_CE_SEG_MAP','{MKVW_SCHEMA}.CDL_MTR_GROUP_DEFINITION']",
             target_table_name = f"{MKVW_SCHEMA}.FXG_FAC_ENTI_BILL_MTH_HIST",
             target_layer      = "FACILITY",
             load_process      = "load_fxg_fac_enti_bill_mth_hist_sp",
             dq_rules          = _dq_facility(),
             depends_on        = None),

        # ── FACILITY → COUNTRY ────────────────────────────────────────────
        _row("fxg_ctry_enti_bill_mth_hist_non_sp",
             source_table_name = f"['{fac_tbl}']",
             target_table_name = f"{MKVW_SCHEMA}.FXG_CTRY_ENTI_BILL_MTH_HIST",
             target_layer      = "COUNTRY",
             load_process      = "load_fxg_ctry_enti_bill_mth_hist",
             dq_rules          = _dq_country(),
             depends_on        = "fxg_fac_enti_bill_mth_hist_non_sp"),

        _row("fxg_ctry_enti_bill_mth_hist_sp",
             source_table_name = f"['{fac_tbl}']",
             target_table_name = f"{MKVW_SCHEMA}.FXG_CTRY_ENTI_BILL_MTH_HIST",
             target_layer      = "COUNTRY",
             load_process      = "load_fxg_ctry_enti_bill_mth_hist_sp",
             dq_rules          = _dq_country(),
             depends_on        = "fxg_fac_enti_bill_mth_hist_sp"),

        # ── COUNTRY → GLOBAL ──────────────────────────────────────────────
        _row("fxg_glbl_enti_bill_mth_hist_non_sp",
             source_table_name = f"['{ctry_tbl}']",
             target_table_name = f"{MKVW_SCHEMA}.FXG_GLBL_ENTI_BILL_MTH_HIST",
             target_layer      = "GLOBAL",
             load_process      = "load_fxg_glbl_enti_bill_mth_hist",
             dq_rules          = _dq_global(),
             depends_on        = "fxg_ctry_enti_bill_mth_hist_non_sp"),

        _row("fxg_glbl_enti_bill_mth_hist_sp",
             source_table_name = f"['{ctry_tbl}']",
             target_table_name = f"{MKVW_SCHEMA}.FXG_GLBL_ENTI_BILL_MTH_HIST",
             target_layer      = "GLOBAL",
             load_process      = "load_fxg_glbl_enti_bill_mth_hist_sp",
             dq_rules          = _dq_global(),
             depends_on        = "fxg_ctry_enti_bill_mth_hist_sp"),
    ]


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
def seed(env: str, opco: str, dry_run: bool) -> None:
    rows = build_rows()
    print(f"Seeding {len(rows)} rows into cdl_table_config [{env}][{opco}]")

    if dry_run:
        print(json.dumps(rows, indent=2, default=str))
        return

    try:
        from pyspark.sql import SparkSession
        spark = SparkSession.builder.getOrCreate()
        df = spark.createDataFrame(rows)
        (
            df.write.format("delta")
            .mode("append")
            .option("mergeSchema", "true")
            .saveAsTable("cdl_metadata.cdl_table_config")
        )
        print(f"Seeded {len(rows)} rows successfully.")
    except Exception as exc:
        print(f"[ERROR] Seed failed: {exc}")
        raise


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Seed cdl_table_config")
    parser.add_argument("--env",     default="azure", choices=["azure", "gcp"])
    parser.add_argument("--opco",    default="GROUND")
    parser.add_argument("--dry-run", action="store_true",
                        help="Print rows as JSON without writing to Spark")
    args = parser.parse_args()
    seed(args.env, args.opco.upper(), args.dry_run)
