"""
config/env_config_azure.py
============================
Azure-specific runtime bootstrap helpers.

Separates Azure concerns from env_config.py so that GCP-only deployments
do not need azure-* packages installed.

Provides:
  configure_spark_azure()  — apply Delta + AQE Spark conf at runtime
  mount_adls()             — mount ADLS Gen2 container to /mnt/<name>
  get_secret_azure()       — fetch a secret from Databricks secret scope
                             (falls back to Key Vault via DefaultAzureCredential)
"""

from __future__ import annotations

import logging
import os
from typing import Optional

logger = logging.getLogger("cdl.azure_config")


def configure_spark_azure(spark, shuffle_partitions: int = 200) -> None:
    """
    Apply production-grade Spark + Delta Lake settings to a running session.
    Call once at notebook/job start, after SparkSession is created.

    Settings are idempotent — safe to call multiple times.
    """
    opts = {
        # Adaptive Query Execution
        "spark.sql.adaptive.enabled":                                  "true",
        "spark.sql.adaptive.coalescePartitions.enabled":               "true",
        "spark.sql.adaptive.skewJoin.enabled":                         "true",
        "spark.databricks.optimizer.adaptiveQueryExecution.enabled":   "true",

        # Delta Lake
        "spark.databricks.delta.optimizeWrite.enabled":                "true",
        "spark.databricks.delta.autoCompact.enabled":                  "true",
        "spark.databricks.delta.merge.enableLowShuffle.mergeEnabled":  "true",
        "spark.databricks.delta.schema.autoMerge.enabled":             "true",

        # Shuffle and join
        "spark.sql.shuffle.partitions":            str(shuffle_partitions),
        "spark.sql.autoBroadcastJoinThreshold":    "104857600",  # 100 MB

        # Pushdown
        "spark.sql.parquet.filterPushdown":        "true",
        "spark.sql.orc.filterPushdown":            "true",
    }
    for k, v in opts.items():
        spark.conf.set(k, v)
    logger.info("Azure Spark config applied (%d settings)", len(opts))


def mount_adls(
    dbutils,
    storage_account: str,
    container:       str,
    mount_name:      str,
    client_id:       str,
    client_secret:   str,
    tenant_id:       str,
) -> str:
    """
    Mount an ADLS Gen2 container to /mnt/<mount_name> using a service principal.
    Returns the mounted path.  Skips silently if already mounted.

    Credentials should be read from Databricks secret scope, not hardcoded:
        client_id     = dbutils.secrets.get("cdl-scope","sp-client-id")
        client_secret = dbutils.secrets.get("cdl-scope","sp-client-secret")
        tenant_id     = dbutils.secrets.get("cdl-scope","tenant-id")
    """
    mount_point = f"/mnt/{mount_name}"

    # Check if already mounted
    existing = [m.mountPoint for m in dbutils.fs.mounts()]
    if mount_point in existing:
        logger.info("Already mounted: %s", mount_point)
        return mount_point

    configs = {
        "fs.azure.account.auth.type":                             "OAuth",
        "fs.azure.account.oauth.provider.type":
            "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider",
        "fs.azure.account.oauth2.client.id":                      client_id,
        "fs.azure.account.oauth2.client.secret":                  client_secret,
        "fs.azure.account.oauth2.client.endpoint":
            f"https://login.microsoftonline.com/{tenant_id}/oauth2/token",
    }

    source = f"abfss://{container}@{storage_account}.dfs.core.windows.net/"
    dbutils.fs.mount(source=source, mount_point=mount_point, extra_configs=configs)
    logger.info("Mounted %s → %s", source, mount_point)
    return mount_point


def get_secret_azure(
    dbutils,
    scope:  str,
    key:    str,
    default: Optional[str] = None,
) -> Optional[str]:
    """
    Fetch a secret from a Databricks secret scope.
    Falls back to `default` (or env var of the same name) if unavailable.
    Never raises — returns None on total failure.
    """
    try:
        return dbutils.secrets.get(scope=scope, key=key)
    except Exception as exc:
        logger.debug("Databricks secret scope miss [%s/%s]: %s", scope, key, exc)

    # Fallback: environment variable
    env_val = os.getenv(key.replace("-", "_").upper())
    if env_val:
        logger.debug("Secret '%s' resolved from env var", key)
        return env_val

    if default is not None:
        return default

    logger.warning("Secret '%s' not found in scope '%s' or env", key, scope)
    return None


def optimize_delta_table(
    spark,
    table:       str,
    zorder_cols: Optional[list] = None,
    vacuum_hours: int = 168,
) -> None:
    """
    OPTIMIZE + VACUUM a Delta table. Safe to call from any notebook.
    zorder_cols — if None, OPTIMIZE runs without Z-ordering (file compaction only).
    """
    zorder = f" ZORDER BY ({', '.join(zorder_cols)})" if zorder_cols else ""
    logger.info("OPTIMIZE %s%s", table, zorder)
    spark.sql(f"OPTIMIZE {table}{zorder}")

    logger.info("VACUUM %s RETAIN %d HOURS", table, vacuum_hours)
    spark.sql(f"VACUUM {table} RETAIN {vacuum_hours} HOURS")
