"""
tests/conftest.py
==================
Pytest configuration for the CDL ETL framework test suite.

Sets up:
  - sys.path so project root is importable without installation.
  - Lazy module aliases for notebooks whose filenames start with digits
    (Python cannot import them with standard import syntax).
  - Shared environment variable defaults so env_config.py does not require
    a real Azure / GCP environment at test time.
"""

from __future__ import annotations

import importlib
import importlib.util
import os
import sys

# ---------------------------------------------------------------------------
# 1. Make project root importable
# ---------------------------------------------------------------------------
PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

# ---------------------------------------------------------------------------
# 2. Default env vars — prevent env_config.py from requiring real credentials
# ---------------------------------------------------------------------------
os.environ.setdefault("CDL_ENV",              "azure")
os.environ.setdefault("CDL_ENVIRONMENT",      "test")
os.environ.setdefault("CDL_CATALOG",          "test_catalog")
os.environ.setdefault("CDL_METADATA_SCHEMA",  "cdl_metadata")
os.environ.setdefault("CDL_DATA_SCHEMA",      "cdl_data")
os.environ.setdefault("CDL_METADATA_DB",      "cdl_metadata")
os.environ.setdefault("CDL_DATA_DB",          "cdl_data")
os.environ.setdefault("CDL_RETRY_MAX",        "2")
os.environ.setdefault("CDL_RETRY_INITIAL_WAIT", "1")
os.environ.setdefault("CDL_RETRY_MAX_WAIT",   "5")
os.environ.setdefault("CDL_SHUFFLE_PARTITIONS", "2")


# ---------------------------------------------------------------------------
# 3. Aliases for digit-prefixed notebook modules
#    Allows test files to do:
#        from notebooks.four_main_core import month_chunks
#        from notebooks.three_transformation import get_transformed_df
# ---------------------------------------------------------------------------
def _load_notebook(alias: str, filename: str):
    """Load a notebook .py file and register it under a friendly module alias."""
    path = os.path.join(PROJECT_ROOT, "notebooks", filename)
    if not os.path.exists(path):
        return  # skip if file not yet created
    spec = importlib.util.spec_from_file_location(alias, path)
    mod  = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    sys.modules[alias] = mod
    # Also register under notebooks.<alias> for test_framework.py imports
    sys.modules[f"notebooks.{alias}"] = mod


_load_notebook("one_framework_core",  "01_framework_core.py")
_load_notebook("two_ingestion",       "02_ingestion.py")
_load_notebook("three_transformation","03_transformation.py")
_load_notebook("four_main_core",      "04_main_core.py")

# ---------------------------------------------------------------------------
# 4. Re-export _framework_import contents so tests can also use:
#        from notebooks._framework_import import TableConfig
# ---------------------------------------------------------------------------
try:
    from notebooks._framework_import import (  # noqa: F401
        TableConfig, DQEngine, RunLogger, log,
        read_table_configs, check_dq_gate, _build_execution_summary,
    )
except Exception:
    pass  # will surface as ImportError in specific tests, not at collection time
