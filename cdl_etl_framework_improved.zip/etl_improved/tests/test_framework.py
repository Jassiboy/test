"""
tests/test_framework.py
=========================
Full unit test suite for the CDL ETL framework.

Covers:
  - DQEngine   (null, range, row-count, duplicate, threshold, warning-only)
  - DQ gate    (dependency check against run log)
  - RunLogger  (_build_execution_summary, status derivation)
  - month_chunks / resolve_windows  (date helpers in 04_main_core)
  - retry_handler  (backoff, cap, success-after-retry, exhaustion)
  - CloudAdapter.read_external  (DELTA_LAKE fast path, unknown source)
  - Transformation loader  (importable modules, bad opco/layer)
  - seed_metadata  (dry-run produces correct number of rows)
  - run_config.json  (schema validation)

Run:
    pytest tests/test_framework.py -v
    pytest tests/test_framework.py -v -k "DQ"
"""

from __future__ import annotations

import json
import sys
import os
import types
from datetime import date, datetime, timezone
from unittest.mock import MagicMock, patch, call

import pytest

# ---------------------------------------------------------------------------
# Make the project root importable
# ---------------------------------------------------------------------------
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))


# ===========================================================================
# Spark fixture  — local[2], Delta extensions, minimal shuffle partitions
# ===========================================================================
@pytest.fixture(scope="session")
def spark():
    from pyspark.sql import SparkSession
    s = (
        SparkSession.builder
        .master("local[2]")
        .appName("cdl_test")
        .config("spark.sql.extensions",
                "io.delta.sql.DeltaSparkSessionExtension")
        .config("spark.sql.catalog.spark_catalog",
                "org.apache.spark.sql.delta.catalog.DeltaCatalog")
        .config("spark.sql.shuffle.partitions", "2")
        .config("spark.databricks.delta.schema.autoMerge.enabled", "true")
        .getOrCreate()
    )
    s.sparkContext.setLogLevel("ERROR")
    return s


# ---------------------------------------------------------------------------
# Helper: build a minimal TableConfig without hitting the database
# ---------------------------------------------------------------------------
def make_cfg(**overrides) -> "TableConfig":
    from notebooks._framework_import import TableConfig
    defaults = dict(
        table_id               = "test_table",
        opco                   = "GROUND",
        target_dataset_layer   = "FACILITY",
        source_system          = "DELTA_LAKE",
        source_table           = ["source_db.source_tbl"],
        source_filter          = None,
        target_system          = "DELTA_LAKE",
        target_table           = "cdl_data.FXG_FAC_ENTI_BILL_MTH_HIST",
        load_process           = "load_fxg_fac_enti_bill_mth_hist",
        schedule_group         = "GROUND_MONTHLY",
        ingestion_mode         = "INCR",
        incremental_cutoff_day = 5,
        load_frequency         = "MONTHLY",
        watermark_column       = "ratemnth",
        last_watermark_value   = None,
        partition_col          = "ratemnth",
        merge_keys             = ["ratemnth", "se_payr_glbl_enti_nbr", "svc_cat_cd"],
        dq_rules               = [],
        dq_status              = True,
        dq_threshold_pct       = 95.0,
        depends_on_table_ids   = [],
        retry_max_attempts     = 2,
        retry_initial_wait_sec = 1,
        retry_backoff_multiplier = 2.0,
        retry_max_wait_sec     = 5,
        alert_config           = [],
        is_active              = True,
    )
    defaults.update(overrides)
    return TableConfig(**defaults)


# ===========================================================================
# DQEngine
# ===========================================================================
class TestDQEngine:
    """Tests for core.DQEngine.run() — exercises dq_rules.py rule functions."""

    @pytest.fixture
    def engine(self):
        from notebooks._framework_import import DQEngine
        return DQEngine()

    def _stage(self, spark, rows, schema):
        """Create an in-memory temp view to act as the stage table."""
        df = spark.createDataFrame(rows, schema)
        df.createOrReplaceTempView("_test_stage")
        return "_test_stage"

    def test_empty_rules_returns_pass(self, engine, spark):
        cfg   = make_cfg(dq_rules=[])
        ok, _ = engine.run(cfg, "GROUND", "202501", "_test_stage", "_test_src")
        assert ok is True

    def test_dq_status_false_skips_rules(self, engine, spark):
        cfg = make_cfg(
            dq_status=False,
            dq_rules=[{"rule_id": "dq_row_count", "severity": "CRITICAL",
                        "error_threshold_pct": 0.0}],
        )
        ok, results = engine.run(cfg, "GROUND", "202501", "_test_stage", "_test_src")
        assert ok is True
        assert results[0]["status"] == "SKIPPED"

    def test_row_count_match_passes(self, engine, spark):
        """dq_row_count should return 0.0 when stage == source count."""
        stage = self._stage(spark,
                            [("GROUND", "202501"), ("GROUND", "202501")],
                            "opco STRING, ratemnth STRING")
        spark.createDataFrame(
            [("GROUND", "202501"), ("GROUND", "202501")],
            "opco STRING, ratemnth STRING"
        ).createOrReplaceTempView("_test_src_rows")

        cfg = make_cfg(dq_rules=[{
            "rule_id": "dq_row_count", "severity": "CRITICAL",
            "error_threshold_pct": 0.0,
        }])
        ok, results = engine.run(cfg, "GROUND", "202501", stage, "_test_src_rows")
        assert ok is True
        assert results[0]["passed"] is True
        assert results[0]["diff_pct"] == 0.0

    def test_row_count_mismatch_fails(self, engine, spark):
        """25% deficit (3 vs 4) should fail a 0% threshold."""
        spark.createDataFrame(
            [("GROUND","202501")] * 3, "opco STRING, ratemnth STRING"
        ).createOrReplaceTempView("_stg_3rows")
        spark.createDataFrame(
            [("GROUND","202501")] * 4, "opco STRING, ratemnth STRING"
        ).createOrReplaceTempView("_src_4rows")

        cfg = make_cfg(dq_rules=[{
            "rule_id": "dq_row_count", "severity": "CRITICAL",
            "error_threshold_pct": 0.0,
        }])
        ok, results = engine.run(cfg, "GROUND", "202501", "_stg_3rows", "_src_4rows")
        assert ok is False
        assert results[0]["passed"] is False
        assert abs(results[0]["diff_pct"] - 25.0) < 0.01

    def test_warning_severity_does_not_fail_overall(self, engine, spark):
        """A failing WARNING rule should not set overall_passed=False."""
        spark.createDataFrame(
            [("GROUND","202501")] * 3, "opco STRING, ratemnth STRING"
        ).createOrReplaceTempView("_stg_w")
        spark.createDataFrame(
            [("GROUND","202501")] * 4, "opco STRING, ratemnth STRING"
        ).createOrReplaceTempView("_src_w")

        cfg = make_cfg(dq_rules=[{
            "rule_id": "dq_row_count", "severity": "WARNING",
            "error_threshold_pct": 0.0,
        }])
        ok, results = engine.run(cfg, "GROUND", "202501", "_stg_w", "_src_w")
        # WARNING failure → overall still True
        assert ok is True
        assert results[0]["passed"] is False

    def test_unknown_rule_marks_failed(self, engine, spark):
        """A rule_id not in dq_rules.py should produce passed=False."""
        cfg = make_cfg(dq_rules=[{
            "rule_id": "nonexistent_rule_xyz", "severity": "CRITICAL",
            "error_threshold_pct": 0.0,
        }])
        ok, results = engine.run(cfg, "GROUND", "202501", "_test_stage", "_test_stage")
        assert ok is False
        assert results[0]["error"] == "rule_not_found"

    def test_multiple_rules_first_critical_fail_wins(self, engine, spark):
        """If one CRITICAL rule fails, overall must be False even if others pass."""
        spark.createDataFrame(
            [("GROUND","202501")] * 3, "opco STRING, ratemnth STRING"
        ).createOrReplaceTempView("_stg_multi")
        spark.createDataFrame(
            [("GROUND","202501")] * 3, "opco STRING, ratemnth STRING"
        ).createOrReplaceTempView("_src_multi")

        cfg = make_cfg(dq_rules=[
            {"rule_id": "dq_row_count",   "severity": "CRITICAL",
             "error_threshold_pct": 0.0},  # PASS
            {"rule_id": "nonexistent_xyz", "severity": "CRITICAL",
             "error_threshold_pct": 0.0},  # FAIL (not found)
        ])
        ok, results = engine.run(cfg, "GROUND", "202501", "_stg_multi", "_src_multi")
        assert ok is False
        assert results[0]["passed"] is True
        assert results[1]["passed"] is False


# ===========================================================================
# _build_execution_summary
# ===========================================================================
class TestBuildExecutionSummary:
    """Tests for the DQ summary builder in 01_framework_core."""

    def _summary(self, month_summaries):
        from notebooks._framework_import import _build_execution_summary
        return _build_execution_summary(month_summaries)

    def test_empty_list_returns_running(self):
        dq_result, _, status = self._summary([])
        assert dq_result == "N/A"
        assert status    == "RUNNING"

    def test_all_pass(self):
        months = [
            {"month": "202501", "dq_status": "PASS", "loaded": True,
             "rows_written": 100, "rules": []},
            {"month": "202502", "dq_status": "PASS", "loaded": True,
             "rows_written": 200, "rules": []},
        ]
        dq_result, summary_json, status = self._summary(months)
        assert dq_result == "PASS"
        assert status    == "SUCCESS"
        parsed = json.loads(summary_json)
        assert parsed["months_passed"] == ["202501", "202502"]
        assert parsed["months_failed"] == []

    def test_all_fail(self):
        months = [
            {"month": "202501", "dq_status": "FAIL", "loaded": True,
             "rows_written": 100, "rules": []},
        ]
        dq_result, _, status = self._summary(months)
        assert dq_result == "FAIL"
        assert status    == "FAILED"

    def test_partial(self):
        months = [
            {"month": "202501", "dq_status": "PASS", "loaded": True,
             "rows_written": 100, "rules": []},
            {"month": "202502", "dq_status": "FAIL", "loaded": True,
             "rows_written": 80,  "rules": []},
        ]
        dq_result, summary_json, status = self._summary(months)
        assert dq_result == "PARTIAL"
        assert status    == "PARTIAL_SUCCESS"
        parsed = json.loads(summary_json)
        assert "202501" in parsed["months_passed"]
        assert "202502" in parsed["months_failed"]


# ===========================================================================
# RunLogger
# ===========================================================================
class TestRunLogger:
    """Tests for RunLogger — verifies _upsert_log is called with right shape."""

    def _make_logger(self, cfg=None):
        from notebooks._framework_import import RunLogger
        return RunLogger(
            run_batch_id    = "BATCH_TEST",
            cfg             = cfg or make_cfg(),
            opco            = "GROUND",
            load_mnth_start = "202501",
            load_mnth_end   = "202501",
            attempt         = 1,
        )

    @patch("notebooks._01_framework_core._upsert_log")
    def test_start_writes_running_status(self, mock_upsert):
        logger = self._make_logger()
        logger.start()
        assert mock_upsert.called
        row = mock_upsert.call_args[1]["row"]
        assert row["status"] == "RUNNING"
        assert row["run_batch_id"] == "BATCH_TEST"

    @patch("notebooks._01_framework_core._upsert_log")
    def test_end_success_writes_success(self, mock_upsert):
        logger = self._make_logger()
        logger.started_at = datetime.now(timezone.utc)
        month_summaries = [
            {"month": "202501", "dq_status": "PASS", "loaded": True,
             "rows_written": 500, "rules": []}
        ]
        logger.end_success(500, 500, month_summaries)
        row = mock_upsert.call_args[1]["row"]
        assert row["status"]       == "SUCCESS"
        assert row["rows_written"] == 500
        assert row["dq_result"]    == "PASS"

    @patch("notebooks._01_framework_core._upsert_log")
    def test_end_failure_final_writes_failed(self, mock_upsert):
        logger = self._make_logger()
        logger.started_at = datetime.now(timezone.utc)
        logger.end_failure("IOError", "connection refused", is_final=True)
        row = mock_upsert.call_args[1]["row"]
        assert row["status"] == "FAILED"
        assert "IOError" in row["message"]

    @patch("notebooks._01_framework_core._upsert_log")
    def test_end_failure_non_final_writes_retrying(self, mock_upsert):
        logger = self._make_logger()
        logger.started_at = datetime.now(timezone.utc)
        logger.end_failure("TimeoutError", "timed out", is_final=False)
        row = mock_upsert.call_args[1]["row"]
        assert row["status"] == "RETRYING"

    @patch("notebooks._01_framework_core._upsert_log")
    def test_upsert_failure_is_non_fatal(self, mock_upsert):
        """_upsert_log raising must not propagate to caller."""
        mock_upsert.side_effect = Exception("delta table not found")
        logger = self._make_logger()
        # Should not raise
        logger.start()


# ===========================================================================
# month_chunks
# ===========================================================================
class TestMonthChunks:

    def _chunks(self, start, end):
        from notebooks.four_main_core import month_chunks
        return month_chunks(start, end)

    def test_single_month(self):
        assert self._chunks(202501, 202501) == ["202501"]

    def test_three_months(self):
        assert self._chunks(202501, 202503) == ["202501", "202502", "202503"]

    def test_year_boundary(self):
        assert self._chunks(202511, 202602) == [
            "202511", "202512", "202601", "202602"
        ]

    def test_string_inputs_accepted(self):
        assert self._chunks("202501", "202503") == ["202501", "202502", "202503"]


# lazily import to avoid circular import at module load
@pytest.fixture(autouse=False)
def _patch_month_chunks(monkeypatch):
    """Allow TestMonthChunks to reference 04_main_core by alias."""
    import importlib.util, importlib
    spec = importlib.util.spec_from_file_location(
        "notebooks.four_main_core",
        os.path.join(os.path.dirname(__file__), "../notebooks/04_main_core.py"),
    )
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    sys.modules["notebooks.four_main_core"] = mod


# ===========================================================================
# resolve_windows
# ===========================================================================
class TestResolveWindows:

    def _rw(self, cfg, run_date, start=None, end=None):
        from notebooks.four_main_core import resolve_windows
        return resolve_windows(cfg, run_date, start, end)

    def test_backfill_enumerates_months(self):
        cfg = make_cfg(incremental_cutoff_day=5)
        result = self._rw(cfg, date(2026, 3, 15), "202501", "202503")
        assert result == ["202501", "202502", "202503"]

    def test_incremental_current_only_after_cutoff(self):
        cfg = make_cfg(incremental_cutoff_day=5)
        result = self._rw(cfg, date(2026, 3, 15))  # day 15 > cutoff 5
        assert result == ["202603"]

    def test_incremental_prev_plus_current_before_cutoff(self):
        cfg = make_cfg(incremental_cutoff_day=10)
        result = self._rw(cfg, date(2026, 3, 3))  # day 3 <= cutoff 10
        assert result == ["202602", "202603"]


# ===========================================================================
# DQ gate
# ===========================================================================
class TestCheckDQGate:

    def _mock_spark(self, rows):
        """Return a MagicMock spark where .sql().collect() returns rows."""
        spark = MagicMock()
        spark.sql.return_value.collect.return_value = rows
        return spark

    def test_no_deps_always_passes(self):
        from notebooks._framework_import import check_dq_gate
        cfg = make_cfg(depends_on_table_ids=[])
        ok, blocked = check_dq_gate([cfg], date(2026, 1, 31), "GROUND")
        assert ok is True
        assert blocked == []

    def test_upstream_succeeded_clears_gate(self):
        from notebooks._framework_import import check_dq_gate
        row = {"table_id": "upstream_tbl", "ok": 1}
        spark = self._mock_spark([MagicMock(**{"__getitem__": lambda s, k: row[k]})])

        cfg = make_cfg(depends_on_table_ids=["upstream_tbl"])
        with patch("notebooks._01_framework_core.SparkSession") as mock_ss:
            mock_ss.getActiveSession.return_value = spark
            ok, blocked = check_dq_gate([cfg], date(2026, 1, 31), "GROUND")
        assert ok is True

    def test_upstream_missing_blocks_gate(self):
        from notebooks._framework_import import check_dq_gate
        spark = self._mock_spark([])  # nothing in log

        cfg = make_cfg(depends_on_table_ids=["missing_upstream"])
        with patch("notebooks._01_framework_core.SparkSession") as mock_ss:
            mock_ss.getActiveSession.return_value = spark
            ok, blocked = check_dq_gate([cfg], date(2026, 1, 31), "GROUND")
        assert ok is False
        assert "missing_upstream" in blocked


# ===========================================================================
# Retry handler
# ===========================================================================
class TestRetryHandler:

    def test_success_on_first_try(self):
        from utils.retry_handler import with_retry
        calls = [0]
        @with_retry(max_attempts=3, initial_wait=0.001)
        def fn():
            calls[0] += 1
            return "ok"
        assert fn() == "ok"
        assert calls[0] == 1

    def test_retries_then_succeeds(self):
        from utils.retry_handler import with_retry
        calls = [0]
        @with_retry(max_attempts=3, initial_wait=0.001, backoff_multiplier=1.0)
        def fn():
            calls[0] += 1
            if calls[0] < 3:
                raise RuntimeError("transient")
            return "ok"
        assert fn() == "ok"
        assert calls[0] == 3

    def test_raises_after_max_attempts(self):
        from utils.retry_handler import with_retry
        @with_retry(max_attempts=2, initial_wait=0.001, backoff_multiplier=1.0)
        def fn():
            raise ValueError("permanent")
        with pytest.raises(ValueError, match="permanent"):
            fn()

    def test_backoff_doubles(self):
        from utils.retry_handler import _compute_wait
        w1 = _compute_wait(1, 30.0, 2.0, 9999.0, 0.0)
        w2 = _compute_wait(2, 30.0, 2.0, 9999.0, 0.0)
        w3 = _compute_wait(3, 30.0, 2.0, 9999.0, 0.0)
        assert abs(w1 - 30.0)  < 0.01
        assert abs(w2 - 60.0)  < 0.01
        assert abs(w3 - 120.0) < 0.01

    def test_backoff_capped_at_max(self):
        from utils.retry_handler import _compute_wait
        assert _compute_wait(99, 30.0, 2.0, 300.0, 0.0) == 300.0

    def test_only_retryable_exceptions_trigger_retry(self):
        from utils.retry_handler import with_retry
        calls = [0]
        @with_retry(max_attempts=3, initial_wait=0.001,
                    retryable_exceptions=(IOError,))
        def fn():
            calls[0] += 1
            raise TypeError("not retryable")
        with pytest.raises(TypeError):
            fn()
        assert calls[0] == 1  # no retry for TypeError


# ===========================================================================
# CloudAdapter
# ===========================================================================
class TestCloudAdapter:

    def _adapter(self, spark):
        from utils.cloud_adapter import CloudAdapter
        with patch("utils.cloud_adapter.get_cloud_config"), \
             patch("utils.cloud_adapter.get_storage_base", return_value="/tmp"):
            return CloudAdapter(spark)

    def test_delta_lake_calls_spark_table(self, spark):
        adapter = self._adapter(spark)
        spark.table = MagicMock(return_value=MagicMock())
        adapter.read_external("DELTA_LAKE", "some_db.some_table")
        spark.table.assert_called_once_with("some_db.some_table")

    def test_unknown_source_raises(self, spark):
        from utils.cloud_adapter import CloudAdapterError
        adapter = self._adapter(spark)
        with pytest.raises(CloudAdapterError, match="Unsupported source_system"):
            adapter.read_external("UNKNOWN_SYSTEM", "tbl")

    def test_optimize_noop_on_gcp(self, spark):
        from utils.cloud_adapter import CloudAdapter
        with patch("utils.cloud_adapter.get_cloud_config"), \
             patch("utils.cloud_adapter.get_storage_base", return_value="/tmp"):
            adapter        = CloudAdapter(spark)
            adapter.env    = "gcp"
            spark_sql_mock = MagicMock()
            adapter.spark  = spark_sql_mock
            adapter.optimize("some_table")
            spark_sql_mock.sql.assert_not_called()

    def test_table_exists_true(self, spark):
        adapter = self._adapter(spark)
        adapter.spark = MagicMock()
        adapter.spark.sql.return_value = MagicMock()   # DESCRIBE succeeds
        assert adapter.table_exists("some.table") is True

    def test_table_exists_false(self, spark):
        adapter = self._adapter(spark)
        adapter.spark = MagicMock()
        adapter.spark.sql.side_effect = Exception("Table not found")
        assert adapter.table_exists("no.such.table") is False


# ===========================================================================
# Transformation loader
# ===========================================================================
class TestTransformationLoader:

    def test_ground_account_importable(self):
        import transformations.ground.account as m
        assert callable(getattr(m, "load_fxg_acct_bill_mth_hist", None))
        assert callable(getattr(m, "load_fxg_acct_bill_mth_hist_sp", None))

    def test_ground_facility_importable(self):
        import transformations.ground.facility as m
        assert callable(getattr(m, "load_fxg_fac_enti_bill_mth_hist", None))
        assert callable(getattr(m, "load_fxg_fac_enti_bill_mth_hist_sp", None))

    def test_ground_country_importable(self):
        import transformations.ground.country as m
        assert callable(getattr(m, "load_fxg_ctry_enti_bill_mth_hist", None))
        assert callable(getattr(m, "load_fxg_ctry_enti_bill_mth_hist_sp", None))

    def test_ground_global_importable(self):
        import transformations.ground.global_ as m
        assert callable(getattr(m, "load_fxg_glbl_enti_bill_mth_hist", None))
        assert callable(getattr(m, "load_fxg_glbl_enti_bill_mth_hist_sp", None))

    def test_unknown_opco_raises(self):
        from notebooks.three_transformation import get_transformed_df
        with pytest.raises(ValueError, match="No transformation module"):
            get_transformed_df("UNKNOWN", "FACILITY", ["tbl"], "load_fn", "202501")

    def test_unknown_layer_raises(self):
        from notebooks.three_transformation import get_transformed_df
        with pytest.raises(ValueError, match="No transformation module"):
            get_transformed_df("GROUND", "BRONZE", ["tbl"], "load_fn", "202501")

    def test_missing_function_raises(self):
        from notebooks.three_transformation import get_transformed_df
        with pytest.raises(ValueError, match="not found"):
            get_transformed_df("GROUND", "FACILITY", ["tbl"],
                               "nonexistent_fn", "202501")


# ===========================================================================
# seed_metadata dry-run
# ===========================================================================
class TestSeedMetadata:

    def test_dry_run_produces_six_rows(self, capsys):
        from config.seed_metadata import build_rows
        rows = build_rows()
        assert len(rows) == 6, f"Expected 6 seed rows, got {len(rows)}"

    def test_all_rows_have_required_keys(self):
        from config.seed_metadata import build_rows
        required = {
            "table_id", "source_system", "source_table_name", "target_table_name",
            "target_dataset_layer", "opco", "load_process", "data_quality_rules",
            "retry_max_attempts", "alert_config", "is_active",
        }
        for row in build_rows():
            missing = required - set(row.keys())
            assert not missing, f"Row {row['table_id']} missing keys: {missing}"

    def test_depends_on_set_for_downstream_tables(self):
        from config.seed_metadata import build_rows
        rows = {r["table_id"]: r for r in build_rows()}
        # Country depends on facility
        assert rows["fxg_ctry_enti_bill_mth_hist_non_sp"]["depends_on_table_ids"] \
               == "fxg_fac_enti_bill_mth_hist_non_sp"
        # Global depends on country
        assert rows["fxg_glbl_enti_bill_mth_hist_non_sp"]["depends_on_table_ids"] \
               == "fxg_ctry_enti_bill_mth_hist_non_sp"

    def test_dq_rules_are_valid_json(self):
        from config.seed_metadata import build_rows
        for row in build_rows():
            rules = json.loads(row["data_quality_rules"])
            assert isinstance(rules, list)
            for rule in rules:
                assert "rule_id"   in rule
                assert "severity"  in rule
                assert "error_threshold_pct" in rule

    def test_alert_config_is_valid_json(self):
        from config.seed_metadata import build_rows
        for row in build_rows():
            cfg = json.loads(row["alert_config"])
            assert isinstance(cfg, list)
            for entry in cfg:
                assert "channel"   in entry
                assert "on_status" in entry


# ===========================================================================
# run_config.json schema
# ===========================================================================
class TestRunConfig:

    @pytest.fixture
    def cfg(self):
        path = os.path.join(os.path.dirname(__file__), "../config/run_config.json")
        with open(path) as f:
            return json.load(f)

    def test_has_runs_key(self, cfg):
        assert "runs" in cfg
        assert isinstance(cfg["runs"], list)
        assert len(cfg["runs"]) > 0

    def test_each_run_has_table_id_or_schedule_group(self, cfg):
        for run in cfg["runs"]:
            has_tables = bool(run.get("table_id"))
            has_group  = bool(run.get("schedule_group"))
            assert has_tables or has_group, \
                f"Run block must have table_id or schedule_group: {run}"

    def test_date_fields_are_yyyymm_or_null(self, cfg):
        import re
        pattern = re.compile(r"^\d{6}$")
        for run in cfg["runs"]:
            for field in ("start_date", "end_date"):
                val = run.get(field)
                if val is not None:
                    assert pattern.match(str(val)), \
                        f"Field {field}={val!r} is not YYYYMM format"

    def test_env_field_is_valid(self, cfg):
        assert cfg.get("env", "azure") in ("azure", "gcp")
