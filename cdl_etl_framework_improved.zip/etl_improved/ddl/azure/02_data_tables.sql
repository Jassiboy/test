-- =============================================================================
-- CDL ETL Framework — Pipeline Data Tables  (Azure Databricks + Delta Lake)
-- Schema : cdl_data (mapped to Unity Catalog: {catalog}.cdl_data)
--
-- Tables created here are the actual business output of the pipeline.
-- All are Delta tables, partitioned by ratemnth for cost-efficient
-- replaceWhere writes and partition-pruned reads.
--
-- Temp/stage tables follow the naming convention:
--   {target_table}_temp  — truncated before each load batch
-- =============================================================================

CREATE SCHEMA IF NOT EXISTS cdl_data
    COMMENT 'CDL ETL pipeline output — Facility, Country and Global layers';

-- ---------------------------------------------------------------------------
-- Shared column macro (comment block — Spark SQL has no macros)
-- Every pipeline output table carries these audit columns:
--   _run_batch_id  STRING   — links row back to cdl_table_run_log
--   _source_system STRING   — source system identifier
--   _loaded_at     TIMESTAMP — when this row was written by the pipeline
-- ---------------------------------------------------------------------------


-- ===========================================================================
-- FACILITY LAYER
-- ===========================================================================

-- ---------------------------------------------------------------------------
-- FXG_FAC_ENTI_BILL_MTH_HIST  (production)
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS cdl_data.FXG_FAC_ENTI_BILL_MTH_HIST (

    -- Rate month — partition key
    ratemnth            STRING        NOT NULL COMMENT 'Rate month YYYYMM',
    shipmnth            STRING        COMMENT 'Ship month YYYYMM',
    dlvrmnth            STRING        COMMENT 'Delivery month YYYYMM',

    -- SE Shipper entity hierarchy
    se_shpr_glbl_enti_nbr   STRING,
    se_shpr_ctry_enti_nbr   STRING,
    se_shpr_fac_enti_nbr    STRING,
    se_shpr_sls_seg_cd       STRING,
    se_shpr_sub_industry_cd  STRING,

    -- SE Payer entity hierarchy
    se_payr_glbl_enti_nbr    STRING,
    se_payr_ctry_enti_nbr    STRING,
    se_payr_fac_enti_nbr     STRING,
    se_payr_sls_seg_cd       STRING,
    se_payr_sub_industry_cd  STRING,

    -- CE Payer entity hierarchy
    ce_payr_glbl_enti_nbr    STRING,
    ce_payr_ctry_enti_nbr    STRING,
    ce_payr_fac_enti_nbr     STRING,
    ce_payr_sls_seg_cd       STRING,

    -- Service classification
    svc_cat_cd          STRING        COMMENT 'Service category code',
    product             STRING        COMMENT 'Product code',

    -- Origin / destination geography
    orig_ctry_cd        STRING,
    orig_st_cd          STRING,
    orig_msa            STRING,
    dest_ctry_cd        STRING,
    dest_st_cd          STRING,
    dest_msa            STRING,
    orig_cbsa           STRING,
    dest_cbsa           STRING,

    -- Shipment attributes
    zone_cd             STRING,
    wgtcat              STRING,
    rsd_flg             STRING,
    lrnn_flg            STRING,
    ec_flg              STRING        COMMENT 'E-commerce flag Y/N',
    dim_avail_flg       STRING,
    revmnth             STRING,
    autogrp             STRING,

    -- Volume and revenue metrics
    packages            DOUBLE,
    netrev              DOUBLE,
    fgtchrg             DOUBLE,
    discount            DOUBLE,
    fuelsch             DOUBLE,
    totalsch            DOUBLE,
    apounds             DOUBLE,
    rpounds             DOUBLE,
    pkg_cubic_size      DOUBLE,

    -- Accessorial amounts
    adh_amt             DOUBLE,
    das_amt             DOUBLE,
    oth_amt             DOUBLE,
    ovs_amt             DOUBLE,
    dlg_amt             DOUBLE,
    dresi_amt           DOUBLE,
    resi_amt            DOUBLE,

    -- Accessorial quantities
    adh_qty             DOUBLE,
    das_qty             DOUBLE,
    oth_qty             DOUBLE,
    ovs_qty             DOUBLE,
    dlg_qty             DOUBLE,
    dresi_qty           DOUBLE,
    resi_qty            DOUBLE,

    -- Pipeline audit columns
    _run_batch_id       STRING        COMMENT 'Links to cdl_table_run_log.run_batch_id',
    _source_system      STRING        COMMENT 'Source system identifier',
    _loaded_at          TIMESTAMP     COMMENT 'Row load timestamp'
)
USING DELTA
PARTITIONED BY (ratemnth)
TBLPROPERTIES (
    'delta.autoOptimize.optimizeWrite' = 'true',
    'delta.autoOptimize.autoCompact'   = 'true',
    'delta.enableChangeDataFeed'       = 'true'
)
COMMENT 'Facility-level entity billing monthly history (non-SP + SP combined)';

-- Stage / temp table — truncated before each batch, never queried by consumers
CREATE TABLE IF NOT EXISTS cdl_data.FXG_FAC_ENTI_BILL_MTH_HIST_temp
    LIKE cdl_data.FXG_FAC_ENTI_BILL_MTH_HIST
    TBLPROPERTIES ('delta.autoOptimize.optimizeWrite' = 'true');


-- ===========================================================================
-- COUNTRY LAYER
-- ===========================================================================

CREATE TABLE IF NOT EXISTS cdl_data.FXG_CTRY_ENTI_BILL_MTH_HIST (

    ratemnth                 STRING  NOT NULL,
    shipmnth                 STRING,
    dlvrmnth                 STRING,

    se_shpr_glbl_enti_nbr    STRING,
    se_shpr_ctry_enti_nbr    STRING,
    se_shpr_sls_seg_cd       STRING,
    se_shpr_sub_industry_cd  STRING,

    se_payr_glbl_enti_nbr    STRING,
    se_payr_ctry_enti_nbr    STRING,
    se_payr_sls_seg_cd       STRING,
    se_payr_sub_industry_cd  STRING,

    ce_payr_glbl_enti_nbr    STRING,
    ce_payr_ctry_enti_nbr    STRING,
    ce_payr_sls_seg_cd       STRING,

    svc_cat_cd               STRING,
    product                  STRING,
    orig_ctry_cd             STRING,
    orig_st_cd               STRING,
    orig_msa                 STRING,
    dest_ctry_cd             STRING,
    dest_st_cd               STRING,
    dest_msa                 STRING,
    zone_cd                  STRING,
    wgtcat                   STRING,
    rsd_flg                  STRING,
    lrnn_flg                 STRING,
    ec_flg                   STRING,
    dim_avail_flg            STRING,
    revmnth                  STRING,
    autogrp                  STRING,

    packages        DOUBLE,
    netrev          DOUBLE,
    fgtchrg         DOUBLE,
    discount        DOUBLE,
    fuelsch         DOUBLE,
    totalsch        DOUBLE,
    apounds         DOUBLE,
    rpounds         DOUBLE,
    pkg_cubic_size  DOUBLE,
    adh_amt         DOUBLE,
    das_amt         DOUBLE,
    oth_amt         DOUBLE,
    ovs_amt         DOUBLE,
    dlg_amt         DOUBLE,
    dresi_amt       DOUBLE,
    resi_amt        DOUBLE,
    adh_qty         DOUBLE,
    das_qty         DOUBLE,
    oth_qty         DOUBLE,
    ovs_qty         DOUBLE,
    dlg_qty         DOUBLE,
    dresi_qty       DOUBLE,
    resi_qty        DOUBLE,

    _run_batch_id   STRING,
    _source_system  STRING,
    _loaded_at      TIMESTAMP
)
USING DELTA
PARTITIONED BY (ratemnth)
TBLPROPERTIES (
    'delta.autoOptimize.optimizeWrite' = 'true',
    'delta.autoOptimize.autoCompact'   = 'true',
    'delta.enableChangeDataFeed'       = 'true'
)
COMMENT 'Country-level entity billing monthly history';

CREATE TABLE IF NOT EXISTS cdl_data.FXG_CTRY_ENTI_BILL_MTH_HIST_temp
    LIKE cdl_data.FXG_CTRY_ENTI_BILL_MTH_HIST
    TBLPROPERTIES ('delta.autoOptimize.optimizeWrite' = 'true');


-- ===========================================================================
-- GLOBAL LAYER
-- ===========================================================================

CREATE TABLE IF NOT EXISTS cdl_data.FXG_GLBL_ENTI_BILL_MTH_HIST (

    ratemnth                 STRING  NOT NULL,
    shipmnth                 STRING,
    dlvrmnth                 STRING,

    se_shpr_glbl_enti_nbr    STRING,
    se_shpr_sls_seg_cd       STRING,
    se_shpr_sub_industry_cd  STRING,

    se_payr_glbl_enti_nbr    STRING,
    se_payr_sls_seg_cd       STRING,
    se_payr_sub_industry_cd  STRING,

    ce_payr_glbl_enti_nbr    STRING,
    ce_payr_sls_seg_cd       STRING,

    svc_cat_cd               STRING,
    product                  STRING,
    orig_ctry_cd             STRING,
    orig_st_cd               STRING,
    orig_msa                 STRING,
    dest_ctry_cd             STRING,
    dest_st_cd               STRING,
    dest_msa                 STRING,
    zone_cd                  STRING,
    wgtcat                   STRING,
    rsd_flg                  STRING,
    lrnn_flg                 STRING,
    ec_flg                   STRING,
    dim_avail_flg            STRING,
    revmnth                  STRING,

    packages        DOUBLE,
    netrev          DOUBLE,
    fgtchrg         DOUBLE,
    discount        DOUBLE,
    fuelsch         DOUBLE,
    totalsch        DOUBLE,
    apounds         DOUBLE,
    rpounds         DOUBLE,
    pkg_cubic_size  DOUBLE,
    adh_amt         DOUBLE,
    das_amt         DOUBLE,
    oth_amt         DOUBLE,
    ovs_amt         DOUBLE,
    dlg_amt         DOUBLE,
    dresi_amt       DOUBLE,
    resi_amt        DOUBLE,
    adh_qty         DOUBLE,
    das_qty         DOUBLE,
    oth_qty         DOUBLE,
    ovs_qty         DOUBLE,
    dlg_qty         DOUBLE,
    dresi_qty       DOUBLE,
    resi_qty        DOUBLE,

    _run_batch_id   STRING,
    _source_system  STRING,
    _loaded_at      TIMESTAMP
)
USING DELTA
PARTITIONED BY (ratemnth)
TBLPROPERTIES (
    'delta.autoOptimize.optimizeWrite' = 'true',
    'delta.autoOptimize.autoCompact'   = 'true',
    'delta.enableChangeDataFeed'       = 'true'
)
COMMENT 'Global-level entity billing monthly history';

CREATE TABLE IF NOT EXISTS cdl_data.FXG_GLBL_ENTI_BILL_MTH_HIST_temp
    LIKE cdl_data.FXG_GLBL_ENTI_BILL_MTH_HIST
    TBLPROPERTIES ('delta.autoOptimize.optimizeWrite' = 'true');
