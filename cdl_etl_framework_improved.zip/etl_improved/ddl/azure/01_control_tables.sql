-- =============================================================================
-- CDL ETL Framework — Control Tables  (Azure Databricks + Delta Lake)
-- Schema : cdl_metadata
-- Tables :
--   1. cdl_table_config   — all pipeline topology, DQ rules, retry, alerts,
--                           watermark, dependency gate in one row per mapping
--   2. cdl_table_run_log  — execution audit, one row per (table + month + attempt)
-- =============================================================================

CREATE SCHEMA IF NOT EXISTS cdl_metadata
    COMMENT 'CDL ETL framework control and audit tables';

-- ---------------------------------------------------------------------------
-- 1. cdl_table_config
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS cdl_metadata.cdl_table_config (

    -- Identity
    table_id                STRING        NOT NULL
        COMMENT 'Unique logical ID e.g. fxg_fac_enti_bill_mth_hist_non_sp',

    -- Source
    source_system           STRING        NOT NULL
        COMMENT 'ACCOUNT_DB | DELTA_LAKE | ORACLE | EDW | SQL_SERVER',
    source_table_name       STRING        NOT NULL
        COMMENT 'Physical source table name, or JSON array for multi-source tables',
    source_filter           STRING
        COMMENT 'Optional SQL WHERE clause applied at source read time',

    -- Target
    target_system           STRING        NOT NULL
        COMMENT 'DELTA_LAKE | BIGQUERY',
    target_table_name       STRING        NOT NULL
        COMMENT 'Physical target table name (fully qualified)',
    target_dataset_layer    STRING        NOT NULL
        COMMENT 'Pipeline layer: ACCOUNT | FACILITY | COUNTRY | GLOBAL',
    opco                    STRING        NOT NULL
        COMMENT 'Operating company: GROUND | FREIGHT | INTERNATIONAL',

    -- Scheduling
    schedule_group          STRING
        COMMENT 'Logical group for batch scheduling e.g. GROUND_MONTHLY',
    load_process            STRING        NOT NULL
        COMMENT 'Function name to call in transformations/{opco}/{layer}.py',

    -- Ingestion
    ingestion_mode          STRING        NOT NULL
        COMMENT 'FULL | INCR | CDC',
    load_frequency          STRING        NOT NULL
        COMMENT 'DAILY | MONTHLY | BOTH',
    watermark_column        STRING
        COMMENT 'Column used to track delta for INCR mode e.g. ratemnth',
    last_watermark_value    TIMESTAMP
        COMMENT 'Persisted watermark — updated after each successful INCR run',
    last_successful_run     DATE
        COMMENT 'Date of last successful run',
    incremental_cutoff_day  INT
        COMMENT 'Day-of-month threshold: if today <= this, also re-process previous month',
    partition_col           STRING
        COMMENT 'Target partition column e.g. ratemnth',
    merge_keys              STRING
        COMMENT 'Comma-separated PK columns for MERGE e.g. ratemnth,se_payr_glbl_enti_nbr,svc_cat_cd',

    -- Data Quality
    -- JSON array of rule objects. Schema per element:
    -- {
    --   "rule_id"             : "dq_row_count",
    --   "rule_type"           : "ROW_COUNT | SUM_COMPARE | UNIQUENESS | NOT_NULL | RANGE",
    --   "target_column"       : "netrev",       -- null for table-level rules
    --   "rule_expression"     : "netrev",       -- column name or SQL expression
    --   "severity"            : "CRITICAL | WARNING | INFO",
    --   "error_threshold_pct" : 1.0             -- max allowed % diff / failure rate
    -- }
    data_quality_rules      STRING
        COMMENT 'JSON array of DQ rule objects — see column comment for schema',
    dq_status               BOOLEAN
        COMMENT 'true = DQ checks enabled; false = skip DQ entirely for this table',
    dq_threshold_pct        DOUBLE
        COMMENT 'Min % of rows passing CRITICAL rules to mark run as DQ-passed (0-100)',

    -- Dependency gate
    depends_on_table_ids    STRING
        COMMENT 'Comma-separated table_ids that must have status=SUCCESS in todays log before this runs. NULL = no gate.',

    -- Retry policy
    retry_max_attempts      INT
        COMMENT 'Total attempts including first try. Default 3.',
    retry_initial_wait_sec  INT
        COMMENT 'Seconds to wait before first retry. Default 30.',
    retry_backoff_multiplier DOUBLE
        COMMENT 'Exponential multiplier per attempt. Default 2.0.',
    retry_max_wait_sec      INT
        COMMENT 'Upper bound on inter-retry wait in seconds. Default 300.',

    -- Alerting
    -- JSON array of alert channel objects. Schema per element:
    -- {
    --   "channel"    : "EMAIL | TEAMS | SLACK",
    --   "recipients" : "user@company.com,user2@company.com  OR  https://webhook...",
    --   "on_status"  : ["FAILED", "HALTED"]
    -- }
    alert_config            STRING
        COMMENT 'JSON array of alert channel objects — see column comment for schema',

    -- Lifecycle
    is_active               BOOLEAN       NOT NULL
        COMMENT 'false = skip this mapping on every run without removing the row',
    created_at              TIMESTAMP     NOT NULL,
    updated_at              TIMESTAMP     NOT NULL,
    created_by              STRING,

    CONSTRAINT pk_cdl_table_config PRIMARY KEY (table_id)
)
USING DELTA
TBLPROPERTIES (
    'delta.enableChangeDataFeed'       = 'true',
    'delta.autoOptimize.optimizeWrite' = 'true',
    'delta.autoOptimize.autoCompact'   = 'true'
)
COMMENT 'CDL master config — all pipeline behaviour driven from here';


-- ---------------------------------------------------------------------------
-- 2. cdl_table_run_log
--    One row per (run_batch_id, table_id, load_mnth_start, attempt_number).
--    Partitioned by load_mnth_start for efficient time-based queries.
--    DQ result is stored as a JSON execution summary in execution_summary —
--    no separate dq_results table needed.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS cdl_metadata.cdl_table_run_log (

    -- Identity
    run_batch_id        STRING        NOT NULL
        COMMENT 'Batch-level ID shared by all tables in one scheduler run e.g. BATCH_20260120_143022_A3F9B1_prod',
    table_id            STRING        NOT NULL
        COMMENT 'FK → cdl_table_config.table_id',
    log_time            TIMESTAMP     NOT NULL
        COMMENT 'Wall-clock time this row was written',

    -- Context
    opco                STRING        NOT NULL,
    dataset_layer       STRING        NOT NULL
        COMMENT 'ACCOUNT | FACILITY | COUNTRY | GLOBAL',
    table_name          STRING        NOT NULL
        COMMENT 'Physical target table name',
    load_process        STRING
        COMMENT 'Transformation function that was called',

    -- Month window
    load_mnth_start     STRING        NOT NULL
        COMMENT 'First month in the processing window YYYYMM — partition key',
    load_mnth_end       STRING        NOT NULL
        COMMENT 'Last month in the processing window YYYYMM',

    -- Execution state
    status              STRING        NOT NULL
        COMMENT 'RUNNING | SUCCESS | PARTIAL_SUCCESS | FAILED | RETRYING',
    message             STRING
        COMMENT 'Top-level human-readable status message',
    attempt_number      INT           NOT NULL
        COMMENT 'Retry attempt sequence starting at 1. Each attempt = one row.',

    -- Watermark
    watermark_start     TIMESTAMP
        COMMENT 'Low-watermark used in this run (from last_watermark_value)',
    watermark_end       TIMESTAMP
        COMMENT 'High-watermark written back to cdl_table_config on success',

    -- Timing
    started_at          TIMESTAMP     COMMENT 'Execution start (after log_start())',
    completed_at        TIMESTAMP     COMMENT 'Execution end',
    duration_seconds    INT           COMMENT 'Elapsed seconds',

    -- Volume
    rows_read           BIGINT        COMMENT 'Records read from stage',
    rows_written        BIGINT        COMMENT 'Records promoted to target',

    -- DQ summary — aggregated across all months and all rules
    -- dq_result  : PASS | FAIL | PARTIAL | SKIPPED
    -- execution_summary : JSON blob — see notebooks/01_framework_core._build_execution_summary()
    -- {
    --   "months_passed": ["202501","202502"],
    --   "months_failed": ["202503"],
    --   "month_details": [
    --     {
    --       "month": "202501", "dq_status": "PASS", "loaded": true,
    --       "rows_written": 12345,
    --       "rules": [{"rule_id":"dq_row_count","passed":true,"diff_pct":0.0}]
    --     }
    --   ]
    -- }
    dq_result           STRING        COMMENT 'Rolled-up DQ outcome: PASS | FAIL | PARTIAL | SKIPPED',
    execution_summary   STRING        COMMENT 'JSON — per-month DQ detail and row counts',

    CONSTRAINT pk_cdl_run_log PRIMARY KEY (run_batch_id, table_id, load_mnth_start, attempt_number)
)
USING DELTA
PARTITIONED BY (load_mnth_start)
TBLPROPERTIES (
    'delta.enableChangeDataFeed'       = 'true',
    'delta.autoOptimize.optimizeWrite' = 'true',
    'delta.logRetentionDuration'       = 'interval 90 days'
)
COMMENT 'Full execution audit log — one row per table per month window per attempt';


-- ---------------------------------------------------------------------------
-- Optimisation hints (run after initial data load)
-- ---------------------------------------------------------------------------
-- OPTIMIZE cdl_metadata.cdl_table_config  ZORDER BY (opco, target_dataset_layer);
-- OPTIMIZE cdl_metadata.cdl_table_run_log ZORDER BY (opco, dataset_layer, load_mnth_start);
