-- =============================================================================
-- CDL ETL Framework — Control Tables  (GCP BigQuery)
-- Dataset : {project}.cdl_metadata
--
-- BigQuery notes vs Azure DDL:
--   - No USING DELTA / TBLPROPERTIES — BQ manages storage
--   - Partition by DATE column (not STRING) → DATE(log_time) or run_date
--   - CLUSTER BY replaces ZORDER BY
--   - BOOL not BOOLEAN, INT64 not INT, FLOAT64 not DOUBLE
--   - No PRIMARY KEY constraint enforcement in BQ (logical only)
-- =============================================================================

-- Create dataset (run via bq CLI or Terraform before applying this file)
-- bq mk --dataset --location=US --description="CDL ETL control tables" project:cdl_metadata

-- ---------------------------------------------------------------------------
-- 1. cdl_table_config
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `project.cdl_metadata.cdl_table_config` (

    table_id                STRING  NOT NULL OPTIONS(description='Unique logical pipeline ID'),

    -- Source
    source_system           STRING  NOT NULL OPTIONS(description='DELTA_LAKE | BIGQUERY | ORACLE | SQL_SERVER'),
    source_table_name       STRING  NOT NULL OPTIONS(description='Physical source table, or JSON array for multi-source'),
    source_filter           STRING           OPTIONS(description='Optional SQL WHERE clause at source read time'),

    -- Target
    target_system           STRING  NOT NULL OPTIONS(description='BIGQUERY | DELTA_LAKE'),
    target_table_name       STRING  NOT NULL OPTIONS(description='Physical target table (fully qualified)'),
    target_dataset_layer    STRING  NOT NULL OPTIONS(description='ACCOUNT | FACILITY | COUNTRY | GLOBAL'),
    opco                    STRING  NOT NULL OPTIONS(description='Operating company: GROUND | FREIGHT | INTERNATIONAL'),

    -- Scheduling
    schedule_group          STRING           OPTIONS(description='Logical group name for batch scheduling'),
    load_process            STRING  NOT NULL OPTIONS(description='Function name in transformations/{opco}/{layer}.py'),

    -- Ingestion
    ingestion_mode          STRING  NOT NULL OPTIONS(description='FULL | INCR | CDC'),
    load_frequency          STRING  NOT NULL OPTIONS(description='DAILY | MONTHLY | BOTH'),
    watermark_column        STRING           OPTIONS(description='Column for incremental tracking e.g. ratemnth'),
    last_watermark_value    TIMESTAMP        OPTIONS(description='Persisted watermark — updated after each successful INCR run'),
    last_successful_run     DATE             OPTIONS(description='Date of last successful run'),
    incremental_cutoff_day  INT64            OPTIONS(description='Day-of-month: if today <= this, also process previous month'),
    partition_col           STRING           OPTIONS(description='Target partition column e.g. ratemnth'),
    merge_keys              STRING           OPTIONS(description='Comma-separated PK columns for MERGE'),

    -- DQ config — JSON array, same schema as Azure DDL
    data_quality_rules      STRING           OPTIONS(description='JSON array of DQ rule objects'),
    dq_status               BOOL             OPTIONS(description='true = DQ checks enabled'),
    dq_threshold_pct        FLOAT64          OPTIONS(description='Min % passing CRITICAL rules to mark DQ passed'),

    -- Dependency gate
    depends_on_table_ids    STRING           OPTIONS(description='Comma-separated table_ids that must succeed first'),

    -- Retry policy
    retry_max_attempts      INT64,
    retry_initial_wait_sec  INT64,
    retry_backoff_multiplier FLOAT64,
    retry_max_wait_sec      INT64,

    -- Alerting — JSON array, same schema as Azure DDL
    alert_config            STRING           OPTIONS(description='JSON array of alert channel objects'),

    -- Lifecycle
    is_active               BOOL    NOT NULL OPTIONS(description='false = skip without removing row'),
    created_at              TIMESTAMP NOT NULL,
    updated_at              TIMESTAMP NOT NULL,
    created_by              STRING
)
OPTIONS(
    description = 'CDL master config — all pipeline behaviour driven from here'
);


-- ---------------------------------------------------------------------------
-- 2. cdl_table_run_log
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `project.cdl_metadata.cdl_table_run_log` (

    run_batch_id        STRING    NOT NULL OPTIONS(description='Batch-level ID shared across all tables in one scheduler run'),
    table_id            STRING    NOT NULL OPTIONS(description='FK → cdl_table_config.table_id'),
    log_time            TIMESTAMP NOT NULL OPTIONS(description='Wall-clock time this row was written'),

    opco                STRING    NOT NULL,
    dataset_layer       STRING    NOT NULL OPTIONS(description='ACCOUNT | FACILITY | COUNTRY | GLOBAL'),
    table_name          STRING    NOT NULL OPTIONS(description='Physical target table name'),
    load_process        STRING             OPTIONS(description='Transformation function called'),

    load_mnth_start     STRING    NOT NULL OPTIONS(description='First month in processing window YYYYMM — partition key'),
    load_mnth_end       STRING    NOT NULL OPTIONS(description='Last month in processing window YYYYMM'),

    status              STRING    NOT NULL OPTIONS(description='RUNNING | SUCCESS | PARTIAL_SUCCESS | FAILED | RETRYING'),
    message             STRING             OPTIONS(description='Top-level human-readable message'),
    attempt_number      INT64     NOT NULL OPTIONS(description='Retry sequence starting at 1 — each attempt = one row'),

    watermark_start     TIMESTAMP          OPTIONS(description='Low-watermark used this run'),
    watermark_end       TIMESTAMP          OPTIONS(description='High-watermark written back on success'),

    started_at          TIMESTAMP,
    completed_at        TIMESTAMP,
    duration_seconds    INT64,

    rows_read           INT64,
    rows_written        INT64,

    -- DQ — same JSON schema as Azure, collapsed to two columns
    dq_result           STRING             OPTIONS(description='PASS | FAIL | PARTIAL | SKIPPED'),
    execution_summary   STRING             OPTIONS(description='JSON — per-month DQ detail and row counts')
)
PARTITION BY DATE(log_time)
CLUSTER BY opco, dataset_layer, load_mnth_start
OPTIONS(
    partition_expiration_days = 1095,
    description = 'Execution audit log — one row per table per month window per attempt'
);
