-- =============================================================================
-- CDL ETL Framework — Pipeline Data Tables  (GCP BigQuery)
-- Dataset : {project}.cdl_data
--
-- All tables are DAY-partitioned on ratemnth (converted to DATE on write).
-- Clustered on the most common filter columns for query cost reduction.
-- Temp tables use a _temp suffix and are overwritten before each batch.
-- =============================================================================

-- bq mk --dataset --location=US --description="CDL pipeline output" project:cdl_data

-- ===========================================================================
-- FACILITY LAYER
-- ===========================================================================

CREATE TABLE IF NOT EXISTS `project.cdl_data.FXG_FAC_ENTI_BILL_MTH_HIST` (

    ratemnth                 STRING    NOT NULL OPTIONS(description='Rate month YYYYMM'),
    shipmnth                 STRING,
    dlvrmnth                 STRING,

    se_shpr_glbl_enti_nbr    STRING,
    se_shpr_ctry_enti_nbr    STRING,
    se_shpr_fac_enti_nbr     STRING,
    se_shpr_sls_seg_cd       STRING,
    se_shpr_sub_industry_cd  STRING,

    se_payr_glbl_enti_nbr    STRING,
    se_payr_ctry_enti_nbr    STRING,
    se_payr_fac_enti_nbr     STRING,
    se_payr_sls_seg_cd       STRING,
    se_payr_sub_industry_cd  STRING,

    ce_payr_glbl_enti_nbr    STRING,
    ce_payr_ctry_enti_nbr    STRING,
    ce_payr_fac_enti_nbr     STRING,
    ce_payr_sls_seg_cd       STRING,

    svc_cat_cd               STRING,
    product                  STRING,
    orig_ctry_cd             STRING,
    orig_st_cd               STRING,
    orig_msa                 STRING,
    dest_ctry_cd             STRING,
    dest_st_cd               STRING,
    dest_msa                 STRING,
    orig_cbsa                STRING,
    dest_cbsa                STRING,
    zone_cd                  STRING,
    wgtcat                   STRING,
    rsd_flg                  STRING,
    lrnn_flg                 STRING,
    ec_flg                   STRING,
    dim_avail_flg            STRING,
    revmnth                  STRING,
    autogrp                  STRING,

    packages        FLOAT64,
    netrev          FLOAT64,
    fgtchrg         FLOAT64,
    discount        FLOAT64,
    fuelsch         FLOAT64,
    totalsch        FLOAT64,
    apounds         FLOAT64,
    rpounds         FLOAT64,
    pkg_cubic_size  FLOAT64,
    adh_amt         FLOAT64,
    das_amt         FLOAT64,
    oth_amt         FLOAT64,
    ovs_amt         FLOAT64,
    dlg_amt         FLOAT64,
    dresi_amt       FLOAT64,
    resi_amt        FLOAT64,
    adh_qty         FLOAT64,
    das_qty         FLOAT64,
    oth_qty         FLOAT64,
    ovs_qty         FLOAT64,
    dlg_qty         FLOAT64,
    dresi_qty       FLOAT64,
    resi_qty        FLOAT64,

    _run_batch_id   STRING,
    _source_system  STRING,
    _loaded_at      TIMESTAMP
)
PARTITION BY RANGE_BUCKET(CAST(ratemnth AS INT64), GENERATE_ARRAY(202001, 203001, 1))
CLUSTER BY se_payr_glbl_enti_nbr, svc_cat_cd, orig_ctry_cd
OPTIONS(description = 'Facility-level entity billing monthly history');

-- Temp table (identical schema, no partition expiry needed)
CREATE TABLE IF NOT EXISTS `project.cdl_data.FXG_FAC_ENTI_BILL_MTH_HIST_temp`
    LIKE `project.cdl_data.FXG_FAC_ENTI_BILL_MTH_HIST`
OPTIONS(expiration_timestamp = NULL, description = 'Stage table — truncated before each batch');


-- ===========================================================================
-- COUNTRY LAYER
-- ===========================================================================

CREATE TABLE IF NOT EXISTS `project.cdl_data.FXG_CTRY_ENTI_BILL_MTH_HIST` (

    ratemnth                 STRING    NOT NULL,
    shipmnth                 STRING,
    dlvrmnth                 STRING,

    se_shpr_glbl_enti_nbr    STRING,
    se_shpr_ctry_enti_nbr    STRING,
    se_shpr_sls_seg_cd       STRING,
    se_shpr_sub_industry_cd  STRING,

    se_payr_glbl_enti_nbr    STRING,
    se_payr_ctry_enti_nbr    STRING,
    se_payr_sls_seg_cd       STRING,
    se_payr_sub_industry_cd  STRING,

    ce_payr_glbl_enti_nbr    STRING,
    ce_payr_ctry_enti_nbr    STRING,
    ce_payr_sls_seg_cd       STRING,

    svc_cat_cd               STRING,
    product                  STRING,
    orig_ctry_cd             STRING,
    orig_st_cd               STRING,
    orig_msa                 STRING,
    dest_ctry_cd             STRING,
    dest_st_cd               STRING,
    dest_msa                 STRING,
    zone_cd                  STRING,
    wgtcat                   STRING,
    rsd_flg                  STRING,
    lrnn_flg                 STRING,
    ec_flg                   STRING,
    dim_avail_flg            STRING,
    revmnth                  STRING,
    autogrp                  STRING,

    packages        FLOAT64,
    netrev          FLOAT64,
    fgtchrg         FLOAT64,
    discount        FLOAT64,
    fuelsch         FLOAT64,
    totalsch        FLOAT64,
    apounds         FLOAT64,
    rpounds         FLOAT64,
    pkg_cubic_size  FLOAT64,
    adh_amt         FLOAT64,
    das_amt         FLOAT64,
    oth_amt         FLOAT64,
    ovs_amt         FLOAT64,
    dlg_amt         FLOAT64,
    dresi_amt       FLOAT64,
    resi_amt        FLOAT64,
    adh_qty         FLOAT64,
    das_qty         FLOAT64,
    oth_qty         FLOAT64,
    ovs_qty         FLOAT64,
    dlg_qty         FLOAT64,
    dresi_qty       FLOAT64,
    resi_qty        FLOAT64,

    _run_batch_id   STRING,
    _source_system  STRING,
    _loaded_at      TIMESTAMP
)
PARTITION BY RANGE_BUCKET(CAST(ratemnth AS INT64), GENERATE_ARRAY(202001, 203001, 1))
CLUSTER BY se_payr_glbl_enti_nbr, svc_cat_cd, orig_ctry_cd
OPTIONS(description = 'Country-level entity billing monthly history');

CREATE TABLE IF NOT EXISTS `project.cdl_data.FXG_CTRY_ENTI_BILL_MTH_HIST_temp`
    LIKE `project.cdl_data.FXG_CTRY_ENTI_BILL_MTH_HIST`;


-- ===========================================================================
-- GLOBAL LAYER
-- ===========================================================================

CREATE TABLE IF NOT EXISTS `project.cdl_data.FXG_GLBL_ENTI_BILL_MTH_HIST` (

    ratemnth                 STRING    NOT NULL,
    shipmnth                 STRING,
    dlvrmnth                 STRING,

    se_shpr_glbl_enti_nbr    STRING,
    se_shpr_sls_seg_cd       STRING,
    se_shpr_sub_industry_cd  STRING,

    se_payr_glbl_enti_nbr    STRING,
    se_payr_sls_seg_cd       STRING,
    se_payr_sub_industry_cd  STRING,

    ce_payr_glbl_enti_nbr    STRING,
    ce_payr_sls_seg_cd       STRING,

    svc_cat_cd               STRING,
    product                  STRING,
    orig_ctry_cd             STRING,
    orig_st_cd               STRING,
    orig_msa                 STRING,
    dest_ctry_cd             STRING,
    dest_st_cd               STRING,
    dest_msa                 STRING,
    zone_cd                  STRING,
    wgtcat                   STRING,
    rsd_flg                  STRING,
    lrnn_flg                 STRING,
    ec_flg                   STRING,
    dim_avail_flg            STRING,
    revmnth                  STRING,

    packages        FLOAT64,
    netrev          FLOAT64,
    fgtchrg         FLOAT64,
    discount        FLOAT64,
    fuelsch         FLOAT64,
    totalsch        FLOAT64,
    apounds         FLOAT64,
    rpounds         FLOAT64,
    pkg_cubic_size  FLOAT64,
    adh_amt         FLOAT64,
    das_amt         FLOAT64,
    oth_amt         FLOAT64,
    ovs_amt         FLOAT64,
    dlg_amt         FLOAT64,
    dresi_amt       FLOAT64,
    resi_amt        FLOAT64,
    adh_qty         FLOAT64,
    das_qty         FLOAT64,
    oth_qty         FLOAT64,
    ovs_qty         FLOAT64,
    dlg_qty         FLOAT64,
    dresi_qty       FLOAT64,
    resi_qty        FLOAT64,

    _run_batch_id   STRING,
    _source_system  STRING,
    _loaded_at      TIMESTAMP
)
PARTITION BY RANGE_BUCKET(CAST(ratemnth AS INT64), GENERATE_ARRAY(202001, 203001, 1))
CLUSTER BY se_payr_glbl_enti_nbr, svc_cat_cd
OPTIONS(description = 'Global-level entity billing monthly history');

CREATE TABLE IF NOT EXISTS `project.cdl_data.FXG_GLBL_ENTI_BILL_MTH_HIST_temp`
    LIKE `project.cdl_data.FXG_GLBL_ENTI_BILL_MTH_HIST`;
