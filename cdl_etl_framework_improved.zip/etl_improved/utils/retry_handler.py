"""
utils/retry_handler.py
========================
Exponential backoff retry decorator + Delta rollback helper.

The framework's main retry logic lives inside run_layer() in 04_main_core.py,
driven by cfg.retry_* fields per table. This module provides:

  @with_retry(...)  — decorator for wrapping any utility function
  rollback_delta()  — restore a Delta table to its previous version after a
                      failed write (called by _promote_to_target on failure)
"""

from __future__ import annotations

import functools
import logging
import math
import random
import time
from typing import Callable, Tuple, Type

logger = logging.getLogger("cdl.retry")


def with_retry(
    max_attempts:        int                           = 3,
    initial_wait:        float                         = 30.0,
    backoff_multiplier:  float                         = 2.0,
    max_wait:            float                         = 300.0,
    jitter_fraction:     float                         = 0.1,
    retryable_exceptions: Tuple[Type[Exception], ...] = (Exception,),
):
    """
    Decorator: wrap a function with exponential backoff + jitter retry.

    Example
    -------
    @with_retry(max_attempts=3, initial_wait=10, retryable_exceptions=(IOError,))
    def read_external_source():
        ...
    """
    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            last_exc = None
            for attempt in range(1, max_attempts + 1):
                try:
                    return func(*args, **kwargs)
                except retryable_exceptions as exc:
                    last_exc = exc
                    if attempt == max_attempts:
                        logger.error(
                            "[retry] %s exhausted %d attempts: %s",
                            func.__name__, max_attempts, exc,
                        )
                        raise
                    wait = _compute_wait(
                        attempt, initial_wait, backoff_multiplier,
                        max_wait, jitter_fraction,
                    )
                    logger.warning(
                        "[retry] %s attempt %d/%d failed: %s. "
                        "Retrying in %.1fs",
                        func.__name__, attempt, max_attempts, exc, wait,
                    )
                    time.sleep(wait)
            raise last_exc  # unreachable, satisfies type checkers
        return wrapper
    return decorator


def rollback_delta(spark, table_name: str) -> bool:
    """
    Restore a Delta table to its immediately previous version.

    Used as a last-resort safety net after a partially committed write.
    Returns True on success, False if rollback was not possible.
    """
    try:
        history = spark.sql(
            f"DESCRIBE HISTORY {table_name} LIMIT 2"
        ).collect()
        if len(history) < 2:
            logger.warning(
                "[rollback] %s: no prior version available (table too new)",
                table_name,
            )
            return False
        target_ver = history[1]["version"]
        logger.warning(
            "[rollback] Restoring %s to version %d", table_name, target_ver
        )
        spark.sql(
            f"RESTORE TABLE {table_name} TO VERSION AS OF {target_ver}"
        )
        logger.info("[rollback] %s restored to version %d ✓",
                    table_name, target_ver)
        return True
    except Exception as exc:
        logger.error("[rollback] %s restore failed: %s", table_name, exc)
        return False


def _compute_wait(
    attempt:    int,
    initial:    float,
    multiplier: float,
    cap:        float,
    jitter:     float,
) -> float:
    """Exponential backoff with ±jitter."""
    base = min(initial * (multiplier ** (attempt - 1)), cap)
    noise = random.uniform(-jitter * base, jitter * base)
    return max(0.0, base + noise)
