"""
utils/cloud_adapter.py
========================
Azure ↔ GCP storage and compute abstraction layer.

Design:
  - Switch via CDL_ENV=azure|gcp environment variable.
  - CloudAdapter.read_external() handles JDBC, GCS, ADLS sources uniformly.
  - _secret() resolves credentials from: Spark conf → GCP Secret Manager
    → Azure Key Vault → env var fallback. Never hardcodes credentials.
  - optimize() / vacuum() are no-ops on GCP (BigQuery manages storage).
  - All methods raise CloudAdapterError on unrecoverable failure so the
    caller can catch a specific type rather than bare Exception.
"""

from __future__ import annotations

import logging
import os
from typing import Optional

logger = logging.getLogger("cdl.cloud_adapter")

try:
    from pyspark.sql import DataFrame, SparkSession
    from pyspark.sql import functions as F
except ImportError:
    pass  # allow import in non-Spark test environments

from config.env_config import CLOUD_ENV, get_cloud_config, get_storage_base


class CloudAdapterError(RuntimeError):
    """Raised when CloudAdapter cannot complete an operation."""


class CloudAdapter:
    """
    Unified read/write/optimize abstraction over Azure (ADLS + Delta) and
    GCP (GCS + BigQuery).  Instantiate once per Spark session.
    """

    def __init__(self, spark: "SparkSession"):
        self.spark = spark
        self.env   = CLOUD_ENV
        self.cfg   = get_cloud_config()
        self.base  = get_storage_base()
        logger.info("CloudAdapter initialised: env=%s  base=%s", self.env, self.base)

    # ── External source reads ─────────────────────────────────────────────
    def read_external(
        self,
        source_system: str,
        table_name:    str,
        options:       Optional[dict] = None,
    ) -> "DataFrame":
        """
        Read from an external source into a Spark DataFrame.

        source_system values:
          ACCOUNT_DB   — JDBC using ACCOUNT_DB_JDBC_URL secret
          ORACLE / EDW — JDBC with Oracle driver
          SQL_SERVER   — JDBC with SQL Server driver
          GCS_*        — Parquet files under gs://bucket/landing/{table}
          ADLS_*       — Parquet files under abfss://container@sa.dfs.../landing/{table}
          DELTA_LAKE   — spark.table() using the catalogued table name
        """
        opts = options or {}
        src  = source_system.upper()

        try:
            if src == "DELTA_LAKE":
                return self.spark.table(table_name)

            if src == "ACCOUNT_DB":
                url = self._secret("ACCOUNT_DB_JDBC_URL")
                return self._jdbc(url, table_name, opts)

            if src in ("ORACLE", "EDW"):
                url = self._secret(f"{src}_JDBC_URL")
                return self._jdbc(url, table_name,
                                  {**opts, "driver": "oracle.jdbc.OracleDriver"})

            if src == "SQL_SERVER":
                url = self._secret("SQLSERVER_JDBC_URL")
                return self._jdbc(
                    url, table_name,
                    {**opts, "driver": "com.microsoft.sqlserver.jdbc.SQLServerDriver"},
                )

            if src.startswith(("GCS_", "ADLS_")):
                path = f"{self.base}/landing/{table_name}"
                logger.info("Reading parquet: %s", path)
                return self.spark.read.parquet(path)

        except CloudAdapterError:
            raise
        except Exception as exc:
            raise CloudAdapterError(
                f"read_external failed for source_system={source_system}, "
                f"table={table_name}: {exc}"
            ) from exc

        raise CloudAdapterError(f"Unsupported source_system: {source_system!r}")

    # ── Delta / BQ table maintenance ─────────────────────────────────────
    def optimize(self, table: str, zorder_cols: Optional[list] = None) -> None:
        """Run OPTIMIZE on a Delta table. No-op on GCP BigQuery."""
        if self.env == "gcp":
            logger.info("optimize() skipped (GCP BigQuery manages storage): %s", table)
            return
        sql = f"OPTIMIZE {table}"
        if zorder_cols:
            sql += f" ZORDER BY ({', '.join(zorder_cols)})"
        logger.info("OPTIMIZE: %s", sql)
        self.spark.sql(sql)

    def vacuum(self, table: str, hours: int = 168) -> None:
        """Run VACUUM on a Delta table. No-op on GCP BigQuery."""
        if self.env == "gcp":
            logger.info("vacuum() skipped (GCP manages retention): %s", table)
            return
        logger.info("VACUUM %s RETAIN %d HOURS", table, hours)
        self.spark.sql(f"VACUUM {table} RETAIN {hours} HOURS")

    def table_exists(self, table: str) -> bool:
        """Return True if the fully-qualified table exists in the catalog."""
        try:
            self.spark.sql(f"DESCRIBE TABLE {table}")
            return True
        except Exception:
            return False

    # ── JDBC helper ───────────────────────────────────────────────────────
    def _jdbc(self, url: str, table: str, opts: dict) -> "DataFrame":
        fetchsize = opts.pop("fetchsize", "10000")
        reader = (
            self.spark.read.format("jdbc")
            .option("url",       url)
            .option("dbtable",   table)
            .option("fetchsize", fetchsize)
        )
        for k, v in opts.items():
            reader = reader.option(k, v)
        logger.info("JDBC read: table=%s  fetchsize=%s", table, fetchsize)
        return reader.load()

    # ── Secret resolution (3-tier) ────────────────────────────────────────
    def _secret(self, name: str) -> str:
        """
        Resolve a secret value from (in priority order):
          1. Spark conf  spark.cdl.secret.<NAME>  (set via cluster secret scope)
          2. GCP Secret Manager  (when env == gcp)
          3. Azure Key Vault     (when env == azure)
          4. Environment variable  <NAME>  (dev/test fallback)
        """
        # 1. Spark conf (works for both Databricks secret-scope binding and
        #    manual spark.conf.set in unit tests)
        try:
            val = self.spark.conf.get(f"spark.cdl.secret.{name}")
            if val:
                return val
        except Exception:
            pass

        # 2. GCP Secret Manager
        if self.env == "gcp":
            try:
                from google.cloud import secretmanager
                client = secretmanager.SecretManagerServiceClient()
                resp   = client.access_secret_version(
                    request={
                        "name": (
                            f"{self.cfg.secret_manager_prefix}"   # type: ignore[attr-defined]
                            f"/{name}/versions/latest"
                        )
                    }
                )
                return resp.payload.data.decode()
            except Exception as exc:
                logger.debug("GCP Secret Manager miss for '%s': %s", name, exc)

        # 3. Azure Key Vault  (requires azure-keyvault-secrets installed)
        if self.env == "azure":
            try:
                from azure.identity import DefaultAzureCredential
                from azure.keyvault.secrets import SecretClient
                kv_uri = getattr(self.cfg, "key_vault_uri", None)
                if kv_uri:
                    client = SecretClient(
                        vault_url=kv_uri, credential=DefaultAzureCredential()
                    )
                    return client.get_secret(name.replace("_", "-")).value
            except Exception as exc:
                logger.debug("Azure Key Vault miss for '%s': %s", name, exc)

        # 4. Env var fallback
        env_val = os.getenv(name.replace("-", "_").upper())
        if env_val:
            logger.debug("Secret '%s' resolved from env var", name)
            return env_val

        raise CloudAdapterError(
            f"Secret '{name}' not found in Spark conf, "
            f"{'GCP Secret Manager' if self.env == 'gcp' else 'Azure Key Vault'}, "
            f"or environment variables."
        )
