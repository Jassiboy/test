"""
utils/alert_manager.py
========================
Multi-channel alerting for the CDL ETL framework.

Alert config is stored per-table in cdl_table_config.alert_config (JSON).
This class is never imported directly in the hot path — it is called only
after a table finishes with FAILED / HALTED status.

Schema of alert_config JSON:
[
  { "channel": "EMAIL",  "recipients": "a@co.com,b@co.com",
    "on_status": ["FAILED","HALTED"] },
  { "channel": "TEAMS",  "recipients": "https://webhook...",
    "on_status": ["FAILED"] },
  { "channel": "SLACK",  "recipients": "https://webhook...",
    "on_status": ["FAILED","PARTIAL_SUCCESS"] }
]

Design:
  - send() is the only public method; it never raises.
  - Each dispatch is attempted independently so one failing channel
    does not prevent others from firing.
  - SMTP credentials come from env vars; no secrets in code.
"""

from __future__ import annotations

import json
import logging
import os
import smtplib
import urllib.request
from datetime import datetime, timezone
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from typing import Optional

logger = logging.getLogger("cdl.alert_manager")


class AlertManager:
    """Dispatches alerts to EMAIL / TEAMS / SLACK based on per-table config."""

    def __init__(self, spark=None):
        self.spark = spark  # reserved for future Spark-based alert log write

    # ── Public API ──────────────────────────────────────────────────────────
    def send(
        self,
        cfg,
        run_batch_id: str,
        status:       str,
        message:      str,
        severity:     str = "CRITICAL",
    ) -> None:
        """
        Route alert to all channels that subscribe to this status.
        Always returns — never raises.
        """
        try:
            if not getattr(cfg, "alert_config", None):
                return
            body = self._build_body(cfg, run_batch_id, status, message, severity)
            for entry in cfg.alert_config:
                on_statuses = [s.upper() for s in entry.get("on_status", ["FAILED"])]
                if status.upper() not in on_statuses:
                    continue
                channel    = entry.get("channel", "").upper()
                recipients = entry.get("recipients", "").strip()
                if not recipients:
                    continue
                try:
                    if channel == "EMAIL":
                        self._send_email(recipients, body, severity, cfg.table_id)
                    elif channel == "TEAMS":
                        self._send_teams(recipients, body, severity, cfg.table_id)
                    elif channel == "SLACK":
                        self._send_slack(recipients, body, severity, cfg.table_id)
                    else:
                        logger.warning("Unknown alert channel: %s", channel)
                except Exception as exc:
                    logger.error("Alert [%s] dispatch failed: %s", channel, exc)
        except Exception as exc:
            logger.error("AlertManager.send failed (non-blocking): %s", exc)

    # ── Message body ────────────────────────────────────────────────────────
    @staticmethod
    def _build_body(cfg, run_batch_id, status, message, severity) -> str:
        now = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
        return (
            f"CDL ETL Alert [{severity}]\n"
            f"{'=' * 50}\n"
            f"Status      : {status}\n"
            f"Table       : {cfg.table_id}\n"
            f"Layer       : {cfg.target_dataset_layer}\n"
            f"OPCO        : {cfg.opco}\n"
            f"Run Batch ID: {run_batch_id}\n"
            f"Timestamp   : {now}\n"
            f"{'=' * 50}\n"
            f"{message}\n"
        )

    # ── EMAIL ───────────────────────────────────────────────────────────────
    def _send_email(self, recipients: str, body: str, severity: str, table_id: str) -> None:
        host      = os.getenv("SMTP_HOST",         "smtp.office365.com")
        port      = int(os.getenv("SMTP_PORT",     "587"))
        from_addr = os.getenv("ALERT_FROM_EMAIL",  "cdl-etl@company.com")
        password  = os.getenv("SMTP_PASSWORD",     "")
        to_list   = [r.strip() for r in recipients.split(",") if r.strip()]

        msg            = MIMEMultipart()
        msg["Subject"] = f"[CDL ETL][{severity}] {table_id}"
        msg["From"]    = from_addr
        msg["To"]      = ", ".join(to_list)
        msg.attach(MIMEText(body, "plain"))

        with smtplib.SMTP(host, port, timeout=15) as s:
            s.ehlo()
            s.starttls()
            if password:
                s.login(from_addr, password)
            s.sendmail(from_addr, to_list, msg.as_string())
        logger.info("Email alert sent to %s", to_list)

    # ── TEAMS ───────────────────────────────────────────────────────────────
    def _send_teams(self, webhook: str, body: str, severity: str, table_id: str) -> None:
        colour  = "FF0000" if severity == "CRITICAL" else "FFA500"
        payload = json.dumps({
            "@type":    "MessageCard",
            "@context": "http://schema.org/extensions",
            "themeColor": colour,
            "summary":    f"CDL Alert — {table_id}",
            "sections": [{
                "activityTitle":    f"CDL ETL [{severity}]",
                "activitySubtitle": table_id,
                "text":             body.replace("\n", "<br>"),
            }],
        }).encode("utf-8")
        req = urllib.request.Request(
            webhook, data=payload,
            headers={"Content-Type": "application/json"}, method="POST",
        )
        with urllib.request.urlopen(req, timeout=15):
            pass
        logger.info("Teams alert sent for %s", table_id)

    # ── SLACK ───────────────────────────────────────────────────────────────
    def _send_slack(self, webhook: str, body: str, severity: str, table_id: str) -> None:
        icon    = ":red_circle:" if severity == "CRITICAL" else ":warning:"
        payload = json.dumps({
            "text": f"{icon} *CDL ETL [{severity}]* — `{table_id}`\n```{body}```"
        }).encode("utf-8")
        req = urllib.request.Request(
            webhook, data=payload,
            headers={"Content-Type": "application/json"}, method="POST",
        )
        with urllib.request.urlopen(req, timeout=15):
            pass
        logger.info("Slack alert sent for %s", table_id)
