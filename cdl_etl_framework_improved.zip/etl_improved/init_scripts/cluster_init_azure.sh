#!/usr/bin/env bash
# =============================================================================
# CDL ETL — Azure Databricks Cluster Init Script
# Runs on every cluster node at startup (driver + workers).
#
# Responsibilities:
#   1. Install Python dependencies not bundled in the DBR image.
#   2. Install JDBC drivers to /databricks/jars/ for JDBC source reads.
#   3. Configure Spark for Delta Lake optimisations and AQE.
#   4. Set CDL_ENV so framework code auto-selects Azure adapters.
#   5. Configure structured logging to stdout (picked up by cluster log delivery).
#   6. Verify critical mounts are accessible (driver only).
#
# Usage:
#   Attach this script in Cluster → Advanced → Init Scripts:
#     dbfs:/cdl/init/cluster_init_azure.sh
#   Set cluster-scoped env vars in Spark Config (not here) so they are
#   visible to notebooks via os.getenv().
# =============================================================================

set -euo pipefail

LOG_PREFIX="[CDL-INIT]"
echo "$LOG_PREFIX Starting Azure cluster init  $(date -u '+%Y-%m-%dT%H:%M:%SZ')"

# ---------------------------------------------------------------------------
# 1. Python dependencies
# ---------------------------------------------------------------------------
echo "$LOG_PREFIX Installing Python packages..."

pip install --quiet --no-cache-dir \
    delta-spark==3.2.0 \
    azure-identity==1.16.0 \
    azure-keyvault-secrets==4.8.0 \
    azure-appconfiguration==1.5.0 \
    dateutils==0.6.12 \
    python-dateutil==2.9.0 \
    pyarrow==14.0.2 \
    requests==2.31.0

echo "$LOG_PREFIX Python packages installed."

# ---------------------------------------------------------------------------
# 2. JDBC driver — SQL Server (for ACCOUNT_DB sources)
#    Download from Maven Central; cached by Databricks after first use.
# ---------------------------------------------------------------------------
JDBC_DIR="/databricks/jars"
MSSQL_JAR="mssql-jdbc-12.4.2.jre11.jar"
MSSQL_URL="https://repo1.maven.org/maven2/com/microsoft/sqlserver/mssql-jdbc/12.4.2.jre11/${MSSQL_JAR}"

if [ ! -f "${JDBC_DIR}/${MSSQL_JAR}" ]; then
    echo "$LOG_PREFIX Downloading MSSQL JDBC driver..."
    curl -sSL "$MSSQL_URL" -o "${JDBC_DIR}/${MSSQL_JAR}"
    echo "$LOG_PREFIX MSSQL JDBC driver installed: ${JDBC_DIR}/${MSSQL_JAR}"
else
    echo "$LOG_PREFIX MSSQL JDBC driver already present."
fi

# ---------------------------------------------------------------------------
# 3. Environment variables
#    CDL_ENV, CDL_CATALOG, CDL_METADATA_SCHEMA, CDL_DATA_SCHEMA are set
#    as cluster-scoped Spark Env Vars in the UI / Terraform.
#    We only set defaults here for variables that must always exist.
# ---------------------------------------------------------------------------
export CDL_ENV="${CDL_ENV:-azure}"
export CDL_ENVIRONMENT="${CDL_ENVIRONMENT:-prod}"
export CDL_METADATA_SCHEMA="${CDL_METADATA_SCHEMA:-cdl_metadata}"
export CDL_DATA_SCHEMA="${CDL_DATA_SCHEMA:-cdl_data}"
export CDL_LOG_RETENTION_DAYS="${CDL_LOG_RETENTION_DAYS:-90}"
export CDL_RETRY_MAX="${CDL_RETRY_MAX:-3}"
export CDL_SHUFFLE_PARTITIONS="${CDL_SHUFFLE_PARTITIONS:-200}"

echo "$LOG_PREFIX Environment: CDL_ENV=$CDL_ENV  CDL_ENVIRONMENT=$CDL_ENVIRONMENT"

# ---------------------------------------------------------------------------
# 4. Spark configuration written to /databricks/driver/conf/
#    These apply cluster-wide without needing spark.conf.set in notebooks.
# ---------------------------------------------------------------------------
SPARK_CONF_FILE="/databricks/driver/conf/cdl-spark-defaults.conf"

cat > "$SPARK_CONF_FILE" << SPARK_EOF
# CDL Spark defaults — written by cluster_init_azure.sh

# Adaptive Query Execution
spark.sql.adaptive.enabled                                    true
spark.sql.adaptive.coalescePartitions.enabled                 true
spark.sql.adaptive.skewJoin.enabled                          true
spark.databricks.optimizer.adaptiveQueryExecution.enabled     true

# Delta Lake write optimisations
spark.databricks.delta.optimizeWrite.enabled                  true
spark.databricks.delta.autoCompact.enabled                    true
spark.databricks.delta.merge.enableLowShuffle.mergeEnabled    true
spark.databricks.delta.schema.autoMerge.enabled               true

# Shuffle & join
spark.sql.shuffle.partitions                                   $CDL_SHUFFLE_PARTITIONS
spark.sql.autoBroadcastJoinThreshold                          104857600

# Parquet pushdown
spark.sql.parquet.filterPushdown                              true
spark.sql.orc.filterPushdown                                  true

# Logging
spark.eventLog.enabled                                        true
SPARK_EOF

echo "$LOG_PREFIX Spark config written to $SPARK_CONF_FILE"

# ---------------------------------------------------------------------------
# 5. Python path — add project root so notebooks can import from config/, dq/
# ---------------------------------------------------------------------------
PROJECT_ROOT="/dbfs/cdl/etl_framework"
if [ -d "$PROJECT_ROOT" ]; then
    echo "$PROJECT_ROOT" >> /databricks/python/lib/python3.11/site-packages/cdl.pth
    echo "$LOG_PREFIX Added $PROJECT_ROOT to PYTHONPATH via cdl.pth"
fi

# ---------------------------------------------------------------------------
# 6. Mount verification (driver node only)
# ---------------------------------------------------------------------------
if [ "$DB_IS_DRIVER_NODE" = "true" ] || [ -z "${DB_IS_DRIVER_NODE:-}" ]; then
    echo "$LOG_PREFIX Verifying ADLS mount (driver)..."
    if ls /dbfs/mnt/cdl-data/ &>/dev/null; then
        echo "$LOG_PREFIX Mount /dbfs/mnt/cdl-data OK"
    else
        echo "$LOG_PREFIX WARNING: /dbfs/mnt/cdl-data not accessible — check mount config"
    fi
fi

echo "$LOG_PREFIX Azure cluster init complete  $(date -u '+%Y-%m-%dT%H:%M:%SZ')"
