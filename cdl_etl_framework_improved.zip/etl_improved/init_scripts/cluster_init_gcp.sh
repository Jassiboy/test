#!/usr/bin/env bash
# =============================================================================
# CDL ETL — GCP Dataproc Cluster Init Script
# Runs on every cluster node at startup (master + workers).
#
# Responsibilities:
#   1. Install Python dependencies for the CDL framework.
#   2. Install BigQuery Spark connector if not bundled in the image.
#   3. Configure Spark for AQE and BQ-connector optimisations.
#   4. Set CDL_ENV=gcp so framework code auto-selects GCP adapters.
#   5. Verify GCS bucket is reachable (master node only).
#
# Usage (Dataproc):
#   gcloud dataproc clusters create cdl-cluster \
#     --initialization-actions gs://cdl-scripts/init/cluster_init_gcp.sh \
#     --initialization-action-timeout 5m \
#     --metadata CDL_ENVIRONMENT=prod,CDL_DATA_SCHEMA=cdl_data
#
# Env vars injected via --metadata appear as /etc/profile.d/*.sh on nodes.
# =============================================================================

set -euo pipefail

LOG_PREFIX="[CDL-INIT-GCP]"
echo "$LOG_PREFIX Starting GCP Dataproc cluster init  $(date -u '+%Y-%m-%dT%H:%M:%SZ')"

# Dataproc sets DATAPROC_JOB_ID on master only
IS_MASTER=false
[[ "$(hostname)" == *-m ]] && IS_MASTER=true

# ---------------------------------------------------------------------------
# 1. Python dependencies
# ---------------------------------------------------------------------------
echo "$LOG_PREFIX Installing Python packages..."
pip3 install --quiet --no-cache-dir \
    delta-spark==3.2.0 \
    google-cloud-secret-manager==2.20.0 \
    google-cloud-bigquery==3.20.0 \
    google-cloud-storage==2.16.0 \
    dateutils==0.6.12 \
    python-dateutil==2.9.0 \
    pyarrow==14.0.2 \
    requests==2.31.0
echo "$LOG_PREFIX Python packages installed."

# ---------------------------------------------------------------------------
# 2. BigQuery Spark connector (present in Dataproc 2.1+ images; install only
#    if missing for custom images)
# ---------------------------------------------------------------------------
BQ_CONNECTOR_JAR="/usr/lib/spark/jars/spark-bigquery-with-dependencies_2.12-0.36.1.jar"
BQ_CONNECTOR_URL="https://storage.googleapis.com/spark-lib/bigquery/spark-bigquery-with-dependencies_2.12-0.36.1.jar"

if [ ! -f "$BQ_CONNECTOR_JAR" ]; then
    echo "$LOG_PREFIX Downloading BigQuery Spark connector..."
    curl -sSL "$BQ_CONNECTOR_URL" -o "$BQ_CONNECTOR_JAR"
    echo "$LOG_PREFIX BQ connector installed."
else
    echo "$LOG_PREFIX BQ connector already present."
fi

# ---------------------------------------------------------------------------
# 3. Environment variables
# ---------------------------------------------------------------------------
export CDL_ENV="${CDL_ENV:-gcp}"
export CDL_ENVIRONMENT="${CDL_ENVIRONMENT:-prod}"
export CDL_METADATA_SCHEMA="${CDL_METADATA_SCHEMA:-cdl_metadata}"
export CDL_DATA_SCHEMA="${CDL_DATA_SCHEMA:-cdl_data}"
export GCP_PROJECT_ID="${GCP_PROJECT_ID:-$(curl -sH 'Metadata-Flavor: Google' \
    http://metadata.google.internal/computeMetadata/v1/project/project-id)}"
export GCS_BUCKET="${GCS_BUCKET:-${GCP_PROJECT_ID}-cdl-data}"
export BQ_LOCATION="${BQ_LOCATION:-US}"
export CDL_SHUFFLE_PARTITIONS="${CDL_SHUFFLE_PARTITIONS:-200}"

echo "$LOG_PREFIX Environment: CDL_ENV=$CDL_ENV  PROJECT=$GCP_PROJECT_ID  BUCKET=$GCS_BUCKET"

# Persist env vars for non-login shells (e.g. Dataproc job executor)
cat >> /etc/environment << ENV_EOF
CDL_ENV=${CDL_ENV}
CDL_ENVIRONMENT=${CDL_ENVIRONMENT}
CDL_METADATA_SCHEMA=${CDL_METADATA_SCHEMA}
CDL_DATA_SCHEMA=${CDL_DATA_SCHEMA}
GCP_PROJECT_ID=${GCP_PROJECT_ID}
GCS_BUCKET=${GCS_BUCKET}
ENV_EOF

# ---------------------------------------------------------------------------
# 4. Spark configuration
# ---------------------------------------------------------------------------
SPARK_CONF_DIR="/etc/spark/conf"
mkdir -p "$SPARK_CONF_DIR"

cat >> "${SPARK_CONF_DIR}/spark-defaults.conf" << SPARK_EOF

# CDL Spark defaults — written by cluster_init_gcp.sh
spark.sql.adaptive.enabled                              true
spark.sql.adaptive.coalescePartitions.enabled           true
spark.sql.adaptive.skewJoin.enabled                    true
spark.sql.shuffle.partitions                            $CDL_SHUFFLE_PARTITIONS
spark.sql.autoBroadcastJoinThreshold                   104857600
spark.sql.parquet.filterPushdown                        true

# BigQuery connector
spark.datasource.bigquery.materializationProject        ${GCP_PROJECT_ID}
spark.datasource.bigquery.materializationDataset        _spark_temp
spark.datasource.bigquery.viewsEnabled                  true
spark.datasource.bigquery.writeMethod                   DIRECT

# Delta Lake (if using GCS-backed Delta)
spark.delta.logStore.gs.impl                            io.delta.storage.GCSLogStore
SPARK_EOF

echo "$LOG_PREFIX Spark config updated."

# ---------------------------------------------------------------------------
# 5. Python path
# ---------------------------------------------------------------------------
PROJECT_ROOT="gs://${GCS_BUCKET}/etl_framework"
echo "$LOG_PREFIX Project root: $PROJECT_ROOT (code downloaded by Dataproc job submit)"

# ---------------------------------------------------------------------------
# 6. GCS bucket check (master only)
# ---------------------------------------------------------------------------
if $IS_MASTER; then
    echo "$LOG_PREFIX Verifying GCS bucket access (master)..."
    if gsutil ls "gs://${GCS_BUCKET}/" &>/dev/null; then
        echo "$LOG_PREFIX GCS bucket gs://${GCS_BUCKET}/ accessible."
    else
        echo "$LOG_PREFIX WARNING: gs://${GCS_BUCKET}/ not accessible — check IAM permissions."
    fi
fi

echo "$LOG_PREFIX GCP Dataproc cluster init complete  $(date -u '+%Y-%m-%dT%H:%M:%SZ')"
