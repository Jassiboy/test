"""
notebooks/01_framework_core.py
================================
Shared helpers used by all other notebooks.
Kept intentionally simple — plain functions and small classes, no inheritance.

Contains:
  - log(msg)                  : structured print logger
  - read_table_configs()      : reads cdl_table_config for an OPCO + layer
  - check_dq_gate()           : checks upstream DQ passed in run log
  - run_dq()                  : runs inline DQ rules on a DataFrame
  - log_start() / log_success() / log_failure() : write to cdl_table_run_log
  - update_watermark()        : persists watermark back to cdl_table_config
"""

import hashlib
import json
import os
from dataclasses import dataclass
from datetime import date, datetime, timezone
from typing import Optional

from pyspark.sql import DataFrame, SparkSession
from pyspark.sql import functions as F
from delta.tables import DeltaTable

from config.env_config import get_metadata_db

# METADATA_DB = get_metadata_db()
METADATA_DB = 'f6180854'


# ─────────────────────────────────────────────────────────────────────────────
# Logger — simple structured print
# ─────────────────────────────────────────────────────────────────────────────
def log(level: str, msg: str, **ctx):
    now = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
    extra = "  ".join(f"{k}={v}" for k, v in ctx.items())
    print(f"[{now}] [{level.upper()}]  {msg}  {extra}".strip())


# ─────────────────────────────────────────────────────────────────────────────
# TableConfig — one row from cdl_table_config
# ─────────────────────────────────────────────────────────────────────────────
@dataclass
class TableConfig:
    table_id:             str
    source_system:        str
    source_table_name:    str
    source_filter:        Optional[str]
    target_system:        str
    target_table_name:    str
    target_dataset_layer: str
    opco:                 str
    ingestion_mode:       str
    load_frequency:       str
    watermark_column:     Optional[str]
    last_watermark_value: Optional[datetime]
    partition_col:        Optional[str]
    merge_keys:           Optional[str]
    dq_rules:             list          # parsed from data_quality_rules JSON
    dq_threshold_pct:     float
    depends_on:           list[str]     # parsed from depends_on_table_ids
    retry_max_attempts:   int
    retry_wait_sec:       int
    retry_backoff:        float
    retry_max_wait:       int
    alert_config:         list          # parsed from alert_config JSON
    is_active:            bool


# ─────────────────────────────────────────────────────────────────────────────
# Read configs from cdl_table_config
# ─────────────────────────────────────────────────────────────────────────────
def read_table_configs(
    opco: str,
    layer: str,
    frequency: Optional[str] = None,
) -> list[TableConfig]:
    """
    Return active TableConfig rows for a given OPCO + layer.
    Optionally filtered by frequency (DAILY / MONTHLY / BOTH).
    """
    spark = SparkSession.getActiveSession()
    where = f"opco = '{opco.upper()}' AND target_dataset_layer = '{layer.upper()}' AND is_active = true"
    if frequency and frequency.upper() != "BOTH":
        where += f" AND load_frequency IN ('{frequency.upper()}', 'BOTH')"

    rows = spark.sql(
        f"SELECT * FROM {METADATA_DB}.cdl_table_config WHERE {where} ORDER BY table_id"
    ).collect()

    log("INFO", f"Loaded {len(rows)} config(s)", layer=layer, opco=opco)
    return [_parse_config(r) for r in rows]


def _parse_config(row) -> TableConfig:
    d = row.asDict()
    return TableConfig(
        table_id             = d["table_id"],
        source_system        = d["source_system"],
        source_table_name    = d["source_table_name"],
        source_filter        = d.get("source_filter"),
        target_system        = d["target_system"],
        target_table_name    = d["target_table_name"],
        target_dataset_layer = d["target_dataset_layer"],
        opco                 = d["opco"],
        ingestion_mode       = d["ingestion_mode"],
        load_frequency       = d["load_frequency"],
        watermark_column     = d.get("watermark_column"),
        last_watermark_value = d.get("last_watermark_value"),
        partition_col        = d.get("partition_col"),
        merge_keys           = d.get("merge_keys"),
        dq_rules             = _parse_json(d.get("data_quality_rules"), default=[]),
        dq_threshold_pct     = float(d.get("dq_threshold_pct") or 95.0),
        depends_on           = [x.strip() for x in (d.get("depends_on_table_ids") or "").split(",") if x.strip()],
        retry_max_attempts   = int(d.get("retry_max_attempts")   or 3),
        retry_wait_sec       = int(d.get("retry_initial_wait_sec") or 30),
        retry_backoff        = float(d.get("retry_backoff_multiplier") or 2.0),
        retry_max_wait       = int(d.get("retry_max_wait_sec")   or 300),
        alert_config         = _parse_json(d.get("alert_config"), default=[]),
        is_active            = bool(d["is_active"]),
    )


def _parse_json(value, default):
    if not value:
        return default
    try:
        return json.loads(value)
    except Exception:
        return default


# ─────────────────────────────────────────────────────────────────────────────
# DQ gate — check upstream layer passed before running this layer
# ─────────────────────────────────────────────────────────────────────────────
def check_dq_gate(
    configs: list[TableConfig],
    run_date: date,
    opco: str,
) -> tuple[bool, list[str]]:
    """
    For each config, check all its depends_on table_ids have
    dq_passed = TRUE in today's run log.
    Returns (all_clear, list_of_failed_upstream_ids).
    """
    spark = SparkSession.getActiveSession()
    needed = set()
    for cfg in configs:
        needed.update(cfg.depends_on)

    if not needed:
        return True, []

    ids = ",".join(f"'{x}'" for x in needed)
    rows = spark.sql(f"""
        SELECT dataset_id, MAX(CAST(dq_passed AS INT)) AS ok
        FROM {METADATA_DB}.cdl_table_run_log
        WHERE dag_run_date = '{run_date}'
          AND opco         = '{opco.upper()}'
          AND status       = 'SUCCESS'
          AND dataset_id   IN ({ids})
        GROUP BY dataset_id
    """).collect()

    passed  = {r["dataset_id"] for r in rows if r["ok"] == 1}
    failed  = [x for x in needed if x not in passed]

    if failed:
        log("ERROR", "DQ gate blocked", failed_upstream=str(failed))
        return False, failed
    return True, []


# ─────────────────────────────────────────────────────────────────────────────
# DQ engine — run inline rules, tag rows, return results
# ─────────────────────────────────────────────────────────────────────────────
def run_dq(
    df: DataFrame,
    cfg: TableConfig,
) -> tuple[DataFrame, list[dict], bool]:
    """
    Run all DQ rules from cfg.dq_rules against df.
    Returns:
        df_tagged   : DataFrame with dq_passed column added per row
        results     : list of dicts with per-rule outcome
        overall_ok  : True if no CRITICAL rule breached its threshold
    """
    total   = df.count()
    results = []

    for rule in cfg.dq_rules:
        result = _run_one_rule(df, rule, total)
        results.append(result)
        log(
            "INFO", f"DQ [{rule['rule_id']}] {'PASS' if result['passed'] else 'FAIL'}",
            severity=rule.get("severity"), pct_failed=result["failure_pct"],
        )

    # Tag each row: fails if it violates any CRITICAL expression rule
    crit_exprs = [
        r["rule_expression"] for r in cfg.dq_rules
        if r.get("severity") == "CRITICAL"
        and r.get("rule_type") not in ("ROW_COUNT", "UNIQUENESS")
    ]
    if crit_exprs:
        combined = " AND ".join(f"({e})" for e in crit_exprs)
        df = df.withColumn(
            "dq_passed",
            F.when(F.expr(combined), F.lit(True)).otherwise(F.lit(False))
        )
    else:
        df = df.withColumn("dq_passed", F.lit(True))

    # Overall: no CRITICAL rule exceeded its threshold AND pass rate >= threshold
    crit_ok = all(r["passed"] for r in results if r["severity"] == "CRITICAL")
    if total > 0:
        crit_failed_rows = sum(r["rows_failed"] for r in results if r["severity"] == "CRITICAL")
        pass_pct = ((total - crit_failed_rows) / total) * 100
        threshold_ok = pass_pct >= cfg.dq_threshold_pct
    else:
        threshold_ok = False

    overall_ok = crit_ok and threshold_ok
    return df, results, overall_ok


def _run_one_rule(df: DataFrame, rule: dict, total: int) -> dict:
    rid   = rule["rule_id"]
    rtype = rule["rule_type"]
    expr  = rule["rule_expression"]
    sev   = rule.get("severity", "WARNING")
    thr   = float(rule.get("error_threshold_pct") or 0.0)

    try:
        if rtype == "ROW_COUNT":
            min_rows = json.loads(expr).get("min_rows", 1) if expr.startswith("{") else 1
            passed = total >= min_rows
            return {"rule_id": rid, "severity": sev, "passed": passed,
                    "rows_checked": total, "rows_failed": 0 if passed else 1,
                    "failure_pct": 0.0 if passed else 100.0}

        elif rtype == "UNIQUENESS":
            col  = rule.get("target_column")
            dups = total - df.select(col).distinct().count()
            pct  = (dups / total * 100) if total else 0.0
            return {"rule_id": rid, "severity": sev, "passed": pct <= thr,
                    "rows_checked": total, "rows_failed": dups, "failure_pct": round(pct, 4)}

        else:
            failed = df.filter(f"NOT ({expr})").count()
            pct    = (failed / total * 100) if total else 0.0
            return {"rule_id": rid, "severity": sev, "passed": pct <= thr,
                    "rows_checked": total, "rows_failed": failed, "failure_pct": round(pct, 4)}

    except Exception as exc:
        return {"rule_id": rid, "severity": sev, "passed": False,
                "rows_checked": total, "rows_failed": total,
                "failure_pct": 100.0, "error": str(exc)[:300]}


# ─────────────────────────────────────────────────────────────────────────────
# Run log helpers
# ─────────────────────────────────────────────────────────────────────────────
def make_run_id(dag_id: str, table_id: str, run_date: date, attempt: int) -> str:
    raw = f"{dag_id}|{table_id}|{run_date}|{attempt}"
    return hashlib.sha256(raw.encode()).hexdigest()[:32]


def log_start(
    run_id: str,
    cfg: TableConfig,
    run_date: date,
    dag_id: str,
    attempt: int,
    watermark_start: Optional[datetime] = None,
):
    spark = SparkSession.getActiveSession()
    now = datetime.now(timezone.utc).isoformat()
    row = {
        "run_id": run_id, "dataset_id": cfg.table_id,
        "dag_run_date": str(run_date), "dag_id": dag_id,
        "task_id": cfg.table_id, "dataset_layer": cfg.target_dataset_layer,
        "opco": cfg.opco, "table_name": cfg.target_table_name,
        "status": "RUNNING", "attempt_number": attempt,
        "rows_read": None, "rows_written": None, "rows_rejected": None,
        "rows_merged": None, "rows_inserted": None, "rows_updated": None,
        "rows_deleted": None,
        "watermark_start": watermark_start.isoformat() if watermark_start else None,
        "watermark_end": None, "started_at": now, "completed_at": None,
        "duration_seconds": None, "dq_results": None, "dq_passed": None,
        "error_code": None, "error_message": None,
        "spark_app_id": spark.sparkContext.applicationId,
        "cluster_id": os.getenv("CLUSTER_ID", "unknown"),
        "created_at": now, "updated_at": now,
    }
    _upsert_run_log(row)


def log_success(
    run_id: str,
    started_at: datetime,
    rows_read: int,
    rows_written: int,
    rows_rejected: int,
    dq_results: list,
    dq_passed: bool,
    watermark_end: Optional[datetime] = None,
):
    now      = datetime.now(timezone.utc)
    duration = int((now - started_at).total_seconds())
    spark = SparkSession.getActiveSession()
    safe_dq  = json.dumps(dq_results).replace("'", "\\'")
    spark.sql(f"""
        UPDATE {METADATA_DB}.cdl_table_run_log
        SET status='SUCCESS', rows_read={rows_read}, rows_written={rows_written},
            rows_rejected={rows_rejected}, completed_at='{now.isoformat()}',
            duration_seconds={duration},
            dq_results='{safe_dq}',
            dq_passed={str(dq_passed)},
            watermark_end={'NULL' if not watermark_end else f"'{watermark_end.isoformat()}'"},
            updated_at='{now.isoformat()}'
        WHERE run_id='{run_id}'
    """)


def log_failure(
    run_id: str,
    started_at: Optional[datetime],
    error_code: str,
    error_message: str,
    status: str = "FAILED",
):
    now      = datetime.now(timezone.utc)
    duration = int((now - started_at).total_seconds()) if started_at else 0
    spark = SparkSession.getActiveSession()
    safe_msg = error_message[:2000].replace("'", "\\'")
    spark.sql(f"""
        UPDATE {METADATA_DB}.cdl_table_run_log
        SET status='{status}', completed_at='{now.isoformat()}',
            duration_seconds={duration}, dq_passed=false,
            error_code='{error_code}', error_message='{safe_msg}',
            updated_at='{now.isoformat()}'
        WHERE run_id='{run_id}'
    """)


def _upsert_run_log(row: dict):
    spark = SparkSession.getActiveSession()
    try:
        df = spark.createDataFrame([row])
        DeltaTable.forName(spark, f"{METADATA_DB}.cdl_table_run_log").alias("t").merge(
            df.alias("s"),
            "t.run_id = s.run_id AND t.attempt_number = s.attempt_number"
        ).whenNotMatchedInsertAll().execute()
    except Exception as e:
        log("ERROR", f"Failed to write run log: {e}")


# ─────────────────────────────────────────────────────────────────────────────
# Watermark — persisted back into cdl_table_config
# ─────────────────────────────────────────────────────────────────────────────
def update_watermark(table_id: str, new_value: datetime, run_date: date):
    spark = SparkSession.getActiveSession()
    now = datetime.now(timezone.utc).isoformat()
    spark.sql(f"""
        UPDATE {METADATA_DB}.cdl_table_config
        SET last_watermark_value = '{new_value.isoformat()}',
            last_successful_run  = '{run_date}',
            updated_at           = '{now}'
        WHERE table_id = '{table_id}'
    """)
    log("INFO", f"Watermark updated → {new_value}", table_id=table_id)
