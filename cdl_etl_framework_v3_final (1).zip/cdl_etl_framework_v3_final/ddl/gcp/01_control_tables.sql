-- =============================================================================
-- CDL ETL Framework — Control Tables  (GCP BigQuery)
-- Dataset : cdl_metadata
-- ONLY 2 TABLES — same schema as Azure, BQ syntax
-- =============================================================================

CREATE TABLE IF NOT EXISTS `cdl_metadata.cdl_table_config` (
    -- Identity
    table_id                STRING    OPTIONS(description='Unique logical mapping ID'),
    -- Source
    source_system           STRING    OPTIONS(description='ACCOUNT_DB | DELTA_LAKE | ORACLE | EDW | SQL_SERVER'),
    source_table_name       STRING,
    source_filter           STRING    OPTIONS(description='Optional SQL WHERE clause'),
    -- Target
    target_system           STRING    OPTIONS(description='DELTA_LAKE | BIGQUERY'),
    target_table_name       STRING,
    target_dataset_layer    STRING    OPTIONS(description='ACCOUNT | FACILITY | COUNTRY | GLOBAL'),
    opco                    STRING    OPTIONS(description='GROUND | FREIGHT | INTERNATIONAL'),
    -- Ingestion
    ingestion_mode          STRING    OPTIONS(description='FULL | INCR | CDC'),
    load_frequency          STRING    OPTIONS(description='DAILY | MONTHLY | BOTH'),
    watermark_column        STRING,
    last_watermark_value    TIMESTAMP OPTIONS(description='Persisted watermark — updated after each successful INCR run'),
    last_successful_run     DATE      OPTIONS(description='Date of last successful run'),
    partition_col           STRING,
    merge_keys              STRING    OPTIONS(description='Comma-separated PK cols for MERGE'),
    -- DQ: JSON array of rule objects
    -- Schema: [{"rule_id","rule_type","target_column","rule_expression","severity","error_threshold_pct"}]
    data_quality_rules      STRING    OPTIONS(description='JSON array of DQ rule objects'),
    dq_threshold_pct        FLOAT64   OPTIONS(description='Min % CRITICAL-rule passing rows (0-100)'),
    -- Dependency gate
    depends_on_table_ids    STRING    OPTIONS(description='Comma-separated upstream table_ids that must DQ-pass first. NULL = no gate.'),
    -- Retry
    retry_max_attempts      INT64     OPTIONS(description='Total attempts including first. Default 3.'),
    retry_initial_wait_sec  INT64     OPTIONS(description='Seconds before first retry. Default 30.'),
    retry_backoff_multiplier FLOAT64  OPTIONS(description='Exponential multiplier. Default 2.0.'),
    retry_max_wait_sec      INT64     OPTIONS(description='Max wait cap in seconds. Default 300.'),
    -- Alerts: JSON array — [{"channel":"EMAIL|TEAMS|SLACK","recipients":"...","on_status":["FAILED"]}]
    alert_config            STRING    OPTIONS(description='JSON array of alert channel objects'),
    -- Lifecycle
    is_active               BOOL,
    created_at              TIMESTAMP,
    updated_at              TIMESTAMP,
    created_by              STRING
)
CLUSTER BY opco, target_dataset_layer
OPTIONS(description='CDL master config — all pipeline behaviour in one table');


CREATE TABLE IF NOT EXISTS `cdl_metadata.cdl_table_run_log` (
    run_id              STRING    OPTIONS(description='SHA-256 of dag_id|task_id|run_date|attempt'),
    dataset_id          STRING    OPTIONS(description='FK → cdl_table_config.table_id'),
    dag_run_date        DATE      OPTIONS(description='Logical processing date — partition key'),
    dag_id              STRING,
    task_id             STRING,
    dataset_layer       STRING    OPTIONS(description='ACCOUNT | FACILITY | COUNTRY | GLOBAL'),
    opco                STRING,
    table_name          STRING,
    status              STRING    OPTIONS(description='RUNNING | SUCCESS | FAILED | SKIPPED | HALTED'),
    attempt_number      INT64,
    rows_read           INT64,
    rows_written        INT64,
    rows_rejected       INT64,
    rows_merged         INT64,
    rows_inserted       INT64,
    rows_updated        INT64,
    rows_deleted        INT64,
    watermark_start     TIMESTAMP,
    watermark_end       TIMESTAMP,
    started_at          TIMESTAMP,
    completed_at        TIMESTAMP,
    duration_seconds    INT64,
    -- JSON array: [{"rule_id","rule_type","target_column","severity","passed","rows_checked","rows_failed","failure_pct"}]
    dq_results          STRING    OPTIONS(description='JSON array of per-rule DQ results'),
    dq_passed           BOOL,
    error_code          STRING,
    error_message       STRING,
    spark_app_id        STRING,
    cluster_id          STRING,
    created_at          TIMESTAMP,
    updated_at          TIMESTAMP
)
PARTITION BY dag_run_date
CLUSTER BY opco, dataset_layer, status
OPTIONS(partition_expiration_days=365, description='Full execution audit log');
