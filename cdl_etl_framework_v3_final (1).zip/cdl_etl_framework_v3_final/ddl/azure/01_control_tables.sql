-- =============================================================================
-- CDL ETL Framework — Control Tables  (Azure Databricks + Delta Lake)
-- Schema : cdl_metadata
-- ONLY 2 TABLES:
--   1. cdl_table_config   — pipeline topology, DQ rules, retry, alerts,
--                           watermark, dependency gate — everything in one row
--   2. cdl_table_run_log  — full execution audit log per task attempt
-- =============================================================================

CREATE SCHEMA IF NOT EXISTS cdl_metadata;

-- ---------------------------------------------------------------------------
-- 1. cdl_table_config
--    One row per source→target table mapping.
--    All framework behaviour — DQ rules, retry policy, alert routing,
--    watermark state, dependency gate — is encoded in this single table.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS cdl_metadata.cdl_table_config (

    -- ── Identity ─────────────────────────────────────────────────────────
    table_id                STRING    NOT NULL
        COMMENT 'Unique logical ID e.g. ground_account_daily_to_facility_daily',

    -- ── Source ───────────────────────────────────────────────────────────
    source_system           STRING    NOT NULL
        COMMENT 'Source system name: ACCOUNT_DB | DELTA_LAKE | ORACLE | EDW | SQL_SERVER',
    source_table_name       STRING    NOT NULL
        COMMENT 'Physical source table or view name',
    source_filter           STRING
        COMMENT 'Optional SQL WHERE clause applied at source read time',

    -- ── Target ───────────────────────────────────────────────────────────
    target_system           STRING    NOT NULL
        COMMENT 'Target platform: DELTA_LAKE | BIGQUERY',
    target_table_name       STRING    NOT NULL
        COMMENT 'Physical target table name',
    target_dataset_layer    STRING    NOT NULL
        COMMENT 'Pipeline layer: ACCOUNT | FACILITY | COUNTRY | GLOBAL',
    opco                    STRING    NOT NULL
        COMMENT 'Operating company: GROUND | FREIGHT | INTERNATIONAL',

    -- ── Ingestion mode ───────────────────────────────────────────────────
    ingestion_mode          STRING    NOT NULL
        COMMENT 'FULL | INCR | CDC',
    load_frequency          STRING    NOT NULL
        COMMENT 'DAILY | MONTHLY | BOTH',
    watermark_column        STRING
        COMMENT 'Column used to track delta for INCR mode e.g. last_modified_ts',
    last_watermark_value    TIMESTAMP
        COMMENT 'Persisted watermark from last successful INCR run (replaces cdl_watermark_state)',
    last_successful_run     DATE
        COMMENT 'Date of last successful run — updated by framework after each success',
    partition_col           STRING
        COMMENT 'Target partition column e.g. load_date',
    merge_keys              STRING
        COMMENT 'Comma-separated PK columns used in MERGE statement e.g. account_id,opco,effective_date',

    -- ── Data Quality ─────────────────────────────────────────────────────
    -- Stored as a JSON array of rule objects.
    -- Each rule object:
    -- {
    --   "rule_id"             : "not_null_account_id",
    --   "rule_type"           : "NOT_NULL | RANGE | REGEX | CUSTOM_SQL | ROW_COUNT | UNIQUENESS",
    --   "target_column"       : "account_id",           -- null for table-level rules
    --   "rule_expression"     : "account_id IS NOT NULL",
    --   "severity"            : "CRITICAL | WARNING | INFO",
    --   "error_threshold_pct" : 0.0                     -- max % failures allowed (0 = zero tolerance)
    -- }
    data_quality_rules      STRING
        COMMENT 'JSON array of inline DQ rule objects — see column comment for schema',
    dq_threshold_pct        DOUBLE
        COMMENT 'Min % rows passing CRITICAL DQ rules required to mark layer as passed (0–100)',

    -- ── Dependency gate ──────────────────────────────────────────────────
    -- Which upstream table_id must have dq_passed=TRUE in today''s run log
    -- before this table is allowed to execute.
    -- NULL = no upstream dependency (e.g. ACCOUNT layer).
    -- Multiple dependencies: comma-separated table_ids.
    depends_on_table_ids    STRING
        COMMENT 'Comma-separated upstream table_ids that must DQ-pass before this runs. NULL = no gate.',

    -- ── Retry policy ─────────────────────────────────────────────────────
    retry_max_attempts      INT
        COMMENT 'Total attempts including first try. Default 3.',
    retry_initial_wait_sec  INT
        COMMENT 'Seconds to wait before first retry. Default 30.',
    retry_backoff_multiplier DOUBLE
        COMMENT 'Exponential multiplier per attempt. Default 2.0.',
    retry_max_wait_sec      INT
        COMMENT 'Upper bound on wait between retries. Default 300.',

    -- ── Alerting ─────────────────────────────────────────────────────────
    -- Stored as a JSON array of alert channel objects.
    -- Each alert object:
    -- {
    --   "channel"    : "EMAIL | TEAMS | SLACK",
    --   "recipients" : "user@company.com,user2@company.com",
    --   "on_status"  : ["FAILED", "HALTED"]
    -- }
    alert_config            STRING
        COMMENT 'JSON array of alert channel objects — see column comment for schema',

    -- ── Lifecycle ────────────────────────────────────────────────────────
    is_active               BOOLEAN   NOT NULL
        COMMENT 'Toggle to enable or disable this pipeline mapping',
    created_at              TIMESTAMP NOT NULL
        COMMENT 'Row creation timestamp',
    updated_at              TIMESTAMP NOT NULL
        COMMENT 'Last modification timestamp',
    created_by              STRING
        COMMENT 'Who created this row',

    CONSTRAINT pk_cdl_table_config PRIMARY KEY (table_id)
)
USING DELTA
TBLPROPERTIES (
    'delta.enableChangeDataFeed'              = 'true',
    'delta.autoOptimize.optimizeWrite'        = 'true',
    'delta.autoOptimize.autoCompact'          = 'true'
)
COMMENT 'CDL master config table — all pipeline behaviour driven from here';


-- ---------------------------------------------------------------------------
-- 2. cdl_table_run_log
--    Full execution audit.  One row per task attempt.
--    Partitioned by dag_run_date for efficient time-based queries.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS cdl_metadata.cdl_table_run_log (

    -- ── Identity ─────────────────────────────────────────────────────────
    run_id                  STRING    NOT NULL
        COMMENT 'SHA-256 hash of dag_id | task_id | dag_run_date | attempt_number',
    dataset_id              STRING    NOT NULL
        COMMENT 'FK → cdl_table_config.table_id',
    dag_run_date            DATE      NOT NULL
        COMMENT 'Logical processing date (Airflow execution_date as DATE) — partition key',
    dag_id                  STRING    NOT NULL
        COMMENT 'Airflow DAG identifier',
    task_id                 STRING    NOT NULL
        COMMENT 'Airflow task identifier',

    -- ── Context ───────────────────────────────────────────────────────────
    dataset_layer           STRING    NOT NULL
        COMMENT 'ACCOUNT | FACILITY | COUNTRY | GLOBAL',
    opco                    STRING    NOT NULL
        COMMENT 'Operating company',
    table_name              STRING    NOT NULL
        COMMENT 'Physical target table being processed',

    -- ── Execution state ──────────────────────────────────────────────────
    status                  STRING    NOT NULL
        COMMENT 'RUNNING | SUCCESS | FAILED | SKIPPED | HALTED',
    attempt_number          INT       NOT NULL
        COMMENT 'Retry attempt sequence — starts at 1',

    -- ── Row-level metrics ────────────────────────────────────────────────
    rows_read               BIGINT    COMMENT 'Records scanned from source',
    rows_written            BIGINT    COMMENT 'Total records committed to target',
    rows_rejected           BIGINT    COMMENT 'Records failing inline DQ rules',
    rows_merged             BIGINT    COMMENT 'Merged records (upsert total)',
    rows_inserted           BIGINT    COMMENT 'Newly inserted records',
    rows_updated            BIGINT    COMMENT 'Updated records',
    rows_deleted            BIGINT    COMMENT 'Deleted records (CDC)',

    -- ── Watermark ────────────────────────────────────────────────────────
    watermark_start         TIMESTAMP COMMENT 'Low-watermark used in this run',
    watermark_end           TIMESTAMP COMMENT 'High-watermark used in this run (written back to cdl_table_config)',

    -- ── Timing ───────────────────────────────────────────────────────────
    started_at              TIMESTAMP COMMENT 'Wall-clock execution start time',
    completed_at            TIMESTAMP COMMENT 'Wall-clock execution end time',
    duration_seconds        INT       COMMENT 'Elapsed seconds (completed_at - started_at)',

    -- ── Data Quality ─────────────────────────────────────────────────────
    -- Structured JSON array matching this schema:
    -- [{ "rule_id": "...", "rule_type": "...", "target_column": "...",
    --    "severity": "...", "passed": true, "rows_checked": 1000,
    --    "rows_failed": 0, "failure_pct": 0.0, "error_message": null }]
    dq_results              STRING    COMMENT 'JSON array of per-rule DQ check results',
    dq_passed               BOOLEAN   COMMENT 'Overall DQ pass/fail for this run',

    -- ── Error ────────────────────────────────────────────────────────────
    error_code              STRING    COMMENT 'Standardised error category code',
    error_message           STRING    COMMENT 'Full stack trace or exception detail',

    -- ── Infrastructure ───────────────────────────────────────────────────
    spark_app_id            STRING    COMMENT 'Spark application ID for log correlation',
    cluster_id              STRING    COMMENT 'Databricks / Dataproc cluster ID',

    -- ── Audit ────────────────────────────────────────────────────────────
    created_at              TIMESTAMP NOT NULL COMMENT 'Row creation timestamp',
    updated_at              TIMESTAMP NOT NULL COMMENT 'Last row update timestamp',

    CONSTRAINT pk_cdl_run_log PRIMARY KEY (run_id, attempt_number)
)
USING DELTA
PARTITIONED BY (dag_run_date)
TBLPROPERTIES (
    'delta.enableChangeDataFeed'       = 'true',
    'delta.autoOptimize.optimizeWrite' = 'true',
    'delta.logRetentionDuration'       = 'interval 90 days'
)
COMMENT 'Full execution audit log — every task attempt recorded here';


-- ---------------------------------------------------------------------------
-- Post-creation optimisation hints (run after initial data load)
-- ---------------------------------------------------------------------------
-- OPTIMIZE cdl_metadata.cdl_table_config  ZORDER BY (opco, target_dataset_layer);
-- OPTIMIZE cdl_metadata.cdl_table_run_log ZORDER BY (opco, dataset_layer, dag_run_date);
