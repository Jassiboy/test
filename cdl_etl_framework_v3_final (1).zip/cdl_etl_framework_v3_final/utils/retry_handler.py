"""
cdl_etl_framework/utils/retry_handler.py
=========================================
Exponential backoff retry decorator.
Note: In the 2-table design, retry policy lives in cdl_table_config columns
(retry_max_attempts, retry_initial_wait_sec, etc.) and is applied directly
inside IngestionEngine.run_table(). This module provides the decorator for
any utility functions that need standalone retry logic.
"""

import functools
import logging
import random
import time
from typing import Callable, Tuple, Type

logger = logging.getLogger("cdl.retry")


def with_retry(
    max_attempts: int = 3,
    initial_wait: float = 30.0,
    backoff_multiplier: float = 2.0,
    max_wait: float = 300.0,
    jitter_fraction: float = 0.1,
    retryable_exceptions: Tuple[Type[Exception], ...] = (Exception,),
):
    """
    Decorator — wraps a function with exponential backoff retry.

    Example:
        @with_retry(max_attempts=3, initial_wait=10)
        def call_external_api():
            ...
    """
    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            last_exc = None
            for attempt in range(1, max_attempts + 1):
                try:
                    return func(*args, **kwargs)
                except retryable_exceptions as exc:
                    last_exc = exc
                    if attempt == max_attempts:
                        logger.error(
                            f"[retry] {func.__name__} failed after "
                            f"{max_attempts} attempts: {exc}"
                        )
                        raise
                    wait = _wait(attempt, initial_wait, backoff_multiplier,
                                 max_wait, jitter_fraction)
                    logger.warning(
                        f"[retry] {func.__name__} attempt {attempt}/{max_attempts} "
                        f"failed: {exc}. Retrying in {wait:.1f}s"
                    )
                    time.sleep(wait)
            raise last_exc
        return wrapper
    return decorator


def rollback_delta(spark, table_name: str) -> bool:
    """Roll back a Delta table to its previous version after a failed write."""
    try:
        history = spark.sql(f"DESCRIBE HISTORY {table_name} LIMIT 2").collect()
        if len(history) < 2:
            logger.warning(f"[rollback] {table_name}: no prior version available")
            return False
        ver = history[1]["version"]
        logger.warning(f"[rollback] Restoring {table_name} to version {ver}")
        spark.sql(f"RESTORE TABLE {table_name} TO VERSION AS OF {ver}")
        logger.info(f"[rollback] {table_name} restored to version {ver} ✓")
        return True
    except Exception as e:
        logger.error(f"[rollback] {table_name} restore failed: {e}")
        return False


def _wait(attempt, initial, mult, cap, jitter) -> float:
    w = min(initial * (mult ** (attempt - 1)), cap)
    return max(0.0, w + random.uniform(-jitter * w, jitter * w))
