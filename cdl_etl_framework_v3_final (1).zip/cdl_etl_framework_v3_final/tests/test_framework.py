"""
tests/test_framework.py
========================
Full test suite for the v3 2-table, OPCO-folder, dual-mode design.
Run: pytest tests/test_framework.py -v
"""

import json
import pytest
from datetime import date
from unittest.mock import MagicMock, patch


# ─────────────────────────────────────────────────────────────────────────────
# Spark fixture
# ─────────────────────────────────────────────────────────────────────────────
@pytest.fixture(scope="session")
def spark():
    from pyspark.sql import SparkSession
    s = (SparkSession.builder
         .master("local[2]")
         .appName("cdl_test")
         .config("spark.sql.extensions",
                 "io.delta.sql.DeltaSparkSessionExtension")
         .config("spark.sql.catalog.spark_catalog",
                 "org.apache.spark.sql.delta.catalog.DeltaCatalog")
         .config("spark.sql.shuffle.partitions", "2")
         .getOrCreate())
    s.sparkContext.setLogLevel("ERROR")
    return s


# ─────────────────────────────────────────────────────────────────────────────
# Helper: build a minimal TableConfig
# ─────────────────────────────────────────────────────────────────────────────
def mock_cfg(**overrides):
    from notebooks.01_framework_core import TableConfig
    defaults = dict(
        table_id             = "ground_account_daily",
        source_system        = "ACCOUNT_DB",
        source_table_name    = "raw_t",
        source_filter        = None,
        target_system        = "DELTA_LAKE",
        target_table_name    = "account_daily",
        target_dataset_layer = "ACCOUNT",
        opco                 = "GROUND",
        ingestion_mode       = "FULL",
        load_frequency       = "DAILY",
        watermark_column     = None,
        last_watermark_value = None,
        partition_col        = "load_date",
        merge_keys           = "account_id,opco,effective_date",
        dq_rules = [
            {"rule_id": "not_null_id",  "rule_type": "NOT_NULL",
             "target_column": "account_id",
             "rule_expression": "account_id IS NOT NULL",
             "severity": "CRITICAL", "error_threshold_pct": 0.0},
            {"rule_id": "positive_rev", "rule_type": "RANGE",
             "target_column": "revenue",
             "rule_expression": "revenue >= 0",
             "severity": "WARNING",  "error_threshold_pct": 1.0},
        ],
        dq_threshold_pct   = 95.0,
        depends_on         = [],
        retry_max_attempts = 2,
        retry_wait_sec     = 1,
        retry_backoff      = 2.0,
        retry_max_wait     = 5,
        alert_config       = [],
        is_active          = True,
    )
    defaults.update(overrides)
    return TableConfig(**defaults)


# ===========================================================================
# DQ engine tests
# ===========================================================================
class TestDQ:

    def test_all_rules_pass(self, spark):
        from notebooks.01_framework_core import run_dq
        df = spark.createDataFrame(
            [("A1", "GROUND", 100.0), ("A2", "GROUND", 50.0)],
            "account_id STRING, opco STRING, revenue DOUBLE")
        _, results, overall = run_dq(spark, df, mock_cfg())
        assert overall is True
        assert all(r["passed"] for r in results if r["severity"] == "CRITICAL")

    def test_critical_null_fails_overall(self, spark):
        from notebooks.01_framework_core import run_dq
        df = spark.createDataFrame(
            [(None, "GROUND", 100.0), ("A2", "GROUND", 50.0)],
            "account_id STRING, opco STRING, revenue DOUBLE")
        _, results, overall = run_dq(spark, df, mock_cfg())
        assert overall is False
        crit = next(r for r in results if r["rule_id"] == "not_null_id")
        assert crit["rows_failed"] == 1

    def test_warning_does_not_block_overall(self, spark):
        from notebooks.01_framework_core import run_dq
        # account_id present (CRITICAL OK), revenue negative (WARNING)
        df = spark.createDataFrame(
            [("A1", "GROUND", -50.0), ("A2", "GROUND", 100.0)],
            "account_id STRING, opco STRING, revenue DOUBLE")
        _, results, overall = run_dq(spark, df, mock_cfg())
        assert overall is True
        warn = next(r for r in results if r["rule_id"] == "positive_rev")
        assert warn["passed"] is False

    def test_row_count_pass(self, spark):
        from notebooks.01_framework_core import run_dq
        cfg = mock_cfg(dq_rules=[{
            "rule_id": "min_rows", "rule_type": "ROW_COUNT",
            "target_column": None,
            "rule_expression": '{"min_rows": 1}',
            "severity": "CRITICAL", "error_threshold_pct": 0.0}])
        df = spark.createDataFrame([("A1",)], "account_id STRING")
        _, _, overall = run_dq(spark, df, cfg)
        assert overall is True

    def test_row_count_fail_on_empty(self, spark):
        from notebooks.01_framework_core import run_dq
        from pyspark.sql.types import StructType, StructField, StringType
        cfg = mock_cfg(dq_rules=[{
            "rule_id": "min_rows", "rule_type": "ROW_COUNT",
            "target_column": None,
            "rule_expression": '{"min_rows": 1}',
            "severity": "CRITICAL", "error_threshold_pct": 0.0}])
        schema = StructType([StructField("account_id", StringType(), True)])
        df     = spark.createDataFrame([], schema)
        _, _, overall = run_dq(spark, df, cfg)
        assert overall is False

    def test_rows_tagged_clean_and_rejected(self, spark):
        from notebooks.01_framework_core import run_dq
        df = spark.createDataFrame(
            [(None, "GROUND", 100.0), ("A2", "GROUND", 50.0)],
            "account_id STRING, opco STRING, revenue DOUBLE")
        df_tagged, _, _ = run_dq(spark, df, mock_cfg())
        tags = {r["account_id"]: r["dq_passed"] for r in df_tagged.collect()}
        assert tags["A2"] is True
        assert tags[None] is False

    def test_threshold_blocks_when_too_many_failures(self, spark):
        from notebooks.01_framework_core import run_dq
        cfg = mock_cfg(
            dq_threshold_pct=99.0,
            dq_rules=[{"rule_id": "not_null_id", "rule_type": "NOT_NULL",
                        "target_column": "account_id",
                        "rule_expression": "account_id IS NOT NULL",
                        "severity": "CRITICAL", "error_threshold_pct": 0.0}])
        # 50% null rows → fails 99% threshold
        df = spark.createDataFrame(
            [(None,), (None,), ("A3",), ("A4",)], "account_id STRING")
        _, _, overall = run_dq(spark, df, cfg)
        assert overall is False


# ===========================================================================
# DQ gate tests
# ===========================================================================
class TestDQGate:

    def _spark_sql(self, rows):
        spark = MagicMock()
        spark.sql.return_value.collect.return_value = rows
        return spark

    def test_no_deps_always_passes(self):
        from notebooks.01_framework_core import check_dq_gate
        spark = self._spark_sql([])
        ok, failed = check_dq_gate(spark, [mock_cfg(depends_on=[])],
                                   date(2026, 1, 31), "GROUND")
        assert ok is True and failed == []

    def test_upstream_present_and_passed(self):
        from notebooks.01_framework_core import check_dq_gate
        row = MagicMock()
        row.__getitem__ = lambda s, k: \
            {"dataset_id": "ground_account_daily", "ok": 1}[k]
        spark = self._spark_sql([row])
        cfg   = mock_cfg(depends_on=["ground_account_daily"])
        ok, failed = check_dq_gate(spark, [cfg], date(2026, 1, 31), "GROUND")
        assert ok is True

    def test_upstream_missing_from_log(self):
        from notebooks.01_framework_core import check_dq_gate
        spark = self._spark_sql([])   # nothing in log
        cfg   = mock_cfg(depends_on=["ground_account_daily"])
        ok, failed = check_dq_gate(spark, [cfg], date(2026, 1, 31), "GROUND")
        assert ok is False
        assert "ground_account_daily" in failed


# ===========================================================================
# Run ID tests
# ===========================================================================
class TestRunId:

    def test_deterministic(self):
        from notebooks.01_framework_core import make_run_id
        r1 = make_run_id("dag", "tbl", date(2026, 1, 31), 1)
        r2 = make_run_id("dag", "tbl", date(2026, 1, 31), 1)
        assert r1 == r2

    def test_differs_by_attempt(self):
        from notebooks.01_framework_core import make_run_id
        assert make_run_id("dag", "t", date(2026, 1, 31), 1) != \
               make_run_id("dag", "t", date(2026, 1, 31), 2)

    def test_32_hex_chars(self):
        from notebooks.01_framework_core import make_run_id
        rid = make_run_id("dag", "tbl", date(2026, 1, 31), 1)
        assert len(rid) == 32
        assert all(c in "0123456789abcdef" for c in rid)


# ===========================================================================
# Date spine tests
# ===========================================================================
class TestDateSpine:

    def test_single_month(self):
        from notebooks.04_pipeline_runner import monthly_spine
        assert monthly_spine(date(2026, 3, 1), date(2026, 3, 31)) \
               == [date(2026, 3, 31)]

    def test_five_months(self):
        from notebooks.04_pipeline_runner import monthly_spine
        assert monthly_spine(date(2026, 1, 1), date(2026, 5, 31)) == [
            date(2026, 1, 31), date(2026, 2, 28),
            date(2026, 3, 31), date(2026, 4, 30), date(2026, 5, 31),
        ]

    def test_end_date_caps_last_month(self):
        from notebooks.04_pipeline_runner import monthly_spine
        assert monthly_spine(date(2026, 1, 1), date(2026, 1, 15)) \
               == [date(2026, 1, 15)]

    def test_cross_year_boundary(self):
        from notebooks.04_pipeline_runner import monthly_spine
        assert monthly_spine(date(2025, 11, 1), date(2026, 2, 28)) == [
            date(2025, 11, 30), date(2025, 12, 31),
            date(2026, 1, 31),  date(2026, 2, 28),
        ]


# ===========================================================================
# layers_from tests
# ===========================================================================
class TestLayersFrom:

    def test_from_account(self):
        from notebooks.04_pipeline_runner import layers_from
        assert layers_from("ACCOUNT") == ["ACCOUNT", "FACILITY", "COUNTRY", "GLOBAL"]

    def test_from_facility(self):
        from notebooks.04_pipeline_runner import layers_from
        assert layers_from("FACILITY") == ["FACILITY", "COUNTRY", "GLOBAL"]

    def test_from_country(self):
        from notebooks.04_pipeline_runner import layers_from
        assert layers_from("COUNTRY") == ["COUNTRY", "GLOBAL"]

    def test_from_global(self):
        from notebooks.04_pipeline_runner import layers_from
        assert layers_from("GLOBAL") == ["GLOBAL"]

    def test_case_insensitive(self):
        from notebooks.04_pipeline_runner import layers_from
        assert layers_from("facility") == ["FACILITY", "COUNTRY", "GLOBAL"]

    def test_invalid_raises(self):
        from notebooks.04_pipeline_runner import layers_from
        with pytest.raises(ValueError, match="Invalid start_layer"):
            layers_from("BRONZE")


# ===========================================================================
# Transformation loader tests
# ===========================================================================
class TestTransformationLoader:

    def test_ground_account_importable(self):
        import transformations.ground.account as m
        assert callable(getattr(m, "transform_daily",   None))
        assert callable(getattr(m, "transform_monthly", None))

    def test_ground_facility_importable(self):
        import transformations.ground.facility as m
        assert callable(getattr(m, "transform_daily",   None))
        assert callable(getattr(m, "transform_monthly", None))

    def test_ground_country_importable(self):
        import transformations.ground.country as m
        assert callable(getattr(m, "transform_daily",   None))
        assert callable(getattr(m, "transform_monthly", None))

    def test_ground_global_importable(self):
        import transformations.ground.global_ as m
        assert callable(getattr(m, "transform_daily",   None))
        assert callable(getattr(m, "transform_monthly", None))

    def test_unknown_opco_raises(self):
        from notebooks.03_transformation import get_transformed_df
        with pytest.raises(ValueError, match="No transformation module"):
            get_transformed_df(MagicMock(), "UNKNOWN", "ACCOUNT", "DAILY",
                               date(2026, 1, 31))

    def test_unknown_layer_raises(self):
        from notebooks.03_transformation import get_transformed_df
        with pytest.raises(ValueError, match="No transformation module"):
            get_transformed_df(MagicMock(), "GROUND", "BRONZE", "DAILY",
                               date(2026, 1, 31))


# ===========================================================================
# Range fallback union test
# ===========================================================================
class TestRangeFallback:

    def test_fallback_calls_base_fn_per_month(self):
        """
        When a module has no transform_daily_range, the loader should call
        transform_daily once per month and union the results.
        """
        from notebooks.03_transformation import get_transformed_df

        call_log = []

        # Minimal fake module with only transform_daily (no range version)
        fake_module = MagicMock()
        del fake_module.transform_daily_range        # ensure it doesn't exist
        fake_module.transform_monthly_range = None   # also missing

        def fake_daily(spark, run_date, opco):
            call_log.append(str(run_date))
            df = spark.createDataFrame(
                [(str(run_date),)], "load_date STRING"
            )
            return df

        fake_module.transform_daily = fake_daily

        import importlib
        with patch("importlib.import_module", return_value=fake_module):
            spark = MagicMock()
            # Simulate unionByName chaining
            spark.createDataFrame.side_effect = lambda rows, schema: MagicMock(
                unionByName=lambda other: other
            )

            try:
                get_transformed_df(
                    spark, "GROUND", "ACCOUNT", "DAILY",
                    run_date=date(2026, 3, 31),
                    start_date=date(2026, 1, 1),
                    end_date=date(2026, 3, 31),
                )
            except Exception:
                pass  # unionByName mock may not chain perfectly — we just check calls

        # 3 months should have been requested: Jan, Feb, Mar
        assert len(call_log) == 3
        assert "2026-01-31" in call_log
        assert "2026-02-28" in call_log
        assert "2026-03-31" in call_log


# ===========================================================================
# ingest_mode in run_config.json tests
# ===========================================================================
class TestRunConfig:

    def test_run_config_has_ingest_mode_field(self, tmp_path):
        cfg = {
            "env": "azure", "dag_id": "test_dag",
            "runs": [
                {"opco": "GROUND", "start_date": "2026-01-01",
                 "end_date": "2026-01-31", "start_layer": "ACCOUNT",
                 "frequency": "BOTH", "ingest_mode": "range"},
                {"opco": "GROUND", "start_date": "2026-02-01",
                 "end_date": "2026-02-28", "start_layer": "FACILITY",
                 "frequency": "DAILY", "ingest_mode": "month_by_month"},
            ]
        }
        p = tmp_path / "run_config.json"
        p.write_text(json.dumps(cfg))
        loaded = json.loads(p.read_text())
        assert loaded["runs"][0]["ingest_mode"] == "range"
        assert loaded["runs"][1]["ingest_mode"] == "month_by_month"
        assert loaded["runs"][1]["start_layer"] == "FACILITY"

    def test_default_ingest_mode_is_month_by_month(self):
        """Omitting ingest_mode should default to month_by_month in the runner."""
        run_block = {"opco": "GROUND", "start_date": "2026-01-01",
                     "end_date": "2026-01-31"}
        mode = run_block.get("ingest_mode", "month_by_month").lower()
        assert mode == "month_by_month"


# ===========================================================================
# Retry handler tests
# ===========================================================================
class TestRetry:

    def test_success_first_try(self):
        from utils.retry_handler import with_retry
        calls = {"n": 0}
        @with_retry(max_attempts=3, initial_wait=0.01)
        def fn():
            calls["n"] += 1
            return "ok"
        assert fn() == "ok"
        assert calls["n"] == 1

    def test_retries_then_succeeds(self):
        from utils.retry_handler import with_retry
        calls = {"n": 0}
        @with_retry(max_attempts=3, initial_wait=0.01, backoff_multiplier=1.0)
        def fn():
            calls["n"] += 1
            if calls["n"] < 3:
                raise RuntimeError("transient")
            return "ok"
        assert fn() == "ok"
        assert calls["n"] == 3

    def test_raises_after_max_attempts(self):
        from utils.retry_handler import with_retry
        @with_retry(max_attempts=2, initial_wait=0.01, backoff_multiplier=1.0)
        def fn():
            raise ValueError("permanent")
        with pytest.raises(ValueError, match="permanent"):
            fn()

    def test_backoff_caps_at_max(self):
        from utils.retry_handler import _wait
        assert _wait(10, 30.0, 2.0, 300.0, 0.0) == 300.0

    def test_backoff_doubles_each_attempt(self):
        from utils.retry_handler import _wait
        assert abs(_wait(1, 30.0, 2.0, 9999.0, 0.0) - 30.0)  < 0.01
        assert abs(_wait(2, 30.0, 2.0, 9999.0, 0.0) - 60.0)  < 0.01
        assert abs(_wait(3, 30.0, 2.0, 9999.0, 0.0) - 120.0) < 0.01
