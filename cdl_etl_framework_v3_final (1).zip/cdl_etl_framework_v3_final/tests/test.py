# Databricks notebook source
# MAGIC %sql
# MAGIC select * from hive_metastore.ds_fcst_de_prod.fxg_acct_bill_mth_hist limit 3

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from hive_metastore.ds_fcst_de_prod.fxg_acct_bill_dly_hist limit 3

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from hive_metastore.ds_fcst_de_prod.fxg_fac_enti_bill_dly_hist limit 3

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from hive_metastore.ds_fcst_de_prod.fxg_fac_enti_bill_mth_hist limit 3