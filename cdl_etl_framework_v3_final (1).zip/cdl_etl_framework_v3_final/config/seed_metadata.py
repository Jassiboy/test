"""
cdl_etl_framework/config/seed_metadata.py
==========================================
Seeds cdl_table_config with all 8 pipeline mappings for one OPCO.
All DQ rules, retry policy, alerts, watermark, and dependency gate
are encoded inline in each row — no auxiliary tables needed.

Usage:
    python seed_metadata.py --env azure --opco GROUND
    python seed_metadata.py --env gcp   --opco GROUND
"""

import argparse
import json
import os
import sys
from datetime import datetime, timezone

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from config.env_config import get_metadata_db

NOW = datetime.now(timezone.utc).isoformat()

# ---------------------------------------------------------------------------
# Reusable DQ rule sets  (inlined per table row)
# ---------------------------------------------------------------------------
def _dq_account():
    return json.dumps([
        {"rule_id": "not_null_account_id",   "rule_type": "NOT_NULL",
         "target_column": "account_id",      "rule_expression": "account_id IS NOT NULL",
         "severity": "CRITICAL",             "error_threshold_pct": 0.0},
        {"rule_id": "not_null_opco",          "rule_type": "NOT_NULL",
         "target_column": "opco",            "rule_expression": "opco IS NOT NULL",
         "severity": "CRITICAL",             "error_threshold_pct": 0.0},
        {"rule_id": "valid_account_status",   "rule_type": "RANGE",
         "target_column": "account_status",
         "rule_expression": "account_status IN ('ACTIVE','INACTIVE','SUSPENDED')",
         "severity": "WARNING",              "error_threshold_pct": 1.0},
        {"rule_id": "non_negative_revenue",   "rule_type": "RANGE",
         "target_column": "revenue",         "rule_expression": "revenue >= 0",
         "severity": "WARNING",              "error_threshold_pct": 0.5},
        {"rule_id": "row_count_min",          "rule_type": "ROW_COUNT",
         "target_column": None,              "rule_expression": '{"min_rows": 1}',
         "severity": "CRITICAL",             "error_threshold_pct": 0.0},
    ])

def _dq_facility():
    return json.dumps([
        {"rule_id": "not_null_facility_id",   "rule_type": "NOT_NULL",
         "target_column": "facility_id",     "rule_expression": "facility_id IS NOT NULL",
         "severity": "CRITICAL",             "error_threshold_pct": 0.0},
        {"rule_id": "not_null_account_id",    "rule_type": "NOT_NULL",
         "target_column": "account_id",      "rule_expression": "account_id IS NOT NULL",
         "severity": "CRITICAL",             "error_threshold_pct": 0.0},
        {"rule_id": "valid_facility_status",  "rule_type": "RANGE",
         "target_column": "facility_status",
         "rule_expression": "facility_status IN ('ACTIVE','INACTIVE','UNDER_MAINTENANCE')",
         "severity": "WARNING",              "error_threshold_pct": 1.0},
        {"rule_id": "utilisation_range",      "rule_type": "RANGE",
         "target_column": "utilisation_pct",
         "rule_expression": "utilisation_pct BETWEEN 0 AND 100",
         "severity": "WARNING",              "error_threshold_pct": 0.5},
        {"rule_id": "row_count_min",          "rule_type": "ROW_COUNT",
         "target_column": None,              "rule_expression": '{"min_rows": 1}',
         "severity": "CRITICAL",             "error_threshold_pct": 0.0},
    ])

def _dq_country():
    return json.dumps([
        {"rule_id": "not_null_country_code",  "rule_type": "NOT_NULL",
         "target_column": "country_code",    "rule_expression": "country_code IS NOT NULL",
         "severity": "CRITICAL",             "error_threshold_pct": 0.0},
        {"rule_id": "iso_country_code",       "rule_type": "REGEX",
         "target_column": "country_code",    "rule_expression": "LENGTH(country_code) = 2",
         "severity": "WARNING",              "error_threshold_pct": 0.0},
        {"rule_id": "gross_margin_derived",   "rule_type": "CUSTOM_SQL",
         "target_column": "gross_margin",
         "rule_expression": "ABS(gross_margin - (revenue - cost)) < 0.01",
         "severity": "WARNING",              "error_threshold_pct": 1.0},
        {"rule_id": "row_count_min",          "rule_type": "ROW_COUNT",
         "target_column": None,              "rule_expression": '{"min_rows": 1}',
         "severity": "CRITICAL",             "error_threshold_pct": 0.0},
    ])

def _dq_global():
    return json.dumps([
        {"rule_id": "not_null_opco",          "rule_type": "NOT_NULL",
         "target_column": "opco",            "rule_expression": "opco IS NOT NULL",
         "severity": "CRITICAL",             "error_threshold_pct": 0.0},
        {"rule_id": "positive_total_revenue", "rule_type": "RANGE",
         "target_column": "revenue",         "rule_expression": "revenue > 0",
         "severity": "CRITICAL",             "error_threshold_pct": 0.0},
        {"rule_id": "margin_pct_range",       "rule_type": "RANGE",
         "target_column": "gross_margin_pct",
         "rule_expression": "gross_margin_pct BETWEEN -100 AND 100",
         "severity": "WARNING",              "error_threshold_pct": 0.5},
        {"rule_id": "row_count_min",          "rule_type": "ROW_COUNT",
         "target_column": None,              "rule_expression": '{"min_rows": 1}',
         "severity": "CRITICAL",             "error_threshold_pct": 0.0},
    ])

def _alerts_critical():
    return json.dumps([
        {"channel": "EMAIL",
         "recipients": "cdl-alerts@company.com,data-eng-oncall@company.com",
         "on_status": ["FAILED", "HALTED"]},
        {"channel": "TEAMS",
         "recipients": "https://company.webhook.office.com/webhookb2/cdl-alerts",
         "on_status": ["FAILED"]},
    ])

def _retry_default():
    return {"retry_max_attempts": 3, "retry_initial_wait_sec": 30,
            "retry_backoff_multiplier": 2.0, "retry_max_wait_sec": 300}

def _retry_aggressive():
    return {"retry_max_attempts": 5, "retry_initial_wait_sec": 60,
            "retry_backoff_multiplier": 2.0, "retry_max_wait_sec": 600}


# ---------------------------------------------------------------------------
# Row definitions
# ---------------------------------------------------------------------------
def get_config_rows(opco: str) -> list[dict]:
    o = opco.lower()
    alerts = _alerts_critical()
    rd = _retry_default()
    ra = _retry_aggressive()

    return [
        # ── ACCOUNT daily ────────────────────────────────────────────────
        {**rd, "table_id": f"{o}_account_daily",
         "source_system": "ACCOUNT_DB", "source_table_name": "raw_account_transactions",
         "source_filter": None,
         "target_system": "DELTA_LAKE", "target_table_name": "account_daily",
         "target_dataset_layer": "ACCOUNT", "opco": opco,
         "ingestion_mode": "INCR", "load_frequency": "DAILY",
         "watermark_column": "last_modified_ts",
         "last_watermark_value": None, "last_successful_run": None,
         "partition_col": "load_date",
         "merge_keys": "account_id,opco,effective_date",
         "data_quality_rules": _dq_account(), "dq_threshold_pct": 95.0,
         "depends_on_table_ids": None,          # first layer — no gate
         "alert_config": alerts,
         "is_active": True, "created_at": NOW, "updated_at": NOW, "created_by": "seed_script"},

        # ── ACCOUNT monthly ──────────────────────────────────────────────
        {**rd, "table_id": f"{o}_account_monthly",
         "source_system": "ACCOUNT_DB", "source_table_name": "raw_account_transactions",
         "source_filter": None,
         "target_system": "DELTA_LAKE", "target_table_name": "account_monthly",
         "target_dataset_layer": "ACCOUNT", "opco": opco,
         "ingestion_mode": "FULL", "load_frequency": "MONTHLY",
         "watermark_column": None,
         "last_watermark_value": None, "last_successful_run": None,
         "partition_col": "load_date",
         "merge_keys": "account_id,opco,month_year",
         "data_quality_rules": _dq_account(), "dq_threshold_pct": 95.0,
         "depends_on_table_ids": None,
         "alert_config": alerts,
         "is_active": True, "created_at": NOW, "updated_at": NOW, "created_by": "seed_script"},

        # ── FACILITY daily ───────────────────────────────────────────────
        {**ra, "table_id": f"{o}_facility_daily",
         "source_system": "DELTA_LAKE", "source_table_name": "account_daily",
         "source_filter": None,
         "target_system": "DELTA_LAKE", "target_table_name": "facility_daily",
         "target_dataset_layer": "FACILITY", "opco": opco,
         "ingestion_mode": "INCR", "load_frequency": "DAILY",
         "watermark_column": "load_date",
         "last_watermark_value": None, "last_successful_run": None,
         "partition_col": "load_date",
         "merge_keys": "facility_id,account_id,opco,effective_date",
         "data_quality_rules": _dq_facility(), "dq_threshold_pct": 95.0,
         "depends_on_table_ids": f"{o}_account_daily",   # gate: account_daily must DQ-pass
         "alert_config": alerts,
         "is_active": True, "created_at": NOW, "updated_at": NOW, "created_by": "seed_script"},

        # ── FACILITY monthly ─────────────────────────────────────────────
        {**rd, "table_id": f"{o}_facility_monthly",
         "source_system": "DELTA_LAKE", "source_table_name": "account_monthly",
         "source_filter": None,
         "target_system": "DELTA_LAKE", "target_table_name": "facility_monthly",
         "target_dataset_layer": "FACILITY", "opco": opco,
         "ingestion_mode": "FULL", "load_frequency": "MONTHLY",
         "watermark_column": None,
         "last_watermark_value": None, "last_successful_run": None,
         "partition_col": "load_date",
         "merge_keys": "facility_id,account_id,opco,month_year",
         "data_quality_rules": _dq_facility(), "dq_threshold_pct": 95.0,
         "depends_on_table_ids": f"{o}_account_monthly",
         "alert_config": alerts,
         "is_active": True, "created_at": NOW, "updated_at": NOW, "created_by": "seed_script"},

        # ── COUNTRY daily ────────────────────────────────────────────────
        {**rd, "table_id": f"{o}_country_daily",
         "source_system": "DELTA_LAKE", "source_table_name": "facility_daily",
         "source_filter": None,
         "target_system": "DELTA_LAKE", "target_table_name": "country_daily",
         "target_dataset_layer": "COUNTRY", "opco": opco,
         "ingestion_mode": "FULL", "load_frequency": "DAILY",
         "watermark_column": "load_date",
         "last_watermark_value": None, "last_successful_run": None,
         "partition_col": "load_date",
         "merge_keys": "country_code,opco,effective_date",
         "data_quality_rules": _dq_country(), "dq_threshold_pct": 98.0,
         "depends_on_table_ids": f"{o}_facility_daily",
         "alert_config": alerts,
         "is_active": True, "created_at": NOW, "updated_at": NOW, "created_by": "seed_script"},

        # ── COUNTRY monthly ──────────────────────────────────────────────
        {**rd, "table_id": f"{o}_country_monthly",
         "source_system": "DELTA_LAKE", "source_table_name": "facility_monthly",
         "source_filter": None,
         "target_system": "DELTA_LAKE", "target_table_name": "country_monthly",
         "target_dataset_layer": "COUNTRY", "opco": opco,
         "ingestion_mode": "FULL", "load_frequency": "MONTHLY",
         "watermark_column": None,
         "last_watermark_value": None, "last_successful_run": None,
         "partition_col": "load_date",
         "merge_keys": "country_code,opco,month_year",
         "data_quality_rules": _dq_country(), "dq_threshold_pct": 98.0,
         "depends_on_table_ids": f"{o}_facility_monthly",
         "alert_config": alerts,
         "is_active": True, "created_at": NOW, "updated_at": NOW, "created_by": "seed_script"},

        # ── GLOBAL daily ─────────────────────────────────────────────────
        {**rd, "table_id": f"{o}_global_daily",
         "source_system": "DELTA_LAKE", "source_table_name": "country_daily",
         "source_filter": None,
         "target_system": "DELTA_LAKE", "target_table_name": "global_daily",
         "target_dataset_layer": "GLOBAL", "opco": opco,
         "ingestion_mode": "FULL", "load_frequency": "DAILY",
         "watermark_column": "load_date",
         "last_watermark_value": None, "last_successful_run": None,
         "partition_col": "load_date",
         "merge_keys": "opco,effective_date,region_code",
         "data_quality_rules": _dq_global(), "dq_threshold_pct": 99.0,
         "depends_on_table_ids": f"{o}_country_daily",
         "alert_config": alerts,
         "is_active": True, "created_at": NOW, "updated_at": NOW, "created_by": "seed_script"},

        # ── GLOBAL monthly ───────────────────────────────────────────────
        {**rd, "table_id": f"{o}_global_monthly",
         "source_system": "DELTA_LAKE", "source_table_name": "country_monthly",
         "source_filter": None,
         "target_system": "DELTA_LAKE", "target_table_name": "global_monthly",
         "target_dataset_layer": "GLOBAL", "opco": opco,
         "ingestion_mode": "FULL", "load_frequency": "MONTHLY",
         "watermark_column": None,
         "last_watermark_value": None, "last_successful_run": None,
         "partition_col": "load_date",
         "merge_keys": "opco,month_year,region_code",
         "data_quality_rules": _dq_global(), "dq_threshold_pct": 99.0,
         "depends_on_table_ids": f"{o}_country_monthly",
         "alert_config": alerts,
         "is_active": True, "created_at": NOW, "updated_at": NOW, "created_by": "seed_script"},
    ]


# ---------------------------------------------------------------------------
# Spark insert
# ---------------------------------------------------------------------------
def seed(spark, opco: str):
    metadata_db = get_metadata_db()
    table = f"{metadata_db}.cdl_table_config"
    rows  = get_config_rows(opco)
    df    = spark.createDataFrame(rows)

    existing = spark.table(table).select("table_id")
    new_rows  = df.join(existing, on="table_id", how="left_anti")
    count     = new_rows.count()

    if count > 0:
        new_rows.write.format("delta").mode("append").saveAsTable(table)
        print(f"  ✓ Inserted {count} row(s) into {table}")
    else:
        print(f"  ⏭  All rows already exist in {table}")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--env",  default="azure", choices=["azure", "gcp"])
    parser.add_argument("--opco", default="GROUND")
    args = parser.parse_args()
    os.environ["CDL_ENV"] = args.env

    try:
        from pyspark.sql import SparkSession
        spark = SparkSession.builder.getOrCreate()
    except ImportError:
        print("ERROR: Run on a Databricks / Dataproc cluster with PySpark available.")
        sys.exit(1)

    print(f"\n{'='*55}\n  Seeding cdl_table_config — OPCO={args.opco.upper()}\n{'='*55}")
    seed(spark, args.opco.upper())
    print("✅  Done.\n")

if __name__ == "__main__":
    main()
