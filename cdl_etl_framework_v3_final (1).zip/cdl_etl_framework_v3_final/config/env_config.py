"""
cdl_etl_framework/config/env_config.py
=======================================
Environment-aware configuration.
Reads from environment variables / Databricks Secrets / GCP Secret Manager.
Switching cloud: set ENV=gcp (default: azure).
"""

import os
from dataclasses import dataclass, field
from typing import Optional


# ---------------------------------------------------------------------------
# Environment detection
# ---------------------------------------------------------------------------
ENV = os.getenv("CDL_ENV", "azure").lower()          # azure | gcp
OPCO = os.getenv("CDL_OPCO", "GROUND").upper()
LOG_LEVEL = os.getenv("CDL_LOG_LEVEL", "INFO")


# ---------------------------------------------------------------------------
# Azure configuration
# ---------------------------------------------------------------------------
@dataclass
class AzureConfig:
    # Storage
    storage_account: str = os.getenv("AZURE_STORAGE_ACCOUNT", "cdlstorageprod")
    container_name: str = os.getenv("AZURE_CONTAINER", "cdl-data")
    adls_base_path: str = f"abfss://{os.getenv('AZURE_CONTAINER','cdl-data')}@{os.getenv('AZURE_STORAGE_ACCOUNT','cdlstorageprod')}.dfs.core.windows.net"

    # Delta catalog
    metadata_schema: str = os.getenv("CDL_METADATA_SCHEMA", "cdl_metadata")
    data_schema: str = os.getenv("CDL_DATA_SCHEMA", "cdl_data")
    catalog: str = os.getenv("CDL_CATALOG", "cdl_catalog")           # Unity Catalog

    # Key Vault
    key_vault_name: str = os.getenv("AZURE_KEY_VAULT", "cdl-kv-prod")
    key_vault_uri: str = f"https://{os.getenv('AZURE_KEY_VAULT','cdl-kv-prod')}.vault.azure.net/"

    # Databricks
    databricks_host: str = os.getenv("DATABRICKS_HOST", "")
    databricks_token_secret: str = "dbx-token"

    # Alerting
    smtp_host: str = os.getenv("SMTP_HOST", "smtp.office365.com")
    smtp_port: int = int(os.getenv("SMTP_PORT", "587"))
    teams_webhook_url: str = os.getenv("TEAMS_WEBHOOK_URL", "")
    alert_from_email: str = os.getenv("ALERT_FROM_EMAIL", "cdl-etl@company.com")


# ---------------------------------------------------------------------------
# GCP configuration
# ---------------------------------------------------------------------------
@dataclass
class GCPConfig:
    # Storage
    project_id: str = os.getenv("GCP_PROJECT_ID", "cdl-prod-project")
    gcs_bucket: str = os.getenv("GCS_BUCKET", "cdl-data-prod")
    gcs_base_path: str = f"gs://{os.getenv('GCS_BUCKET','cdl-data-prod')}"

    # BigQuery
    metadata_dataset: str = os.getenv("CDL_METADATA_SCHEMA", "cdl_metadata")
    data_dataset: str = os.getenv("CDL_DATA_SCHEMA", "cdl_data")
    bq_location: str = os.getenv("BQ_LOCATION", "US")

    # Dataproc
    dataproc_region: str = os.getenv("DATAPROC_REGION", "us-central1")
    dataproc_cluster: str = os.getenv("DATAPROC_CLUSTER", "cdl-spark-cluster")

    # Secret Manager
    secret_manager_prefix: str = f"projects/{os.getenv('GCP_PROJECT_ID','cdl-prod-project')}/secrets"

    # Alerting
    sendgrid_api_key_secret: str = "cdl-sendgrid-api-key"
    alert_from_email: str = os.getenv("ALERT_FROM_EMAIL", "cdl-etl@company.com")


# ---------------------------------------------------------------------------
# Shared pipeline config
# ---------------------------------------------------------------------------
@dataclass
class PipelineConfig:
    # Layer ordering — drives dependency checks
    layer_order: list = field(default_factory=lambda: [
        "ACCOUNT", "FACILITY", "COUNTRY", "GLOBAL"
    ])

    # Table name map per layer (daily + monthly)
    layer_tables: dict = field(default_factory=lambda: {
        "ACCOUNT":  {"daily": "account_daily",  "monthly": "account_monthly"},
        "FACILITY": {"daily": "facility_daily", "monthly": "facility_monthly"},
        "COUNTRY":  {"daily": "country_daily",  "monthly": "country_monthly"},
        "GLOBAL":   {"daily": "global_daily",   "monthly": "global_monthly"},
    })

    # Default DQ threshold — layers must achieve this % pass rate to unblock downstream
    default_dq_threshold_pct: float = float(os.getenv("CDL_DQ_THRESHOLD", "95.0"))

    # Retry defaults (overridden by cdl_retry_config table)
    default_max_attempts: int = 3
    default_initial_wait_sec: int = 30
    default_backoff_multiplier: float = 2.0
    default_max_wait_sec: int = 300

    # Run log retention (days)
    run_log_retention_days: int = int(os.getenv("CDL_LOG_RETENTION_DAYS", "90"))

    # Spark configs
    spark_shuffle_partitions: int = int(os.getenv("CDL_SHUFFLE_PARTITIONS", "200"))
    spark_adaptive_enabled: bool = True


# ---------------------------------------------------------------------------
# Active config singleton
# ---------------------------------------------------------------------------
def get_cloud_config():
    """Return the cloud-specific config object based on ENV."""
    if ENV == "gcp":
        return GCPConfig()
    return AzureConfig()


def get_metadata_db(cloud_cfg=None) -> str:
    """Return the fully-qualified metadata schema/dataset string."""
    cfg = cloud_cfg or get_cloud_config()
    if ENV == "gcp":
        return f"{cfg.project_id}.{cfg.metadata_dataset}"
    return f"{cfg.catalog}.{cfg.metadata_schema}"


def get_data_db(cloud_cfg=None) -> str:
    """Return the fully-qualified data schema/dataset string."""
    cfg = cloud_cfg or get_cloud_config()
    if ENV == "gcp":
        return f"{cfg.project_id}.{cfg.data_dataset}"
    return f"{cfg.catalog}.{cfg.data_schema}"


def get_storage_base(cloud_cfg=None) -> str:
    """Return the base storage path (ADLS or GCS)."""
    cfg = cloud_cfg or get_cloud_config()
    if ENV == "gcp":
        return cfg.gcs_base_path
    return cfg.adls_base_path


PIPELINE_CONFIG = PipelineConfig()
CLOUD_CONFIG = get_cloud_config()
