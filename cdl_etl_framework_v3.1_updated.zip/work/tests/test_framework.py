"""
tests/test_framework.py
========================
Test suite for the v3.1 class-based, fault-tolerant framework.

NOTE: this replaces an older test file that referenced modules/functions
which no longer exist in this codebase (04_pipeline_runner, run_dq,
make_run_id, transform_daily_range, a `global_` module name, etc.) — those
were leftovers from an earlier design iteration and none of the tests could
actually pass against the current code.

Run: pytest tests/test_framework.py -v
"""

import importlib
import json
import sys
import os
from datetime import date, datetime, timezone
from unittest.mock import MagicMock, patch

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

framework_core = importlib.import_module("notebooks.01_framework_core")
ingestion_core = importlib.import_module("notebooks.02_ingestion")
transformation_core = importlib.import_module("notebooks.03_transformation")
main_core = importlib.import_module("notebooks.04_main_core")

TableConfig = framework_core.TableConfig
DQEngine = framework_core.DQEngine
DQGateChecker = framework_core.DQGateChecker
RunLogger = framework_core.RunLogger
IngestionEngine = ingestion_core.IngestionEngine
TransformationLoader = transformation_core.TransformationLoader
PipelineOrchestrator = main_core.PipelineOrchestrator


# ─────────────────────────────────────────────────────────────────────────────
# Helper: build a minimal TableConfig matching the CURRENT schema
# ─────────────────────────────────────────────────────────────────────────────
def mock_cfg(**overrides):
    defaults = dict(
        table_id="ground_facility_monthly",
        opco="GROUND",
        target_dataset_layer="FACILITY",
        source_system="DELTA_LAKE",
        source_table=["account_monthly"],
        target_system="DELTA_LAKE",
        target_table="facility_monthly",
        load_process="transform_monthly",
        schedule_group="ground_monthly",
        ingestion_mode="FULL",
        incremental_cutoff_day="5",
        load_frequency="MONTHLY",
        watermark_column="ratemnth",
        last_watermark_value=None,
        partition_col="ratemnth",
        dq_rules=[{"dq_rule": "dq_row_count", "error_threshold_pct": 2.0}],
        dq_status=True,
        is_active=True,
        depends_on=["ground_account_monthly"],
        hard_dq_gate=False,
        retry_max_attempts=2,
        retry_initial_wait_sec=0.01,
        retry_backoff_multiplier=1.0,
        retry_max_wait_sec=0.05,
    )
    defaults.update(overrides)
    return TableConfig(**defaults)


# ===========================================================================
# TableConfig defaults
# ===========================================================================
class TestTableConfigDefaults:

    def test_hard_dq_gate_defaults_false(self):
        """Never-halt-downstream is the default behaviour."""
        cfg = mock_cfg()
        assert cfg.hard_dq_gate is False

    def test_depends_on_defaults_empty_list(self):
        cfg = TableConfig(
            table_id="t1", opco="GROUND", target_dataset_layer="ACCOUNT",
            source_system="ACCOUNT_DB", source_table=["raw"],
            target_system="DELTA_LAKE", target_table="account_monthly",
            load_process="transform_monthly", schedule_group=None,
            ingestion_mode="FULL", incremental_cutoff_day="5",
            load_frequency="MONTHLY", watermark_column=None,
            last_watermark_value=None, partition_col=None,
            dq_rules=[], dq_status=True, is_active=True,
        )
        assert cfg.depends_on == []
        assert cfg.retry_max_attempts == 3  # class default


# ===========================================================================
# DQEngine — must never raise, never block the load
# ===========================================================================
class TestDQEngine:

    def test_no_rules_configured_passes(self):
        engine = DQEngine()
        cfg = mock_cfg(dq_rules=[])
        passed, results = engine.run(cfg, "GROUND", "202606", "stg.t", "src.t")
        assert passed is True
        assert results[0]["info"].startswith("No DQ rules")

    def test_dq_status_false_skips_rules_and_passes(self):
        engine = DQEngine()
        cfg = mock_cfg(dq_status=False)
        passed, results = engine.run(cfg, "GROUND", "202606", "stg.t", "src.t")
        assert passed is True

    def test_rule_failure_reported_but_engine_does_not_raise(self):
        engine = DQEngine()
        cfg = mock_cfg(dq_rules=[{"dq_rule": "dq_row_count", "error_threshold_pct": 0.0}])
        with patch.object(engine, "_module") as mock_module:
            mock_module.return_value.dq_row_count = MagicMock(return_value=50.0)
            passed, results = engine.run(cfg, "GROUND", "202606", "stg.t", "src.t")
        assert passed is False
        assert results[0]["diff_pct"] == 50.0

    def test_rule_exception_degrades_gracefully(self):
        """A bug inside a DQ rule must never propagate out of DQEngine.run()."""
        engine = DQEngine()
        cfg = mock_cfg()
        with patch.object(engine, "_module") as mock_module:
            mock_module.return_value.dq_row_count = MagicMock(side_effect=RuntimeError("boom"))
            passed, results = engine.run(cfg, "GROUND", "202606", "stg.t", "src.t")
        assert passed is False
        assert results[0]["dq_rule"] == "dq_row_count"

    def test_missing_rules_module_degrades_gracefully(self):
        engine = DQEngine(rules_module="does.not.exist")
        cfg = mock_cfg()
        passed, results = engine.run(cfg, "GROUND", "202606", "stg.t", "src.t")
        assert passed is True  # never blocks the load
        assert "unavailable" in results[0]["info"]


# ===========================================================================
# DQGateChecker — soft (non-blocking) by default
# ===========================================================================
class TestDQGateChecker:

    def _spark(self, rows):
        spark = MagicMock()
        spark.sql.return_value.collect.return_value = rows
        return spark

    def test_no_dependencies_always_proceeds(self):
        checker = DQGateChecker(spark_session=self._spark([]))
        proceed, failed = checker.check(mock_cfg(depends_on=[]), "batch_1")
        assert proceed is True and failed == []

    def test_upstream_failed_but_soft_gate_still_proceeds(self):
        row = {"table_id": "ground_account_monthly", "ok": 0}
        checker = DQGateChecker(spark_session=self._spark([MagicMock(**{"__getitem__.side_effect": row.__getitem__})]))
        cfg = mock_cfg(depends_on=["ground_account_monthly"], hard_dq_gate=False)
        proceed, failed = checker.check(cfg, "batch_1")
        # Soft gate: even with a failed upstream we still proceed.
        assert proceed is True

    def test_hard_gate_blocks_on_upstream_failure(self):
        checker = DQGateChecker(spark_session=self._spark([]))  # nothing logged as passed
        cfg = mock_cfg(depends_on=["ground_account_monthly"], hard_dq_gate=True)
        proceed, failed = checker.check(cfg, "batch_1")
        assert proceed is False
        assert "ground_account_monthly" in failed

    def test_gate_evaluation_error_defaults_to_proceed(self):
        spark = MagicMock()
        spark.sql.side_effect = RuntimeError("metastore unavailable")
        checker = DQGateChecker(spark_session=spark)
        cfg = mock_cfg(depends_on=["ground_account_monthly"], hard_dq_gate=True)
        proceed, failed = checker.check(cfg, "batch_1")
        assert proceed is True  # fault tolerant: never hang the pipeline on a metastore hiccup


# ===========================================================================
# IngestionEngine — ALWAYS loads, regardless of DQ outcome
# ===========================================================================
class TestIngestionEngine:

    def test_run_always_promotes_even_when_dq_fails(self):
        engine = IngestionEngine(data_db="test_db")
        engine._promote_to_target_with_retry = MagicMock(return_value=42)
        engine.dq_engine.run = MagicMock(return_value=(False, [{"dq_rule": "dq_row_count", "passed": False}]))

        cfg = mock_cfg()
        dq_passed, summary = engine.run("batch_1", cfg, "GROUND", "202606", "test_db.stage_temp")

        assert dq_passed is False
        assert summary["loaded"] is True          # <-- the key contract: still loaded
        assert summary["rows_written"] == 42
        engine._promote_to_target_with_retry.assert_called_once()

    def test_run_never_raises_on_unexpected_exception(self):
        engine = IngestionEngine(data_db="test_db")
        engine._promote_to_target_with_retry = MagicMock(side_effect=RuntimeError("delta write conflict"))
        engine.dq_engine.run = MagicMock(return_value=(True, []))

        cfg = mock_cfg()
        dq_passed, summary = engine.run("batch_1", cfg, "GROUND", "202606", "test_db.stage_temp")

        assert dq_passed is False
        assert summary["loaded"] is False
        assert "EXCEPTION" in summary["message"]

    def test_dq_engine_exception_does_not_block_promotion(self):
        engine = IngestionEngine(data_db="test_db")
        engine._promote_to_target_with_retry = MagicMock(return_value=10)
        engine.dq_engine.run = MagicMock(side_effect=RuntimeError("dq engine bug"))

        cfg = mock_cfg()
        dq_passed, summary = engine.run("batch_1", cfg, "GROUND", "202606", "test_db.stage_temp")

        assert summary["loaded"] is True
        engine._promote_to_target_with_retry.assert_called_once()


# ===========================================================================
# TransformationLoader
# ===========================================================================
class TestTransformationLoader:

    def test_ground_account_importable_and_callable(self):
        import transformations.ground.account as m
        assert callable(getattr(m, "transform_daily", None))
        assert callable(getattr(m, "transform_monthly", None))

    def test_ground_facility_has_adapter(self):
        import transformations.ground.facility as m
        assert callable(getattr(m, "transform_monthly", None))

    def test_ground_country_has_adapter(self):
        import transformations.ground.country as m
        assert callable(getattr(m, "transform_monthly", None))

    def test_ground_global_has_adapter(self):
        m = importlib.import_module("transformations.ground.global")
        assert callable(getattr(m, "transform_monthly", None))

    def test_unknown_module_raises_actionable_error(self):
        loader = TransformationLoader()
        with pytest.raises(ValueError, match="No transformation module"):
            loader.get_transformed_df("UNKNOWN_OPCO", "ACCOUNT", "t", ["src"], "transform_monthly", "202606")

    def test_unknown_function_raises_actionable_error(self):
        loader = TransformationLoader()
        with pytest.raises(ValueError, match="missing function"):
            loader.get_transformed_df("GROUND", "ACCOUNT", "t", ["src"], "does_not_exist", "202606")


# ===========================================================================
# PipelineOrchestrator — grouping / windowing / never-halt behaviour
# ===========================================================================
class TestPipelineOrchestrator:

    def test_month_chunks_single_month(self):
        assert main_core.month_chunks(202606, 202606) == [202606]

    def test_month_chunks_crosses_year_boundary(self):
        assert main_core.month_chunks(202511, 202602) == [202511, 202512, 202601, 202602]

    def test_resolve_groups_orders_by_layer(self):
        orchestrator = PipelineOrchestrator()
        cfgs = [
            mock_cfg(table_id="t_global", target_dataset_layer="GLOBAL", opco="GROUND"),
            mock_cfg(table_id="t_account", target_dataset_layer="ACCOUNT", opco="GROUND"),
            mock_cfg(table_id="t_facility", target_dataset_layer="FACILITY", opco="GROUND"),
        ]
        orchestrator.config_repo.read = MagicMock(return_value=cfgs)
        groups = orchestrator.resolve_groups(["t_global", "t_account", "t_facility"])
        layers_in_order = [g[1] for g in groups]
        assert layers_in_order.index("ACCOUNT") < layers_in_order.index("FACILITY") < layers_in_order.index("GLOBAL")

    def test_run_layer_does_not_halt_on_table_failure(self):
        """A failed table in one layer must not prevent other tables/layers from running."""
        orchestrator = PipelineOrchestrator()
        cfg_ok = mock_cfg(table_id="t_ok")
        cfg_fail = mock_cfg(table_id="t_fail")
        orchestrator.config_repo.read = MagicMock(return_value=[cfg_fail, cfg_ok])
        orchestrator.run_table = MagicMock(side_effect=[
            {"table_id": "t_fail", "opco": "GROUND", "layer": "FACILITY", "ok": False},
            {"table_id": "t_ok", "opco": "GROUND", "layer": "FACILITY", "ok": True},
        ])
        results = orchestrator.run_layer("batch_1", "GROUND", "FACILITY", ["t_fail", "t_ok"])
        assert len(results) == 2
        assert orchestrator.run_table.call_count == 2  # both tables still attempted


# ===========================================================================
# Retry handler
# ===========================================================================
class TestRetry:

    def test_success_first_try(self):
        from utils.retry_handler import with_retry
        calls = {"n": 0}

        @with_retry(max_attempts=3, initial_wait=0.01)
        def fn():
            calls["n"] += 1
            return "ok"

        assert fn() == "ok"
        assert calls["n"] == 1

    def test_retries_then_succeeds(self):
        from utils.retry_handler import with_retry
        calls = {"n": 0}

        @with_retry(max_attempts=3, initial_wait=0.01, backoff_multiplier=1.0)
        def fn():
            calls["n"] += 1
            if calls["n"] < 3:
                raise RuntimeError("transient")
            return "ok"

        assert fn() == "ok"
        assert calls["n"] == 3

    def test_raises_after_max_attempts(self):
        from utils.retry_handler import with_retry

        @with_retry(max_attempts=2, initial_wait=0.01, backoff_multiplier=1.0)
        def fn():
            raise ValueError("permanent")

        with pytest.raises(ValueError, match="permanent"):
            fn()

    def test_backoff_caps_at_max(self):
        from utils.retry_handler import _wait
        assert _wait(10, 30.0, 2.0, 300.0, 0.0) == 300.0

    def test_backoff_doubles_each_attempt(self):
        from utils.retry_handler import _wait
        assert abs(_wait(1, 30.0, 2.0, 9999.0, 0.0) - 30.0) < 0.01
        assert abs(_wait(2, 30.0, 2.0, 9999.0, 0.0) - 60.0) < 0.01
        assert abs(_wait(3, 30.0, 2.0, 9999.0, 0.0) - 120.0) < 0.01


# ===========================================================================
# run_config.json parsing
# ===========================================================================
class TestRunConfigParsing:

    def test_none_string_normalised_to_none(self):
        assert main_core._none_if_blank("None") is None
        assert main_core._none_if_blank("") is None
        assert main_core._none_if_blank(None) is None
        assert main_core._none_if_blank("2026-01") == "2026-01"

    def test_params_from_file(self, tmp_path):
        cfg = {
            "runs": [
                {"table_id": ["ground_account_monthly"], "schedule_group": None,
                 "start_date": "None", "end_date": ""}
            ]
        }
        p = tmp_path / "run_config.json"
        p.write_text(json.dumps(cfg))
        params = main_core._params_from_file(str(p))
        assert params["table_id"] == ["ground_account_monthly"]
        assert params["start_date"] is None
        assert params["end_date"] is None
