# Databricks notebook source
# MAGIC %skip
# MAGIC %sql
# MAGIC ALTER TABLE f6180854.cdl_table_config SET TBLPROPERTIES (
# MAGIC   'delta.columnMapping.mode' = 'name',
# MAGIC   'delta.minReaderVersion' = '2',
# MAGIC   'delta.minWriterVersion' = '5'
# MAGIC );
# MAGIC ALTER TABLE f6180854.cdl_table_config DROP COLUMN source_filter, dq_threshold_pct, retry_max_attempts, retry_initial_wait_sec,retry_backoff_multiplier,retry_max_wait_sec

# COMMAND ----------

# DBTITLE 1,Cell 2
from pyspark.sql.types import *
from pyspark.sql.functions import *
from datetime import datetime, date
from dateutil.relativedelta import relativedelta
import json
import re

# spark = SparkSession.builder.appName("cdl_table_config_loader").getOrCreate()

# ---------------------------------------------------------------------
# 1. Target schema — exactly matches cdl_table_config
# ---------------------------------------------------------------------


def insert_data(data_string):
    data = []
    schema_col_count = 16
    for line in data_string.strip().split("\n"):
        parts = line.split("\t")
        while len(parts) < schema_col_count:
            parts.append("")
        lowercased = [part.strip().lower() if part.strip() != "" else None for part in parts[:-1]]
        lowercased.append(parts[-1] if parts[-1].strip() != "" else None)
        data.append(tuple(lowercased))

    schema = StructType([
        StructField("table_id",               StringType(),    False),
        StructField("opco",                   StringType(),    True),
        StructField("target_dataset_layer",   StringType(),    True),
        StructField("source_system",          StringType(),    True),
        StructField("source_table",           StringType(),    True),   # comma-separated for multi-source
        StructField("target_system",          StringType(),    True),
        StructField("target_table",           StringType(),    True),
        StructField("load_process",           StringType(),    True),
        StructField("schedule_group",         StringType(),    True),
        StructField("ingestion_mode",         StringType(),    True),
        StructField("incremental_cutoff_day", StringType(),    True),
        StructField("load_frequency",         StringType(),    True),
        StructField("watermark_column",       StringType(),    True),
        StructField("last_watermark_value",   StringType(),    True),
        StructField("partition_col",          StringType(),    True),
        StructField("dq_rules",               StringType(),    True)  # JSON string
        # StructField("dq_status",              BooleanType(),   True),
        # StructField("is_active",              BooleanType(),   True),
        # StructField("created_at",             TimestampType(), True),
    ])

    df = spark.createDataFrame(data, schema)
    df = df.withColumn('dq_status', lit(True))\
            .withColumn('is_active', lit(True))\
            .withColumn('created_at', current_timestamp())
    return df

# ---------------------------------------------------------------------
# 2. Reusable defaults (DQ rules + alerting) — parameterized by target col
# ---------------------------------------------------------------------
def default_dq_rules(pk_column: str = "account_id"):
    return json.dumps([
        {"rule_id": f"not_null_{pk_column}", "rule_type": "NOT_NULL",
         "target_column": pk_column, "rule_expression": f"{pk_column} IS NOT NULL",
         "severity": "CRITICAL", "error_threshold_pct": 0.0},
        {"rule_id": "row_count_min", "rule_type": "ROW_COUNT",
         "target_column": None, "rule_expression": json.dumps({"min_rows": 1}),
         "severity": "CRITICAL", "error_threshold_pct": 0.0},
    ])


control_table_data_string = """cdl_testing_1	GROUND	facility	DELTA_LAKE	fxg_ctry_enti_bill_mth_hist	DELTA_LAKE	cdl_testing_table_1	load_cdl_testing_table_1	sp_daily	Incremental	9	daily	ratemnth		ratemnth	[{"dq_rule": "dq_net_rev", "error_threshold_pct": 0.0}]
cdl_testing_2	GROUND	global	DELTA_LAKE	fxg_ctry_enti_bill_dly_hist	DELTA_LAKE	cdl_testing_table_2	load_cdl_testing_table_2	sp_daily	Incremental	9	daily	ratemnth		ratemnth	
fxg_acct_bill_dly_hist	GROUND	acct	DELTA_LAKE	Base_table_1,data_mart_table2	DELTA_LAKE	fxg_acct_bill_dly_hist	load_fxg_acct_bill_dly_hist	sp_daily	Incremental	9	daily	ratemnth		ratemnth	
fxg_acct_bill_mth_hist	GROUND	acct	DELTA_LAKE	Base_table_1,data_mart_table3	DELTA_LAKE	fxg_acct_bill_mth_hist	load_fxg_acct_bill_mth_hist	sp_daily	Incremental	9	daily	ratemnth		ratemnth	
fxg_ctry_enti_bill_dly_hist_non_sp	GROUND	country	DELTA_LAKE	fxg_fac_enti_bill_mth_hist	DELTA_LAKE	fxg_ctry_enti_bill_dly_hist	load_fxg_ctry_enti_bill_dly_hist_non_sp	non_sp_weekly	Incremental	9	weekly	ratemnth		ratemnth	
fxg_ctry_enti_bill_dly_hist_sp	GROUND	country	DELTA_LAKE	fxg_fac_enti_bill_mth_hist	DELTA_LAKE	fxg_ctry_enti_bill_dly_hist	load_fxg_ctry_enti_bill_dly_hist_sp	sp_daily	Incremental	9	daily	ratemnth		ratemnth	
fxg_ctry_enti_bill_mth_hist_non_sp	GROUND	country	DELTA_LAKE	fxg_fac_enti_bill_dly_hist	DELTA_LAKE	fxg_ctry_enti_bill_mth_hist	load_fxg_ctry_enti_bill_mth_hist_non_sp	non_sp_weekly	Incremental	9	weekly	ratemnth		ratemnth	
fxg_ctry_enti_bill_mth_hist_sp	GROUND	country	DELTA_LAKE	fxg_fac_enti_bill_dly_hist	DELTA_LAKE	fxg_ctry_enti_bill_mth_hist	load_fxg_ctry_enti_bill_mth_hist_sp	sp_daily	Incremental	9	daily	ratemnth		ratemnth	
fxg_fac_enti_bill_dly_hist_non_sp	GROUND	facility	DELTA_LAKE	CUST_SE_SEG_MAP,CUST_CE_SEG_MAP,fxg_acct_bill_dly_hist	DELTA_LAKE	fxg_fac_enti_bill_dly_hist	load_fxg_fac_enti_bill_dly_hist_non_sp	non_sp_weekly	Incremental	9	weekly	ratemnth		ratemnth	
fxg_fac_enti_bill_dly_hist_sp	GROUND	facility	DELTA_LAKE	CUST_SE_SEG_MAP,CUST_CE_SEG_MAP,fxg_acct_bill_dly_hist	DELTA_LAKE	fxg_fac_enti_bill_dly_hist	load_fxg_fac_enti_bill_dly_hist_sp	sp_daily	Incremental	9	daily	ratemnth		ratemnth	
fxg_fac_enti_bill_mth_hist_non_sp	GROUND	facility	DELTA_LAKE	CUST_SE_SEG_MAP,CUST_CE_SEG_MAP,CDL_MTR_GROUP_DEFINITION,fxg_acct_bill_mth_hist	DELTA_LAKE	fxg_fac_enti_bill_mth_hist	load_fxg_fac_enti_bill_mth_hist_non_sp	non_sp_weekly	Incremental	9	weekly	ratemnth		ratemnth	
fxg_fac_enti_bill_mth_hist_sp	GROUND	facility	DELTA_LAKE	CUST_SE_SEG_MAP,CUST_CE_SEG_MAP,CDL_MTR_GROUP_DEFINITION,fxg_acct_bill_mth_hist	DELTA_LAKE	fxg_fac_enti_bill_mth_hist	load_fxg_fac_enti_bill_mth_hist_sp	sp_daily	Incremental	9	daily	ratemnth		ratemnth	
fxg_glbl_enti_bill_dly_hist_non_sp	GROUND	global	DELTA_LAKE	fxg_ctry_enti_bill_mth_hist	DELTA_LAKE	fxg_glbl_enti_bill_dly_hist	load_fxg_glbl_enti_bill_dly_hist_non_sp	non_sp_weekly	Incremental	9	weekly	ratemnth		ratemnth	
fxg_glbl_enti_bill_dly_hist_sp	GROUND	global	DELTA_LAKE	fxg_ctry_enti_bill_mth_hist	DELTA_LAKE	fxg_glbl_enti_bill_dly_hist	load_fxg_glbl_enti_bill_dly_hist_sp	sp_daily	Incremental	9	daily	ratemnth		ratemnth	
fxg_glbl_enti_bill_mth_hist_non_sp	GROUND	global	DELTA_LAKE	fxg_ctry_enti_bill_dly_hist	DELTA_LAKE	fxg_glbl_enti_bill_mth_hist	load_fxg_glbl_enti_bill_mth_hist_non_sp	non_sp_weekly	Incremental	9	weekly	ratemnth		ratemnth	
fxg_glbl_enti_bill_mth_hist_sp	GROUND	global	DELTA_LAKE	fxg_ctry_enti_bill_dly_hist	DELTA_LAKE	fxg_glbl_enti_bill_mth_hist	load_fxg_glbl_enti_bill_mth_hist_sp	sp_daily	Incremental	9	daily	ratemnth		ratemnth	
"""


df = insert_data(control_table_data_string)
df = df.dropDuplicates()
df.display()
# ---------------------------------------------------------------------
# 5. Upsert (idempotent) into cdl_table_config using Delta MERGE
# ---------------------------------------------------------------------
# from delta.tables import DeltaTable

target_path = "f6180854.cdl_table_config"   # or a path if not using Hive metastore

# # if DeltaTable.isDeltaTable(spark, target_path):
# #     dt = DeltaTable.forName(spark, target_path)
# #     (dt.alias("t")
# #        .merge(df.alias("s"), "t.table_id = s.table_id")
# #        .whenMatchedUpdateAll()
# #        .whenNotMatchedInsertAll()
# #        .execute())
# # else:
df.write.format("delta").mode("overwrite").saveAsTable(target_path)

# print(f"Loaded {df.count()} rows into {target_path}")
# df.show(truncate=False)

# COMMAND ----------

# NOTE: the block below was a stray leftover fragment (an orphaned dict
# literal with no assignment) left over from copy-pasting a DQ rule example
# into this scratch/exploration notebook — it made the file fail to even
# parse. Commented out rather than silently deleted, since this file is a
# throwaway exploration notebook, not part of the actual pipeline (nothing
# imports tests/test.py).
# {"dq_rule": "dq_net_rev", "error_threshold_pct": 0.0}

# COMMAND ----------

# MAGIC %sql
# MAGIC drop table f6180854.cdl_table_config

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE f6180854.cdl_table_config (
# MAGIC    table_id STRING NOT NULL,
# MAGIC    opco STRING,
# MAGIC    target_dataset_layer STRING,
# MAGIC    source_system STRING ,
# MAGIC    source_table STRING ,
# MAGIC    target_system STRING ,
# MAGIC    target_table STRING ,
# MAGIC    load_process STRING ,
# MAGIC    schedule_group STRING ,
# MAGIC    ingestion_mode STRING ,
# MAGIC    incremental_cutoff_day STRING ,
# MAGIC    load_frequency STRING ,
# MAGIC    watermark_column STRING,
# MAGIC    last_watermark_value STRING,
# MAGIC    partition_col STRING,
# MAGIC    dq_rules STRING,
# MAGIC    dq_status BOOLEAN,
# MAGIC    is_active BOOLEAN ,
# MAGIC    created_at TIMESTAMP 
# MAGIC ) 
# MAGIC USING delta 
# MAGIC TBLPROPERTIES (
# MAGIC    'delta.autoOptimize.autoCompact' = 'true',
# MAGIC    'delta.autoOptimize.optimizeWrite' = 'true',
# MAGIC    'delta.columnMapping.mode' = 'name',
# MAGIC    'delta.enableChangeDataFeed' = 'true',
# MAGIC    'delta.enableDeletionVectors' = 'true',
# MAGIC    'delta.feature.appendOnly' = 'supported',
# MAGIC    'delta.feature.changeDataFeed' = 'supported',
# MAGIC    'delta.feature.checkConstraints' = 'supported',
# MAGIC    'delta.feature.columnMapping' = 'supported',
# MAGIC    'delta.feature.deletionVectors' = 'supported',
# MAGIC    'delta.feature.generatedColumns' = 'supported',
# MAGIC    'delta.feature.invariants' = 'supported',
# MAGIC    'delta.minReaderVersion' = '3',
# MAGIC    'delta.minWriterVersion' = '7'
# MAGIC )
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from f6180854.cdl_table_config

# COMMAND ----------

# DBTITLE 1,Cell 5
from pyspark.sql import SparkSession
from pyspark.sql.functions import current_timestamp
import re

# Initialize SparkSession (if you are in Databricks, 'spark' is already available)
spark = SparkSession.builder.appName("DynamicTimestampDF").getOrCreate()

# The raw text data you provided
# raw_data = """
# table_id opco target_dataset_layer source_system source_table_name target_system target_table_name load_process schedule_group load_frequency ingestion_mode watermark_column last_watermark_value last_successful_run partition_col data_quality_rules is_active created_at
# fxg_acct_bill_dly_hist GROUND acct DELTA_LAKE Base_table_1,data_mart_table2 DELTA_LAKE fxg_acct_bill_dly_hist load_fxg_acct_bill_dly_hist sp_daily daily Incremental ratemnth - - ratemnth FALSE 2026-07-03T12:11:28.862+00:00
# fxg_acct_bill_mth_hist GROUND acct DELTA_LAKE Base_table_1,data_mart_table3 DELTA_LAKE fxg_acct_bill_mth_hist load_fxg_acct_bill_mth_hist sp_daily daily Incremental ratemnth - - ratemnth FALSE 2026-07-03T12:11:28.862+00:00
# fxg_ctry_enti_bill_dly_hist_non_sp GROUND country DELTA_LAKE fxg_fac_enti_bill_mth_hist DELTA_LAKE fxg_ctry_enti_bill_dly_hist load_fxg_ctry_enti_bill_dly_hist_non_sp non_sp_weekly weekly Incremental ratemnth - - ratemnth TRUE 2026-07-03T12:11:28.862+00:00
# fxg_ctry_enti_bill_mth_hist_non_sp GROUND country DELTA_LAKE fxg_fac_enti_bill_dly_hist DELTA_LAKE fxg_ctry_enti_bill_mth_hist load_fxg_ctry_enti_bill_mth_hist_non_sp non_sp_weekly weekly Incremental ratemnth - - ratemnth TRUE 2026-07-03T12:11:28.862+00:00
# fxg_fac_enti_bill_dly_hist_non_sp GROUND facility DELTA_LAKE CUST_SE_SEG_MAP,CUST_CE_SEG_MAP,fxg_acct_bill_dly_hist DELTA_LAKE fxg_fac_enti_bill_dly_hist load_fxg_fac_enti_bill_dly_hist_non_sp non_sp_weekly weekly Incremental ratemnth - - ratemnth TRUE 2026-07-03T12:11:28.862+00:00
# fxg_fac_enti_bill_dly_hist_sp GROUND facility DELTA_LAKE CUST_SE_SEG_MAP,CUST_CE_SEG_MAP,fxg_acct_bill_dly_hist DELTA_LAKE fxg_fac_enti_bill_dly_hist load_fxg_fac_enti_bill_dly_hist_sp sp_daily daily Incremental ratemnth - - ratemnth TRUE 2026-07-03T12:11:28.862+00:00
# fxg_fac_enti_bill_mth_hist_non_sp GROUND facility DELTA_LAKE CUST_SE_SEG_MAP,CUST_CE_SEG_MAP,CDL_MTR_GROUP_DEFINITION,fxg_acct_bill_mth_hist DELTA_LAKE fxg_fac_enti_bill_mth_hist load_fxg_fac_enti_bill_mth_hist_non_sp non_sp_weekly weekly Incremental ratemnth - - ratemnth TRUE 2026-07-03T12:11:28.862+00:00
# fxg_glbl_enti_bill_dly_hist_non_sp GROUND global DELTA_LAKE fxg_ctry_enti_bill_mth_hist DELTA_LAKE fxg_glbl_enti_bill_dly_hist load_fxg_glbl_enti_bill_dly_hist_non_sp non_sp_weekly weekly Incremental ratemnth - - ratemnth TRUE 2026-07-03T12:11:28.862+00:00
# fxg_glbl_enti_bill_mth_hist_non_sp GROUND global DELTA_LAKE fxg_ctry_enti_bill_dly_hist DELTA_LAKE fxg_glbl_enti_bill_mth_hist load_fxg_glbl_enti_bill_mth_hist_non_sp non_sp_weekly weekly Incremental ratemnth - - ratemnth TRUE 2026-07-03T12:11:28.862+00:00
# fxg_fac_enti_bill_mth_hist_sp GROUND facility DELTA_LAKE CUST_SE_SEG_MAP,CUST_CE_SEG_MAP,CDL_MTR_GROUP_DEFINITION,fxg_acct_bill_mth_hist DELTA_LAKE fxg_fac_enti_bill_mth_hist load_fxg_fac_enti_bill_mth_hist_sp sp_daily daily Incremental ratemnth - - ratemnth TRUE 2026-07-03T12:11:28.862+00:00
# fxg_ctry_enti_bill_dly_hist_sp GROUND country DELTA_LAKE fxg_fac_enti_bill_mth_hist DELTA_LAKE fxg_ctry_enti_bill_dly_hist load_fxg_ctry_enti_bill_dly_hist_sp sp_daily daily Incremental ratemnth - - ratemnth TRUE 2026-07-03T12:11:28.862+00:00
# fxg_ctry_enti_bill_mth_hist_sp GROUND country DELTA_LAKE fxg_fac_enti_bill_dly_hist DELTA_LAKE fxg_ctry_enti_bill_mth_hist load_fxg_ctry_enti_bill_mth_hist_sp sp_daily daily Incremental ratemnth - - ratemnth TRUE 2026-07-03T12:11:28.862+00:00
# fxg_glbl_enti_bill_dly_hist_sp GROUND global DELTA_LAKE fxg_ctry_enti_bill_mth_hist DELTA_LAKE fxg_glbl_enti_bill_dly_hist load_fxg_glbl_enti_bill_dly_hist_sp sp_daily daily Incremental ratemnth - - ratemnth TRUE 2026-07-03T12:11:28.862+00:00
# fxg_glbl_enti_bill_mth_hist_sp GROUND global DELTA_LAKE fxg_ctry_enti_bill_dly_hist DELTA_LAKE fxg_glbl_enti_bill_mth_hist load_fxg_glbl_enti_bill_mth_hist_sp sp_daily daily Incremental ratemnth - - ratemnth TRUE 2026-07-03T12:11:28.862+00:00
# """

raw_data = """cdl_testing_1	GROUND	facility	DELTA_LAKE	fxg_ctry_enti_bill_mth_hist	DELTA_LAKE	cdl_testing_table_1	load_cdl_testing_table_1	sp_daily	daily	Incremental	ratemnth	-	-	ratemnth		TRUE	2026-07-03T12:11:28.862+00:00
cdl_testing_2	GROUND	global	DELTA_LAKE	fxg_ctry_enti_bill_dly_hist	DELTA_LAKE	cdl_testing_table_2	load_cdl_testing_table_2	sp_daily	daily	Incremental	ratemnth	-	-	ratemnth		TRUE	2026-07-03T12:11:28.862+00:00
"""

# Parse the data rows. Note: This simple split assumes no spaces within data fields.
lines = raw_data.strip().split('\n')[:]
data_rows = [line.split() for line in lines]

# Define the schema. Note that 'data_quality_rules' is omitted as it's not in the data rows.
schema = [
    "table_id", "opco", "target_dataset_layer", "source_system",
    "source_table_name", "target_system", "target_table_name", "load_process",
    "schedule_group", "load_frequency", "ingestion_mode", "watermark_column",
    "last_watermark_value", "last_successful_run", "partition_col", "is_active",
    "created_at_static"  # Name for the original timestamp column
]

# Create the initial DataFrame from the parsed data and schema
df = spark.createDataFrame(data_rows, schema=schema)

# Add the new 'created_at' column with the dynamic current timestamp
# and drop the old static column
df_final = (df
    .withColumn("created_at", current_timestamp())
    .withColumn("is_active", df["is_active"].cast("boolean"))
    .drop("created_at_static"))

# Display the final DataFrame to verify the result
display(df_final)

target_path = "f6180854.cdl_table_config" 
df_final.write.format("delta").mode("append").saveAsTable(target_path)


# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql.types import StructType, StructField, StringType, DoubleType

# 1. Initialize SparkSession (if not already running in an environment like Databricks)
spark = SparkSession.builder.appName("RateMonthDF").getOrCreate()

# 2. Define the Schema (Exactly 6 columns)
schema = StructType([
    StructField("shipment_id", StringType(), True),
    StructField("origin", StringType(), True),
    StructField("destination", StringType(), True),
    StructField("weight_kg", DoubleType(), True),
    StructField("status", StringType(), True),
    StructField("ratemnth", StringType(), True) # yyyymm format
])

# 3. Create Sample Data for 6 distinct months
data = [
    ("SHP-101", "New York", "London", 12.5, "Delivered", "202601"),
    ("SHP-102", "Chicago", "Tokyo", 45.0, "Delivered", "202602"),
    ("SHP-103", "Los Angeles", "Sydney", 8.2, "In Transit", "202603"),
    ("SHP-104", "Houston", "Paris", 22.1, "Delivered", "202604"),
    ("SHP-105", "Miami", "Berlin", 15.3, "Pending", "202605"),
    ("SHP-106", "Seattle", "Mumbai", 30.0, "Delivered", "202606"),
    ("SHP-107", "Seasasattle", "Mumbai", 33.0, "Delivered", "202606")
]

# 4. Create the DataFrame
df = spark.createDataFrame(data, schema)
df.show()

# 5. Save the DataFrame to a table
table_name = "default.shipment_monthly_rates"

# Saving as a Delta table and overwriting existing data. 
# Partitioning by 'ratemnth' is recommended for time-series data to improve query performance.
df.write \
  .format("delta") \
  .mode("overwrite") \
  .partitionBy("ratemnth") \
  .saveAsTable(table_name)
  
print(f"Data successfully saved to {table_name}")


# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE IF NOT EXISTS f6180854.cdl_testing_table_1_stage (
# MAGIC     shipment_id STRING,
# MAGIC     origin STRING,
# MAGIC     destination STRING,
# MAGIC     weight_kg DOUBLE,
# MAGIC     status STRING,
# MAGIC     ratemnth STRING
# MAGIC )
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from f6180854.cdl_table_run_log

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from f6180854.cdl_testing_table_1

# COMMAND ----------

# MAGIC %sql
# MAGIC drop table spark_catalog.f6180854.cdl_table_run_log

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE spark_catalog.f6180854.cdl_table_run_log (
# MAGIC      run_batch_id STRING,
# MAGIC      log_time TIMESTAMP,
# MAGIC      opco STRING,
# MAGIC      dataset_layer STRING,
# MAGIC      table_name STRING,
# MAGIC      table_id STRING,
# MAGIC      load_process STRING,
# MAGIC      load_mnth_start STRING,
# MAGIC      load_mnth_end STRING,
# MAGIC      status STRING,
# MAGIC      message STRING,
# MAGIC      attempt_number INT,
# MAGIC      watermark_start TIMESTAMP,
# MAGIC      watermark_end TIMESTAMP,
# MAGIC      started_at TIMESTAMP,
# MAGIC      completed_at TIMESTAMP,
# MAGIC      duration_seconds INT,
# MAGIC      rows_read BIGINT,
# MAGIC      rows_written BIGINT,
# MAGIC      dq_result STRING,
# MAGIC      execution_summary STRING
# MAGIC )
# MAGIC USING delta
# MAGIC COMMENT 'Execution audit table capturing every pipeline run attempt'
# MAGIC TBLPROPERTIES (
# MAGIC   'delta.autoOptimize.optimizeWrite' = 'true',
# MAGIC   'delta.enableChangeDataFeed' = 'true',
# MAGIC   'delta.enableDeletionVectors' = 'true',
# MAGIC   'delta.feature.appendOnly' = 'supported',
# MAGIC   'delta.feature.changeDataFeed' = 'supported',
# MAGIC   'delta.feature.deletionVectors' = 'supported',
# MAGIC   'delta.feature.invariants' = 'supported',
# MAGIC   'delta.logRetentionDuration' = 'interval 90 days',
# MAGIC   'delta.minReaderVersion' = '3',
# MAGIC   'delta.minWriterVersion' = '7')
# MAGIC
# MAGIC --  CREATE TABLE load_execution_log (
# MAGIC
# MAGIC --  )
# MAGIC --  USING DELTA;

# COMMAND ----------

# MAGIC %sql
# MAGIC select sum(netrev) from ds_fcst_de_prod.fxg_acct_bill_mth_hist where ratemnth = '202605'
# MAGIC union all
# MAGIC select sum(netrev) from ds_fcst_de_prod.fxg_fac_enti_bill_mth_hist where ratemnth = '202605'
# MAGIC

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE TABLE spark_catalog.f6180854.cdl_testing_table_1_temp (
# MAGIC   shipment_id STRING,
# MAGIC   origin STRING,
# MAGIC   destination STRING,
# MAGIC   weight_kg DOUBLE,
# MAGIC   status STRING,
# MAGIC   ratemnth STRING)
# MAGIC USING delta
# MAGIC TBLPROPERTIES (
# MAGIC   'delta.enableDeletionVectors' = 'true',
# MAGIC   'delta.feature.deletionVectors' = 'supported',
# MAGIC   'delta.minReaderVersion' = '3',
# MAGIC   'delta.minWriterVersion' = '7')

# COMMAND ----------

# MAGIC %sql
# MAGIC describe history f6180854.cdl_testing_table_1_stage

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from f6180854.cdl_testing_table_1

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from hive_metastore.f6180854.cdl_table_run_log