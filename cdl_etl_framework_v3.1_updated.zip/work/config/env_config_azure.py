# Databricks notebook source
# MAGIC %pip install azure-appconfiguration

# COMMAND ----------

def fetch_app_config_values(keys, label):
    """
    Fetches configuration values for given keys from azure app configuration service
    """
    try:
        from azure.appconfiguration import AzureAppConfigurationClient
        client = AzureAppConfigurationClient.from_connection_string(dbutils.secrets.get("vault-scope", "app-configuration-connection-string"))
        config_values = {key: client.get_configuration_setting(key=key, label=label.replace("_", "-")).value for key in keys}
        return config_values
    except Exception as e:
        print(f"Error while retrieving values from App Config service. Exception:\n{e}")
        raise e

# COMMAND ----------

# DBTITLE 1,Cell 3
dsma_restricted_schema,dsma_restricted_landing_path,dsma_restricted_path,COE_DE_Private_Location,COE_DE_Public_Location,coe_de_inbox_path,environment = (fetch_app_config_values([key], "COE-DE") [key] for key in ["dsma_restricted_schema", "coe_file_landing_path","dsma_restricted_path","COE_DE_Private_Location","COE_DE_Public_Location","coe_de_inbox_path","environment"])
print(dsma_restricted_schema,dsma_restricted_landing_path,dsma_restricted_path,COE_DE_Private_Location,COE_DE_Public_Location,coe_de_inbox_path,environment)

# COMMAND ----------

"""
cdl_etl_framework/config/env_config.py
=======================================
Environment-aware configuration.
Reads from environment variables / Databricks Secrets / GCP Secret Manager.
Switching cloud: set ENV=gcp (default: azure).
"""

import os
from dataclasses import dataclass, field
from typing import Optional


# ---------------------------------------------------------------------------
# Environment detection
# ---------------------------------------------------------------------------
# ENV = os.getenv("CDL_ENV", "azure").lower()          # azure | gcp
# OPCO = os.getenv("CDL_OPCO", "GROUND").upper()
# LOG_LEVEL = os.getenv("CDL_LOG_LEVEL", "INFO")

# ---------------------------------------------------------------------------
# --- Environment configuration
# --- Determines which cloud-specific configuration to use (e.g., "azure", "gcp")
# ---------------------------------------------------------------------------
CLOUD_ENV = 'azure'

# ---------------------------------------------------------------------------
# --- Shared pipeline config (Base Class)
# --- Must be defined before the classes that inherit from it
# ---------------------------------------------------------------------------
@dataclass
class PipelineConfig:
    """Base configuration class holding shared pipeline settings."""
    # Layer ordering — drives dependency checks
    layer_order: list = field(default_factory=lambda: [
        "ACCOUNT", "FACILITY", "COUNTRY", "GLOBAL"
    ])

    # Table name map per layer (daily + monthly)
    layer_tables: dict = field(default_factory=lambda: {
        "ACCOUNT":  {"daily": "account_daily",  "monthly": "account_monthly"},
        "FACILITY": {"daily": "facility_daily", "monthly": "facility_monthly"},
        "COUNTRY":  {"daily": "country_daily",  "monthly": "country_monthly"},
        "GLOBAL":   {"daily": "global_daily",   "monthly": "global_monthly"},
    })

    # Retry defaults (can be overridden by a cdl_retry_config table)
    default_max_attempts: int = 2
    default_initial_wait_sec: int = 10
    default_max_wait_sec: int = 60

    # Run log retention (days)
    run_log_retention_days: int = int(os.getenv("CDL_LOG_RETENTION_DAYS", "90"))

    # Spark configs
    spark_shuffle_partitions: int = int(os.getenv("CDL_SHUFFLE_PARTITIONS", "200"))
    spark_adaptive_enabled: bool = True

# ---------------------------------------------------------------------------
# --- Azure configuration (Child Class)
# ---------------------------------------------------------------------------
@dataclass
class AzureConfig(PipelineConfig):
    try:
        """Configuration specific to the Azure environment."""
        # Storage
        storage_account: str = os.getenv("AZURE_STORAGE_ACCOUNT", "cdlstorageprod")
        container_name: str = os.getenv("AZURE_CONTAINER", "cdl-data")
        adls_base_path: str = f"abfss://{container_name}@{storage_account}.dfs.core.windows.net"

        # Delta catalog
        metadata_schema: str = os.getenv("CDL_METADATA_SCHEMA", "cdl_metadata")
        data_schema: str = os.getenv("CDL_DATA_SCHEMA", "cdl_data")
        catalog: str = os.getenv("CDL_CATALOG", "cdl_catalog")      # Unity Catalog

        # Key Vault
        key_vault_name: str = os.getenv("AZURE_KEY_VAULT", "cdl-kv-prod")
        key_vault_uri: str = f"https://{key_vault_name}.vault.azure.net/"

        # Databricks
        databricks_host: str = os.getenv("DATABRICKS_HOST", "")
        databricks_token_secret: str = "dbx-token"

        # Alerting
        smtp_host: str = os.getenv("SMTP_HOST", "smtp.office365.com")
        smtp_port: int = int(os.getenv("SMTP_PORT", "587"))
        teams_webhook_url: str = os.getenv("TEAMS_WEBHOOK_URL", "")
        alert_from_email: str = os.getenv("ALERT_FROM_EMAIL", "cdl-etl@company.com")


        dsma_restricted_schema,dsma_restricted_landing_path,dsma_restricted_path,COE_DE_Private_Location,COE_DE_Public_Location,coe_de_inbox_path,environment = (fetch_app_config_values([key], "COE-DE") [key] for key in ["dsma_restricted_schema", "coe_file_landing_path","dsma_restricted_path","COE_DE_Private_Location","COE_DE_Public_Location","coe_de_inbox_path","environment"])

    except Exception as e:
        print(f"Error while retrieving values from App Config service. Exception:\n{e}")
        raise e

# ---------------------------------------------------------------------------
# --- GCP configuration (Child Class)
# ---------------------------------------------------------------------------
@dataclass
class GCPConfig(PipelineConfig):
    """Configuration specific to the GCP environment."""
    # Storage
    project_id: str = os.getenv("GCP_PROJECT_ID", "cdl-prod-project")
    gcs_bucket: str = os.getenv("GCS_BUCKET", "cdl-data-prod")
    gcs_base_path: str = f"gs://{gcs_bucket}"

    # BigQuery
    metadata_dataset: str = os.getenv("CDL_METADATA_SCHEMA", "cdl_metadata")
    data_dataset: str = os.getenv("CDL_DATA_SCHEMA", "cdl_data")
    bq_location: str = os.getenv("BQ_LOCATION", "US")

    # Dataproc
    dataproc_region: str = os.getenv("DATAPROC_REGION", "us-central1")
    dataproc_cluster: str = os.getenv("DATAPROC_CLUSTER", "cdl-spark-cluster")

    # Secret Manager
    secret_manager_prefix: str = f"projects/{project_id}/secrets"

    # Alerting
    sendgrid_api_key_secret: str = "cdl-sendgrid-api-key"
    alert_from_email: str = os.getenv("ALERT_FROM_EMAIL", "cdl-etl@company.com")

# ---------------------------------------------------------------------------
# --- Active config singleton and helper functions
# ---------------------------------------------------------------------------
def get_cloud_config() -> PipelineConfig:
    """Return the cloud-specific config object based on the ENV variable."""
    if CLOUD_ENV == "gcp":
        return GCPConfig()
    return AzureConfig()

def get_metadata_db(cloud_cfg: PipelineConfig = None) -> str:
    """Return the fully-qualified metadata schema/dataset string."""
    cfg = cloud_cfg or get_cloud_config()
    if isinstance(cfg, GCPConfig):
        return f"{cfg.project_id}.{cfg.metadata_dataset}"
    if isinstance(cfg, AzureConfig):
        return f"{cfg.catalog}.{cfg.metadata_schema}"
    raise TypeError("Unsupported configuration type")

def get_data_db(cloud_cfg: PipelineConfig = None) -> str:
    """Return the fully-qualified data schema/dataset string."""
    cfg = cloud_cfg or get_cloud_config()
    if isinstance(cfg, GCPConfig):
        return f"{cfg.project_id}.{cfg.data_dataset}"
    if isinstance(cfg, AzureConfig):
        return f"{cfg.catalog}.{cfg.data_schema}"
    raise TypeError("Unsupported configuration type")

def get_storage_base(cloud_cfg: PipelineConfig = None) -> str:
    """Return the base storage path (ADLS or GCS)."""
    cfg = cloud_cfg or get_cloud_config()
    if isinstance(cfg, GCPConfig):
        return cfg.gcs_base_path
    if isinstance(cfg, AzureConfig):
        return cfg.adls_base_path
    raise TypeError("Unsupported configuration type")

# --- Instantiate the active configuration object ---
PIPELINE_CONFIG = get_cloud_config()

# --- Example of how to use the config object ---
# print(f"Active Cloud Environment: {CLOUD_ENV.upper()}")
# print(f"Storage Base Path: {get_storage_base(PIPELINE_CONFIG)}")
# print(f"Metadata DB: {get_metadata_db(PIPELINE_CONFIG)}")
# print(f"Default DQ Threshold: {PIPELINE_CONFIG.default_dq_threshold_pct}%")



# COMMAND ----------

print(PIPELINE_CONFIG.environment)

# COMMAND ----------

import uuid
from datetime import datetime
from pyspark.sql.functions import lit
# 1. Generate the custom batch_run_id ONCE at the start of the job
current_time_str = datetime.now().strftime("%Y%m%d_%H%M%S")
short_uuid = uuid.uuid4().hex[:6].upper() # 6-character random string

# Example output: BATCH_20260715_124453_A1B2C3
custom_batch_run_id = f"BATCH_{current_time_str}_{short_uuid}"
print(custom_batch_run_id)