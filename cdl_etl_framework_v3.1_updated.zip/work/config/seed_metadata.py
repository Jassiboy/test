"""
cdl_etl_framework/config/seed_metadata.py
==========================================
Seeds cdl_table_config with the pipeline mappings for one OPCO, using the
CURRENT (v3.1) schema:
    - source_table       : JSON list (a load can read >1 source table)
    - target_table        : physical target table name
    - load_process         : function name in transformations/{opco}/{layer}.py
    - schedule_group       : optional named batch trigger
    - incremental_cutoff_day, dq_status, hard_dq_gate, retry_*

NOTE on hard_dq_gate: every row here defaults to hard_dq_gate=False, i.e.
poor upstream data quality is recorded but never stops a downstream layer
from loading. depends_on_table_ids is still populated for FACILITY/COUNTRY/
GLOBAL so the (informational, non-blocking) DQGateChecker can log a WARNING
when it sees an upstream miss — turn hard_dq_gate on per-table only if a
specific table genuinely must not run on top of known-bad upstream data.

Usage:
    python seed_metadata.py --env azure --opco GROUND
    python seed_metadata.py --env gcp   --opco GROUND
"""

import argparse
import json
import os
import sys
from datetime import datetime, timezone

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from config.env_config import get_metadata_db

NOW = datetime.now(timezone.utc).isoformat()


# ---------------------------------------------------------------------------
# Reusable DQ rule sets (inlined per table row)
# `dq_rule` names must exist as functions in dq/dq_rules.py.
# ---------------------------------------------------------------------------
def _dq_row_count(threshold_pct: float = 2.0):
    return {"dq_rule": "dq_row_count", "error_threshold_pct": threshold_pct}


def _dq_net_rev(threshold_pct: float = 1.0):
    return {"dq_rule": "dq_net_rev", "error_threshold_pct": threshold_pct}


def _alerts_critical():
    return json.dumps([
        {"channel": "EMAIL",
         "recipients": "cdl-alerts@company.com,data-eng-oncall@company.com",
         "on_status": ["FAILED"]},
        {"channel": "TEAMS",
         "recipients": "https://company.webhook.office.com/webhookb2/cdl-alerts",
         "on_status": ["FAILED"]},
    ])


def _retry_default():
    return {"retry_max_attempts": 3, "retry_initial_wait_sec": 15.0,
            "retry_backoff_multiplier": 2.0, "retry_max_wait_sec": 180.0}


def _retry_aggressive():
    return {"retry_max_attempts": 5, "retry_initial_wait_sec": 30.0,
            "retry_backoff_multiplier": 2.0, "retry_max_wait_sec": 300.0}


# ---------------------------------------------------------------------------
# Row definitions — one per (opco, layer) monthly pipeline mapping.
# Daily variants are omitted here since the current transformation modules
# (transformations/ground/*.py) only implement monthly rollups; add DAILY
# rows the same way once transform_daily() exists for a given layer.
# ---------------------------------------------------------------------------
def get_config_rows(opco: str) -> list:
    o = opco.lower()
    alerts = _alerts_critical()
    rd = _retry_default()
    ra = _retry_aggressive()

    common = dict(
        schedule_group=f"{o}_monthly",
        target_system="DELTA_LAKE",
        ingestion_mode="FULL",
        load_frequency="MONTHLY",
        incremental_cutoff_day="5",
        watermark_column="ratemnth",
        last_watermark_value=None,
        partition_col="ratemnth",
        dq_status=True,
        hard_dq_gate=False,
        alert_config=alerts,
        is_active=True,
        created_at=NOW,
        updated_at=NOW,
        created_by="seed_script",
    )

    return [
        # ── ACCOUNT monthly — first layer, no upstream gate ─────────────
        {**common, **rd,
         "table_id": f"{o}_account_monthly",
         "source_system": "ACCOUNT_DB",
         "source_table": json.dumps(["raw_account_transactions"]),
         "target_table": "account_monthly",
         "target_dataset_layer": "ACCOUNT", "opco": opco,
         "load_process": "transform_monthly",
         "data_quality_rules": json.dumps([_dq_row_count(2.0)]),
         "depends_on_table_ids": None},

        # ── FACILITY monthly — depends on ACCOUNT (soft gate) ───────────
        {**common, **ra,
         "table_id": f"{o}_facility_monthly",
         "source_system": "DELTA_LAKE",
         "source_table": json.dumps(["MKVW_COMN_SCHEMA.FXG_ACCT_BILL_MTH_HIST"]),
         "target_table": "facility_monthly",
         "target_dataset_layer": "FACILITY", "opco": opco,
         "load_process": "transform_monthly",
         "data_quality_rules": json.dumps([_dq_row_count(2.0), _dq_net_rev(1.0)]),
         "depends_on_table_ids": f"{o}_account_monthly"},

        # ── COUNTRY monthly — depends on FACILITY (soft gate) ───────────
        {**common, **rd,
         "table_id": f"{o}_country_monthly",
         "source_system": "DELTA_LAKE",
         "source_table": json.dumps(["MKVW_COMN_SCHEMA.FXG_FAC_ENTI_BILL_MTH_HIST"]),
         "target_table": "country_monthly",
         "target_dataset_layer": "COUNTRY", "opco": opco,
         "load_process": "transform_monthly",
         "data_quality_rules": json.dumps([_dq_row_count(2.0), _dq_net_rev(1.0)]),
         "depends_on_table_ids": f"{o}_facility_monthly"},

        # ── GLOBAL monthly — depends on COUNTRY (soft gate) ─────────────
        {**common, **rd,
         "table_id": f"{o}_global_monthly",
         "source_system": "DELTA_LAKE",
         "source_table": json.dumps(["MKVW_COMN_SCHEMA.FXG_CTRY_ENTI_BILL_MTH_HIST"]),
         "target_table": "global_monthly",
         "target_dataset_layer": "GLOBAL", "opco": opco,
         "load_process": "transform_monthly",
         "data_quality_rules": json.dumps([_dq_row_count(2.0), _dq_net_rev(1.0)]),
         "depends_on_table_ids": f"{o}_country_monthly"},
    ]


# ---------------------------------------------------------------------------
# Spark insert — idempotent (left-anti join on table_id before appending)
# ---------------------------------------------------------------------------
def seed(spark, opco: str):
    metadata_db = get_metadata_db()
    table = f"{metadata_db}.cdl_table_config"
    rows = get_config_rows(opco)
    df = spark.createDataFrame(rows)

    if spark.catalog.tableExists(table):
        existing = spark.table(table).select("table_id")
        new_rows = df.join(existing, on="table_id", how="left_anti")
    else:
        new_rows = df

    count = new_rows.count()
    if count > 0:
        new_rows.write.format("delta").mode("append").saveAsTable(table)
        print(f"  \u2713 Inserted {count} row(s) into {table}")
    else:
        print(f"  \u23ed  All rows already exist in {table}")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--env", default="azure", choices=["azure", "gcp"])
    parser.add_argument("--opco", default="GROUND")
    args = parser.parse_args()
    os.environ["CDL_ENV"] = args.env

    try:
        from pyspark.sql import SparkSession
        spark = SparkSession.builder.getOrCreate()
    except ImportError:
        print("ERROR: Run on a Databricks / Dataproc cluster with PySpark available.")
        sys.exit(1)

    print(f"\n{'=' * 55}\n  Seeding cdl_table_config \u2014 OPCO={args.opco.upper()}\n{'=' * 55}")
    seed(spark, args.opco.upper())
    print("\u2705  Done.\n")


if __name__ == "__main__":
    main()
