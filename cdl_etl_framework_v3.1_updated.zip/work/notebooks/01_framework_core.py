"""
notebooks/01_framework_core.py
================================
Shared, class-based framework core used by every other notebook.

Design principles applied throughout this rewrite
--------------------------------------------------
1.  NEVER HALT ON POOR DATA QUALITY.
    A DQ failure is *information*, not a stop condition. Every layer always
    loads its data; DQ outcomes are written to the log table so humans (and
    downstream jobs, if they choose to look) know quality was poor. The next
    layer is never blocked by an upstream DQ failure.
2.  ONE LOG ROW PER (table_id, load_mnth, attempt).
    cdl_table_run_log is keyed on
    (run_batch_id, table_id, load_mnth_start, attempt_number), so every retry
    of every table gets its own durable row, and you can see exactly what
    failed on attempt 1 vs attempt 2 for a given table.
3.  FAULT TOLERANT BY DEFAULT.
    Anything that talks to external state (metastore reads, Delta MERGE
    writes) goes through retry-with-backoff. Logging failures are always
    non-fatal — a broken audit write must never take down a data load.
4.  CLASS-BASED.
    TableConfigRepository, DQEngine and RunLogger each own one responsibility
    and can be tested / swapped independently.

Contains:
  - log(msg)                    : structured print logger (kept as a free
                                   function for backward compatibility)
  - TableConfig                 : one row from cdl_table_config
  - TableConfigRepository       : reads cdl_table_config for an OPCO + layer
  - DQEngine                    : runs inline DQ rules, never raises
  - DQGateChecker                : OPTIONAL upstream-gate check (soft by
                                   default — see hard_dq_gate)
  - RunLogger                   : all cdl_table_run_log read/write behaviour
"""

import importlib
import json
from dataclasses import dataclass, field
from datetime import date, datetime, timezone
from typing import Optional

from pyspark.sql import SparkSession
from pyspark.sql import functions as F
from pyspark.sql.types import (
    StructType, StructField, StringType, IntegerType, LongType, TimestampType,
)
from delta.tables import DeltaTable

try:
    from utils.retry_handler import with_retry
except Exception:  # pragma: no cover - allows this module to load standalone
    def with_retry(*_a, **_kw):
        def _decorator(fn):
            return fn
        return _decorator

# from config.env_config import get_metadata_db
# METADATA_DB = get_metadata_db()
METADATA_DB = 'f6180854'
RUN_LOG_TABLE = f'{METADATA_DB}.cdl_table_run_log'
TABLE_CONFIG_TABLE = f'{METADATA_DB}.cdl_table_config'

spark = SparkSession.builder.getOrCreate()


# ─────────────────────────────────────────────────────────────────────────────
# Logger — simple structured print
# ─────────────────────────────────────────────────────────────────────────────
def log(level: str, msg: str, **ctx):
    now = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
    extra = "  ".join(f"{k}={v}" for k, v in ctx.items())
    print(f"[{now}] [{level.upper()}]  {msg}  {extra}".strip())


# ─────────────────────────────────────────────────────────────────────────────
# TableConfig — one row from cdl_table_config
# ─────────────────────────────────────────────────────────────────────────────
@dataclass
class TableConfig:
    table_id:              str
    opco:                  str
    target_dataset_layer:  str
    source_system:         str
    source_table:          list
    target_system:         str
    target_table:          str
    load_process:          str
    schedule_group:        Optional[str]
    ingestion_mode:        str
    incremental_cutoff_day: str
    load_frequency:        str
    watermark_column:      Optional[str]
    last_watermark_value:  Optional[datetime]
    partition_col:         Optional[str]
    dq_rules:               list
    dq_status:              bool
    is_active:              bool

    # ── Gating / resilience knobs — all optional with safe defaults so old
    # config rows (without these columns yet) keep working. ─────────────────
    depends_on:             list = field(default_factory=list)
    hard_dq_gate:           bool = False     # False == never halt downstream
    retry_max_attempts:     int = 3
    retry_initial_wait_sec: float = 15.0
    retry_backoff_multiplier: float = 2.0
    retry_max_wait_sec:     float = 180.0


# ─────────────────────────────────────────────────────────────────────────────
# TableConfigRepository — reads / parses cdl_table_config
# ─────────────────────────────────────────────────────────────────────────────
class TableConfigRepository:
    """Encapsulates all reads of cdl_table_config into typed TableConfig objects."""

    def __init__(self, spark_session: Optional[SparkSession] = None, table: str = TABLE_CONFIG_TABLE):
        self.spark = spark_session or SparkSession.getActiveSession() or spark
        self.table = table

    @with_retry(max_attempts=3, initial_wait=5.0, retryable_exceptions=(Exception,))
    def _fetch_rows(self, where: str):
        return self.spark.sql(f"SELECT * FROM {self.table} WHERE {where}").collect()

    def read(
        self,
        table_id: Optional[list] = None,
        schedule_group: Optional[str] = None,
    ) -> list:
        clauses = ["is_active = true"]
        if schedule_group:
            clauses.append(f"schedule_group = '{schedule_group}'")
        elif table_id:
            table_ids = ",".join(f"'{t}'" for t in table_id)
            clauses.append(f"table_id IN ({table_ids})")
        else:
            raise ValueError("Either schedule_group or table_id must be provided.")

        where = " AND ".join(clauses)

        try:
            rows = self._fetch_rows(where)
        except Exception as exc:
            # Reading config is foundational — if it fails after retries there
            # is nothing useful we can do downstream, so we surface it clearly
            # rather than silently returning an empty list.
            log("ERROR", f"Failed to read {self.table} after retries: {exc}")
            raise

        if table_id and not schedule_group:
            order_map = {tid: idx for idx, tid in enumerate(table_id)}
            rows = sorted(rows, key=lambda r: order_map.get(r.table_id, float("inf")))

        log("INFO", f"Loaded {len(rows)} config(s)", schedule_group=schedule_group, table_id=table_id)
        return [self._to_config(r) for r in rows]

    @staticmethod
    def _parse_json(v, default):
        if not v:
            return default
        v = v.strip()
        if not v:
            return default
        if v.startswith(("[", "{")):
            try:
                return json.loads(v)
            except json.JSONDecodeError as exc:
                log("WARN", f"Malformed JSON config value, falling back to default: {exc}")
                return default
        return [x.strip() for x in v.split(",") if x.strip()]

    @classmethod
    def _to_config(cls, row) -> TableConfig:
        d = row.asDict()

        def opt(name, default=None):
            return d[name] if name in d and d[name] is not None else default

        return TableConfig(
            table_id=d["table_id"],
            opco=d["opco"],
            target_dataset_layer=d["target_dataset_layer"],
            source_system=d["source_system"],
            source_table=cls._parse_json(d.get("source_table"), []),
            target_system=d["target_system"],
            target_table=d["target_table"],
            load_process=d["load_process"],
            schedule_group=d.get("schedule_group"),
            ingestion_mode=d["ingestion_mode"],
            incremental_cutoff_day=d["incremental_cutoff_day"],
            load_frequency=d["load_frequency"],
            watermark_column=d.get("watermark_column"),
            last_watermark_value=d.get("last_watermark_value"),
            partition_col=d.get("partition_col"),
            dq_rules=cls._parse_json(d.get("data_quality_rules"), []),
            dq_status=bool(d["dq_status"]) if d.get("dq_status") is not None else True,
            is_active=bool(d["is_active"]),
            depends_on=cls._parse_json(d.get("depends_on_table_ids"), []),
            hard_dq_gate=bool(opt("hard_dq_gate", False)),
            retry_max_attempts=int(opt("retry_max_attempts", 3) or 3),
            retry_initial_wait_sec=float(opt("retry_initial_wait_sec", 15.0) or 15.0),
            retry_backoff_multiplier=float(opt("retry_backoff_multiplier", 2.0) or 2.0),
            retry_max_wait_sec=float(opt("retry_max_wait_sec", 180.0) or 180.0),
        )


# Backwards-compatible module-level function some notebooks still import.
def read_table_configs(table_id: Optional[list] = None, schedule_group: Optional[str] = None) -> list:
    return TableConfigRepository().read(table_id=table_id, schedule_group=schedule_group)


# ─────────────────────────────────────────────────────────────────────────────
# DQGateChecker — OPTIONAL upstream gate. SOFT by default (never blocks).
# ─────────────────────────────────────────────────────────────────────────────
class DQGateChecker:
    """
    Historically this framework could HALT a downstream layer if an upstream
    layer's DQ checks failed. Per the current requirement, layers must never
    be halted because of poor upstream data quality — the bad-quality data is
    still loaded, just clearly flagged in the log table.

    This class is kept so a table can *opt in* to hard gating
    (cfg.hard_dq_gate = True) for the rare case some table truly must not run
    on top of known-bad upstream data. By default it only WARNS.
    """

    def __init__(self, spark_session: Optional[SparkSession] = None, run_log_table: str = RUN_LOG_TABLE):
        self.spark = spark_session or SparkSession.getActiveSession() or spark
        self.run_log_table = run_log_table

    def check(self, cfg: TableConfig, run_batch_id: str) -> tuple:
        """
        Returns (proceed: bool, failed_upstream: list[str]).
        proceed is always True unless cfg.hard_dq_gate is explicitly set.
        """
        if not cfg.depends_on:
            return True, []

        ids = ",".join(f"'{x}'" for x in cfg.depends_on)
        try:
            rows = self.spark.sql(f"""
                SELECT table_id, MAX(CASE WHEN dq_result = 'PASS' THEN 1 ELSE 0 END) AS ok
                FROM {self.run_log_table}
                WHERE run_batch_id = '{run_batch_id}'
                  AND table_id IN ({ids})
                GROUP BY table_id
            """).collect()
        except Exception as exc:
            log("WARN", f"Could not evaluate DQ gate (treating as pass-through): {exc}", table=cfg.table_id)
            return True, []

        passed = {r["table_id"] for r in rows if r["ok"] == 1}
        failed = [x for x in cfg.depends_on if x not in passed]

        if failed:
            if cfg.hard_dq_gate:
                log("ERROR", "HARD DQ gate blocked table", table=cfg.table_id, failed_upstream=str(failed))
                return False, failed
            log("WARN",
                "Upstream DQ failed but hard_dq_gate is off — proceeding anyway",
                table=cfg.table_id, failed_upstream=str(failed))
        return True, failed


# ─────────────────────────────────────────────────────────────────────────────
# DQEngine — run inline rules, never raise, never block the load
# ─────────────────────────────────────────────────────────────────────────────
class DQEngine:
    """
    Runs every rule in cfg.dq_rules against (stage_table, source_table) for a
    given (opco, load_mnth). This class NEVER raises — a bug in a DQ rule, or
    the DQ engine itself, degrades to an "UNKNOWN" quality result rather than
    stopping the ingestion. Data always gets loaded; only the quality verdict
    can vary.
    """

    def __init__(self, rules_module: str = "dq.dq_rules"):
        self._rules_module_name = rules_module
        self._rules_module = None

    def _module(self):
        if self._rules_module is None:
            self._rules_module = importlib.import_module(self._rules_module_name)
        return self._rules_module

    def run(
        self,
        cfg: TableConfig,
        opco: str,
        load_mnth: str,
        stage_table: str,
        source_table: str,
    ) -> tuple:
        """
        Returns (dq_passed: bool, results: list[dict]).
        dq_passed=True is also returned (with an explanatory result entry)
        when there are no rules configured, or DQ is switched off for this
        table — "no rules" must never be conflated with "failed rules".
        """
        if not cfg.dq_rules or cfg.dq_status is False:
            return True, [{
                "dq_rule": None,
                "passed": True,
                "info": "No DQ rules configured or DQ status inactive for this table",
            }]

        try:
            module = self._module()
        except Exception as exc:
            log("ERROR", f"Could not load DQ rules module '{self._rules_module_name}': {exc}", table=cfg.table_id)
            return True, [{"dq_rule": None, "passed": None,
                           "info": f"DQ engine unavailable: {exc}"}]

        spark_session = SparkSession.getActiveSession() or spark
        results = []
        overall_ok = True

        for rule in cfg.dq_rules:
            rule_name = rule.get("dq_rule")
            threshold = float(rule.get("error_threshold_pct", 0.0))
            fn = getattr(module, rule_name, None) if rule_name else None

            if fn is None:
                log("ERROR", f"DQ rule '{rule_name}' not found in {self._rules_module_name}", table=cfg.table_id)
                results.append({"dq_rule": rule_name, "threshold_pct": threshold,
                                 "diff_pct": None, "passed": False, "error": "rule not found"})
                overall_ok = False
                continue

            try:
                diff_pct = fn(spark_session, stage_table, source_table, opco, load_mnth)
                passed = diff_pct is not None and diff_pct <= threshold
            except Exception as exc:
                log("ERROR", f"DQ rule '{rule_name}' raised: {exc}", table=cfg.table_id)
                diff_pct, passed = None, False

            results.append({"dq_rule": rule_name, "threshold_pct": threshold,
                             "diff_pct": diff_pct, "passed": passed})
            overall_ok = overall_ok and passed

        return overall_ok, results


# ─────────────────────────────────────────────────────────────────────────────
# RunLogger — all cdl_table_run_log behaviour, one row per (table_id,
# load_mnth_start, attempt_number)
# ─────────────────────────────────────────────────────────────────────────────
# Target schema for cdl_table_run_log — used to build typed DataFrames.
_RUN_LOG_TYPES = {
    "run_batch_id":      StringType(),
    "log_time":          TimestampType(),
    "opco":              StringType(),
    "dataset_layer":     StringType(),
    "table_name":        StringType(),
    "table_id":          StringType(),
    "load_process":      StringType(),
    "load_mnth_start":   StringType(),
    "load_mnth_end":     StringType(),
    "status":            StringType(),
    "message":           StringType(),
    "attempt_number":    IntegerType(),
    "watermark_start":   TimestampType(),
    "watermark_end":     TimestampType(),
    "started_at":        TimestampType(),
    "completed_at":      TimestampType(),
    "duration_seconds":  IntegerType(),
    "rows_read":         LongType(),
    "rows_written":      LongType(),
    "dq_result":         StringType(),
    "execution_summary": StringType(),
}


class RunLogger:
    """
    Owns every write to cdl_table_run_log. Rows are keyed on
    (run_batch_id, table_id, load_mnth_start, attempt_number) — this is the
    "per table ID, per row (month) attempt" granularity the log table is
    designed around, so every retry of every table/month combination is
    independently visible and auditable.

    Logging failures are ALWAYS non-fatal: a broken audit write must never
    take down (or be mistaken for a failure of) the actual data load.
    """

    def __init__(self, spark_session: Optional[SparkSession] = None, table: str = RUN_LOG_TABLE):
        self.spark = spark_session or SparkSession.getActiveSession() or spark
        self.table = table

    # ── start ────────────────────────────────────────────────────────────
    def log_start(
        self,
        run_batch_id: str,
        cfg: TableConfig,
        opco: str,
        load_mnth_start: str,
        load_mnth_end: str,
        attempt: int,
        watermark_start: Optional[datetime] = None,
    ) -> datetime:
        started_at = datetime.now(timezone.utc)
        row = {
            "run_batch_id":     run_batch_id,
            "log_time":         started_at.isoformat(),
            "opco":             opco,
            "dataset_layer":    cfg.target_dataset_layer,
            "table_name":       cfg.target_table,
            "table_id":         cfg.table_id,
            "load_process":     cfg.load_process,
            "load_mnth_start":  load_mnth_start,
            "load_mnth_end":    load_mnth_end,
            "status":           "RUNNING",
            "message":          None,
            "attempt_number":   attempt,
            "watermark_start":  watermark_start.isoformat() if watermark_start else None,
            "watermark_end":    None,
            "started_at":       started_at.isoformat(),
            "completed_at":     None,
            "duration_seconds": None,
            "rows_read":        None,
            "rows_written":     None,
            "dq_result":        None,
            "execution_summary": None,
        }
        self._upsert(run_batch_id, cfg.table_id, load_mnth_start, attempt, row)
        return started_at

    # ── success / partial success ───────────────────────────────────────
    def log_end_success(
        self,
        run_batch_id: str,
        cfg: TableConfig,
        opco: str,
        load_mnth_start: str,
        load_mnth_end: str,
        attempt: int,
        started_at: datetime,
        rows_read: int,
        rows_written: int,
        month_summaries: list,
    ) -> str:
        """Returns the final status string written (SUCCESS/PARTIAL_SUCCESS/FAILED)."""
        now = datetime.now(timezone.utc)
        duration = int((now - started_at).total_seconds())

        dq_result, execution_summary_json, status = self._build_execution_summary(month_summaries)
        row = {
            "run_batch_id":     run_batch_id,
            "log_time":         now.isoformat(),
            "opco":             opco,
            "dataset_layer":    cfg.target_dataset_layer,
            "table_name":       cfg.target_table,
            "table_id":         cfg.table_id,
            "load_process":     cfg.load_process,
            "load_mnth_start":  load_mnth_start,
            "load_mnth_end":    load_mnth_end,
            "status":           status,
            "message":          "Completed — data loaded for all months in scope"
                                 if dq_result == "PASS" else
                                 "Completed — data loaded for all months; some months failed DQ checks",
            "attempt_number":   attempt,
            "watermark_start":  None,
            "watermark_end":    None,
            "started_at":       started_at.isoformat(),
            "completed_at":     now.isoformat(),
            "duration_seconds": duration,
            "rows_read":        rows_read,
            "rows_written":     rows_written,
            "dq_result":        dq_result,
            "execution_summary": execution_summary_json,
        }
        self._upsert(run_batch_id, cfg.table_id, load_mnth_start, attempt, row)
        return status

    # ── failure / retrying ──────────────────────────────────────────────
    def log_end_failure(
        self,
        run_batch_id: str,
        cfg: TableConfig,
        opco: str,
        load_mnth_start: str,
        load_mnth_end: str,
        attempt: int,
        started_at: Optional[datetime],
        error_code: str,
        error_message: str,
        is_final: bool = True,
        month_summaries: Optional[list] = None,
    ) -> None:
        now = datetime.now(timezone.utc)
        duration = int((now - started_at).total_seconds()) if started_at else 0
        status = "FAILED" if is_final else "RETRYING"

        dq_result = "SKIPPED"
        execution_summary_json = json.dumps({"error": "DQ did not complete before failure"})
        if month_summaries:
            dq_result, execution_summary_json, _ = self._build_execution_summary(month_summaries)

        row = {
            "run_batch_id":     run_batch_id,
            "log_time":         now.isoformat(),
            "opco":             opco,
            "dataset_layer":    cfg.target_dataset_layer,
            "table_name":       cfg.target_table,
            "table_id":         cfg.table_id,
            "load_process":     cfg.load_process,
            "load_mnth_start":  load_mnth_start,
            "load_mnth_end":    load_mnth_end,
            "status":           status,
            "message":          f"{error_code}: {str(error_message)[:500]}",
            "attempt_number":   attempt,
            "watermark_start":  None,
            "watermark_end":    None,
            "started_at":       started_at.isoformat() if started_at else None,
            "completed_at":     now.isoformat(),
            "duration_seconds": duration,
            "rows_read":        None,
            "rows_written":     None,
            "dq_result":        dq_result,
            "execution_summary": execution_summary_json,
        }
        self._upsert(run_batch_id, cfg.table_id, load_mnth_start, attempt, row)

    # ── execution summary builder ───────────────────────────────────────
    @staticmethod
    def _build_execution_summary(month_summaries: list) -> tuple:
        """Returns (dq_result_status, execution_summary_json, pipeline_status)."""
        if not month_summaries:
            return "N/A", json.dumps({"month_details": []}), "RUNNING"

        good_months = [s["month"] for s in month_summaries if s.get("dq_status") == "PASS"]
        bad_months = [s["month"] for s in month_summaries if s.get("dq_status") == "FAIL"]

        execution_summary_json = json.dumps({"month_details": month_summaries}, indent=2, default=str)

        if not bad_months:
            return "PASS", execution_summary_json, "SUCCESS"
        elif good_months:
            return "PARTIAL", execution_summary_json, "PARTIAL_SUCCESS"
        else:
            # NOTE: even when every month fails DQ we still mark this SUCCESS
            # from a "did the data load" perspective — the framework's job is
            # to load data regardless of quality, and month_summaries here
            # only exist at all if the load itself succeeded. A truly failed
            # *load* goes through log_end_failure instead, not this path.
            return "FAIL", execution_summary_json, "SUCCESS_WITH_DQ_FAILURES"

    # ── upsert (with retry — Delta MERGE can hit transient conflicts) ────
    @with_retry(max_attempts=3, initial_wait=2.0, backoff_multiplier=2.0, max_wait=20.0)
    def _do_merge(self, df):
        (
            DeltaTable
            .forName(self.spark, self.table)
            .alias("t")
            .merge(
                df.alias("s"),
                """t.run_batch_id     = s.run_batch_id
               AND t.table_id         = s.table_id
               AND t.load_mnth_start  = s.load_mnth_start
               AND t.attempt_number   = s.attempt_number""",
            )
            .whenMatchedUpdateAll()
            .whenNotMatchedInsertAll()
            .execute()
        )

    def _upsert(self, run_batch_id: str, table_id: str, load_mnth_start: str, attempt: int, row: dict) -> None:
        """
        MERGE on (run_batch_id, table_id, load_mnth_start, attempt_number).
        First call inserts (RUNNING). Subsequent calls update in place.
        Sink failures are non-fatal — logged to stdout only, so a logging
        outage never masks or blocks the actual data load.
        """
        try:
            str_schema = StructType([StructField(k, StringType(), True) for k in row])
            str_row = {k: (str(v) if v is not None else None) for k, v in row.items()}
            df = self.spark.createDataFrame([str_row], schema=str_schema)

            for col_name in df.columns:
                target_type = _RUN_LOG_TYPES.get(col_name)
                if target_type and not isinstance(target_type, StringType):
                    df = df.withColumn(col_name, F.col(col_name).cast(target_type))

            self._do_merge(df)
        except Exception as e:
            log("WARN", f"_upsert_log failed (non-fatal, data load is unaffected): {e}",
                table_id=table_id, load_mnth_start=load_mnth_start, attempt=attempt)


# ─────────────────────────────────────────────────────────────────────────────
# Module-level convenience wrappers (kept for any code still importing
# functions instead of instantiating classes)
# ─────────────────────────────────────────────────────────────────────────────
_default_run_logger = None
_default_dq_engine = None
_default_gate_checker = None


def _run_logger() -> RunLogger:
    global _default_run_logger
    if _default_run_logger is None:
        _default_run_logger = RunLogger()
    return _default_run_logger


def _dq_engine() -> DQEngine:
    global _default_dq_engine
    if _default_dq_engine is None:
        _default_dq_engine = DQEngine()
    return _default_dq_engine


def _gate_checker() -> DQGateChecker:
    global _default_gate_checker
    if _default_gate_checker is None:
        _default_gate_checker = DQGateChecker()
    return _default_gate_checker


def check_dq_gate(cfg: TableConfig, run_batch_id: str) -> tuple:
    return _gate_checker().check(cfg, run_batch_id)


def run_dq_on_stage(cfg: TableConfig, opco: str, load_mnth: str, stage_table: str, source_table: str) -> tuple:
    return _dq_engine().run(cfg, opco, load_mnth, stage_table, source_table)


def log_start(run_batch_id, cfg, opco, load_mnth_start, load_mnth_end, attempt, watermark_start=None):
    return _run_logger().log_start(run_batch_id, cfg, opco, load_mnth_start, load_mnth_end, attempt, watermark_start)


def log_end_success(run_batch_id, cfg, opco, load_mnth_start, load_mnth_end, attempt, started_at,
                     rows_read, rows_written, month_summaries):
    return _run_logger().log_end_success(run_batch_id, cfg, opco, load_mnth_start, load_mnth_end,
                                          attempt, started_at, rows_read, rows_written, month_summaries)


def log_end_failure(run_batch_id, cfg, opco, load_mnth_start, load_mnth_end, attempt, started_at,
                     error_code, error_message, is_final=True, month_summaries=None):
    return _run_logger().log_end_failure(run_batch_id, cfg, opco, load_mnth_start, load_mnth_end, attempt,
                                          started_at, error_code, error_message, is_final, month_summaries)
