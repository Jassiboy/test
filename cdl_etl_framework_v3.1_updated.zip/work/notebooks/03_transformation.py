"""
notebooks/03_transformation.py
================================
TransformationLoader — loads the correct transformation module for a given
OPCO + layer and calls the function named by cfg.load_process.

Each transformation module (e.g. transformations/ground/account.py) is
expected to expose a callable named exactly `cfg.load_process`
(e.g. "transform_daily" / "transform_monthly") with the signature:

    fn(spark, source_table: list, load_mnth: str) -> DataFrame

Fault tolerance
---------------
* Modules are imported once and cached — a transient import hiccup is
  retried before we give up.
* A missing module or missing function is a *configuration* error (not a
  transient one) and is raised immediately with a clear, actionable message
  — retrying it would just waste time since it can never succeed without a
  config/code fix.
"""

import importlib
from typing import Optional

from pyspark.sql import DataFrame, SparkSession

# Dynamic import to handle module names starting with digits
_framework_core = importlib.import_module('notebooks.01_framework_core')
log = _framework_core.log

try:
    from utils.retry_handler import with_retry
except Exception:  # pragma: no cover
    def with_retry(*_a, **_kw):
        def _decorator(fn):
            return fn
        return _decorator


class TransformationLoader:
    """Resolves and invokes transformations/{opco}/{layer}.py::{load_process}."""

    def __init__(self):
        self._module_cache = {}

    @with_retry(max_attempts=3, initial_wait=2.0, backoff_multiplier=2.0, max_wait=15.0)
    def _import(self, module_path: str):
        if module_path in self._module_cache:
            return self._module_cache[module_path]
        module = importlib.import_module(module_path)
        self._module_cache[module_path] = module
        return module

    def get_transformed_df(
        self,
        opco: str,
        layer: str,
        target_table: str,
        source_table: list,
        load_process: str,
        load_mnth: str,
    ) -> DataFrame:
        """
        Parameters
        ----------
        opco         : "GROUND" | "FREIGHT" | ...
        layer        : "ACCOUNT" | "FACILITY" | "COUNTRY" | "GLOBAL"
        target_table : physical target table name (for logging only)
        source_table : list of source table names the transform should read
        load_process : name of the function to call in the transform module
        load_mnth    : YYYYMM string scope for this run

        Returns a DataFrame ready to pass to IngestionEngine.run().
        """
        module_path = f"transformations.{opco.lower()}.{layer.lower()}"
        log("INFO", "Loading transformer", module=module_path, target_table=target_table)

        try:
            module = self._import(module_path)
        except ModuleNotFoundError as exc:
            raise ValueError(
                f"No transformation module at '{module_path}'.\n"
                f"Create transformations/{opco.lower()}/{layer.lower()}.py "
                f"with a '{load_process}' function.") from exc

        fn = getattr(module, load_process, None)
        if fn is None:
            raise ValueError(
                f"Module '{module_path}' is missing function '{load_process}'. "
                f"Available callables: "
                f"{[n for n in dir(module) if not n.startswith('_') and callable(getattr(module, n))]}"
            )

        spark = SparkSession.getActiveSession()
        return fn(spark, source_table, load_mnth)


# ─────────────────────────────────────────────────────────────────────────────
# Module-level convenience wrapper (kept for backward compatibility)
# ─────────────────────────────────────────────────────────────────────────────
_default_loader = None


def _loader() -> TransformationLoader:
    global _default_loader
    if _default_loader is None:
        _default_loader = TransformationLoader()
    return _default_loader


def get_transformed_df(opco: str, layer: str, target_table: str, source_table: list,
                        load_process: str, load_mnth: str) -> DataFrame:
    return _loader().get_transformed_df(opco, layer, target_table, source_table, load_process, load_mnth)
