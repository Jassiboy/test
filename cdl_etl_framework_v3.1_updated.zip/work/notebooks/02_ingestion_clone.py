"""
notebooks/02_ingestion_clone.py
================================
DEPRECATED — superseded by notebooks/02_ingestion.py (IngestionEngine).

This file used to hold an alternate MERGE/CDC-based ingestion path
(incremental watermark mode + range/backfill mode with FULL/INCR/CDC
branching). It referenced functions that no longer exist in the current
framework (make_run_id, log_success/log_failure, run_dq, update_watermark)
and would raise ImportError the moment it was imported.

It is kept only as a reference/history of that design and is intentionally
NOT wired into 04_main_core.py. If you need MERGE/CDC-style ingestion again,
port the logic into a method on IngestionEngine (notebooks/02_ingestion.py)
rather than importing this file — that keeps a single source of truth for
ingestion behaviour (staging, DQ, retry, and the "always load, never halt
on DQ" contract all live there now).
"""

raise ImportError(
    "notebooks/02_ingestion_clone.py is deprecated and intentionally "
    "disabled. Use notebooks.02_ingestion.IngestionEngine instead."
)
