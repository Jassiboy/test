# Databricks notebook source
# MAGIC %md
# MAGIC # CDL ETL — Main Orchestrator
# MAGIC Class-based, fault-tolerant orchestration. Key behaviours:
# MAGIC * Every layer ALWAYS loads its data, however poor the DQ result —
# MAGIC   quality is recorded in the log table, never used to stop a load.
# MAGIC * An upstream layer's DQ failure never halts a downstream layer.
# MAGIC * Every (table_id, load_mnth, attempt) combination gets its own durable
# MAGIC   run-log row, so retries are individually auditable.
# MAGIC * Automatic retry with backoff around each table's staging + promotion.

# COMMAND ----------

import importlib
import json
import sys
import os
import time
import traceback
import uuid
from collections import defaultdict
from datetime import date, datetime, timezone
from typing import Optional

# Force reload — clear cached modules so updated files are picked up
for _mod in ['notebooks.01_framework_core', 'notebooks.02_ingestion',
             'notebooks.03_transformation', 'config.env_config', 'dq.dq_rules']:
    sys.modules.pop(_mod, None)

# Add parent directory to path for imports
sys.path.insert(0, os.path.abspath(os.path.join(os.getcwd(), "..")))

# Import framework modules using importlib (module names start with digits)
framework_core = importlib.import_module('notebooks.01_framework_core')
ingestion_core = importlib.import_module('notebooks.02_ingestion')
transformation_core = importlib.import_module('notebooks.03_transformation')
_env_config_mod = importlib.import_module('config.env_config')
PIPELINE_CONFIG = _env_config_mod.PIPELINE_CONFIG

try:
    from utils.retry_handler import with_retry, _wait as retry_wait
except Exception:  # pragma: no cover
    def retry_wait(attempt, initial, mult, cap, jitter):
        return min(initial * (mult ** (attempt - 1)), cap)

TableConfig             = framework_core.TableConfig
TableConfigRepository   = framework_core.TableConfigRepository
DQGateChecker           = framework_core.DQGateChecker
RunLogger               = framework_core.RunLogger
log                     = framework_core.log
IngestionEngine         = ingestion_core.IngestionEngine
TransformationLoader    = transformation_core.TransformationLoader

LAYER_ORDER = PIPELINE_CONFIG.layer_order  # e.g. ["ACCOUNT","FACILITY","COUNTRY","GLOBAL"]
CONFIG_PATH = "../config/run_config.json"
DATA_DB = 'f6180854'
DEFAULT_RETRY_MAX_ATTEMPTS = getattr(PIPELINE_CONFIG, "default_max_attempts", 3)

# COMMAND ----------


def _none_if_blank(val):
    """Normalises "", "None" (string), and None into a real None."""
    if val is None:
        return None
    if isinstance(val, str) and val.strip() in ("", "None", "none", "null"):
        return None
    return val


def month_chunks(start_yyyymm: int, end_yyyymm: int) -> list:
    """Return list of YYYYMM ints between start and end (inclusive)."""
    chunks = []
    cur_y, cur_m = start_yyyymm // 100, start_yyyymm % 100
    end_y, end_m = end_yyyymm // 100, end_yyyymm % 100
    while (cur_y, cur_m) <= (end_y, end_m):
        chunks.append(cur_y * 100 + cur_m)
        cur_m += 1
        if cur_m > 12:
            cur_m = 1
            cur_y += 1
    return chunks


# COMMAND ----------
# DBTITLE 1,PipelineOrchestrator — the single class driving every run
class PipelineOrchestrator:
    """
    Owns the full run lifecycle: resolving which (opco, layer, table) groups
    to run, working out which months are in scope, staging + ingesting each
    month with retry, and writing one log row per (table_id, month, attempt).
    """

    def __init__(
        self,
        data_db: str = DATA_DB,
        layer_order: Optional[list] = None,
        config_repo: Optional[TableConfigRepository] = None,
        run_logger: Optional[RunLogger] = None,
        gate_checker: Optional[DQGateChecker] = None,
        ingestion_engine: Optional[IngestionEngine] = None,
        transformation_loader: Optional[TransformationLoader] = None,
    ):
        self.data_db = data_db
        self.layer_order = layer_order or LAYER_ORDER
        self.config_repo = config_repo or TableConfigRepository()
        self.run_logger = run_logger or RunLogger()
        self.gate_checker = gate_checker or DQGateChecker()
        self.ingestion_engine = ingestion_engine or IngestionEngine(data_db=self.data_db)
        self.transformation_loader = transformation_loader or TransformationLoader()

    # ── Scope resolution ────────────────────────────────────────────────
    def resolve_groups(self, table_ids: list) -> list:
        """
        Returns [(opco, layer, [table_ids in original order]), ...] sorted
        by layer_order so ACCOUNT runs before FACILITY before COUNTRY etc.
        Layers still run in this natural dependency order for readability,
        but — per the current requirement — a poor/failed DQ result in one
        layer never prevents the next layer's group from running.
        """
        configs = self.config_repo.read(table_id=table_ids)
        if not configs:
            return []

        table_order = {tid: idx for idx, tid in enumerate(table_ids)}
        configs.sort(key=lambda c: table_order.get(c.table_id, float("inf")))

        grouped = defaultdict(list)
        for cfg in configs:
            grouped[(cfg.opco, cfg.target_dataset_layer)].append(cfg.table_id)

        layer_rank = {layer: idx for idx, layer in enumerate(self.layer_order)}
        return sorted(
            [(opco, layer, ids) for (opco, layer), ids in grouped.items()],
            key=lambda grp: layer_rank.get(grp[1], 99),
        )

    def resolve_windows(self, cfg: TableConfig, start_date: Optional[str], end_date: Optional[str]) -> tuple:
        """Returns (windows: list[str YYYYMM], mode: str)."""
        run_date = date.today()

        if start_date is not None and end_date is not None:
            windows = [str(w) for w in month_chunks(int(start_date), int(end_date))]
            return windows, "monthly_backfill"

        # Incremental mode: current month, plus previous month if we're still
        # inside this table's cutoff window for late-arriving data.
        current_month_str = run_date.strftime("%Y%m")
        cutoff_day = int(cfg.incremental_cutoff_day) if cfg.incremental_cutoff_day else 0
        if run_date.day <= cutoff_day:
            from dateutil.relativedelta import relativedelta
            prev_month_str = (run_date - relativedelta(months=1)).strftime("%Y%m")
            return [prev_month_str, current_month_str], "incremental"
        return [current_month_str], "incremental"

    # ── Per-table execution (retry loop lives here) ─────────────────────
    def run_table(
        self,
        run_batch_id: str,
        opco: str,
        layer: str,
        cfg: TableConfig,
        start_date: Optional[str],
        end_date: Optional[str],
    ) -> dict:
        # Soft-check upstream DQ — never blocks unless the table explicitly
        # opts in to hard gating via cfg.hard_dq_gate.
        proceed, failed_upstream = self.gate_checker.check(cfg, run_batch_id)
        if not proceed:
            log("ERROR", "Table halted by hard DQ gate", table=cfg.table_id, failed_upstream=str(failed_upstream))
            return {"table_id": cfg.table_id, "opco": opco, "layer": layer, "ok": False,
                    "reason": f"hard_dq_gate blocked on upstream failures: {failed_upstream}"}

        windows, mode = self.resolve_windows(cfg, start_date, end_date)
        if not windows:
            log("WARN", f"No months to process for table {cfg.table_id}.")
            return {"table_id": cfg.table_id, "opco": opco, "layer": layer, "ok": True, "reason": "no windows"}

        temp_table = f"{self.data_db}.{cfg.target_table}_temp"
        max_attempts = cfg.retry_max_attempts or DEFAULT_RETRY_MAX_ATTEMPTS

        completed_staged_months = set()
        completed_ingested_months = set()
        all_ok = False

        for attempt in range(1, max_attempts + 1):
            month_summaries = []
            started_at = self.run_logger.log_start(
                run_batch_id=run_batch_id, cfg=cfg, opco=opco,
                load_mnth_start=windows[0], load_mnth_end=windows[-1], attempt=attempt,
                watermark_start=cfg.last_watermark_value,
            )
            total_rows_written = 0
            try:
                if attempt == 1:
                    self.ingestion_engine.reset_stage(temp_table)

                # 1. Stage every month not already staged in a prior attempt.
                for mnth in windows:
                    if mnth in completed_staged_months:
                        log("INFO", f"Skipping stage for {mnth} — already staged in a prior attempt.",
                            table=cfg.table_id)
                        continue
                    tdf = self.transformation_loader.get_transformed_df(
                        opco, layer, cfg.target_table, cfg.source_table, cfg.load_process, mnth)
                    tdf.write.format("delta").mode("append").saveAsTable(temp_table)
                    completed_staged_months.add(mnth)
                    log("INFO", f"Staged {mnth}", table=cfg.table_id)

                # 2. DQ + promote every month — ALWAYS loads regardless of DQ
                #    outcome (see IngestionEngine docstring).
                for mnth in windows:
                    if mnth in completed_ingested_months:
                        log("INFO", f"Skipping ingest for {mnth} — already ingested in a prior attempt.",
                            table=cfg.table_id)
                        continue
                    _dq_passed, mnth_summary = self.ingestion_engine.run(
                        run_batch_id, cfg, opco, mnth, temp_table)
                    month_summaries.append(mnth_summary)
                    total_rows_written += mnth_summary.get("rows_written") or 0
                    if mnth_summary.get("loaded"):
                        completed_ingested_months.add(mnth)

                self.run_logger.log_end_success(
                    run_batch_id=run_batch_id, cfg=cfg, opco=opco,
                    load_mnth_start=windows[0], load_mnth_end=windows[-1],
                    attempt=attempt, started_at=started_at,
                    rows_read=0, rows_written=total_rows_written,
                    month_summaries=month_summaries,
                )
                log("INFO", f"{cfg.table_id}: execution complete "
                            f"({len(completed_ingested_months)}/{len(windows)} months loaded).")
                all_ok = True
                break  # finished this table without an unhandled exception

            except Exception as exc:
                msg = f"{type(exc).__name__}: {exc}\n{traceback.format_exc()}"
                is_last = attempt == max_attempts
                log("ERROR", f"Attempt {attempt}/{max_attempts} failed for {cfg.table_id}: {exc}")

                self.run_logger.log_end_failure(
                    run_batch_id=run_batch_id, cfg=cfg, opco=opco,
                    load_mnth_start=windows[0], load_mnth_end=windows[-1],
                    attempt=attempt, started_at=started_at,
                    error_code="UNHANDLED_EXCEPTION", error_message=msg,
                    is_final=is_last, month_summaries=month_summaries,
                )

                if is_last:
                    all_ok = False
                    break

                wait = retry_wait(attempt, cfg.retry_initial_wait_sec, cfg.retry_backoff_multiplier,
                                   cfg.retry_max_wait_sec, 0.1)
                log("INFO", f"Retrying {cfg.table_id} in {wait:.0f}s …")
                time.sleep(wait)

        return {"table_id": cfg.table_id, "opco": opco, "layer": layer, "ok": all_ok,
                "months": windows, "mode": mode}

    # ── Per-layer / per-opco orchestration ──────────────────────────────
    def run_layer(
        self,
        run_batch_id: str,
        opco: str,
        layer: str,
        table_ids: list,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
    ) -> list:
        configs = self.config_repo.read(table_id=table_ids)
        if not configs:
            log("WARN", "No configs found", layer=layer, opco=opco)
            return []

        log("INFO", "═" * 55)
        log("INFO", f"Running layer={layer} opco={opco} tables={[c.table_id for c in configs]}")

        results = []
        for cfg in configs:
            results.append(self.run_table(run_batch_id, opco, layer, cfg, start_date, end_date))
        return results

    def run_opco(
        self,
        batch_run_id: str,
        opco: str,
        table_ids: list,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
    ) -> list:
        groups = self.resolve_groups(table_ids)
        if not groups:
            log("WARN", "No matching tables for this run", opco=opco)
            return []

        all_results = []
        for i, (g_opco, g_layer, g_table_ids) in enumerate(groups):
            log("INFO", "─" * 45)
            log("INFO", f"(opco={g_opco}) Layer: {g_layer}  Tables: {g_table_ids}")
            # Layers are still processed in dependency order for clarity, but
            # we deliberately do NOT gate on the previous layer's results —
            # every layer always gets a chance to load its data.
            layer_results = self.run_layer(
                batch_run_id, g_opco, g_layer, g_table_ids,
                start_date=start_date, end_date=end_date,
            )
            all_results.extend(layer_results)
        return all_results


# COMMAND ----------
# DBTITLE 1,Widgets / run_config.json parameter resolution
def _params_from_widgets(dbutils) -> Optional[dict]:
    """
    Read run parameters from Databricks widgets, if `table_id` or
    `schedule_group` was actually set. Returns None (→ caller falls back to
    run_config.json) when no widget values are present.
    """
    try:
        for name, default in [
            ("table_id", ""), ("schedule_group", ""),
            ("start_month", ""), ("end_month", ""),
        ]:
            dbutils.widgets.text(name, default)

        table_id = [t.strip() for t in dbutils.widgets.get("table_id").split(",") if t.strip()]
        schedule_group = _none_if_blank(dbutils.widgets.get("schedule_group").strip())

        if not table_id and not schedule_group:
            return None

        return {
            "table_id":       table_id,
            "schedule_group": schedule_group,
            "start_date":     _none_if_blank(dbutils.widgets.get("start_month").strip()),
            "end_date":       _none_if_blank(dbutils.widgets.get("end_month").strip()),
        }
    except Exception as e:
        log("WARN", f"Widgets unavailable, falling back to config file: {e}")
        return None


def _params_from_file(config_path: str = CONFIG_PATH) -> dict:
    with open(config_path) as f:
        file_cfg = json.load(f)
    run_blocks = [r for r in file_cfg.get("runs", []) if set(r.keys()) != {"_comment"}]
    if not run_blocks:
        raise ValueError(f"No runnable blocks found in {config_path}")
    params = run_blocks[0]
    return {
        "table_id":       params.get("table_id") or [],
        "schedule_group": _none_if_blank(params.get("schedule_group")),
        "start_date":     _none_if_blank(params.get("start_date")),
        "end_date":       _none_if_blank(params.get("end_date")),
    }


# COMMAND ----------
# DBTITLE 1,Summary
def print_summary(results: list, started: "datetime") -> None:
    elapsed = (datetime.now(timezone.utc) - started).total_seconds()
    total, passed = len(results), sum(1 for r in results if r.get("ok"))

    log("INFO", "╔" + "═" * 60 + "╗")
    log("INFO", "║        CDL ETL — GRAND SUMMARY" + " " * 29 + "║")
    log("INFO", f"║  Tables:{total}  Pass:{passed}  Fail:{total - passed}  Elapsed:{elapsed:.0f}s")
    log("INFO", "╠" + "═" * 60 + "╣")
    for r in results:
        icon = "✓" if r.get("ok") else "✗"
        log("INFO", f"║  {r.get('opco',''):<10}  {r.get('table_id',''):<30}  {icon}")
    log("INFO", "╚" + "═" * 60 + "╝")


# COMMAND ----------
# DBTITLE 1,Entry point
def main() -> bool:
    orchestrator = PipelineOrchestrator()
    started = datetime.now(timezone.utc)

    dbutils = globals().get("dbutils")
    params = _params_from_widgets(dbutils) if dbutils is not None else None

    if params:
        log("INFO", "Parameters supplied via widgets — skipping run_config.json")
    else:
        log("INFO", "No widget parameters set — reading config/run_config.json")
        params = _params_from_file()

    current_time_str = datetime.now().strftime("%Y%m%d_%H%M%S")
    short_uuid = uuid.uuid4().hex[:6].upper()
    batch_run_id = f"BATCH_{current_time_str}_{short_uuid}_{getattr(PIPELINE_CONFIG, 'environment', 'na')}"

    configs = orchestrator.config_repo.read(table_id=params["table_id"] or None,
                                             schedule_group=params["schedule_group"])
    if not configs:
        log("WARN", "No configs found — nothing to run")
        return True

    distinct_opcos = list(dict.fromkeys(c.opco for c in configs))
    distinct_table_ids = list(dict.fromkeys(c.table_id for c in configs))

    results = []
    for opco in distinct_opcos:
        results.extend(orchestrator.run_opco(
            batch_run_id=batch_run_id,
            opco=opco,
            table_ids=distinct_table_ids,
            start_date=params["start_date"],
            end_date=params["end_date"],
        ))

    print_summary(results, started)
    return all(r.get("ok") for r in results)


if __name__ == "__main__":
    # main()
    pass
