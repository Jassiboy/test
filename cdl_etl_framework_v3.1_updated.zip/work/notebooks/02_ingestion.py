"""
notebooks/02_ingestion.py
===========================
IngestionEngine — stages, DQ-checks, and promotes one (opco, load_mnth)
scope of data into its Delta Lake target table.

Core behavioural contract (per current requirements)
-----------------------------------------------------
* Data is ALWAYS promoted to the target table, whatever the DQ outcome.
  DQ results only change what gets *recorded*, never whether the row is
  loaded. "Load first, flag quality after" — never the other way round.
* Every call to `IngestionEngine.run(...)` returns a well-formed
  (dq_passed, summary) tuple — it never raises. Any unexpected exception is
  caught, logged, and folded into the summary so the caller (04_main_core)
  can keep going with the next month/table instead of the whole batch dying.
* Transient infrastructure failures (lock conflicts, throttling, etc.) around
  the actual Delta write are retried with backoff before being surfaced.

Public entry point:
    IngestionEngine(data_db).run(run_batch_id, cfg, opco, load_mnth, temp_table)
        -> (dq_passed: bool, summary: dict)
"""

from datetime import datetime, timezone
from typing import Optional

from pyspark.sql import DataFrame, SparkSession
from pyspark.sql import functions as F
from delta.tables import DeltaTable

import importlib

# Dynamic import to handle the module name starting with a digit — resolved
# via the standard import machinery (works on Databricks, locally, and in
# CI) rather than a hardcoded absolute workspace path.
_framework_core = importlib.import_module('notebooks.01_framework_core')

TableConfig = _framework_core.TableConfig
log = _framework_core.log
DQEngine = _framework_core.DQEngine

try:
    from utils.retry_handler import with_retry
except Exception:  # pragma: no cover
    def with_retry(*_a, **_kw):
        def _decorator(fn):
            return fn
        return _decorator

# DATA_DB = get_data_db()
DATA_DB = 'f6180854'


class IngestionEngine:
    """
    Handles staging → DQ → promotion for a single table config, one month at
    a time. Instantiate once per pipeline run and re-use across tables.
    """

    def __init__(self, data_db: str = DATA_DB, dq_engine: Optional[DQEngine] = None):
        self.data_db = data_db
        self.dq_engine = dq_engine or DQEngine()

    # ── Public entry point ──────────────────────────────────────────────
    def run(
        self,
        run_batch_id: str,
        cfg: "TableConfig",
        opco: str,
        load_mnth: str,
        temp_table: str,
    ) -> tuple:
        """
        Always loads `load_mnth`'s data into the target table, regardless of
        DQ outcome. Returns (dq_passed, summary) and never raises.
        """
        target = f"{self.data_db}.{cfg.target_table}"
        scope = f"{cfg.watermark_column} = '{load_mnth}'" if cfg.watermark_column else f"1=1"
        source_table = f"{cfg.source_system}.{cfg.source_table[0]}" if cfg.source_table else cfg.source_system

        dq_passed, dq_results = True, []
        rows_written = 0

        try:
            # 1. Measure data quality — this can never block the promotion below.
            try:
                dq_passed, dq_results = self.dq_engine.run(cfg, opco, load_mnth, temp_table, source_table)
            except Exception as dq_exc:
                # Defensive: DQEngine already catches its own errors, but if
                # something still escapes, quality becomes "UNKNOWN" and the
                # load proceeds anyway.
                log("ERROR", f"DQ engine raised unexpectedly (load will still proceed): {dq_exc}",
                    table=cfg.table_id, load_mnth=load_mnth)
                dq_passed, dq_results = False, [{"dq_rule": None, "passed": False, "error": str(dq_exc)}]

            # 2. Promote regardless of DQ outcome — with retry for transient
            #    Delta write conflicts.
            rows_written = self._promote_to_target_with_retry(cfg, target, temp_table, scope)

            summary = {
                "month": load_mnth,
                "dq_status": "PASS" if dq_passed else "FAIL",
                "loaded": True,
                "rows_written": rows_written,
                "dq_results": dq_results,
                "message": "Loaded successfully" if dq_passed else
                           "Loaded successfully, but data quality checks did not pass — see dq_results",
            }
            return dq_passed, summary

        except Exception as exc:
            # A genuine failure to load (e.g. the promote itself failed even
            # after retries). We still return a well-formed summary rather
            # than letting the exception propagate and abort the whole batch.
            log("ERROR", f"Ingestion failed for {cfg.table_id} / {load_mnth}: {exc}", table=cfg.table_id)
            summary = {
                "month": load_mnth,
                "dq_status": "FAIL" if not dq_passed else "UNKNOWN",
                "loaded": False,
                "rows_written": 0,
                "dq_results": dq_results,
                "message": f"EXCEPTION: {exc}",
            }
            return False, summary

    # ── Helpers ──────────────────────────────────────────────────────────
    def reset_stage(self, temp_table: str) -> None:
        self._reset_stage_with_retry(temp_table)

    @with_retry(max_attempts=3, initial_wait=5.0, backoff_multiplier=2.0, max_wait=30.0)
    def _reset_stage_with_retry(self, temp_table: str) -> None:
        spark = SparkSession.getActiveSession()
        spark.sql(f"TRUNCATE TABLE {temp_table}")
        log("INFO", f"Truncated {temp_table}")

    @with_retry(max_attempts=3, initial_wait=10.0, backoff_multiplier=2.0, max_wait=60.0)
    def _promote_to_target_with_retry(self, cfg: "TableConfig", target: str, temp_table: str, scope: str) -> int:
        return self._promote_to_target(cfg, target, temp_table, scope)

    @staticmethod
    def _promote_to_target(cfg: "TableConfig", target: str, temp_table: str, scope: str) -> int:
        """Atomic overwrite of just this month's partition in target, from stage."""
        spark = SparkSession.getActiveSession()
        stage_df = spark.table(temp_table).where(scope)
        (stage_df.write.format("delta").mode("overwrite")
            .option("replaceWhere", scope)
            .saveAsTable(target))
        ct = stage_df.count()
        log("INFO", f"Promoted {scope} → {target}: {ct} rows", table=cfg.table_id)
        return ct

    @staticmethod
    def add_meta(df: DataFrame, run_id: str, cfg: "TableConfig") -> DataFrame:
        now = datetime.now(timezone.utc).isoformat()
        return (df
            .withColumn("run_id", F.lit(run_id))
            .withColumn("source_system", F.lit(cfg.source_system))
            .withColumn("created_at", F.lit(now).cast("timestamp"))
            .withColumn("updated_at", F.lit(now).cast("timestamp"))
        )


# ─────────────────────────────────────────────────────────────────────────────
# Module-level convenience wrappers (kept for backward compatibility with any
# code that imports free functions rather than the class)
# ─────────────────────────────────────────────────────────────────────────────
_default_engine = None


def _engine() -> IngestionEngine:
    global _default_engine
    if _default_engine is None:
        _default_engine = IngestionEngine()
    return _default_engine


def run_ingestion(run_batch_id: str, cfg: "TableConfig", opco: str, load_mnth: str, temp_table: str) -> tuple:
    return _engine().run(run_batch_id, cfg, opco, load_mnth, temp_table)


def _reset_stage(temp_table: str) -> None:
    _engine().reset_stage(temp_table)
