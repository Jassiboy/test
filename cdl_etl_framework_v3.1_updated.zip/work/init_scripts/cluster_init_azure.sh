#!/bin/bash
# =============================================================================
# init_scripts/cluster_init_azure.sh
# Databricks cluster-scoped init script.
# Add to cluster config: Advanced → Init Scripts → ADLS path to this file.
# =============================================================================
set -euo pipefail
exec > >(tee -a /tmp/cdl_init_azure.log) 2>&1

echo "=== CDL Azure Init === $(date -u)"

# Python libraries
/databricks/python3/bin/pip install -q --upgrade pip
/databricks/python3/bin/pip install -q \
    "delta-spark==3.1.0" \
    "pyarrow==14.0.2" \
    "pandas==2.1.4" \
    "azure-storage-blob==12.19.0" \
    "azure-identity==1.15.0" \
    "azure-keyvault-secrets==4.7.0" \
    "requests==2.31.0"

# Spark tuning
cat >> /databricks/spark/conf/spark-defaults.conf <<'EOF'
spark.sql.shuffle.partitions                        200
spark.sql.adaptive.enabled                          true
spark.sql.adaptive.coalescePartitions.enabled       true
spark.sql.adaptive.skewJoin.enabled                 true
spark.databricks.delta.optimizeWrite.enabled        true
spark.databricks.delta.autoCompact.enabled          true
spark.databricks.delta.merge.repartitionBeforeWrite.enabled true
EOF

# Framework code
FRAMEWORK_SRC="/dbfs/cdl_etl_framework"
FRAMEWORK_DST="/opt/cdl_etl_framework"
[ -d "$FRAMEWORK_SRC" ] && cp -r "$FRAMEWORK_SRC" "$FRAMEWORK_DST"
echo "export PYTHONPATH=${FRAMEWORK_DST}:\${PYTHONPATH:-}" >> /etc/profile.d/cdl.sh

# Environment
cat >> /etc/environment <<EOF
CDL_ENV=azure
CDL_LOG_LEVEL=INFO
CDL_SHUFFLE_PARTITIONS=200
CDL_DQ_THRESHOLD=95.0
CDL_FRAMEWORK_PATH=${FRAMEWORK_DST}
EOF

echo "=== CDL Azure Init DONE === $(date -u)"
