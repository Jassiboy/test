#!/bin/bash
# =============================================================================
# init_scripts/cluster_init_gcp.sh
# Dataproc initialization action.
# --initialization-actions gs://YOUR_BUCKET/init_scripts/cluster_init_gcp.sh
# =============================================================================
set -euo pipefail
exec > >(tee -a /tmp/cdl_init_gcp.log) 2>&1

echo "=== CDL GCP Init === $(date -u)"
ROLE="$(/usr/share/google/get_metadata_value attributes/dataproc-role)"

pip3 install -q --upgrade pip
pip3 install -q \
    "delta-spark==3.1.0" \
    "google-cloud-bigquery==3.14.1" \
    "google-cloud-storage==2.14.0" \
    "google-cloud-secret-manager==2.18.2" \
    "pyarrow==14.0.2" \
    "pandas==2.1.4" \
    "requests==2.31.0"

# BQ Spark connector
BQ_VER="0.37.0"
BQ_JAR="spark-bigquery-with-dependencies_2.12-${BQ_VER}.jar"
[ ! -f "/usr/lib/spark/jars/${BQ_JAR}" ] && \
    gsutil cp "gs://spark-lib/bigquery/${BQ_JAR}" "/usr/lib/spark/jars/${BQ_JAR}" 2>/dev/null || true

# Spark defaults
cat >> /etc/spark/conf/spark-defaults.conf <<'EOF'
spark.sql.shuffle.partitions                        200
spark.sql.adaptive.enabled                          true
spark.sql.adaptive.coalescePartitions.enabled       true
spark.sql.extensions                                io.delta.sql.DeltaSparkSessionExtension
spark.sql.catalog.spark_catalog                     org.apache.spark.sql.delta.catalog.DeltaCatalog
spark.hadoop.fs.gs.impl                             com.google.cloud.hadoop.fs.gcs.GoogleHadoopFileSystem
EOF

# Framework code (master only syncs from GCS)
GCS_BUCKET="$(/usr/share/google/get_metadata_value attributes/cdl-gcs-bucket 2>/dev/null || echo 'cdl-data-prod')"
FRAMEWORK_DST="/opt/cdl_etl_framework"
mkdir -p "$FRAMEWORK_DST"
gsutil -m -q rsync -r "gs://${GCS_BUCKET}/framework/cdl_etl_framework/" "$FRAMEWORK_DST" 2>/dev/null || true
echo "export PYTHONPATH=${FRAMEWORK_DST}:\${PYTHONPATH:-}" >> /etc/profile.d/cdl.sh

GCP_PROJECT="$(/usr/share/google/get_metadata_value project/project-id 2>/dev/null || echo '')"
cat >> /etc/environment <<EOF
CDL_ENV=gcp
CDL_LOG_LEVEL=INFO
CDL_SHUFFLE_PARTITIONS=200
GCP_PROJECT_ID=${GCP_PROJECT}
GCS_BUCKET=${GCS_BUCKET}
CDL_FRAMEWORK_PATH=${FRAMEWORK_DST}
EOF

echo "=== CDL GCP Init DONE === $(date -u)"
