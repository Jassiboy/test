-- =============================================================================
-- CDL ETL Framework — Control Tables  (Azure Databricks + Delta Lake)
-- Schema : cdl_metadata
-- ONLY 2 TABLES:
--   1. cdl_table_config   — pipeline topology, DQ rules, retry, alerts,
--                           watermark, dependency gate — everything in one row
--   2. cdl_table_run_log  — full execution audit log, ONE ROW PER
--                           (run_batch_id, table_id, load_mnth_start,
--                           attempt_number) — i.e. per table, per row
--                           (month) attempt, so every retry of every table
--                           is independently visible.
--
-- v3.1 CHANGES (this revision):
--   * cdl_table_config gained: load_process, schedule_group, source_table
--     (JSON list — a table can now read from more than one source table),
--     incremental_cutoff_day, hard_dq_gate. dq_threshold_pct / merge_keys /
--     source_filter / last_successful_run were dropped — they belonged to a
--     MERGE/CDC ingestion design that is no longer used (see
--     notebooks/02_ingestion_clone.py, now deprecated).
--   * cdl_table_run_log was rebuilt around (run_batch_id, table_id,
--     load_mnth_start, attempt_number) instead of (run_id, dag_run_date) —
--     this framework runs month-scoped batches, not single-day DAG runs, and
--     the log needs to key on the same grain the code actually loads at.
--   * dq_result/execution_summary replace dq_results/dq_passed — DQ outcome
--     is now recorded per-month inside a JSON execution_summary, because a
--     single attempt can span multiple months with different DQ outcomes.
-- =============================================================================

CREATE SCHEMA IF NOT EXISTS cdl_metadata;

-- ---------------------------------------------------------------------------
-- 1. cdl_table_config
--    One row per source→target table mapping.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS cdl_metadata.cdl_table_config (

    -- ── Identity ─────────────────────────────────────────────────────────
    table_id                STRING    NOT NULL
        COMMENT 'Unique logical ID e.g. ground_account_daily_to_facility_daily',
    schedule_group          STRING
        COMMENT 'Optional named group used to trigger a batch of tables together instead of listing table_ids explicitly',

    -- ── Source ───────────────────────────────────────────────────────────
    source_system           STRING    NOT NULL
        COMMENT 'Source system name: ACCOUNT_DB | DELTA_LAKE | ORACLE | EDW | SQL_SERVER',
    source_table            STRING    NOT NULL
        COMMENT 'JSON array of source table names this load reads, e.g. ["schema.table_a"]. A plain comma-separated string is also accepted.',

    -- ── Target ───────────────────────────────────────────────────────────
    target_system           STRING    NOT NULL
        COMMENT 'Target platform: DELTA_LAKE | BIGQUERY',
    target_table            STRING    NOT NULL
        COMMENT 'Physical target table name (unqualified — schema comes from the environment config)',
    target_dataset_layer    STRING    NOT NULL
        COMMENT 'Pipeline layer: ACCOUNT | FACILITY | COUNTRY | GLOBAL',
    opco                    STRING    NOT NULL
        COMMENT 'Operating company: GROUND | FREIGHT | INTERNATIONAL',

    -- ── Transformation ───────────────────────────────────────────────────
    load_process             STRING    NOT NULL
        COMMENT 'Name of the function to call in transformations/{opco}/{layer}.py, e.g. transform_monthly',

    -- ── Ingestion mode ───────────────────────────────────────────────────
    ingestion_mode          STRING    NOT NULL
        COMMENT 'FULL | INCR | CDC',
    load_frequency          STRING    NOT NULL
        COMMENT 'DAILY | MONTHLY | BOTH',
    incremental_cutoff_day  STRING    NOT NULL
        COMMENT 'Day-of-month cutoff (1-28) — while today.day <= this value, incremental runs also reprocess the previous month to catch late-arriving data',
    watermark_column        STRING
        COMMENT 'Column used to scope a load to one load_mnth, e.g. ratemnth',
    last_watermark_value    TIMESTAMP
        COMMENT 'Reserved for future true incremental (row-level watermark) support',
    partition_col           STRING
        COMMENT 'Target partition column e.g. load_mnth',

    -- ── Data Quality ─────────────────────────────────────────────────────
    -- JSON array of rule objects:
    -- [{ "dq_rule": "dq_row_count", "error_threshold_pct": 1.0 }, ...]
    -- `dq_rule` is a function name looked up in dq/dq_rules.py.
    -- IMPORTANT: A DQ failure NEVER stops the load — data for the month is
    -- always promoted to the target table. The result is only ever recorded
    -- (execution_summary / dq_result in the run log), never enforced, unless
    -- hard_dq_gate below is explicitly turned on for a downstream table.
    data_quality_rules      STRING
        COMMENT 'JSON array of inline DQ rule objects — see column comment for schema',
    dq_status               BOOLEAN
        COMMENT 'Master on/off switch for running DQ checks on this table at all. Defaults to TRUE.',

    -- ── Dependency gate (soft by default — see hard_dq_gate) ────────────
    depends_on_table_ids    STRING
        COMMENT 'Comma-separated or JSON list of upstream table_ids. By default this is informational only (logged as a WARNING if upstream failed DQ) and never blocks this table from running.',
    hard_dq_gate            BOOLEAN
        COMMENT 'Opt-in only. If TRUE, this table is skipped when any depends_on_table_ids failed DQ in this run_batch_id. Defaults to FALSE — i.e. never halt downstream.',

    -- ── Retry policy ─────────────────────────────────────────────────────
    retry_max_attempts       INT
        COMMENT 'Total attempts including first try. Default 3.',
    retry_initial_wait_sec   DOUBLE
        COMMENT 'Seconds to wait before first retry. Default 15.',
    retry_backoff_multiplier DOUBLE
        COMMENT 'Exponential multiplier per attempt. Default 2.0.',
    retry_max_wait_sec       DOUBLE
        COMMENT 'Upper bound on wait between retries, in seconds. Default 180.',

    -- ── Alerting ─────────────────────────────────────────────────────────
    -- [{ "channel": "EMAIL|TEAMS|SLACK", "recipients": "...", "on_status": ["FAILED"] }]
    alert_config            STRING
        COMMENT 'JSON array of alert channel objects — see column comment for schema',

    -- ── Lifecycle ────────────────────────────────────────────────────────
    is_active               BOOLEAN   NOT NULL
        COMMENT 'Toggle to enable or disable this pipeline mapping',
    created_at              TIMESTAMP NOT NULL
        COMMENT 'Row creation timestamp',
    updated_at              TIMESTAMP NOT NULL
        COMMENT 'Last modification timestamp',
    created_by              STRING
        COMMENT 'Who created this row',

    CONSTRAINT pk_cdl_table_config PRIMARY KEY (table_id)
)
USING DELTA
TBLPROPERTIES (
    'delta.enableChangeDataFeed'              = 'true',
    'delta.autoOptimize.optimizeWrite'        = 'true',
    'delta.autoOptimize.autoCompact'          = 'true'
)
COMMENT 'CDL master config table — all pipeline behaviour driven from here';


-- ---------------------------------------------------------------------------
-- 2. cdl_table_run_log
--    Full execution audit. ONE ROW PER (run_batch_id, table_id,
--    load_mnth_start, attempt_number) — every retry attempt of every table,
--    for every load-month window it covers, is independently recorded and
--    updated in place (RUNNING -> SUCCESS/PARTIAL_SUCCESS/FAILED/RETRYING).
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS cdl_metadata.cdl_table_run_log (

    -- ── Identity / grain ─────────────────────────────────────────────────
    run_batch_id             STRING    NOT NULL
        COMMENT 'Identifies one orchestrator invocation, e.g. BATCH_20260721_143200_A1B2C3_prod',
    table_id                 STRING    NOT NULL
        COMMENT 'FK -> cdl_table_config.table_id',
    load_mnth_start          STRING    NOT NULL
        COMMENT 'First YYYYMM month in this attempt''s window — part of the grain key',
    attempt_number            INT       NOT NULL
        COMMENT 'Retry attempt sequence for this (run_batch_id, table_id, load_mnth_start) — starts at 1',

    -- ── Context ───────────────────────────────────────────────────────────
    log_time                 TIMESTAMP
        COMMENT 'Timestamp of the most recent write to this row',
    opco                     STRING    NOT NULL,
    dataset_layer            STRING    NOT NULL
        COMMENT 'ACCOUNT | FACILITY | COUNTRY | GLOBAL',
    table_name               STRING    NOT NULL
        COMMENT 'Physical target table being processed',
    load_process             STRING
        COMMENT 'Transformation function used for this run',
    load_mnth_end            STRING
        COMMENT 'Last YYYYMM month in this attempt''s window',

    -- ── Execution state ──────────────────────────────────────────────────
    status                   STRING    NOT NULL
        COMMENT 'RUNNING | SUCCESS | PARTIAL_SUCCESS | SUCCESS_WITH_DQ_FAILURES | RETRYING | FAILED',
    message                  STRING
        COMMENT 'Human-readable outcome / truncated error message',

    -- ── Row-level metrics ────────────────────────────────────────────────
    rows_read                BIGINT    COMMENT 'Records scanned from source (best-effort)',
    rows_written             BIGINT    COMMENT 'Total records committed to target across all months in this attempt',

    -- ── Watermark (reserved) ─────────────────────────────────────────────
    watermark_start          TIMESTAMP,
    watermark_end            TIMESTAMP,

    -- ── Timing ───────────────────────────────────────────────────────────
    started_at               TIMESTAMP COMMENT 'Wall-clock execution start time for this attempt',
    completed_at             TIMESTAMP COMMENT 'Wall-clock execution end time for this attempt',
    duration_seconds         INT       COMMENT 'Elapsed seconds (completed_at - started_at)',

    -- ── Data Quality — data is ALWAYS loaded; this only records the verdict
    dq_result                STRING
        COMMENT 'PASS | PARTIAL | FAIL | N/A | SKIPPED — rolled up across every month in this attempt''s window',
    execution_summary        STRING
        COMMENT 'JSON: {"month_details": [{"month","dq_status","loaded","rows_written","dq_results","message"}, ...]} — one entry per load_mnth in this attempt, so you can see exactly which months loaded cleanly and which loaded with poor DQ',

    -- ── Audit ────────────────────────────────────────────────────────────
    created_at               TIMESTAMP
        COMMENT 'Row creation timestamp (first attempt=1 write)',
    updated_at               TIMESTAMP
        COMMENT 'Last row update timestamp',

    CONSTRAINT pk_cdl_run_log PRIMARY KEY (run_batch_id, table_id, load_mnth_start, attempt_number)
)
USING DELTA
TBLPROPERTIES (
    'delta.enableChangeDataFeed'       = 'true',
    'delta.autoOptimize.optimizeWrite' = 'true',
    'delta.logRetentionDuration'       = 'interval 90 days'
)
COMMENT 'Full execution audit log — one row per table_id, per load-month window, per retry attempt';


-- ---------------------------------------------------------------------------
-- Post-creation optimisation hints (run after initial data load)
-- ---------------------------------------------------------------------------
-- OPTIMIZE cdl_metadata.cdl_table_config  ZORDER BY (opco, target_dataset_layer);
-- OPTIMIZE cdl_metadata.cdl_table_run_log ZORDER BY (table_id, run_batch_id);
