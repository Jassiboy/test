-- =============================================================================
-- CDL ETL Framework — Pipeline Data Tables  (Azure Databricks + Delta Lake)
-- Schema : cdl_data
-- Layers : Account → Facility → Country → Global
-- Each   : {layer}_daily  +  {layer}_monthly
-- =============================================================================

CREATE SCHEMA IF NOT EXISTS cdl_data;

-- ===========================================================================
-- ACCOUNT LAYER  (Bronze)
-- ===========================================================================
CREATE TABLE IF NOT EXISTS cdl_data.account_daily (
    account_id          STRING    NOT NULL,
    opco                STRING    NOT NULL,
    account_name        STRING,
    account_type        STRING,
    account_status      STRING    COMMENT 'ACTIVE | INACTIVE | SUSPENDED',
    account_category    STRING,
    region_code         STRING,
    country_code        STRING,
    currency_code       STRING,
    credit_limit        DOUBLE,
    balance             DOUBLE,
    transaction_count   BIGINT,
    revenue             DOUBLE,
    cost                DOUBLE,
    effective_date      DATE      NOT NULL,
    last_modified_ts    TIMESTAMP,
    load_date           DATE      NOT NULL,
    source_system       STRING,
    run_id              STRING,
    dq_passed           BOOLEAN,
    created_at          TIMESTAMP NOT NULL,
    updated_at          TIMESTAMP NOT NULL,
    CONSTRAINT pk_account_daily PRIMARY KEY (account_id, opco, effective_date)
)
USING DELTA
PARTITIONED BY (load_date, opco)
TBLPROPERTIES ('delta.enableChangeDataFeed'='true','delta.autoOptimize.optimizeWrite'='true')
COMMENT 'Account layer — daily grain';

CREATE TABLE IF NOT EXISTS cdl_data.account_monthly (
    account_id          STRING    NOT NULL,
    opco                STRING    NOT NULL,
    account_name        STRING,
    account_type        STRING,
    account_status      STRING,
    account_category    STRING,
    region_code         STRING,
    country_code        STRING,
    currency_code       STRING,
    month_year          STRING    NOT NULL  COMMENT 'Format: YYYY-MM',
    avg_daily_balance   DOUBLE,
    total_revenue       DOUBLE,
    total_cost          DOUBLE,
    transaction_count   BIGINT,
    active_days         INT,
    load_date           DATE      NOT NULL,
    source_system       STRING,
    run_id              STRING,
    dq_passed           BOOLEAN,
    created_at          TIMESTAMP NOT NULL,
    updated_at          TIMESTAMP NOT NULL,
    CONSTRAINT pk_account_monthly PRIMARY KEY (account_id, opco, month_year)
)
USING DELTA
PARTITIONED BY (load_date, opco)
TBLPROPERTIES ('delta.enableChangeDataFeed'='true','delta.autoOptimize.optimizeWrite'='true')
COMMENT 'Account layer — monthly grain';

-- ===========================================================================
-- FACILITY LAYER  (Silver)
-- ===========================================================================
CREATE TABLE IF NOT EXISTS cdl_data.facility_daily (
    facility_id             STRING    NOT NULL,
    account_id              STRING    NOT NULL,
    opco                    STRING    NOT NULL,
    facility_name           STRING,
    facility_type           STRING    COMMENT 'WAREHOUSE | OFFICE | DEPOT | HUB',
    facility_status         STRING    COMMENT 'ACTIVE | INACTIVE | UNDER_MAINTENANCE',
    facility_category       STRING,
    country_code            STRING,
    region_code             STRING,
    city                    STRING,
    postal_code             STRING,
    account_name            STRING,
    account_type            STRING,
    account_status          STRING,
    shipment_count          BIGINT,
    volume_kg               DOUBLE,
    revenue                 DOUBLE,
    cost                    DOUBLE,
    on_time_delivery_pct    DOUBLE,
    utilisation_pct         DOUBLE,
    effective_date          DATE      NOT NULL,
    last_modified_ts        TIMESTAMP,
    load_date               DATE      NOT NULL,
    source_system           STRING,
    run_id                  STRING,
    dq_passed               BOOLEAN,
    created_at              TIMESTAMP NOT NULL,
    updated_at              TIMESTAMP NOT NULL,
    CONSTRAINT pk_facility_daily PRIMARY KEY (facility_id, account_id, opco, effective_date)
)
USING DELTA
PARTITIONED BY (load_date, opco)
TBLPROPERTIES ('delta.enableChangeDataFeed'='true','delta.autoOptimize.optimizeWrite'='true')
COMMENT 'Facility layer — daily grain';

CREATE TABLE IF NOT EXISTS cdl_data.facility_monthly (
    facility_id             STRING    NOT NULL,
    account_id              STRING    NOT NULL,
    opco                    STRING    NOT NULL,
    facility_name           STRING,
    facility_type           STRING,
    facility_status         STRING,
    country_code            STRING,
    region_code             STRING,
    month_year              STRING    NOT NULL,
    total_shipments         BIGINT,
    total_volume_kg         DOUBLE,
    total_revenue           DOUBLE,
    total_cost              DOUBLE,
    avg_on_time_pct         DOUBLE,
    avg_utilisation_pct     DOUBLE,
    active_days             INT,
    load_date               DATE      NOT NULL,
    source_system           STRING,
    run_id                  STRING,
    dq_passed               BOOLEAN,
    created_at              TIMESTAMP NOT NULL,
    updated_at              TIMESTAMP NOT NULL,
    CONSTRAINT pk_facility_monthly PRIMARY KEY (facility_id, account_id, opco, month_year)
)
USING DELTA
PARTITIONED BY (load_date, opco)
TBLPROPERTIES ('delta.enableChangeDataFeed'='true','delta.autoOptimize.optimizeWrite'='true')
COMMENT 'Facility layer — monthly grain';

-- ===========================================================================
-- COUNTRY LAYER  (Silver+)
-- ===========================================================================
CREATE TABLE IF NOT EXISTS cdl_data.country_daily (
    country_code            STRING    NOT NULL,
    opco                    STRING    NOT NULL,
    country_name            STRING,
    region_code             STRING,
    region_name             STRING,
    currency_code           STRING,
    total_facilities        INT,
    total_accounts          INT,
    shipment_count          BIGINT,
    volume_kg               DOUBLE,
    revenue                 DOUBLE,
    cost                    DOUBLE,
    gross_margin            DOUBLE,
    avg_on_time_pct         DOUBLE,
    avg_utilisation_pct     DOUBLE,
    effective_date          DATE      NOT NULL,
    load_date               DATE      NOT NULL,
    source_system           STRING,
    run_id                  STRING,
    dq_passed               BOOLEAN,
    created_at              TIMESTAMP NOT NULL,
    updated_at              TIMESTAMP NOT NULL,
    CONSTRAINT pk_country_daily PRIMARY KEY (country_code, opco, effective_date)
)
USING DELTA
PARTITIONED BY (load_date, opco)
TBLPROPERTIES ('delta.enableChangeDataFeed'='true','delta.autoOptimize.optimizeWrite'='true')
COMMENT 'Country layer — daily grain';

CREATE TABLE IF NOT EXISTS cdl_data.country_monthly (
    country_code            STRING    NOT NULL,
    opco                    STRING    NOT NULL,
    country_name            STRING,
    region_code             STRING,
    region_name             STRING,
    currency_code           STRING,
    month_year              STRING    NOT NULL,
    total_facilities        INT,
    total_accounts          INT,
    total_shipments         BIGINT,
    total_volume_kg         DOUBLE,
    total_revenue           DOUBLE,
    total_cost              DOUBLE,
    gross_margin            DOUBLE,
    avg_on_time_pct         DOUBLE,
    avg_utilisation_pct     DOUBLE,
    yoy_revenue_growth      DOUBLE,
    load_date               DATE      NOT NULL,
    source_system           STRING,
    run_id                  STRING,
    dq_passed               BOOLEAN,
    created_at              TIMESTAMP NOT NULL,
    updated_at              TIMESTAMP NOT NULL,
    CONSTRAINT pk_country_monthly PRIMARY KEY (country_code, opco, month_year)
)
USING DELTA
PARTITIONED BY (load_date, opco)
TBLPROPERTIES ('delta.enableChangeDataFeed'='true','delta.autoOptimize.optimizeWrite'='true')
COMMENT 'Country layer — monthly grain';

-- ===========================================================================
-- GLOBAL LAYER  (Gold)
-- ===========================================================================
CREATE TABLE IF NOT EXISTS cdl_data.global_daily (
    opco                    STRING    NOT NULL,
    effective_date          DATE      NOT NULL,
    region_code             STRING    COMMENT 'NULL = global total; set = regional breakdown',
    total_countries         INT,
    total_facilities        INT,
    total_accounts          INT,
    shipment_count          BIGINT,
    volume_kg               DOUBLE,
    revenue                 DOUBLE,
    cost                    DOUBLE,
    gross_margin            DOUBLE,
    gross_margin_pct        DOUBLE,
    avg_on_time_pct         DOUBLE,
    avg_utilisation_pct     DOUBLE,
    prev_day_revenue        DOUBLE,
    dod_revenue_change      DOUBLE,
    load_date               DATE      NOT NULL,
    source_system           STRING,
    run_id                  STRING,
    dq_passed               BOOLEAN,
    created_at              TIMESTAMP NOT NULL,
    updated_at              TIMESTAMP NOT NULL,
    CONSTRAINT pk_global_daily PRIMARY KEY (opco, effective_date, region_code)
)
USING DELTA
PARTITIONED BY (load_date, opco)
TBLPROPERTIES ('delta.enableChangeDataFeed'='true','delta.autoOptimize.optimizeWrite'='true')
COMMENT 'Global layer — daily grain';

CREATE TABLE IF NOT EXISTS cdl_data.global_monthly (
    opco                    STRING    NOT NULL,
    month_year              STRING    NOT NULL,
    region_code             STRING,
    total_countries         INT,
    total_facilities        INT,
    total_accounts          INT,
    total_shipments         BIGINT,
    total_volume_kg         DOUBLE,
    total_revenue           DOUBLE,
    total_cost              DOUBLE,
    gross_margin            DOUBLE,
    gross_margin_pct        DOUBLE,
    avg_on_time_pct         DOUBLE,
    avg_utilisation_pct     DOUBLE,
    yoy_revenue_growth      DOUBLE,
    mom_revenue_growth      DOUBLE,
    load_date               DATE      NOT NULL,
    source_system           STRING,
    run_id                  STRING,
    dq_passed               BOOLEAN,
    created_at              TIMESTAMP NOT NULL,
    updated_at              TIMESTAMP NOT NULL,
    CONSTRAINT pk_global_monthly PRIMARY KEY (opco, month_year, region_code)
)
USING DELTA
PARTITIONED BY (load_date, opco)
TBLPROPERTIES ('delta.enableChangeDataFeed'='true','delta.autoOptimize.optimizeWrite'='true')
COMMENT 'Global layer — monthly grain';
