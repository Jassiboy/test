-- =============================================================================
-- CDL ETL Framework — Control Tables  (GCP BigQuery)
-- Dataset : cdl_metadata
-- ONLY 2 TABLES — same schema/grain as Azure (ddl/azure/01_control_tables.sql),
-- BigQuery syntax. See that file's header comment for the full v3.1 changelog
-- explaining why each column exists.
-- =============================================================================

CREATE TABLE IF NOT EXISTS `cdl_metadata.cdl_table_config` (
    -- Identity
    table_id                 STRING    OPTIONS(description='Unique logical mapping ID'),
    schedule_group            STRING   OPTIONS(description='Optional named group used to trigger a batch of tables together'),

    -- Source
    source_system            STRING    OPTIONS(description='ACCOUNT_DB | DELTA_LAKE | ORACLE | EDW | SQL_SERVER'),
    source_table             STRING    OPTIONS(description='JSON array of source table names, e.g. ["schema.table_a"]'),

    -- Target
    target_system             STRING   OPTIONS(description='DELTA_LAKE | BIGQUERY'),
    target_table               STRING  OPTIONS(description='Physical target table name'),
    target_dataset_layer      STRING   OPTIONS(description='ACCOUNT | FACILITY | COUNTRY | GLOBAL'),
    opco                       STRING  OPTIONS(description='GROUND | FREIGHT | INTERNATIONAL'),

    -- Transformation
    load_process               STRING  OPTIONS(description='Function name to call in transformations/{opco}/{layer}.py'),

    -- Ingestion
    ingestion_mode              STRING OPTIONS(description='FULL | INCR | CDC'),
    load_frequency               STRING OPTIONS(description='DAILY | MONTHLY | BOTH'),
    incremental_cutoff_day        STRING OPTIONS(description='Day-of-month cutoff for also reprocessing the previous month'),
    watermark_column              STRING OPTIONS(description='Column used to scope a load to one load_mnth'),
    last_watermark_value          TIMESTAMP OPTIONS(description='Reserved for future row-level watermark support'),
    partition_col                  STRING,

    -- DQ — informational only, never blocks a load. See load_process comment.
    data_quality_rules            STRING OPTIONS(description='JSON array of DQ rule objects: [{"dq_rule","error_threshold_pct"}]'),
    dq_status                      BOOL  OPTIONS(description='Master on/off switch for DQ checks on this table. Defaults TRUE.'),

    -- Dependency gate — soft by default
    depends_on_table_ids           STRING OPTIONS(description='Comma-separated/JSON upstream table_ids — informational unless hard_dq_gate=TRUE'),
    hard_dq_gate                    BOOL  OPTIONS(description='Opt-in only. TRUE = skip this table if upstream failed DQ. Default FALSE.'),

    -- Retry
    retry_max_attempts              INT64   OPTIONS(description='Total attempts including first. Default 3.'),
    retry_initial_wait_sec           FLOAT64 OPTIONS(description='Seconds before first retry. Default 15.'),
    retry_backoff_multiplier          FLOAT64 OPTIONS(description='Exponential multiplier. Default 2.0.'),
    retry_max_wait_sec                 FLOAT64 OPTIONS(description='Max wait cap in seconds. Default 180.'),

    -- Alerts
    alert_config                        STRING OPTIONS(description='JSON array of alert channel objects'),

    -- Lifecycle
    is_active                            BOOL,
    created_at                            TIMESTAMP,
    updated_at                             TIMESTAMP,
    created_by                              STRING
)
CLUSTER BY opco, target_dataset_layer
OPTIONS(description='CDL master config — all pipeline behaviour in one table');


CREATE TABLE IF NOT EXISTS `cdl_metadata.cdl_table_run_log` (
    -- Grain: one row per (run_batch_id, table_id, load_mnth_start, attempt_number)
    run_batch_id         STRING    OPTIONS(description='Identifies one orchestrator invocation'),
    table_id             STRING    OPTIONS(description='FK -> cdl_table_config.table_id'),
    load_mnth_start      STRING    OPTIONS(description='First YYYYMM month in this attempt window — part of grain key'),
    attempt_number       INT64     OPTIONS(description='Retry attempt sequence for this (run_batch_id, table_id, load_mnth_start)'),

    log_time             TIMESTAMP,
    opco                 STRING,
    dataset_layer        STRING    OPTIONS(description='ACCOUNT | FACILITY | COUNTRY | GLOBAL'),
    table_name           STRING,
    load_process         STRING,
    load_mnth_end        STRING,

    status                STRING   OPTIONS(description='RUNNING | SUCCESS | PARTIAL_SUCCESS | SUCCESS_WITH_DQ_FAILURES | RETRYING | FAILED'),
    message               STRING,

    rows_read             INT64,
    rows_written          INT64,

    watermark_start       TIMESTAMP,
    watermark_end         TIMESTAMP,

    started_at            TIMESTAMP,
    completed_at          TIMESTAMP,
    duration_seconds      INT64,

    -- Data is ALWAYS loaded; these two columns only record the DQ verdict.
    dq_result             STRING   OPTIONS(description='PASS | PARTIAL | FAIL | N/A | SKIPPED, rolled up across the attempt''s months'),
    execution_summary     STRING   OPTIONS(description='JSON: {"month_details":[{"month","dq_status","loaded","rows_written","dq_results","message"}]}'),

    created_at            TIMESTAMP,
    updated_at            TIMESTAMP
)
CLUSTER BY table_id, run_batch_id
OPTIONS(description='Full execution audit log — one row per table_id, per load-month window, per retry attempt');
