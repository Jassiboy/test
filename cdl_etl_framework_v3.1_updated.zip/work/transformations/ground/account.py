"""
transformations/ground/account.py
===================================
ACCOUNT layer transformations for OPCO=GROUND.

This was an empty placeholder in the previous version of the framework —
ACCOUNT is the first layer in LAYER_ORDER, so every other layer's tests and
seed config implicitly depend on a working module existing here.

Contract expected by TransformationLoader (notebooks/03_transformation.py):

    fn(spark, source_table: list, load_mnth: str) -> DataFrame

`cfg.load_process` (from cdl_table_config) names which function to call —
by convention "transform_daily" or "transform_monthly". Both are provided
here; replace the SQL below with the real account-level business logic.
"""

from pyspark.sql import DataFrame, SparkSession


def _read_source(spark: SparkSession, source_table: list, load_mnth: str) -> DataFrame:
    """
    Shared helper: reads and scopes the first configured source table to a
    single load_mnth. If your account extract spans multiple source tables,
    union/join them here.
    """
    if not source_table:
        raise ValueError("cfg.source_table is empty — at least one source table is required")

    src = source_table[0]
    return spark.table(src).where(f"ratemnth = '{load_mnth}'")


def transform_monthly(spark: SparkSession, source_table: list, load_mnth: str) -> DataFrame:
    """
    Monthly ACCOUNT-level aggregation.

    TODO: replace this pass-through with the real account-level rollup
    (e.g. GROUP BY account/segment dimensions, SUM of billing metrics) —
    this scaffold only guarantees the pipeline has something runnable to
    call while that business logic is ported in.
    """
    df = _read_source(spark, source_table, load_mnth)
    return df


def transform_daily(spark: SparkSession, source_table: list, load_mnth: str) -> DataFrame:
    """
    Daily ACCOUNT-level pass-through/aggregation.
    TODO: replace with real daily account-level business logic.
    """
    df = _read_source(spark, source_table, load_mnth)
    return df
