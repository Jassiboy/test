# CDL ETL Framework — v3.1 Change Log

This revision focused on three things you asked for, in order:
1. **Never halt on poor data quality** — every layer always loads its data.
2. **Never halt the next layer** because of an upstream DQ failure.
3. **Log table keyed per table_id, per row (month) attempt** — plus general
   fault tolerance, retries, and a full class-based (OOP) rewrite.

Along the way I found and fixed a number of real bugs that would have
stopped the pipeline from running at all. Everything below was verified:
all `.py` files compile, and a 31-test suite (`tests/test_framework.py`)
passes against a real local Spark session (not just mocks).

---

## 1. Bugs fixed (the pipeline could not previously run)

| File | Bug | Fix |
|---|---|---|
| `notebooks/04_main_core.py` | Missing imports: `time`, `traceback`, `collections.defaultdict` | Added |
| `notebooks/04_main_core.py` | `resolve_groups` referenced undefined `table_id` instead of `table_ids` | Fixed |
| `notebooks/04_main_core.py` | `run_layer`/`run_opco` called each other with mismatched signatures (`run_date`, `skip_gate` params that didn't exist) | Rewritten with one consistent signature throughout |
| `notebooks/04_main_core.py` | `make_run_id`, `log_run` called but never defined | Replaced with `RunLogger` class methods |
| `notebooks/02_ingestion.py` | `dq_passed` referenced in the `except` block **before** being assigned — a real failure would crash with `NameError` instead of logging the actual error | Initialized before the try block; `IngestionEngine.run()` now never raises |
| `notebooks/02_ingestion.py` | Imported `01_framework_core.py` via a **hardcoded absolute Databricks workspace path** (`/Workspace/Users/shubham.jaiswal@.../...`) — would break for any other user/environment | Replaced with a portable `importlib.import_module(...)` call, consistent with the other notebooks |
| `notebooks/01_framework_core.py` | `run_dq_on_stage` hardcoded `source_table = 'f6180854.cdl_testing_table_1_stage'`, silently ignoring the real parameter | Removed — uses the actual parameter |
| `notebooks/01_framework_core.py` | `check_dq_gate` referenced `cfg.depends_on`, a field that didn't exist on `TableConfig` | Added `depends_on` (default `[]`) to `TableConfig` |
| `notebooks/02_ingestion_clone.py` | Imported `make_run_id`, `run_dq`, `update_watermark` — none of which exist anywhere in the codebase; would `ImportError` the moment it was imported | Deprecated with a clear message pointing at `IngestionEngine` (see below) |
| `transformations/ground/{country,facility,global}.py` | Ran a live query **and called `display()`** (Databricks-only) at *import time* — meant importing these modules anywhere outside a live notebook (tests, `TransformationLoader`, CI) crashed with `NameError`, and every import re-ran a real query against a hardcoded month | Guarded behind `if __name__ == "__main__":` |
| `transformations/ground/account.py` | **Completely empty** — ACCOUNT is the first layer in `LAYER_ORDER`, so nothing downstream had anything to run against | Implemented a working `transform_daily`/`transform_monthly` scaffold (business logic still needs porting in — see TODOs) |
| `transformations/ground/{facility,country,global}.py` | Real transform functions (e.g. `get_fxg_facility_billing_monthly_history_sp`) use bespoke signatures (`v_load_ym`, named table kwargs) that don't match what `TransformationLoader` calls (`fn(spark, source_table, load_mnth)`) | Added a `transform_monthly(spark, source_table, load_mnth)` adapter to each module that unions the non-SP and SP variants |
| `utils/cloud_adapter.py` | Imported `ENV` from `config.env_config`, which only defined `CLOUD_ENV` | Added `ENV` as an alias |
| `ddl/azure/01_control_tables.sql`, `ddl/gcp/01_control_tables.sql` | Schema didn't match what the code actually writes (missing `run_batch_id`, `load_mnth_start/end`, `execution_summary`, `dq_result`, `load_process`, `schedule_group`, etc.) | Rewritten to match current code exactly |
| `config/seed_metadata.py` | Entirely stale — missing `load_process`, `schedule_group`, `source_table` (as a list), `incremental_cutoff_day` | Rewritten against the current schema |
| `tests/test_framework.py` | Every test referenced modules/functions that no longer exist (`04_pipeline_runner`, `run_dq`, `make_run_id`, `transform_daily_range`) — none could ever pass | Rewritten; all 31 tests pass |

---

## 2. Behavioural changes (what you asked for)

### "Load the data even if quality is poor — never halt the next layer"

- `IngestionEngine.run()` (`notebooks/02_ingestion.py`) **always** calls
  `_promote_to_target_with_retry(...)` regardless of the DQ verdict. DQ only
  changes what gets *recorded* (`dq_status: "PASS"/"FAIL"` in the log), never
  whether the month's data is written to the target table.
- `DQEngine` (`notebooks/01_framework_core.py`) **never raises** — a bug in a
  rule, a missing rule module, or a rule referencing a column that doesn't
  exist all degrade to a recorded failure/unknown result rather than
  stopping the ingestion.
- `DQGateChecker` — the old `check_dq_gate` used to be able to block a
  downstream layer. It's now **soft by default**: if an upstream table's DQ
  failed, it logs a `WARNING` and proceeds anyway. A table can opt into the
  old hard-blocking behavior with `cfg.hard_dq_gate = True` in
  `cdl_table_config`, but the default for every row is `False`.
- `PipelineOrchestrator.run_opco()` still runs layers in `LAYER_ORDER`
  (ACCOUNT → FACILITY → COUNTRY → GLOBAL) for readability and natural data
  dependency, but does **not** gate one layer's execution on the previous
  layer's DQ outcome.

### "Log table per table_id, per row (month) attempt"

`cdl_table_run_log` is keyed on
**`(run_batch_id, table_id, load_mnth_start, attempt_number)`**:

- Every retry of every table gets a fresh row (or an updated one — the key
  includes `attempt_number`, so attempt 1 and attempt 2 are both visible,
  side by side, forever).
- `execution_summary` is a JSON blob with one entry per month in that
  attempt's window, so a single attempt spanning e.g. `202605`–`202606` still
  shows you which specific month(s) had poor DQ and which didn't:
  ```json
  {"month_details": [
    {"month": "202605", "dq_status": "PASS", "loaded": true, "rows_written": 1204, ...},
    {"month": "202606", "dq_status": "FAIL", "loaded": true, "rows_written": 980,  ...}
  ]}
  ```
- `dq_result` on the row rolls this up to `PASS` / `PARTIAL` / `FAIL` /
  `N/A` / `SKIPPED` for quick filtering, but note: **`FAIL` here always means
  "loaded, but didn't pass quality checks" — never "not loaded."** A genuine
  load failure shows up as `status = FAILED` with `dq_result = SKIPPED`
  instead.
- Writing this log row is itself wrapped in retry-with-backoff
  (`RunLogger._do_merge`), and if it still fails after retries, that failure
  is caught and only printed — **a broken audit write can never block or
  fail an actual data load.**

### Fault tolerance / retry, made class-based

- **`TableConfigRepository`** — reads `cdl_table_config`, retries transient
  metastore read failures.
- **`DQEngine`** — runs inline DQ rules; never raises (see above).
- **`DQGateChecker`** — soft upstream check (see above).
- **`RunLogger`** — all `cdl_table_run_log` reads/writes; MERGE writes retry
  on transient Delta write conflicts; failures are always non-fatal.
- **`IngestionEngine`** — stage reset + promote-to-target, with retry around
  the Delta write; `.run()` never raises.
- **`TransformationLoader`** — resolves and calls
  `transformations/{opco}/{layer}.py::{load_process}`, with cached imports
  and retry on transient import errors; raises immediately (no retry) on a
  genuine config error like a missing function, since retrying that would
  just waste time.
- **`PipelineOrchestrator`** — the single class driving a run. Its
  `run_table()` method owns the full per-table retry loop: on a retry, it
  **skips months that already staged/loaded successfully in a prior
  attempt** instead of redoing all of them, and every attempt gets its own
  log row.

Retry policy (`retry_max_attempts`, `retry_initial_wait_sec`,
`retry_backoff_multiplier`, `retry_max_wait_sec`) is per-table, read straight
from `cdl_table_config` — a flaky source table can get a more aggressive
retry policy than a stable one, with no code change.

---

## 3. Suggestions implemented

- **`account.py`** now has a working (if placeholder) `transform_daily` /
  `transform_monthly` — the real business SQL still needs to be ported in
  (see the `TODO`s), but the framework has something runnable to call
  immediately, and every other layer's tests/config now have something to
  point at.
- **Adapter functions** (`transform_monthly`) added to `facility.py`,
  `country.py`, `global.py` so their existing bespoke functions (e.g.
  `get_fxg_facility_billing_monthly_history_sp`) are actually callable by
  the framework, without touching the underlying business SQL.
- **`02_ingestion_clone.py`** deprecated rather than silently left broken —
  it now fails loudly and immediately with a message explaining what
  replaced it, instead of failing confusingly later if something ever tried
  to import it.
- **DDL and `seed_metadata.py`** brought back in sync with the code, so a
  fresh environment can actually be stood up end-to-end.
- **`tests/test_framework.py`** rewritten against the current design (31
  tests, all passing), covering: DQ never blocking a load, the soft gate vs.
  `hard_dq_gate`, `IngestionEngine` never raising, layer ordering, retry
  backoff math, and `run_config.json` parsing (including normalizing the
  literal string `"None"` to a real `None`, another small pre-existing bug).

## 4. What I did *not* rewrite

- The actual business SQL inside `facility.py` / `country.py` / `global.py`
  (segment mappings, zone/weight-category logic, etc.) — that's your
  domain logic, not something I should be guessing at. I only made it
  *reachable* by the framework.
- `account.py`'s real business logic — same reasoning; it's a scaffold with
  clear `TODO`s.
- Full Delta Lake MERGE integration testing — the sandbox this was built in
  has no access to Maven Central to fetch the Delta storage JAR, so I could
  only validate the MERGE/retry logic with mocks (all passing) plus real
  imports against a live local Spark session, not a live Delta table. I'd
  recommend running `tests/test_framework.py` once in your actual Databricks
  environment as a final check.
