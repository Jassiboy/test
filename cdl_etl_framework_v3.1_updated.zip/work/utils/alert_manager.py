"""
cdl_etl_framework/utils/alert_manager.py
=========================================
Multi-channel alerting.
Channel/recipient config comes from TableConfig.alert_config JSON
(stored in cdl_table_config.alert_config column) — no separate alert table.

alert_config JSON schema:
[
  { "channel": "EMAIL",  "recipients": "a@co.com,b@co.com", "on_status": ["FAILED","HALTED"] },
  { "channel": "TEAMS",  "recipients": "https://webhook...", "on_status": ["FAILED"] },
  { "channel": "SLACK",  "recipients": "https://webhook...", "on_status": ["FAILED"] }
]
"""

import json
import logging
import os
import smtplib
import urllib.request
from datetime import datetime, timezone
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

logger = logging.getLogger("cdl.alert_manager")


class AlertManager:
    """
    Dispatches alerts based on alert_config embedded in each TableConfig row.
    Fails silently — alerting must never block the pipeline.
    """

    def __init__(self, spark=None):
        self.spark = spark  # reserved for future Spark-based alert logging

    def send(
        self,
        cfg,                  # TableConfig
        run_id: str,
        status: str,
        message: str,
        severity: str = "CRITICAL",
    ):
        """Route alert to all matching channels. Never raises."""
        try:
            if not cfg.alert_config:
                return
            body = self._body(cfg, run_id, status, message, severity)
            for entry in cfg.alert_config:
                on_status = [s.upper() for s in entry.get("on_status", ["FAILED"])]
                if status.upper() not in on_status:
                    continue
                channel    = entry.get("channel", "").upper()
                recipients = entry.get("recipients", "")
                if not recipients:
                    continue
                try:
                    if channel == "EMAIL":
                        self._email(recipients, body, severity, cfg.table_id)
                    elif channel == "TEAMS":
                        self._teams(recipients, body, severity, cfg.table_id)
                    elif channel == "SLACK":
                        self._slack(recipients, body, severity, cfg.table_id)
                    else:
                        logger.warning(f"Unknown alert channel: {channel}")
                except Exception as e:
                    logger.error(f"Alert [{channel}] dispatch error: {e}")
        except Exception as e:
            logger.error(f"AlertManager.send failed (non-blocking): {e}")

    # ── Message body ──────────────────────────────────────────────────────
    @staticmethod
    def _body(cfg, run_id, status, message, severity) -> str:
        now = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
        return (
            f"CDL ETL Alert [{severity}]\n"
            f"{'='*50}\n"
            f"Status    : {status}\n"
            f"Table     : {cfg.table_id}\n"
            f"Layer     : {cfg.target_dataset_layer}\n"
            f"OPCO      : {cfg.opco}\n"
            f"Run ID    : {run_id}\n"
            f"Timestamp : {now}\n"
            f"{'='*50}\n"
            f"{message}\n"
        )

    # ── Email ─────────────────────────────────────────────────────────────
    def _email(self, recipients: str, body: str, severity: str, table_id: str):
        host      = os.getenv("SMTP_HOST",     "smtp.office365.com")
        port      = int(os.getenv("SMTP_PORT", "587"))
        from_addr = os.getenv("ALERT_FROM_EMAIL", "cdl-etl@company.com")
        password  = os.getenv("SMTP_PASSWORD",  "")
        to_list   = [r.strip() for r in recipients.split(",") if r.strip()]

        msg = MIMEMultipart()
        msg["Subject"] = f"[CDL ETL][{severity}] {table_id}"
        msg["From"]    = from_addr
        msg["To"]      = ", ".join(to_list)
        msg.attach(MIMEText(body, "plain"))

        with smtplib.SMTP(host, port, timeout=10) as s:
            s.ehlo(); s.starttls()
            if password:
                s.login(from_addr, password)
            s.sendmail(from_addr, to_list, msg.as_string())
        logger.info(f"Email alert sent → {to_list}")

    # ── Microsoft Teams ───────────────────────────────────────────────────
    def _teams(self, webhook: str, body: str, severity: str, table_id: str):
        colour  = "FF0000" if severity == "CRITICAL" else "FFA500"
        payload = json.dumps({
            "@type": "MessageCard", "@context": "http://schema.org/extensions",
            "themeColor": colour,
            "summary": f"CDL Alert — {table_id}",
            "sections": [{"activityTitle": f"CDL ETL [{severity}]",
                          "activitySubtitle": table_id,
                          "text": body.replace("\n", "<br>")}],
        }).encode()
        req = urllib.request.Request(
            webhook, data=payload,
            headers={"Content-Type": "application/json"}, method="POST"
        )
        with urllib.request.urlopen(req, timeout=10):
            pass
        logger.info("Teams alert sent")

    # ── Slack ─────────────────────────────────────────────────────────────
    def _slack(self, webhook: str, body: str, severity: str, table_id: str):
        icon    = ":red_circle:" if severity == "CRITICAL" else ":warning:"
        payload = json.dumps({
            "text": f"{icon} *CDL ETL [{severity}]* — `{table_id}`\n```{body}```"
        }).encode()
        req = urllib.request.Request(
            webhook, data=payload,
            headers={"Content-Type": "application/json"}, method="POST"
        )
        with urllib.request.urlopen(req, timeout=10):
            pass
        logger.info("Slack alert sent")
