"""
cdl_etl_framework/utils/cloud_adapter.py
=========================================
Azure ↔ GCP storage and compute abstraction.
Switch via CDL_ENV=azure|gcp environment variable.
"""

import logging
import os
from typing import Optional

logger = logging.getLogger("cdl.cloud_adapter")

try:
    from pyspark.sql import DataFrame, SparkSession
    from pyspark.sql import functions as F
except ImportError:
    pass

from config.env_config import ENV, get_cloud_config, get_storage_base


class CloudAdapter:

    def __init__(self, spark: "SparkSession"):
        self.spark    = spark
        self.env      = ENV
        self.cfg      = get_cloud_config()
        self.base     = get_storage_base()

    # ── External source reads ─────────────────────────────────────────────
    def read_external(self, source_system: str, table_name: str,
                      options: Optional[dict] = None) -> "DataFrame":
        opts = options or {}
        src  = source_system.upper()
        if src == "ACCOUNT_DB":
            return self._jdbc(self._secret("ACCOUNT_DB_JDBC_URL"), table_name, opts)
        elif src in ("ORACLE", "EDW"):
            return self._jdbc(self._secret(f"{src}_JDBC_URL"), table_name,
                              {**opts, "driver": "oracle.jdbc.OracleDriver"})
        elif src == "SQL_SERVER":
            return self._jdbc(self._secret("SQLSERVER_JDBC_URL"), table_name,
                              {**opts, "driver": "com.microsoft.sqlserver.jdbc.SQLServerDriver"})
        elif "GCS_" in src or "ADLS_" in src:
            return self.spark.read.parquet(f"{self.base}/landing/{table_name}")
        else:
            raise ValueError(f"Unsupported source_system: {source_system}")

    # ── Delta helpers ─────────────────────────────────────────────────────
    def optimize(self, table: str, zorder_cols: Optional[list] = None):
        sql = f"OPTIMIZE {table}"
        if zorder_cols:
            sql += f" ZORDER BY ({', '.join(zorder_cols)})"
        self.spark.sql(sql)

    def vacuum(self, table: str, hours: int = 168):
        self.spark.sql(f"VACUUM {table} RETAIN {hours} HOURS")

    # ── JDBC ─────────────────────────────────────────────────────────────
    def _jdbc(self, url: str, table: str, opts: dict) -> "DataFrame":
        r = (self.spark.read.format("jdbc")
             .option("url", url).option("dbtable", table)
             .option("fetchsize", opts.pop("fetchsize", "10000")))
        for k, v in opts.items():
            r = r.option(k, v)
        return r.load()

    # ── Secrets ───────────────────────────────────────────────────────────
    def _secret(self, name: str) -> str:
        # 1. Databricks / Spark conf (set via cluster secret scope)
        try:
            return self.spark.conf.get(f"spark.cdl.secret.{name}")
        except Exception:
            pass
        # 2. GCP Secret Manager
        if self.env == "gcp":
            try:
                from google.cloud import secretmanager
                client   = secretmanager.SecretManagerServiceClient()
                resp     = client.access_secret_version(
                    request={"name": f"{self.cfg.secret_manager_prefix}/{name}/versions/latest"}
                )
                return resp.payload.data.decode()
            except Exception:
                pass
        # 3. Env var fallback (dev/test)
        val = os.getenv(name.replace("-", "_").upper())
        if val:
            return val
        raise RuntimeError(f"Secret '{name}' not found")
