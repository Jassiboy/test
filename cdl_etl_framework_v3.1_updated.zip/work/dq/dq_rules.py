
"""
dq_rules.py
=============
One function per `dq_rule` name that shows up in
cdl_table_config.data_quality_rules, e.g.:

    [{ "dq_rule": "dq_net_rev", "error_threshold_pct": 0.0 }]

The framework (run_dq_on_stage, in 01_framework_core.py) looks up each rule
by name in this file and calls it — you don't touch the framework to add a
new rule, you just add a function here with a matching name.

CONTRACT every rule function must follow:
    fn(spark, stage_table: str, source_table: str, opco: str, load_mnth: str) -> float

    Returns a diff_pct: how far apart stage and source are on whatever
    metric this rule checks (0.0 = identical). The framework compares this
    return value to the rule's error_threshold_pct — the rule function
    itself doesn't decide pass/fail, it just measures.
"""


def _pct_diff(expected, actual) -> float:
    """Shared helper: % difference between an expected and actual value."""
    if expected in (None, 0):
        return 0.0 if actual in (None, 0) else 100.0
    return abs(float(expected) - float(actual)) / float(expected) * 100


def _scalar(spark, sql: str):
    return spark.sql(sql).collect()[0][0]


# ─────────────────────────────────────────────────────────────────────────────
# Row count — stage vs source, same (opco, load_mnth) scope
# ─────────────────────────────────────────────────────────────────────────────
def dq_row_count(spark, stage_table, source_table, opco, load_mnth) -> float:
    scope = f"opco = '{opco}' AND ratemnth = '{load_mnth}'"
    stage_cnt  = _scalar(spark, f"SELECT COUNT(*) FROM {stage_table}  WHERE {scope}")
    source_cnt = _scalar(spark, f"SELECT COUNT(*) FROM {source_table} WHERE {scope}")
    return _pct_diff(source_cnt, stage_cnt)


# ─────────────────────────────────────────────────────────────────────────────
# Net revenue — example business-metric rule (matches the config example)
# ─────────────────────────────────────────────────────────────────────────────
def dq_net_rev(spark, stage_table, source_table, opco, load_mnth) -> float:
    scope = f"ratemnth = '{load_mnth}'"
    stage_rev  = _scalar(spark, f"SELECT SUM(weight_kg) FROM {stage_table}  WHERE {scope}") or 0
    source_rev = _scalar(spark, f"SELECT SUM(weight_kg) FROM {source_table} WHERE {scope}") or 0
    return _pct_diff(source_rev, stage_rev)


# ─────────────────────────────────────────────────────────────────────────────
# Add more rules the same way, e.g.:
#
# def dq_distinct_accounts(spark, stage_table, source_table, opco, load_mnth) -> float:
#     scope = f"opco = '{opco}' AND load_mnth = '{load_mnth}'"
#     stage_ct  = _scalar(spark, f"SELECT COUNT(DISTINCT account_id) FROM {stage_table}  WHERE {scope}")
#     source_ct = _scalar(spark, f"SELECT COUNT(DISTINCT account_id) FROM {source_table} WHERE {scope}")
#     return _pct_diff(source_ct, stage_ct)
# ─────────────────────────────────────────────────────────────────────────────

