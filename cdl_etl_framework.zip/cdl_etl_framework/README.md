# CDL Metadata-Driven ETL Framework

## Overview

A **production-ready, metadata-driven ETL framework** built on **Azure Databricks + Delta Lake + ADLS Gen2**, fully portable to **GCP Dataproc + BigQuery + GCS**. Implements the **Medallion Architecture** (Landing → Bronze → Silver → Gold) with a four-layer transformation hierarchy: Account → Facility → Country → Global.

All pipeline behaviour — source/target mappings, DQ rules, ingestion modes, retry policies — is driven entirely from metadata tables. Adding a new OPCO or source system requires **zero code changes**.

---

## Architecture

```
┌─────────────────────────────────────────────────────────────────────┐
│                    METADATA CONTROL PLANE                           │
│  cdl_table_config | cdl_table_run_log | cdl_dq_rules |             │
│  cdl_pipeline_dependency | cdl_retry_config | cdl_alert_config     │
└──────────────────────────┬──────────────────────────────────────────┘
                           │ drives
┌──────────────────────────▼──────────────────────────────────────────┐
│                  ORCHESTRATION LAYER (Airflow)                      │
│  DAG: cdl_master_pipeline                                           │
│   └─> account_to_facility_dag                                       │
│   └─> facility_to_country_dag  (gated on DQ pass)                  │
│   └─> country_to_global_dag    (gated on DQ pass)                  │
└──────────────────────────┬──────────────────────────────────────────┘
                           │ triggers
┌──────────────────────────▼──────────────────────────────────────────┐
│              TRANSFORMATION LAYER  (Spark / PySpark)                │
│                                                                     │
│  Account Layer  ──DQ PASS──►  Facility Layer                        │
│                      │                                              │
│                   DQ PASS ──►  Country Layer                        │
│                                     │                               │
│                                  DQ PASS ──►  Global Layer          │
│                                                                     │
│  Each layer: Daily table + Monthly table                            │
│  Fault tolerance: Retry / Rollback / Alert / Halt                   │
└─────────────────────────────────────────────────────────────────────┘
```

### Data Flow (per OPCO)

| Step | Source Layer | Target Layer | Tables |
|------|-------------|--------------|--------|
| 1 | Raw / Landing | Account (Bronze) | acc_daily, acc_monthly |
| 2 | Account | Facility (Silver) | fac_daily, fac_monthly |
| 3 | Facility | Country (Silver+) | cntry_daily, cntry_monthly |
| 4 | Country | Global (Gold) | global_daily, global_monthly |

---

## Project Structure

```
cdl_etl_framework/
│
├── README.md                          # This file
│
├── ddl/
│   ├── azure/
│   │   ├── 01_metadata_tables.sql     # Azure SQL / Databricks DDL for all control tables
│   │   └── 02_data_tables.sql         # Delta Lake DDL for all 8 pipeline tables
│   └── gcp/
│       ├── 01_metadata_tables.sql     # BigQuery DDL for control tables
│       └── 02_data_tables.sql         # BigQuery DDL for pipeline tables
│
├── config/
│   ├── env_config.py                  # Environment-aware config (Azure vs GCP)
│   ├── seed_metadata.py               # Seed script: populates all metadata tables
│   └── pipeline_config.json           # Static pipeline topology config
│
├── notebooks/
│   ├── 01_framework_core.py           # MetadataManager, DQEngine, RunLogger (shared)
│   ├── 02_ingestion.py                # Generic ingestion notebook (all layers, all modes)
│   ├── 03_transformation.py           # Layer-specific transformation logic (metadata-driven)
│   └── 04_pipeline_runner.py          # End-to-end orchestration entry point
│
├── utils/
│   ├── retry_handler.py               # Exponential backoff retry decorator
│   ├── alert_manager.py               # Email / Teams / PagerDuty alerting
│   ├── schema_validator.py            # Schema drift detection
│   └── cloud_adapter.py              # Azure ↔ GCP abstraction layer
│
├── dags/
│   └── cdl_master_dag.py              # Airflow DAG: full pipeline with dependency gates
│
├── init_scripts/
│   ├── cluster_init_azure.sh          # Databricks cluster init (libraries, env vars)
│   └── cluster_init_gcp.sh            # Dataproc cluster init
│
├── tests/
│   ├── test_dq_engine.py              # Unit tests for DQ framework
│   ├── test_metadata_manager.py       # Unit tests for metadata operations
│   └── test_transformations.py        # Unit tests for transformation logic
│
└── docs/
    └── runbook.md                      # Operations runbook
```

---

## Metadata Tables

| Table | Purpose |
|-------|---------|
| `cdl_table_config` | Pipeline topology, source/target mapping, ingestion mode, DQ rules |
| `cdl_table_run_log` | Full audit log per task execution |
| `cdl_dq_rules` | Reusable, named DQ rule library |
| `cdl_pipeline_dependency` | Layer-level dependency graph (what must pass before what runs) |
| `cdl_retry_config` | Per-table retry policies (max attempts, backoff strategy) |
| `cdl_alert_config` | Alert routing (email/teams) per pipeline/severity |
| `cdl_watermark_state` | Persistent watermark tracking for incremental loads |

---

## Quick Start

### 1. Provision infrastructure

```bash
# Azure
bash init_scripts/cluster_init_azure.sh

# GCP
bash init_scripts/cluster_init_gcp.sh
```

### 2. Create metadata tables

```sql
-- Azure Databricks
%run ddl/azure/01_metadata_tables.sql
%run ddl/azure/02_data_tables.sql

-- GCP BigQuery
bq query --use_legacy_sql=false < ddl/gcp/01_metadata_tables.sql
bq query --use_legacy_sql=false < ddl/gcp/02_data_tables.sql
```

### 3. Seed metadata

```bash
python config/seed_metadata.py --env azure --opco GROUND
```

### 4. Run the pipeline

```bash
# Full pipeline (all layers)
python notebooks/04_pipeline_runner.py --opco GROUND --run_date 2024-01-15 --env azure

# Single layer
python notebooks/04_pipeline_runner.py --opco GROUND --run_date 2024-01-15 --layer FACILITY --env azure
```

### 5. Deploy Airflow DAG

```bash
cp dags/cdl_master_dag.py $AIRFLOW_HOME/dags/
airflow dags trigger cdl_master_pipeline --conf '{"opco":"GROUND","run_date":"2024-01-15"}'
```

---

## Adding a New OPCO

1. Insert rows into `cdl_table_config` for the new OPCO
2. Insert DQ rules into `cdl_dq_rules` if custom rules are needed
3. Insert retry config into `cdl_retry_config`
4. Insert alert routing into `cdl_alert_config`
5. Trigger the pipeline — **zero code changes required**

---

## Cloud Portability

| Concern | Azure | GCP |
|---------|-------|-----|
| Compute | Databricks (Spark) | Dataproc (Spark) |
| Storage | ADLS Gen2 | GCS |
| Table format | Delta Lake | Delta Lake on GCS or BigQuery |
| Orchestration | Airflow / ADF | Cloud Composer (Airflow) |
| Secrets | Azure Key Vault | Secret Manager |
| Monitoring | Azure Monitor | Cloud Monitoring |

Switch via `ENV=gcp` environment variable — the `cloud_adapter.py` handles all platform differences.

---

## DQ Framework

Three-tier validation:
- **Tier 1 – Schema**: null checks, data type conformance, column existence
- **Tier 2 – Business**: range checks, referential integrity, custom SQL predicates
- **Tier 3 – Statistical**: row count thresholds, anomaly detection vs. prior run

DQ results are stored in `dq_results` (JSON) within `cdl_table_run_log`. A layer will not proceed to the next unless DQ passes (configurable threshold per table).

---

## Retry & Fault Tolerance

- Configurable per-table retry policy in `cdl_retry_config`
- Exponential backoff with jitter
- On final failure: rollback Delta transaction, set status = `FAILED`, trigger alert
- Downstream layers halted automatically via dependency check

---

## Observability

- Every task execution writes to `cdl_table_run_log`
- Row-level metrics: rows_read, rows_written, rows_rejected, rows_merged
- DQ results stored as structured JSON
- Watermark state persisted in `cdl_watermark_state`
- Alert routing via `cdl_alert_config`
