"""
cdl_etl_framework/config/seed_metadata.py
==========================================
Seeds all CDL metadata/control tables with initial configuration for OPCO=GROUND.
Run once after DDL is applied.

Usage:
    python seed_metadata.py --env azure --opco GROUND
    python seed_metadata.py --env gcp   --opco GROUND
"""

import argparse
import json
import sys
import os
from datetime import datetime, timezone

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from config.env_config import get_metadata_db, PIPELINE_CONFIG

NOW = datetime.now(timezone.utc).isoformat()


# ---------------------------------------------------------------------------
# Seed data definitions
# ---------------------------------------------------------------------------

def get_table_config_rows(opco: str) -> list[dict]:
    """cdl_table_config seed rows for one OPCO."""
    base_dq_account = json.dumps([
        "not_null_account_id", "not_null_opco", "valid_account_status",
        "positive_revenue", "row_count_min"
    ])
    base_dq_facility = json.dumps([
        "not_null_facility_id", "not_null_account_id", "valid_facility_status",
        "valid_utilisation_range", "row_count_min"
    ])
    base_dq_country = json.dumps([
        "not_null_country_code", "valid_iso_country_code",
        "positive_gross_margin_check", "row_count_min"
    ])
    base_dq_global = json.dumps([
        "not_null_opco", "positive_total_revenue", "gross_margin_pct_range",
        "row_count_min"
    ])

    rows = [
        # ----- Account Layer -----
        {
            "table_id":             f"{opco.lower()}_account_daily",
            "source_system":        "ACCOUNT_DB",
            "source_table_name":    "raw_account_transactions",
            "target_system":        "DELTA_LAKE",
            "target_table_name":    "account_daily",
            "target_dataset_layer": "ACCOUNT",
            "opco":                 opco,
            "ingestion_mode":       "INCR",
            "watermark_column":     "last_modified_ts",
            "partition_col":        "load_date",
            "merge_keys":           "account_id,opco,effective_date",
            "source_filter":        None,
            "load_frequency":       "DAILY",
            "dq_threshold_pct":     95.0,
            "is_active":            True,
            "data_quality_rules":   base_dq_account,
            "created_at":           NOW,
            "updated_at":           NOW,
            "created_by":           "seed_script",
        },
        {
            "table_id":             f"{opco.lower()}_account_monthly",
            "source_system":        "ACCOUNT_DB",
            "source_table_name":    "raw_account_transactions",
            "target_system":        "DELTA_LAKE",
            "target_table_name":    "account_monthly",
            "target_dataset_layer": "ACCOUNT",
            "opco":                 opco,
            "ingestion_mode":       "FULL",
            "watermark_column":     None,
            "partition_col":        "load_date",
            "merge_keys":           "account_id,opco,month_year",
            "source_filter":        None,
            "load_frequency":       "MONTHLY",
            "dq_threshold_pct":     95.0,
            "is_active":            True,
            "data_quality_rules":   base_dq_account,
            "created_at":           NOW,
            "updated_at":           NOW,
            "created_by":           "seed_script",
        },
        # ----- Facility Layer -----
        {
            "table_id":             f"{opco.lower()}_facility_daily",
            "source_system":        "ACCOUNT_DB",
            "source_table_name":    "account_daily",
            "target_system":        "DELTA_LAKE",
            "target_table_name":    "facility_daily",
            "target_dataset_layer": "FACILITY",
            "opco":                 opco,
            "ingestion_mode":       "INCR",
            "watermark_column":     "load_date",
            "partition_col":        "load_date",
            "merge_keys":           "facility_id,account_id,opco,effective_date",
            "source_filter":        None,
            "load_frequency":       "DAILY",
            "dq_threshold_pct":     95.0,
            "is_active":            True,
            "data_quality_rules":   base_dq_facility,
            "created_at":           NOW,
            "updated_at":           NOW,
            "created_by":           "seed_script",
        },
        {
            "table_id":             f"{opco.lower()}_facility_monthly",
            "source_system":        "ACCOUNT_DB",
            "source_table_name":    "account_monthly",
            "target_system":        "DELTA_LAKE",
            "target_table_name":    "facility_monthly",
            "target_dataset_layer": "FACILITY",
            "opco":                 opco,
            "ingestion_mode":       "FULL",
            "watermark_column":     None,
            "partition_col":        "load_date",
            "merge_keys":           "facility_id,account_id,opco,month_year",
            "source_filter":        None,
            "load_frequency":       "MONTHLY",
            "dq_threshold_pct":     95.0,
            "is_active":            True,
            "data_quality_rules":   base_dq_facility,
            "created_at":           NOW,
            "updated_at":           NOW,
            "created_by":           "seed_script",
        },
        # ----- Country Layer -----
        {
            "table_id":             f"{opco.lower()}_country_daily",
            "source_system":        "DELTA_LAKE",
            "source_table_name":    "facility_daily",
            "target_system":        "DELTA_LAKE",
            "target_table_name":    "country_daily",
            "target_dataset_layer": "COUNTRY",
            "opco":                 opco,
            "ingestion_mode":       "FULL",
            "watermark_column":     "load_date",
            "partition_col":        "load_date",
            "merge_keys":           "country_code,opco,effective_date",
            "source_filter":        None,
            "load_frequency":       "DAILY",
            "dq_threshold_pct":     98.0,
            "is_active":            True,
            "data_quality_rules":   base_dq_country,
            "created_at":           NOW,
            "updated_at":           NOW,
            "created_by":           "seed_script",
        },
        {
            "table_id":             f"{opco.lower()}_country_monthly",
            "source_system":        "DELTA_LAKE",
            "source_table_name":    "facility_monthly",
            "target_system":        "DELTA_LAKE",
            "target_table_name":    "country_monthly",
            "target_dataset_layer": "COUNTRY",
            "opco":                 opco,
            "ingestion_mode":       "FULL",
            "watermark_column":     None,
            "partition_col":        "load_date",
            "merge_keys":           "country_code,opco,month_year",
            "source_filter":        None,
            "load_frequency":       "MONTHLY",
            "dq_threshold_pct":     98.0,
            "is_active":            True,
            "data_quality_rules":   base_dq_country,
            "created_at":           NOW,
            "updated_at":           NOW,
            "created_by":           "seed_script",
        },
        # ----- Global Layer -----
        {
            "table_id":             f"{opco.lower()}_global_daily",
            "source_system":        "DELTA_LAKE",
            "source_table_name":    "country_daily",
            "target_system":        "DELTA_LAKE",
            "target_table_name":    "global_daily",
            "target_dataset_layer": "GLOBAL",
            "opco":                 opco,
            "ingestion_mode":       "FULL",
            "watermark_column":     "load_date",
            "partition_col":        "load_date",
            "merge_keys":           "opco,effective_date,region_code",
            "source_filter":        None,
            "load_frequency":       "DAILY",
            "dq_threshold_pct":     99.0,
            "is_active":            True,
            "data_quality_rules":   base_dq_global,
            "created_at":           NOW,
            "updated_at":           NOW,
            "created_by":           "seed_script",
        },
        {
            "table_id":             f"{opco.lower()}_global_monthly",
            "source_system":        "DELTA_LAKE",
            "source_table_name":    "country_monthly",
            "target_system":        "DELTA_LAKE",
            "target_table_name":    "global_monthly",
            "target_dataset_layer": "GLOBAL",
            "opco":                 opco,
            "ingestion_mode":       "FULL",
            "watermark_column":     None,
            "partition_col":        "load_date",
            "merge_keys":           "opco,month_year,region_code",
            "source_filter":        None,
            "load_frequency":       "MONTHLY",
            "dq_threshold_pct":     99.0,
            "is_active":            True,
            "data_quality_rules":   base_dq_global,
            "created_at":           NOW,
            "updated_at":           NOW,
            "created_by":           "seed_script",
        },
    ]
    return rows


def get_dq_rules_rows() -> list[dict]:
    return [
        {"rule_id": "not_null_account_id",    "rule_name": "Account ID Not Null",
         "rule_type": "NOT_NULL",    "target_column": "account_id",
         "rule_expression": "account_id IS NOT NULL",
         "severity": "CRITICAL",    "error_threshold_pct": 0.0,
         "applies_to_layers": "ACCOUNT", "applies_to_opcos": "ALL",
         "is_active": True, "created_at": NOW, "updated_at": NOW},

        {"rule_id": "not_null_opco",          "rule_name": "OPCO Not Null",
         "rule_type": "NOT_NULL",    "target_column": "opco",
         "rule_expression": "opco IS NOT NULL",
         "severity": "CRITICAL",    "error_threshold_pct": 0.0,
         "applies_to_layers": "ACCOUNT,FACILITY,COUNTRY,GLOBAL", "applies_to_opcos": "ALL",
         "is_active": True, "created_at": NOW, "updated_at": NOW},

        {"rule_id": "valid_account_status",   "rule_name": "Account Status Valid",
         "rule_type": "RANGE",       "target_column": "account_status",
         "rule_expression": "account_status IN ('ACTIVE','INACTIVE','SUSPENDED')",
         "severity": "WARNING",      "error_threshold_pct": 1.0,
         "applies_to_layers": "ACCOUNT", "applies_to_opcos": "ALL",
         "is_active": True, "created_at": NOW, "updated_at": NOW},

        {"rule_id": "positive_revenue",       "rule_name": "Revenue Non-Negative",
         "rule_type": "RANGE",       "target_column": "revenue",
         "rule_expression": "revenue >= 0",
         "severity": "WARNING",      "error_threshold_pct": 0.5,
         "applies_to_layers": "ACCOUNT,FACILITY,COUNTRY,GLOBAL", "applies_to_opcos": "ALL",
         "is_active": True, "created_at": NOW, "updated_at": NOW},

        {"rule_id": "row_count_min",          "rule_name": "Minimum Row Count",
         "rule_type": "ROW_COUNT",   "target_column": None,
         "rule_expression": json.dumps({"min_rows": 1}),
         "severity": "CRITICAL",    "error_threshold_pct": 0.0,
         "applies_to_layers": "ACCOUNT,FACILITY,COUNTRY,GLOBAL", "applies_to_opcos": "ALL",
         "is_active": True, "created_at": NOW, "updated_at": NOW},

        {"rule_id": "not_null_facility_id",   "rule_name": "Facility ID Not Null",
         "rule_type": "NOT_NULL",    "target_column": "facility_id",
         "rule_expression": "facility_id IS NOT NULL",
         "severity": "CRITICAL",    "error_threshold_pct": 0.0,
         "applies_to_layers": "FACILITY", "applies_to_opcos": "ALL",
         "is_active": True, "created_at": NOW, "updated_at": NOW},

        {"rule_id": "not_null_account_id_fac","rule_name": "Facility Account ID Not Null",
         "rule_type": "NOT_NULL",    "target_column": "account_id",
         "rule_expression": "account_id IS NOT NULL",
         "severity": "CRITICAL",    "error_threshold_pct": 0.0,
         "applies_to_layers": "FACILITY", "applies_to_opcos": "ALL",
         "is_active": True, "created_at": NOW, "updated_at": NOW},

        {"rule_id": "valid_facility_status",  "rule_name": "Facility Status Valid",
         "rule_type": "RANGE",       "target_column": "facility_status",
         "rule_expression": "facility_status IN ('ACTIVE','INACTIVE','UNDER_MAINTENANCE')",
         "severity": "WARNING",      "error_threshold_pct": 1.0,
         "applies_to_layers": "FACILITY", "applies_to_opcos": "ALL",
         "is_active": True, "created_at": NOW, "updated_at": NOW},

        {"rule_id": "valid_utilisation_range","rule_name": "Utilisation 0-100%",
         "rule_type": "RANGE",       "target_column": "utilisation_pct",
         "rule_expression": "utilisation_pct BETWEEN 0 AND 100",
         "severity": "WARNING",      "error_threshold_pct": 0.5,
         "applies_to_layers": "FACILITY", "applies_to_opcos": "ALL",
         "is_active": True, "created_at": NOW, "updated_at": NOW},

        {"rule_id": "not_null_country_code",  "rule_name": "Country Code Not Null",
         "rule_type": "NOT_NULL",    "target_column": "country_code",
         "rule_expression": "country_code IS NOT NULL",
         "severity": "CRITICAL",    "error_threshold_pct": 0.0,
         "applies_to_layers": "COUNTRY", "applies_to_opcos": "ALL",
         "is_active": True, "created_at": NOW, "updated_at": NOW},

        {"rule_id": "valid_iso_country_code", "rule_name": "Country Code 2-char ISO",
         "rule_type": "REGEX",       "target_column": "country_code",
         "rule_expression": "LENGTH(country_code) = 2",
         "severity": "WARNING",      "error_threshold_pct": 0.0,
         "applies_to_layers": "COUNTRY", "applies_to_opcos": "ALL",
         "is_active": True, "created_at": NOW, "updated_at": NOW},

        {"rule_id": "positive_gross_margin_check", "rule_name": "Gross Margin Computable",
         "rule_type": "CUSTOM_SQL",  "target_column": "gross_margin",
         "rule_expression": "gross_margin = revenue - cost",
         "severity": "WARNING",      "error_threshold_pct": 1.0,
         "applies_to_layers": "COUNTRY,GLOBAL", "applies_to_opcos": "ALL",
         "is_active": True, "created_at": NOW, "updated_at": NOW},

        {"rule_id": "positive_total_revenue", "rule_name": "Total Revenue Positive",
         "rule_type": "RANGE",       "target_column": "revenue",
         "rule_expression": "revenue > 0",
         "severity": "CRITICAL",    "error_threshold_pct": 0.0,
         "applies_to_layers": "GLOBAL", "applies_to_opcos": "ALL",
         "is_active": True, "created_at": NOW, "updated_at": NOW},

        {"rule_id": "gross_margin_pct_range", "rule_name": "Gross Margin % in (-100,100)",
         "rule_type": "RANGE",       "target_column": "gross_margin_pct",
         "rule_expression": "gross_margin_pct BETWEEN -100 AND 100",
         "severity": "WARNING",      "error_threshold_pct": 0.5,
         "applies_to_layers": "GLOBAL", "applies_to_opcos": "ALL",
         "is_active": True, "created_at": NOW, "updated_at": NOW},
    ]


def get_pipeline_dependency_rows(opco: str) -> list[dict]:
    o = opco.lower()
    return [
        {"dependency_id": f"{o}_acc_to_fac_daily",    "upstream_layer": "ACCOUNT",
         "upstream_table_id": f"{o}_account_daily",   "downstream_layer": "FACILITY",
         "downstream_table_id": f"{o}_facility_daily","opco": opco,
         "dependency_type": "DQ_PASS", "threshold_value": None,
         "is_active": True, "created_at": NOW},

        {"dependency_id": f"{o}_acc_to_fac_monthly",  "upstream_layer": "ACCOUNT",
         "upstream_table_id": f"{o}_account_monthly", "downstream_layer": "FACILITY",
         "downstream_table_id": f"{o}_facility_monthly","opco": opco,
         "dependency_type": "DQ_PASS", "threshold_value": None,
         "is_active": True, "created_at": NOW},

        {"dependency_id": f"{o}_fac_to_cntry_daily",  "upstream_layer": "FACILITY",
         "upstream_table_id": f"{o}_facility_daily",  "downstream_layer": "COUNTRY",
         "downstream_table_id": f"{o}_country_daily", "opco": opco,
         "dependency_type": "DQ_PASS", "threshold_value": None,
         "is_active": True, "created_at": NOW},

        {"dependency_id": f"{o}_fac_to_cntry_monthly","upstream_layer": "FACILITY",
         "upstream_table_id": f"{o}_facility_monthly","downstream_layer": "COUNTRY",
         "downstream_table_id": f"{o}_country_monthly","opco": opco,
         "dependency_type": "DQ_PASS", "threshold_value": None,
         "is_active": True, "created_at": NOW},

        {"dependency_id": f"{o}_cntry_to_global_daily","upstream_layer": "COUNTRY",
         "upstream_table_id": f"{o}_country_daily",   "downstream_layer": "GLOBAL",
         "downstream_table_id": f"{o}_global_daily",  "opco": opco,
         "dependency_type": "DQ_PASS", "threshold_value": None,
         "is_active": True, "created_at": NOW},

        {"dependency_id": f"{o}_cntry_to_global_monthly","upstream_layer": "COUNTRY",
         "upstream_table_id": f"{o}_country_monthly", "downstream_layer": "GLOBAL",
         "downstream_table_id": f"{o}_global_monthly","opco": opco,
         "dependency_type": "DQ_PASS", "threshold_value": None,
         "is_active": True, "created_at": NOW},
    ]


def get_retry_config_rows() -> list[dict]:
    return [
        # Global default
        {"config_id": "global_default", "table_id": None, "opco": None,
         "max_attempts": 3, "initial_wait_seconds": 30,
         "backoff_multiplier": 2.0, "max_wait_seconds": 300,
         "retry_on_errors": None, "alert_on_attempt": 2,
         "is_active": True, "created_at": NOW},
        # Critical account layer — more retries
        {"config_id": "account_retry", "table_id": "ground_account_daily", "opco": "GROUND",
         "max_attempts": 5, "initial_wait_seconds": 60,
         "backoff_multiplier": 2.0, "max_wait_seconds": 600,
         "retry_on_errors": "TRANSIENT_ERROR,CLUSTER_ERROR", "alert_on_attempt": 3,
         "is_active": True, "created_at": NOW},
    ]


def get_alert_config_rows() -> list[dict]:
    return [
        {"alert_id": "critical_email", "pipeline_pattern": "*",
         "opco": None, "severity": "CRITICAL", "channel": "EMAIL",
         "recipients": "cdl-alerts@company.com,data-eng-oncall@company.com",
         "alert_on_status": "FAILED,HALTED",
         "message_template": None, "is_active": True, "created_at": NOW},

        {"alert_id": "warning_teams",  "pipeline_pattern": "*",
         "opco": None, "severity": "WARNING", "channel": "TEAMS",
         "recipients": "https://company.webhook.office.com/webhookb2/cdl-alerts",
         "alert_on_status": "FAILED",
         "message_template": None, "is_active": True, "created_at": NOW},
    ]


# ---------------------------------------------------------------------------
# Spark insert helpers
# ---------------------------------------------------------------------------
def seed_table(spark, metadata_db: str, table_name: str, rows: list[dict]):
    """Insert seed rows — skip if table_id / rule_id already exists."""
    if not rows:
        return
    df = spark.createDataFrame(rows)
    full_table = f"{metadata_db}.{table_name}"
    pk_col = "table_id" if "table_id" in rows[0] else \
             "rule_id" if "rule_id" in rows[0] else \
             "dependency_id" if "dependency_id" in rows[0] else \
             "config_id" if "config_id" in rows[0] else \
             "alert_id"

    # Deduplicate against existing data
    existing = spark.table(full_table).select(pk_col)
    new_rows = df.join(existing, on=pk_col, how="left_anti")
    count = new_rows.count()
    if count > 0:
        new_rows.write.format("delta").mode("append").saveAsTable(full_table)
        print(f"  ✓ Seeded {count} row(s) into {full_table}")
    else:
        print(f"  ⏭  No new rows for {full_table} (all already exist)")


def main(opco: str):
    try:
        from pyspark.sql import SparkSession
        spark = SparkSession.builder.getOrCreate()
    except ImportError:
        print("ERROR: PySpark not available. Run this script on a Databricks / Dataproc cluster.")
        sys.exit(1)

    metadata_db = get_metadata_db()
    print(f"\n{'='*60}")
    print(f"Seeding CDL metadata — OPCO={opco}  DB={metadata_db}")
    print(f"{'='*60}\n")

    seed_table(spark, metadata_db, "cdl_table_config",
               get_table_config_rows(opco))
    seed_table(spark, metadata_db, "cdl_dq_rules",
               get_dq_rules_rows())
    seed_table(spark, metadata_db, "cdl_pipeline_dependency",
               get_pipeline_dependency_rows(opco))
    seed_table(spark, metadata_db, "cdl_retry_config",
               get_retry_config_rows())
    seed_table(spark, metadata_db, "cdl_alert_config",
               get_alert_config_rows())
    print("\n✅  Metadata seeding complete.\n")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Seed CDL metadata tables")
    parser.add_argument("--env",  default="azure", choices=["azure", "gcp"])
    parser.add_argument("--opco", default="GROUND")
    args = parser.parse_args()

    os.environ["CDL_ENV"] = args.env
    main(args.opco.upper())
