"""
cdl_etl_framework/tests/test_dq_engine.py
==========================================
Unit tests for DQEngine — runs with pytest + pyspark.
Uses a local SparkSession with Delta Lake extensions.

Run:
    pytest tests/test_dq_engine.py -v
"""

import json
import pytest
from datetime import date


# ---------------------------------------------------------------------------
# Pytest fixtures
# ---------------------------------------------------------------------------
@pytest.fixture(scope="session")
def spark():
    """Local SparkSession with Delta extensions."""
    from pyspark.sql import SparkSession
    spark = (
        SparkSession.builder
        .master("local[2]")
        .appName("cdl_test_dq_engine")
        .config("spark.sql.extensions",
                "io.delta.sql.DeltaSparkSessionExtension")
        .config("spark.sql.catalog.spark_catalog",
                "org.apache.spark.sql.delta.catalog.DeltaCatalog")
        .config("spark.sql.shuffle.partitions", "2")
        .config("spark.databricks.delta.schema.autoMerge.enabled", "false")
        .getOrCreate()
    )
    spark.sparkContext.setLogLevel("ERROR")
    return spark


@pytest.fixture
def logger():
    from notebooks.01_framework_core import CDLLogger
    return CDLLogger("test_dq", run_id="test-001", opco="GROUND", layer="ACCOUNT")


@pytest.fixture
def dq_engine(spark, logger):
    from notebooks.01_framework_core import DQEngine
    return DQEngine(spark, logger)


@pytest.fixture
def table_cfg():
    from notebooks.01_framework_core import TableConfig
    return TableConfig(
        table_id="ground_account_daily",
        source_system="ACCOUNT_DB",
        source_table_name="raw_account_transactions",
        target_system="DELTA_LAKE",
        target_table_name="account_daily",
        target_dataset_layer="ACCOUNT",
        opco="GROUND",
        ingestion_mode="INCR",
        watermark_column="last_modified_ts",
        partition_col="load_date",
        merge_keys="account_id,opco,effective_date",
        source_filter=None,
        load_frequency="DAILY",
        dq_threshold_pct=95.0,
        is_active=True,
        data_quality_rules=["not_null_account_id", "positive_revenue"],
    )


# ---------------------------------------------------------------------------
# Helper to build test DataFrames
# ---------------------------------------------------------------------------
def make_df(spark, rows, schema=None):
    if schema:
        return spark.createDataFrame(rows, schema)
    return spark.createDataFrame(rows)


# ===========================================================================
# Tests: NOT_NULL rule
# ===========================================================================
class TestNotNullRule:

    def test_all_pass(self, dq_engine, spark, table_cfg):
        df = make_df(spark, [
            ("ACC001", "GROUND", 100.0),
            ("ACC002", "GROUND", 200.0),
        ], "account_id STRING, opco STRING, revenue DOUBLE")

        rule = {
            "rule_id": "not_null_account_id",
            "rule_type": "NOT_NULL",
            "target_column": "account_id",
            "rule_expression": "account_id IS NOT NULL",
            "severity": "CRITICAL",
            "error_threshold_pct": 0.0,
        }
        result = dq_engine._run_rule(df, rule, df.count())
        assert result.passed is True
        assert result.rows_failed == 0
        assert result.failure_pct == 0.0

    def test_some_fail(self, dq_engine, spark, table_cfg):
        df = make_df(spark, [
            ("ACC001", "GROUND", 100.0),
            (None,     "GROUND", 200.0),
        ], "account_id STRING, opco STRING, revenue DOUBLE")

        rule = {
            "rule_id": "not_null_account_id",
            "rule_type": "NOT_NULL",
            "target_column": "account_id",
            "rule_expression": "account_id IS NOT NULL",
            "severity": "CRITICAL",
            "error_threshold_pct": 0.0,
        }
        result = dq_engine._run_rule(df, rule, df.count())
        assert result.passed is False
        assert result.rows_failed == 1
        assert result.failure_pct == 50.0

    def test_within_threshold(self, dq_engine, spark, table_cfg):
        """1 failure in 100 rows — 1% — within 2% threshold → pass."""
        rows = [("ACC%03d" % i, "GROUND", float(i * 10)) for i in range(1, 100)]
        rows.append((None, "GROUND", 0.0))   # 1 null
        df = make_df(spark, rows, "account_id STRING, opco STRING, revenue DOUBLE")

        rule = {
            "rule_id": "not_null_account_id",
            "rule_type": "NOT_NULL",
            "target_column": "account_id",
            "rule_expression": "account_id IS NOT NULL",
            "severity": "CRITICAL",
            "error_threshold_pct": 2.0,   # allow up to 2%
        }
        result = dq_engine._run_rule(df, rule, df.count())
        assert result.passed is True
        assert result.rows_failed == 1


# ===========================================================================
# Tests: RANGE rule
# ===========================================================================
class TestRangeRule:

    def test_positive_revenue_all_pass(self, dq_engine, spark, table_cfg):
        df = make_df(spark, [
            ("ACC001", 100.0),
            ("ACC002", 50.0),
        ], "account_id STRING, revenue DOUBLE")

        rule = {
            "rule_id": "positive_revenue",
            "rule_type": "RANGE",
            "target_column": "revenue",
            "rule_expression": "revenue >= 0",
            "severity": "WARNING",
            "error_threshold_pct": 0.5,
        }
        result = dq_engine._run_rule(df, rule, df.count())
        assert result.passed is True

    def test_negative_revenue_fails(self, dq_engine, spark, table_cfg):
        df = make_df(spark, [
            ("ACC001",  100.0),
            ("ACC002", -50.0),   # invalid
        ], "account_id STRING, revenue DOUBLE")

        rule = {
            "rule_id": "positive_revenue",
            "rule_type": "RANGE",
            "target_column": "revenue",
            "rule_expression": "revenue >= 0",
            "severity": "WARNING",
            "error_threshold_pct": 0.5,
        }
        result = dq_engine._run_rule(df, rule, df.count())
        assert result.passed is False
        assert result.rows_failed == 1

    def test_range_within_valid_set(self, dq_engine, spark, table_cfg):
        df = make_df(spark, [
            ("ACC001", "ACTIVE"),
            ("ACC002", "INACTIVE"),
        ], "account_id STRING, account_status STRING")

        rule = {
            "rule_id": "valid_account_status",
            "rule_type": "RANGE",
            "target_column": "account_status",
            "rule_expression": "account_status IN ('ACTIVE','INACTIVE','SUSPENDED')",
            "severity": "WARNING",
            "error_threshold_pct": 1.0,
        }
        result = dq_engine._run_rule(df, rule, df.count())
        assert result.passed is True


# ===========================================================================
# Tests: ROW_COUNT rule
# ===========================================================================
class TestRowCountRule:

    def test_min_row_count_pass(self, dq_engine, spark, table_cfg):
        df = make_df(spark, [("ACC001",), ("ACC002",)], "account_id STRING")
        rule = {
            "rule_id": "row_count_min",
            "rule_type": "ROW_COUNT",
            "target_column": None,
            "rule_expression": json.dumps({"min_rows": 1}),
            "severity": "CRITICAL",
            "error_threshold_pct": 0.0,
        }
        result = dq_engine._run_rule(df, rule, df.count())
        assert result.passed is True

    def test_empty_df_fails(self, dq_engine, spark, table_cfg):
        from pyspark.sql.types import StringType, StructType, StructField
        schema = StructType([StructField("account_id", StringType(), True)])
        df = spark.createDataFrame([], schema)
        rule = {
            "rule_id": "row_count_min",
            "rule_type": "ROW_COUNT",
            "target_column": None,
            "rule_expression": json.dumps({"min_rows": 1}),
            "severity": "CRITICAL",
            "error_threshold_pct": 0.0,
        }
        result = dq_engine._run_rule(df, rule, 0)
        assert result.passed is False


# ===========================================================================
# Tests: Full DQ run (multiple rules)
# ===========================================================================
class TestFullDQRun:

    def test_all_rules_pass(self, dq_engine, spark, table_cfg):
        df = make_df(spark, [
            ("ACC001", "GROUND", 100.0),
            ("ACC002", "GROUND", 200.0),
        ], "account_id STRING, opco STRING, revenue DOUBLE")

        rules = [
            {
                "rule_id": "not_null_account_id",
                "rule_type": "NOT_NULL",
                "target_column": "account_id",
                "rule_expression": "account_id IS NOT NULL",
                "severity": "CRITICAL",
                "error_threshold_pct": 0.0,
            },
            {
                "rule_id": "positive_revenue",
                "rule_type": "RANGE",
                "target_column": "revenue",
                "rule_expression": "revenue >= 0",
                "severity": "WARNING",
                "error_threshold_pct": 0.5,
            },
        ]
        results, overall = dq_engine.run(df, table_cfg, rules)
        assert overall is True
        assert all(r.passed for r in results)

    def test_critical_failure_fails_overall(self, dq_engine, spark, table_cfg):
        df = make_df(spark, [
            (None,     "GROUND", 100.0),
            ("ACC002", "GROUND", 200.0),
        ], "account_id STRING, opco STRING, revenue DOUBLE")

        rules = [
            {
                "rule_id": "not_null_account_id",
                "rule_type": "NOT_NULL",
                "target_column": "account_id",
                "rule_expression": "account_id IS NOT NULL",
                "severity": "CRITICAL",
                "error_threshold_pct": 0.0,
            },
        ]
        results, overall = dq_engine.run(df, table_cfg, rules)
        assert overall is False

    def test_warning_failure_does_not_fail_overall(self, dq_engine, spark, table_cfg):
        df = make_df(spark, [
            ("ACC001", "GROUND", -50.0),  # negative revenue (WARNING rule)
            ("ACC002", "GROUND",  200.0),
        ], "account_id STRING, opco STRING, revenue DOUBLE")

        rules = [
            {
                "rule_id": "positive_revenue",
                "rule_type": "RANGE",
                "target_column": "revenue",
                "rule_expression": "revenue >= 0",
                "severity": "WARNING",          # NOT critical
                "error_threshold_pct": 0.5,
            },
        ]
        results, overall = dq_engine.run(df, table_cfg, rules)
        # WARNING failure should not make overall = False
        assert overall is True
        assert results[0].passed is False      # rule itself failed
