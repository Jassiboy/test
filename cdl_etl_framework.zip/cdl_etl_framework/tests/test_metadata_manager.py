"""
cdl_etl_framework/tests/test_metadata_manager.py
=================================================
Unit tests for MetadataManager and transformation registry.
Uses mocked Spark SQL results where full Spark is unavailable.
"""

import json
import pytest
from datetime import date
from unittest.mock import MagicMock, patch, PropertyMock


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------
@pytest.fixture
def mock_spark():
    spark = MagicMock()
    spark.sparkContext.applicationId = "test-app-001"
    return spark


@pytest.fixture
def run_date():
    return date(2024, 1, 15)


@pytest.fixture
def opco():
    return "GROUND"


# ---------------------------------------------------------------------------
# Helper to mock spark.sql().collect() response
# ---------------------------------------------------------------------------
def make_mock_row(**kwargs):
    row = MagicMock()
    row.asDict.return_value = kwargs
    return row


# ===========================================================================
# Tests: MetadataManager.get_table_configs
# ===========================================================================
class TestMetadataManagerGetConfigs:

    def test_returns_active_configs(self, mock_spark, run_date, opco):
        from notebooks.01_framework_core import MetadataManager

        mock_row = make_mock_row(
            table_id="ground_account_daily",
            source_system="ACCOUNT_DB",
            source_table_name="raw_account_transactions",
            target_system="DELTA_LAKE",
            target_table_name="account_daily",
            target_dataset_layer="ACCOUNT",
            opco="GROUND",
            ingestion_mode="INCR",
            watermark_column="last_modified_ts",
            partition_col="load_date",
            merge_keys="account_id,opco,effective_date",
            source_filter=None,
            load_frequency="DAILY",
            dq_threshold_pct=95.0,
            is_active=True,
            data_quality_rules='["not_null_account_id"]',
        )
        mock_spark.sql.return_value.collect.return_value = [mock_row]

        mgr = MetadataManager(mock_spark, opco, run_date)
        configs = mgr.get_table_configs(layer="ACCOUNT")

        assert len(configs) == 1
        assert configs[0].table_id == "ground_account_daily"
        assert configs[0].ingestion_mode == "INCR"
        assert configs[0].data_quality_rules == ["not_null_account_id"]

    def test_empty_result_returns_empty_list(self, mock_spark, run_date, opco):
        from notebooks.01_framework_core import MetadataManager

        mock_spark.sql.return_value.collect.return_value = []
        mgr = MetadataManager(mock_spark, opco, run_date)
        configs = mgr.get_table_configs(layer="GLOBAL")
        assert configs == []

    def test_null_dq_rules_parsed_as_empty_list(self, mock_spark, run_date, opco):
        from notebooks.01_framework_core import MetadataManager

        mock_row = make_mock_row(
            table_id="ground_global_daily",
            source_system="DELTA_LAKE",
            source_table_name="country_daily",
            target_system="DELTA_LAKE",
            target_table_name="global_daily",
            target_dataset_layer="GLOBAL",
            opco="GROUND",
            ingestion_mode="FULL",
            watermark_column=None,
            partition_col="load_date",
            merge_keys="opco,effective_date,region_code",
            source_filter=None,
            load_frequency="DAILY",
            dq_threshold_pct=99.0,
            is_active=True,
            data_quality_rules=None,   # NULL in DB
        )
        mock_spark.sql.return_value.collect.return_value = [mock_row]
        mgr = MetadataManager(mock_spark, opco, run_date)
        configs = mgr.get_table_configs()
        assert configs[0].data_quality_rules == []


# ===========================================================================
# Tests: MetadataManager.check_upstream_dq_passed
# ===========================================================================
class TestUpstreamDQGate:

    def test_all_upstream_pass(self, mock_spark, run_date, opco):
        from notebooks.01_framework_core import MetadataManager

        mock_row = make_mock_row(
            upstream_table_id="ground_account_daily",
            dq_passed=True,
        )
        mock_spark.sql.return_value.collect.return_value = [mock_row]
        mgr = MetadataManager(mock_spark, opco, run_date)
        assert mgr.check_upstream_dq_passed("FACILITY") is True

    def test_upstream_dq_failed(self, mock_spark, run_date, opco):
        from notebooks.01_framework_core import MetadataManager

        mock_row = make_mock_row(
            upstream_table_id="ground_account_daily",
            dq_passed=False,
        )
        mock_spark.sql.return_value.collect.return_value = [mock_row]
        mgr = MetadataManager(mock_spark, opco, run_date)
        assert mgr.check_upstream_dq_passed("FACILITY") is False

    def test_no_dependencies_allows_execution(self, mock_spark, run_date, opco):
        from notebooks.01_framework_core import MetadataManager

        mock_spark.sql.return_value.collect.return_value = []
        mgr = MetadataManager(mock_spark, opco, run_date)
        # No dependency rows → allow (ACCOUNT layer case)
        assert mgr.check_upstream_dq_passed("ACCOUNT") is True


# ===========================================================================
# Tests: MetadataManager.get_retry_config
# ===========================================================================
class TestRetryConfig:

    def test_table_specific_config_returned(self, mock_spark, run_date, opco):
        from notebooks.01_framework_core import MetadataManager

        mock_row = make_mock_row(
            config_id="account_retry",
            table_id="ground_account_daily",
            opco="GROUND",
            max_attempts=5,
            initial_wait_seconds=60,
            backoff_multiplier=2.0,
            max_wait_seconds=600,
            retry_on_errors="TRANSIENT_ERROR",
            alert_on_attempt=3,
            is_active=True,
        )
        mock_spark.sql.return_value.collect.return_value = [mock_row]
        mgr = MetadataManager(mock_spark, opco, run_date)
        cfg = mgr.get_retry_config("ground_account_daily")
        assert cfg["max_attempts"] == 5
        assert cfg["initial_wait_seconds"] == 60

    def test_fallback_to_global_default(self, mock_spark, run_date, opco):
        from notebooks.01_framework_core import MetadataManager
        from config.env_config import PIPELINE_CONFIG

        mock_spark.sql.return_value.collect.return_value = []  # no matching config
        mgr = MetadataManager(mock_spark, opco, run_date)
        cfg = mgr.get_retry_config("unknown_table")
        assert cfg["max_attempts"] == PIPELINE_CONFIG.default_max_attempts


# ===========================================================================
# Tests: RunLogger.make_run_id
# ===========================================================================
class TestRunLogger:

    def test_run_id_is_deterministic(self):
        from notebooks.01_framework_core import RunLogger
        rid1 = RunLogger.make_run_id("dag_a", "task_b", date(2024, 1, 15), 1)
        rid2 = RunLogger.make_run_id("dag_a", "task_b", date(2024, 1, 15), 1)
        assert rid1 == rid2

    def test_run_id_differs_by_attempt(self):
        from notebooks.01_framework_core import RunLogger
        rid1 = RunLogger.make_run_id("dag_a", "task_b", date(2024, 1, 15), 1)
        rid2 = RunLogger.make_run_id("dag_a", "task_b", date(2024, 1, 15), 2)
        assert rid1 != rid2

    def test_run_id_is_32_hex_chars(self):
        from notebooks.01_framework_core import RunLogger
        rid = RunLogger.make_run_id("dag_a", "task_b", date(2024, 1, 15), 1)
        assert len(rid) == 32
        assert all(c in "0123456789abcdef" for c in rid)


# ===========================================================================
# Tests: Transformer registry
# ===========================================================================
class TestTransformerRegistry:

    def test_all_layers_registered(self):
        from notebooks.03_transformation import TRANSFORMER_REGISTRY, PIPELINE_CONFIG
        from config.env_config import PIPELINE_CONFIG as PC
        for layer in PC.layer_order:
            assert layer in TRANSFORMER_REGISTRY, f"Missing transformer for layer {layer}"

    def test_get_transformer_returns_correct_class(self):
        from notebooks.03_transformation import (
            get_transformer,
            AccountTransformer, FacilityTransformer,
            CountryTransformer, GlobalTransformer,
        )
        mock_spark = MagicMock()
        rd = date(2024, 1, 15)

        assert isinstance(get_transformer("ACCOUNT",  mock_spark, rd, "GROUND"), AccountTransformer)
        assert isinstance(get_transformer("FACILITY", mock_spark, rd, "GROUND"), FacilityTransformer)
        assert isinstance(get_transformer("COUNTRY",  mock_spark, rd, "GROUND"), CountryTransformer)
        assert isinstance(get_transformer("GLOBAL",   mock_spark, rd, "GROUND"), GlobalTransformer)

    def test_invalid_layer_raises(self):
        from notebooks.03_transformation import get_transformer
        with pytest.raises(ValueError, match="No transformer registered"):
            get_transformer("NONEXISTENT", MagicMock(), date(2024, 1, 1), "GROUND")

    def test_layer_names_case_insensitive(self):
        from notebooks.03_transformation import get_transformer, AccountTransformer
        mock_spark = MagicMock()
        rd = date(2024, 1, 15)
        assert isinstance(get_transformer("account", mock_spark, rd, "GROUND"), AccountTransformer)
        assert isinstance(get_transformer("Account", mock_spark, rd, "GROUND"), AccountTransformer)


# ===========================================================================
# Tests: Retry handler
# ===========================================================================
class TestRetryHandler:

    def test_succeeds_on_first_attempt(self):
        from utils.retry_handler import with_retry
        counter = {"calls": 0}

        @with_retry(max_attempts=3, initial_wait=0.01)
        def always_succeeds():
            counter["calls"] += 1
            return "ok"

        result = always_succeeds()
        assert result == "ok"
        assert counter["calls"] == 1

    def test_retries_on_failure_then_succeeds(self):
        from utils.retry_handler import with_retry
        counter = {"calls": 0}

        @with_retry(max_attempts=3, initial_wait=0.01, backoff_multiplier=1.0)
        def fails_twice_then_succeeds():
            counter["calls"] += 1
            if counter["calls"] < 3:
                raise RuntimeError("transient error")
            return "ok"

        result = fails_twice_then_succeeds()
        assert result == "ok"
        assert counter["calls"] == 3

    def test_raises_after_max_attempts(self):
        from utils.retry_handler import with_retry
        counter = {"calls": 0}

        @with_retry(max_attempts=2, initial_wait=0.01, backoff_multiplier=1.0)
        def always_fails():
            counter["calls"] += 1
            raise ValueError("permanent error")

        with pytest.raises(ValueError, match="permanent error"):
            always_fails()
        assert counter["calls"] == 2

    def test_backoff_compute(self):
        from utils.retry_handler import _compute_wait
        # attempt=1 → initial_wait * 1
        w1 = _compute_wait(1, 30.0, 2.0, 300.0, 0.0)
        assert abs(w1 - 30.0) < 0.01
        # attempt=2 → initial_wait * 2
        w2 = _compute_wait(2, 30.0, 2.0, 300.0, 0.0)
        assert abs(w2 - 60.0) < 0.01
        # capped at max_wait
        w_cap = _compute_wait(10, 30.0, 2.0, 300.0, 0.0)
        assert w_cap == 300.0
