-- =============================================================================
-- CDL ETL Framework — Pipeline Data Tables
-- Platform : Azure Databricks + Delta Lake
-- Layers   : Account → Facility → Country → Global
-- Each layer has: {layer}_daily  +  {layer}_monthly
-- =============================================================================

CREATE SCHEMA IF NOT EXISTS cdl_data;

-- ===========================================================================
-- ACCOUNT LAYER  (Bronze — closest to raw source)
-- ===========================================================================

CREATE TABLE IF NOT EXISTS cdl_data.account_daily (
    -- Natural Keys
    account_id            STRING        NOT NULL COMMENT 'Unique account identifier',
    opco                  STRING        NOT NULL COMMENT 'Operating company',
    -- Business Columns
    account_name          STRING        COMMENT 'Account name',
    account_type          STRING        COMMENT 'Account classification type',
    account_status        STRING        COMMENT 'ACTIVE | INACTIVE | SUSPENDED',
    account_category      STRING        COMMENT 'Business category of account',
    region_code           STRING        COMMENT 'Geographic region code',
    country_code          STRING        COMMENT 'ISO 3166-1 alpha-2 country code',
    currency_code         STRING        COMMENT 'ISO 4217 currency code',
    credit_limit          DOUBLE        COMMENT 'Account credit limit',
    balance               DOUBLE        COMMENT 'Current account balance',
    transaction_count     BIGINT        COMMENT 'Number of transactions for the day',
    revenue               DOUBLE        COMMENT 'Daily revenue',
    cost                  DOUBLE        COMMENT 'Daily cost',
    -- Temporal
    effective_date        DATE          NOT NULL COMMENT 'Business date for this record',
    last_modified_ts      TIMESTAMP     COMMENT 'Source system last modification timestamp',
    -- Metadata
    load_date             DATE          NOT NULL COMMENT 'ETL load date (partition key)',
    source_system         STRING        COMMENT 'Source system name',
    source_file           STRING        COMMENT 'Source file/table path',
    run_id                STRING        COMMENT 'FK → cdl_table_run_log.run_id',
    dq_passed             BOOLEAN       COMMENT 'DQ validation result for this record',
    created_at            TIMESTAMP     NOT NULL COMMENT 'Row insert time',
    updated_at            TIMESTAMP     NOT NULL COMMENT 'Row last update time',

    CONSTRAINT pk_account_daily PRIMARY KEY (account_id, opco, effective_date)
)
USING DELTA
PARTITIONED BY (load_date, opco)
TBLPROPERTIES (
    'delta.enableChangeDataFeed' = 'true',
    'delta.autoOptimize.optimizeWrite' = 'true',
    'delta.autoOptimize.autoCompact' = 'true',
    'delta.dataSkippingNumIndexedCols' = '4'
)
COMMENT 'Account layer — daily grain';


CREATE TABLE IF NOT EXISTS cdl_data.account_monthly (
    account_id            STRING        NOT NULL,
    opco                  STRING        NOT NULL,
    account_name          STRING,
    account_type          STRING,
    account_status        STRING,
    account_category      STRING,
    region_code           STRING,
    country_code          STRING,
    currency_code         STRING,
    -- Monthly aggregates
    month_year            STRING        NOT NULL COMMENT 'Format: YYYY-MM',
    avg_daily_balance     DOUBLE        COMMENT 'Average daily balance for the month',
    total_revenue         DOUBLE        COMMENT 'Total monthly revenue',
    total_cost            DOUBLE        COMMENT 'Total monthly cost',
    transaction_count     BIGINT        COMMENT 'Total transactions in month',
    active_days           INT           COMMENT 'Number of active days in month',
    -- Metadata
    load_date             DATE          NOT NULL,
    source_system         STRING,
    run_id                STRING,
    dq_passed             BOOLEAN,
    created_at            TIMESTAMP     NOT NULL,
    updated_at            TIMESTAMP     NOT NULL,

    CONSTRAINT pk_account_monthly PRIMARY KEY (account_id, opco, month_year)
)
USING DELTA
PARTITIONED BY (load_date, opco)
TBLPROPERTIES ('delta.enableChangeDataFeed' = 'true', 'delta.autoOptimize.optimizeWrite' = 'true')
COMMENT 'Account layer — monthly grain';


-- ===========================================================================
-- FACILITY LAYER  (Silver — account data enriched with facility attributes)
-- ===========================================================================

CREATE TABLE IF NOT EXISTS cdl_data.facility_daily (
    -- Natural Keys
    facility_id           STRING        NOT NULL COMMENT 'Unique facility identifier',
    account_id            STRING        NOT NULL COMMENT 'FK → account_daily.account_id',
    opco                  STRING        NOT NULL,
    -- Business Columns
    facility_name         STRING        COMMENT 'Facility name',
    facility_type         STRING        COMMENT 'WAREHOUSE | OFFICE | DEPOT | HUB',
    facility_status       STRING        COMMENT 'ACTIVE | INACTIVE | UNDER_MAINTENANCE',
    facility_category     STRING,
    country_code          STRING        COMMENT 'ISO country code of facility location',
    region_code           STRING,
    city                  STRING,
    postal_code           STRING,
    -- Account-derived columns (joined from Account layer)
    account_name          STRING,
    account_type          STRING,
    account_status        STRING,
    -- Operational metrics (daily)
    shipment_count        BIGINT        COMMENT 'Daily shipment count through facility',
    volume_kg             DOUBLE        COMMENT 'Total volume in kilograms',
    revenue               DOUBLE        COMMENT 'Daily revenue attributed to facility',
    cost                  DOUBLE        COMMENT 'Daily cost attributed to facility',
    on_time_delivery_pct  DOUBLE        COMMENT 'On-time delivery percentage (0-100)',
    utilisation_pct       DOUBLE        COMMENT 'Facility utilisation percentage (0-100)',
    effective_date        DATE          NOT NULL,
    last_modified_ts      TIMESTAMP,
    -- Metadata
    load_date             DATE          NOT NULL,
    source_system         STRING,
    run_id                STRING,
    dq_passed             BOOLEAN,
    created_at            TIMESTAMP     NOT NULL,
    updated_at            TIMESTAMP     NOT NULL,

    CONSTRAINT pk_facility_daily PRIMARY KEY (facility_id, account_id, opco, effective_date)
)
USING DELTA
PARTITIONED BY (load_date, opco)
TBLPROPERTIES ('delta.enableChangeDataFeed' = 'true', 'delta.autoOptimize.optimizeWrite' = 'true')
COMMENT 'Facility layer — daily grain — enriched with account attributes';


CREATE TABLE IF NOT EXISTS cdl_data.facility_monthly (
    facility_id           STRING        NOT NULL,
    account_id            STRING        NOT NULL,
    opco                  STRING        NOT NULL,
    facility_name         STRING,
    facility_type         STRING,
    facility_status       STRING,
    country_code          STRING,
    region_code           STRING,
    month_year            STRING        NOT NULL,
    -- Monthly aggregates
    total_shipments       BIGINT,
    total_volume_kg       DOUBLE,
    total_revenue         DOUBLE,
    total_cost            DOUBLE,
    avg_on_time_pct       DOUBLE,
    avg_utilisation_pct   DOUBLE,
    active_days           INT,
    -- Metadata
    load_date             DATE          NOT NULL,
    source_system         STRING,
    run_id                STRING,
    dq_passed             BOOLEAN,
    created_at            TIMESTAMP     NOT NULL,
    updated_at            TIMESTAMP     NOT NULL,

    CONSTRAINT pk_facility_monthly PRIMARY KEY (facility_id, account_id, opco, month_year)
)
USING DELTA
PARTITIONED BY (load_date, opco)
TBLPROPERTIES ('delta.enableChangeDataFeed' = 'true', 'delta.autoOptimize.optimizeWrite' = 'true')
COMMENT 'Facility layer — monthly grain';


-- ===========================================================================
-- COUNTRY LAYER  (Silver+ — facility data rolled up to country)
-- ===========================================================================

CREATE TABLE IF NOT EXISTS cdl_data.country_daily (
    -- Natural Keys
    country_code          STRING        NOT NULL COMMENT 'ISO 3166-1 alpha-2',
    opco                  STRING        NOT NULL,
    -- Descriptive
    country_name          STRING,
    region_code           STRING,
    region_name           STRING,
    currency_code         STRING,
    -- Facility roll-up metrics (daily)
    total_facilities      INT           COMMENT 'Active facility count in country',
    total_accounts        INT           COMMENT 'Active account count in country',
    shipment_count        BIGINT        COMMENT 'Total daily shipments in country',
    volume_kg             DOUBLE        COMMENT 'Total daily volume (kg)',
    revenue               DOUBLE        COMMENT 'Total daily revenue',
    cost                  DOUBLE        COMMENT 'Total daily cost',
    gross_margin          DOUBLE        COMMENT 'Revenue minus cost',
    avg_on_time_pct       DOUBLE,
    avg_utilisation_pct   DOUBLE,
    effective_date        DATE          NOT NULL,
    -- Metadata
    load_date             DATE          NOT NULL,
    source_system         STRING,
    run_id                STRING,
    dq_passed             BOOLEAN,
    created_at            TIMESTAMP     NOT NULL,
    updated_at            TIMESTAMP     NOT NULL,

    CONSTRAINT pk_country_daily PRIMARY KEY (country_code, opco, effective_date)
)
USING DELTA
PARTITIONED BY (load_date, opco)
TBLPROPERTIES ('delta.enableChangeDataFeed' = 'true', 'delta.autoOptimize.optimizeWrite' = 'true')
COMMENT 'Country layer — daily grain — facility data aggregated to country level';


CREATE TABLE IF NOT EXISTS cdl_data.country_monthly (
    country_code          STRING        NOT NULL,
    opco                  STRING        NOT NULL,
    country_name          STRING,
    region_code           STRING,
    region_name           STRING,
    currency_code         STRING,
    month_year            STRING        NOT NULL,
    total_facilities      INT,
    total_accounts        INT,
    total_shipments       BIGINT,
    total_volume_kg       DOUBLE,
    total_revenue         DOUBLE,
    total_cost            DOUBLE,
    gross_margin          DOUBLE,
    avg_on_time_pct       DOUBLE,
    avg_utilisation_pct   DOUBLE,
    yoy_revenue_growth    DOUBLE        COMMENT 'Year-over-year revenue growth %',
    -- Metadata
    load_date             DATE          NOT NULL,
    source_system         STRING,
    run_id                STRING,
    dq_passed             BOOLEAN,
    created_at            TIMESTAMP     NOT NULL,
    updated_at            TIMESTAMP     NOT NULL,

    CONSTRAINT pk_country_monthly PRIMARY KEY (country_code, opco, month_year)
)
USING DELTA
PARTITIONED BY (load_date, opco)
TBLPROPERTIES ('delta.enableChangeDataFeed' = 'true', 'delta.autoOptimize.optimizeWrite' = 'true')
COMMENT 'Country layer — monthly grain';


-- ===========================================================================
-- GLOBAL LAYER  (Gold — country data consolidated to global view)
-- ===========================================================================

CREATE TABLE IF NOT EXISTS cdl_data.global_daily (
    -- Natural Keys
    opco                  STRING        NOT NULL,
    effective_date        DATE          NOT NULL,
    -- Rollup dimensions
    region_code           STRING        COMMENT 'NULL = global total; set = regional breakdown',
    -- Global metrics (daily)
    total_countries       INT           COMMENT 'Active country count',
    total_facilities      INT,
    total_accounts        INT,
    shipment_count        BIGINT,
    volume_kg             DOUBLE,
    revenue               DOUBLE,
    cost                  DOUBLE,
    gross_margin          DOUBLE,
    gross_margin_pct      DOUBLE        COMMENT 'Gross margin as percentage of revenue',
    avg_on_time_pct       DOUBLE,
    avg_utilisation_pct   DOUBLE,
    -- Benchmarks
    prev_day_revenue      DOUBLE        COMMENT 'Previous day revenue (for WoW comparison)',
    dod_revenue_change    DOUBLE        COMMENT 'Day-over-day revenue change %',
    -- Metadata
    load_date             DATE          NOT NULL,
    source_system         STRING,
    run_id                STRING,
    dq_passed             BOOLEAN,
    created_at            TIMESTAMP     NOT NULL,
    updated_at            TIMESTAMP     NOT NULL,

    CONSTRAINT pk_global_daily PRIMARY KEY (opco, effective_date, region_code)
)
USING DELTA
PARTITIONED BY (load_date, opco)
TBLPROPERTIES ('delta.enableChangeDataFeed' = 'true', 'delta.autoOptimize.optimizeWrite' = 'true')
COMMENT 'Global layer — daily grain — highest level executive view';


CREATE TABLE IF NOT EXISTS cdl_data.global_monthly (
    opco                  STRING        NOT NULL,
    month_year            STRING        NOT NULL,
    region_code           STRING,
    total_countries       INT,
    total_facilities      INT,
    total_accounts        INT,
    total_shipments       BIGINT,
    total_volume_kg       DOUBLE,
    total_revenue         DOUBLE,
    total_cost            DOUBLE,
    gross_margin          DOUBLE,
    gross_margin_pct      DOUBLE,
    avg_on_time_pct       DOUBLE,
    avg_utilisation_pct   DOUBLE,
    yoy_revenue_growth    DOUBLE,
    mom_revenue_growth    DOUBLE        COMMENT 'Month-over-month revenue growth %',
    -- Metadata
    load_date             DATE          NOT NULL,
    source_system         STRING,
    run_id                STRING,
    dq_passed             BOOLEAN,
    created_at            TIMESTAMP     NOT NULL,
    updated_at            TIMESTAMP     NOT NULL,

    CONSTRAINT pk_global_monthly PRIMARY KEY (opco, month_year, region_code)
)
USING DELTA
PARTITIONED BY (load_date, opco)
TBLPROPERTIES ('delta.enableChangeDataFeed' = 'true', 'delta.autoOptimize.optimizeWrite' = 'true')
COMMENT 'Global layer — monthly grain — consolidated across all countries';
