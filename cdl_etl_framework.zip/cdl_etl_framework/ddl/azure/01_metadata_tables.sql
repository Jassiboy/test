-- =============================================================================
-- CDL ETL Framework — Metadata / Control Tables
-- Platform : Azure Databricks + Delta Lake
-- Schema   : cdl_metadata  (change to your target catalog/schema)
-- =============================================================================

CREATE SCHEMA IF NOT EXISTS cdl_metadata;

-- ---------------------------------------------------------------------------
-- 1. cdl_table_config
--    Master pipeline topology.  One row per source→target table mapping.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS cdl_metadata.cdl_table_config (
    table_id              STRING        NOT NULL COMMENT 'Unique logical mapping ID e.g. ground_acc_daily_to_fac_daily',
    source_system         STRING        NOT NULL COMMENT 'Source system name e.g. ACCOUNT_DB',
    source_table_name     STRING        NOT NULL COMMENT 'Physical source table/view name',
    target_system         STRING        NOT NULL COMMENT 'Target platform: DELTA_LAKE | BIGQUERY',
    target_table_name     STRING        NOT NULL COMMENT 'Physical target table name',
    target_dataset_layer  STRING        NOT NULL COMMENT 'ACCOUNT | FACILITY | COUNTRY | GLOBAL',
    opco                  STRING        NOT NULL COMMENT 'Operating company: GROUND | FREIGHT | INTERNATIONAL',
    ingestion_mode        STRING        NOT NULL COMMENT 'FULL | INCR | CDC',
    watermark_column      STRING        COMMENT 'Delta column e.g. last_modified_ts',
    partition_col         STRING        COMMENT 'Target partition column e.g. load_date',
    merge_keys            STRING        COMMENT 'Comma-separated PK columns for upsert',
    source_filter         STRING        COMMENT 'Optional SQL WHERE clause applied to source read',
    target_path           STRING        COMMENT 'ADLS/GCS path for Delta table (if path-based)',
    load_frequency        STRING        COMMENT 'DAILY | MONTHLY | BOTH',
    dq_threshold_pct      DOUBLE        COMMENT 'Min % rows passing DQ to consider layer successful (0-100)',
    is_active             BOOLEAN       NOT NULL COMMENT 'Enable/disable this pipeline mapping',
    data_quality_rules    STRING        COMMENT 'JSON array of inline DQ rule references',
    created_at            TIMESTAMP     NOT NULL COMMENT 'Row insertion time',
    updated_at            TIMESTAMP     NOT NULL COMMENT 'Last modification time',
    created_by            STRING        COMMENT 'Who inserted this row',

    CONSTRAINT pk_cdl_table_config PRIMARY KEY (table_id)
)
USING DELTA
TBLPROPERTIES (
    'delta.enableChangeDataFeed' = 'true',
    'delta.autoOptimize.optimizeWrite' = 'true',
    'delta.autoOptimize.autoCompact' = 'true'
)
COMMENT 'Master metadata table — drives all ETL pipeline behaviour';


-- ---------------------------------------------------------------------------
-- 2. cdl_table_run_log
--    Full execution audit log — one row per task attempt.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS cdl_metadata.cdl_table_run_log (
    run_id                STRING        NOT NULL COMMENT 'SHA-256 of dag_id + task_id + execution_date',
    dataset_id            STRING        NOT NULL COMMENT 'FK → cdl_table_config.table_id',
    dag_run_date          DATE          NOT NULL COMMENT 'Logical processing date (Airflow execution_date)',
    dag_id                STRING        NOT NULL COMMENT 'Airflow DAG identifier',
    task_id               STRING        NOT NULL COMMENT 'Airflow task identifier',
    dataset_layer         STRING        NOT NULL COMMENT 'ACCOUNT | FACILITY | COUNTRY | GLOBAL',
    opco                  STRING        NOT NULL COMMENT 'Operating company',
    table_name            STRING        NOT NULL COMMENT 'Table being processed',
    status                STRING        NOT NULL COMMENT 'RUNNING | SUCCESS | FAILED | SKIPPED | HALTED',
    attempt_number        INT           NOT NULL COMMENT 'Retry attempt sequence (starts at 1)',
    rows_read             BIGINT        COMMENT 'Records scanned from source',
    rows_written          BIGINT        COMMENT 'Total records committed to destination',
    rows_rejected         BIGINT        COMMENT 'Records failing inline DQ rules',
    rows_merged           BIGINT        COMMENT 'Records merged (upsert)',
    rows_inserted         BIGINT        COMMENT 'Newly inserted records',
    rows_updated          BIGINT        COMMENT 'Updated records',
    rows_deleted          BIGINT        COMMENT 'Deleted records (CDC)',
    watermark_start       TIMESTAMP     COMMENT 'Low-watermark used in this run',
    watermark_end         TIMESTAMP     COMMENT 'High-watermark used in this run',
    started_at            TIMESTAMP     COMMENT 'Execution start time',
    completed_at          TIMESTAMP     COMMENT 'Execution end time',
    duration_seconds      INT           COMMENT 'Elapsed seconds (computed)',
    dq_results            STRING        COMMENT 'JSON payload of all DQ checks run',
    dq_passed             BOOLEAN       COMMENT 'Overall DQ pass/fail for this run',
    error_code            STRING        COMMENT 'Standardised error category code',
    error_message         STRING        COMMENT 'Full stack trace / exception detail',
    spark_app_id          STRING        COMMENT 'Spark application ID for log correlation',
    cluster_id            STRING        COMMENT 'Databricks / Dataproc cluster ID',
    created_at            TIMESTAMP     NOT NULL COMMENT 'Row creation time',
    updated_at            TIMESTAMP     NOT NULL COMMENT 'Last update time',

    CONSTRAINT pk_cdl_run_log PRIMARY KEY (run_id, attempt_number)
)
USING DELTA
PARTITIONED BY (dag_run_date)
TBLPROPERTIES (
    'delta.enableChangeDataFeed' = 'true',
    'delta.autoOptimize.optimizeWrite' = 'true',
    'delta.logRetentionDuration' = 'interval 90 days'
)
COMMENT 'Full execution audit log — every task attempt is recorded here';


-- ---------------------------------------------------------------------------
-- 3. cdl_dq_rules
--    Named, reusable DQ rule library.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS cdl_metadata.cdl_dq_rules (
    rule_id               STRING        NOT NULL COMMENT 'Unique rule identifier e.g. not_null_account_id',
    rule_name             STRING        NOT NULL COMMENT 'Human-readable rule name',
    rule_type             STRING        NOT NULL COMMENT 'NOT_NULL | RANGE | REGEX | REFERENTIAL | CUSTOM_SQL | ROW_COUNT | UNIQUENESS',
    target_column         STRING        COMMENT 'Column the rule applies to (NULL for table-level rules)',
    rule_expression       STRING        NOT NULL COMMENT 'SQL expression or JSON config defining the check',
    severity              STRING        NOT NULL COMMENT 'CRITICAL | WARNING | INFO',
    error_threshold_pct   DOUBLE        COMMENT 'Max % failures allowed before rule fails (0=zero tolerance)',
    applies_to_layers     STRING        COMMENT 'Comma-separated layers: ACCOUNT,FACILITY,COUNTRY,GLOBAL',
    applies_to_opcos      STRING        COMMENT 'Comma-separated OPCOs or ALL',
    is_active             BOOLEAN       NOT NULL,
    created_at            TIMESTAMP     NOT NULL,
    updated_at            TIMESTAMP     NOT NULL,

    CONSTRAINT pk_cdl_dq_rules PRIMARY KEY (rule_id)
)
USING DELTA
TBLPROPERTIES ('delta.autoOptimize.optimizeWrite' = 'true')
COMMENT 'Reusable DQ rule library — referenced from cdl_table_config.data_quality_rules';


-- ---------------------------------------------------------------------------
-- 4. cdl_pipeline_dependency
--    Defines which upstream layer/table must pass DQ before downstream runs.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS cdl_metadata.cdl_pipeline_dependency (
    dependency_id         STRING        NOT NULL,
    upstream_layer        STRING        NOT NULL COMMENT 'Layer that must succeed first',
    upstream_table_id     STRING        COMMENT 'Specific table_id (NULL = entire layer)',
    downstream_layer      STRING        NOT NULL COMMENT 'Layer blocked until upstream passes',
    downstream_table_id   STRING        COMMENT 'Specific table_id (NULL = entire layer)',
    opco                  STRING        NOT NULL,
    dependency_type       STRING        NOT NULL COMMENT 'DQ_PASS | COMPLETION | ROW_COUNT_MIN',
    threshold_value       DOUBLE        COMMENT 'Numeric threshold for ROW_COUNT_MIN checks',
    is_active             BOOLEAN       NOT NULL,
    created_at            TIMESTAMP     NOT NULL,

    CONSTRAINT pk_cdl_pipeline_dep PRIMARY KEY (dependency_id)
)
USING DELTA
COMMENT 'Layer-level dependency graph — gates downstream execution on upstream success';


-- ---------------------------------------------------------------------------
-- 5. cdl_retry_config
--    Per-table (or default) retry policy.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS cdl_metadata.cdl_retry_config (
    config_id             STRING        NOT NULL,
    table_id              STRING        COMMENT 'FK → cdl_table_config.table_id. NULL = global default',
    opco                  STRING        COMMENT 'OPCO scope. NULL = all OPCOs',
    max_attempts          INT           NOT NULL COMMENT 'Maximum retry attempts (including first try)',
    initial_wait_seconds  INT           NOT NULL COMMENT 'Wait before first retry',
    backoff_multiplier    DOUBLE        NOT NULL COMMENT 'Exponential multiplier e.g. 2.0',
    max_wait_seconds      INT           NOT NULL COMMENT 'Cap on wait time between retries',
    retry_on_errors       STRING        COMMENT 'Comma-separated error codes to retry on (NULL = all)',
    alert_on_attempt      INT           COMMENT 'Send alert when this attempt number is reached',
    is_active             BOOLEAN       NOT NULL,
    created_at            TIMESTAMP     NOT NULL,

    CONSTRAINT pk_cdl_retry_config PRIMARY KEY (config_id)
)
USING DELTA
COMMENT 'Retry policy configuration — supports per-table and global defaults';


-- ---------------------------------------------------------------------------
-- 6. cdl_alert_config
--    Alert routing per pipeline / severity.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS cdl_metadata.cdl_alert_config (
    alert_id              STRING        NOT NULL,
    pipeline_pattern      STRING        NOT NULL COMMENT 'Glob pattern matching table_id or layer',
    opco                  STRING        COMMENT 'OPCO scope. NULL = all',
    severity              STRING        NOT NULL COMMENT 'CRITICAL | WARNING | INFO',
    channel               STRING        NOT NULL COMMENT 'EMAIL | TEAMS | PAGERDUTY | SLACK',
    recipients            STRING        NOT NULL COMMENT 'Comma-separated emails or webhook URLs',
    alert_on_status       STRING        NOT NULL COMMENT 'Comma-separated statuses e.g. FAILED,HALTED',
    message_template      STRING        COMMENT 'Jinja2 template for alert message body',
    is_active             BOOLEAN       NOT NULL,
    created_at            TIMESTAMP     NOT NULL,

    CONSTRAINT pk_cdl_alert_config PRIMARY KEY (alert_id)
)
USING DELTA
COMMENT 'Alert routing configuration — drives notifications for pipeline failures';


-- ---------------------------------------------------------------------------
-- 7. cdl_watermark_state
--    Persistent watermark tracking for incremental loads.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS cdl_metadata.cdl_watermark_state (
    table_id              STRING        NOT NULL COMMENT 'FK → cdl_table_config.table_id',
    opco                  STRING        NOT NULL,
    last_watermark_value  TIMESTAMP     NOT NULL COMMENT 'Last successfully processed watermark',
    last_successful_run   DATE          NOT NULL COMMENT 'Date of last successful run',
    updated_at            TIMESTAMP     NOT NULL,

    CONSTRAINT pk_cdl_watermark PRIMARY KEY (table_id, opco)
)
USING DELTA
COMMENT 'Persistent watermark state for incremental extraction';


-- ---------------------------------------------------------------------------
-- Indexes / Z-ORDER hints (applied post-creation via OPTIMIZE)
-- ---------------------------------------------------------------------------
-- OPTIMIZE cdl_metadata.cdl_table_run_log ZORDER BY (opco, dataset_layer, dag_run_date);
-- OPTIMIZE cdl_metadata.cdl_table_config  ZORDER BY (opco, target_dataset_layer);
