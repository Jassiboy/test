-- =============================================================================
-- CDL ETL Framework — Pipeline Data Tables
-- Platform : GCP BigQuery
-- Layers   : Account → Facility → Country → Global
-- =============================================================================

-- ===========================================================================
-- ACCOUNT LAYER
-- ===========================================================================
CREATE TABLE IF NOT EXISTS `cdl_data.account_daily` (
    account_id            STRING,
    opco                  STRING,
    account_name          STRING,
    account_type          STRING,
    account_status        STRING,
    account_category      STRING,
    region_code           STRING,
    country_code          STRING,
    currency_code         STRING,
    credit_limit          FLOAT64,
    balance               FLOAT64,
    transaction_count     INT64,
    revenue               FLOAT64,
    cost                  FLOAT64,
    effective_date        DATE,
    last_modified_ts      TIMESTAMP,
    load_date             DATE,
    source_system         STRING,
    source_file           STRING,
    run_id                STRING,
    dq_passed             BOOL,
    created_at            TIMESTAMP,
    updated_at            TIMESTAMP
)
PARTITION BY load_date
CLUSTER BY opco, account_id, effective_date
OPTIONS(description='Account layer — daily grain');


CREATE TABLE IF NOT EXISTS `cdl_data.account_monthly` (
    account_id            STRING,
    opco                  STRING,
    account_name          STRING,
    account_type          STRING,
    account_status        STRING,
    account_category      STRING,
    region_code           STRING,
    country_code          STRING,
    currency_code         STRING,
    month_year            STRING,
    avg_daily_balance     FLOAT64,
    total_revenue         FLOAT64,
    total_cost            FLOAT64,
    transaction_count     INT64,
    active_days           INT64,
    load_date             DATE,
    source_system         STRING,
    run_id                STRING,
    dq_passed             BOOL,
    created_at            TIMESTAMP,
    updated_at            TIMESTAMP
)
PARTITION BY load_date
CLUSTER BY opco, account_id
OPTIONS(description='Account layer — monthly grain');


-- ===========================================================================
-- FACILITY LAYER
-- ===========================================================================
CREATE TABLE IF NOT EXISTS `cdl_data.facility_daily` (
    facility_id           STRING,
    account_id            STRING,
    opco                  STRING,
    facility_name         STRING,
    facility_type         STRING,
    facility_status       STRING,
    facility_category     STRING,
    country_code          STRING,
    region_code           STRING,
    city                  STRING,
    postal_code           STRING,
    account_name          STRING,
    account_type          STRING,
    account_status        STRING,
    shipment_count        INT64,
    volume_kg             FLOAT64,
    revenue               FLOAT64,
    cost                  FLOAT64,
    on_time_delivery_pct  FLOAT64,
    utilisation_pct       FLOAT64,
    effective_date        DATE,
    last_modified_ts      TIMESTAMP,
    load_date             DATE,
    source_system         STRING,
    run_id                STRING,
    dq_passed             BOOL,
    created_at            TIMESTAMP,
    updated_at            TIMESTAMP
)
PARTITION BY load_date
CLUSTER BY opco, country_code, facility_id
OPTIONS(description='Facility layer — daily grain');


CREATE TABLE IF NOT EXISTS `cdl_data.facility_monthly` (
    facility_id           STRING,
    account_id            STRING,
    opco                  STRING,
    facility_name         STRING,
    facility_type         STRING,
    facility_status       STRING,
    country_code          STRING,
    region_code           STRING,
    month_year            STRING,
    total_shipments       INT64,
    total_volume_kg       FLOAT64,
    total_revenue         FLOAT64,
    total_cost            FLOAT64,
    avg_on_time_pct       FLOAT64,
    avg_utilisation_pct   FLOAT64,
    active_days           INT64,
    load_date             DATE,
    source_system         STRING,
    run_id                STRING,
    dq_passed             BOOL,
    created_at            TIMESTAMP,
    updated_at            TIMESTAMP
)
PARTITION BY load_date
CLUSTER BY opco, country_code
OPTIONS(description='Facility layer — monthly grain');


-- ===========================================================================
-- COUNTRY LAYER
-- ===========================================================================
CREATE TABLE IF NOT EXISTS `cdl_data.country_daily` (
    country_code          STRING,
    opco                  STRING,
    country_name          STRING,
    region_code           STRING,
    region_name           STRING,
    currency_code         STRING,
    total_facilities      INT64,
    total_accounts        INT64,
    shipment_count        INT64,
    volume_kg             FLOAT64,
    revenue               FLOAT64,
    cost                  FLOAT64,
    gross_margin          FLOAT64,
    avg_on_time_pct       FLOAT64,
    avg_utilisation_pct   FLOAT64,
    effective_date        DATE,
    load_date             DATE,
    source_system         STRING,
    run_id                STRING,
    dq_passed             BOOL,
    created_at            TIMESTAMP,
    updated_at            TIMESTAMP
)
PARTITION BY load_date
CLUSTER BY opco, region_code, country_code
OPTIONS(description='Country layer — daily grain');


CREATE TABLE IF NOT EXISTS `cdl_data.country_monthly` (
    country_code          STRING,
    opco                  STRING,
    country_name          STRING,
    region_code           STRING,
    region_name           STRING,
    currency_code         STRING,
    month_year            STRING,
    total_facilities      INT64,
    total_accounts        INT64,
    total_shipments       INT64,
    total_volume_kg       FLOAT64,
    total_revenue         FLOAT64,
    total_cost            FLOAT64,
    gross_margin          FLOAT64,
    avg_on_time_pct       FLOAT64,
    avg_utilisation_pct   FLOAT64,
    yoy_revenue_growth    FLOAT64,
    load_date             DATE,
    source_system         STRING,
    run_id                STRING,
    dq_passed             BOOL,
    created_at            TIMESTAMP,
    updated_at            TIMESTAMP
)
PARTITION BY load_date
CLUSTER BY opco, region_code
OPTIONS(description='Country layer — monthly grain');


-- ===========================================================================
-- GLOBAL LAYER
-- ===========================================================================
CREATE TABLE IF NOT EXISTS `cdl_data.global_daily` (
    opco                  STRING,
    effective_date        DATE,
    region_code           STRING,
    total_countries       INT64,
    total_facilities      INT64,
    total_accounts        INT64,
    shipment_count        INT64,
    volume_kg             FLOAT64,
    revenue               FLOAT64,
    cost                  FLOAT64,
    gross_margin          FLOAT64,
    gross_margin_pct      FLOAT64,
    avg_on_time_pct       FLOAT64,
    avg_utilisation_pct   FLOAT64,
    prev_day_revenue      FLOAT64,
    dod_revenue_change    FLOAT64,
    load_date             DATE,
    source_system         STRING,
    run_id                STRING,
    dq_passed             BOOL,
    created_at            TIMESTAMP,
    updated_at            TIMESTAMP
)
PARTITION BY load_date
CLUSTER BY opco, effective_date
OPTIONS(description='Global layer — daily grain');


CREATE TABLE IF NOT EXISTS `cdl_data.global_monthly` (
    opco                  STRING,
    month_year            STRING,
    region_code           STRING,
    total_countries       INT64,
    total_facilities      INT64,
    total_accounts        INT64,
    total_shipments       INT64,
    total_volume_kg       FLOAT64,
    total_revenue         FLOAT64,
    total_cost            FLOAT64,
    gross_margin          FLOAT64,
    gross_margin_pct      FLOAT64,
    avg_on_time_pct       FLOAT64,
    avg_utilisation_pct   FLOAT64,
    yoy_revenue_growth    FLOAT64,
    mom_revenue_growth    FLOAT64,
    load_date             DATE,
    source_system         STRING,
    run_id                STRING,
    dq_passed             BOOL,
    created_at            TIMESTAMP,
    updated_at            TIMESTAMP
)
PARTITION BY load_date
CLUSTER BY opco
OPTIONS(description='Global layer — monthly grain');
