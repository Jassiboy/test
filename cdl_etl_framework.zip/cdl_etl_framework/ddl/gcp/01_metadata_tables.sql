-- =============================================================================
-- CDL ETL Framework — Metadata / Control Tables
-- Platform : GCP BigQuery
-- Dataset  : cdl_metadata  (change to your project.dataset)
-- =============================================================================

-- NOTE: BigQuery does not support PRIMARY KEY enforcement, listed as documentation only.
--       Run these via: bq query --use_legacy_sql=false < 01_metadata_tables.sql
--       Or use Terraform / bq mk for dataset creation.

-- ---------------------------------------------------------------------------
-- 1. cdl_table_config
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `cdl_metadata.cdl_table_config` (
    table_id              STRING        OPTIONS(description='Unique logical mapping ID'),
    source_system         STRING        OPTIONS(description='Source system name'),
    source_table_name     STRING        OPTIONS(description='Physical source table/view name'),
    target_system         STRING        OPTIONS(description='DELTA_LAKE | BIGQUERY'),
    target_table_name     STRING        OPTIONS(description='Physical target table name'),
    target_dataset_layer  STRING        OPTIONS(description='ACCOUNT | FACILITY | COUNTRY | GLOBAL'),
    opco                  STRING        OPTIONS(description='GROUND | FREIGHT | INTERNATIONAL'),
    ingestion_mode        STRING        OPTIONS(description='FULL | INCR | CDC'),
    watermark_column      STRING        OPTIONS(description='Delta column for incremental'),
    partition_col         STRING        OPTIONS(description='Target partition column'),
    merge_keys            STRING        OPTIONS(description='Comma-separated PK columns for upsert'),
    source_filter         STRING        OPTIONS(description='Optional SQL WHERE clause'),
    target_path           STRING        OPTIONS(description='GCS path for Delta/Parquet (if path-based)'),
    load_frequency        STRING        OPTIONS(description='DAILY | MONTHLY | BOTH'),
    dq_threshold_pct      FLOAT64       OPTIONS(description='Min % rows passing DQ (0-100)'),
    is_active             BOOL          OPTIONS(description='Enable/disable this mapping'),
    data_quality_rules    STRING        OPTIONS(description='JSON array of DQ rule references'),
    created_at            TIMESTAMP     OPTIONS(description='Row insertion time'),
    updated_at            TIMESTAMP     OPTIONS(description='Last modification time'),
    created_by            STRING        OPTIONS(description='Owner/creator')
)
OPTIONS(
    description='Master metadata table — drives all ETL pipeline behaviour'
);


-- ---------------------------------------------------------------------------
-- 2. cdl_table_run_log
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `cdl_metadata.cdl_table_run_log` (
    run_id                STRING        OPTIONS(description='SHA-256 of dag_id+task_id+execution_date'),
    dataset_id            STRING        OPTIONS(description='FK → cdl_table_config.table_id'),
    dag_run_date          DATE          OPTIONS(description='Logical processing date'),
    dag_id                STRING        OPTIONS(description='Airflow DAG identifier'),
    task_id               STRING        OPTIONS(description='Airflow task identifier'),
    dataset_layer         STRING        OPTIONS(description='ACCOUNT | FACILITY | COUNTRY | GLOBAL'),
    opco                  STRING        OPTIONS(description='Operating company'),
    table_name            STRING        OPTIONS(description='Table being processed'),
    status                STRING        OPTIONS(description='RUNNING|SUCCESS|FAILED|SKIPPED|HALTED'),
    attempt_number        INT64         OPTIONS(description='Retry attempt (starts at 1)'),
    rows_read             INT64,
    rows_written          INT64,
    rows_rejected         INT64,
    rows_merged           INT64,
    rows_inserted         INT64,
    rows_updated          INT64,
    rows_deleted          INT64,
    watermark_start       TIMESTAMP,
    watermark_end         TIMESTAMP,
    started_at            TIMESTAMP,
    completed_at          TIMESTAMP,
    duration_seconds      INT64,
    dq_results            STRING        OPTIONS(description='JSON payload of DQ checks'),
    dq_passed             BOOL,
    error_code            STRING,
    error_message         STRING,
    spark_app_id          STRING,
    cluster_id            STRING,
    created_at            TIMESTAMP     OPTIONS(description='Row creation time'),
    updated_at            TIMESTAMP     OPTIONS(description='Last update time')
)
PARTITION BY dag_run_date
CLUSTER BY opco, dataset_layer, status
OPTIONS(
    partition_expiration_days=365,
    description='Full execution audit log'
);


-- ---------------------------------------------------------------------------
-- 3. cdl_dq_rules
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `cdl_metadata.cdl_dq_rules` (
    rule_id               STRING,
    rule_name             STRING,
    rule_type             STRING        OPTIONS(description='NOT_NULL|RANGE|REGEX|REFERENTIAL|CUSTOM_SQL|ROW_COUNT|UNIQUENESS'),
    target_column         STRING,
    rule_expression       STRING,
    severity              STRING        OPTIONS(description='CRITICAL | WARNING | INFO'),
    error_threshold_pct   FLOAT64,
    applies_to_layers     STRING,
    applies_to_opcos      STRING,
    is_active             BOOL,
    created_at            TIMESTAMP,
    updated_at            TIMESTAMP
)
OPTIONS(description='Reusable DQ rule library');


-- ---------------------------------------------------------------------------
-- 4. cdl_pipeline_dependency
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `cdl_metadata.cdl_pipeline_dependency` (
    dependency_id         STRING,
    upstream_layer        STRING,
    upstream_table_id     STRING,
    downstream_layer      STRING,
    downstream_table_id   STRING,
    opco                  STRING,
    dependency_type       STRING        OPTIONS(description='DQ_PASS|COMPLETION|ROW_COUNT_MIN'),
    threshold_value       FLOAT64,
    is_active             BOOL,
    created_at            TIMESTAMP
)
OPTIONS(description='Layer dependency graph');


-- ---------------------------------------------------------------------------
-- 5. cdl_retry_config
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `cdl_metadata.cdl_retry_config` (
    config_id             STRING,
    table_id              STRING,
    opco                  STRING,
    max_attempts          INT64,
    initial_wait_seconds  INT64,
    backoff_multiplier    FLOAT64,
    max_wait_seconds      INT64,
    retry_on_errors       STRING,
    alert_on_attempt      INT64,
    is_active             BOOL,
    created_at            TIMESTAMP
)
OPTIONS(description='Retry policy configuration');


-- ---------------------------------------------------------------------------
-- 6. cdl_alert_config
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `cdl_metadata.cdl_alert_config` (
    alert_id              STRING,
    pipeline_pattern      STRING,
    opco                  STRING,
    severity              STRING,
    channel               STRING        OPTIONS(description='EMAIL|TEAMS|PAGERDUTY|SLACK'),
    recipients            STRING,
    alert_on_status       STRING,
    message_template      STRING,
    is_active             BOOL,
    created_at            TIMESTAMP
)
OPTIONS(description='Alert routing configuration');


-- ---------------------------------------------------------------------------
-- 7. cdl_watermark_state
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `cdl_metadata.cdl_watermark_state` (
    table_id              STRING,
    opco                  STRING,
    last_watermark_value  TIMESTAMP,
    last_successful_run   DATE,
    updated_at            TIMESTAMP
)
CLUSTER BY table_id, opco
OPTIONS(description='Persistent watermark state for incremental loads');
