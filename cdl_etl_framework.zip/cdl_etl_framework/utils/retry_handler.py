"""
cdl_etl_framework/utils/retry_handler.py
=========================================
Exponential-backoff retry decorator and context manager.
Used by IngestionEngine and any utility that calls external services.
"""

import functools
import logging
import random
import time
import traceback
from typing import Any, Callable, Optional, Tuple, Type

logger = logging.getLogger("cdl.retry_handler")


# ===========================================================================
# Core retry logic
# ===========================================================================
def with_retry(
    max_attempts: int = 3,
    initial_wait: float = 30.0,
    backoff_multiplier: float = 2.0,
    max_wait: float = 300.0,
    jitter_fraction: float = 0.1,
    retryable_exceptions: Tuple[Type[Exception], ...] = (Exception,),
    on_retry: Optional[Callable[[int, Exception], None]] = None,
):
    """
    Decorator factory — wraps a function with exponential backoff retry logic.

    Parameters
    ----------
    max_attempts       : total number of attempts (including first try)
    initial_wait       : seconds to wait before first retry
    backoff_multiplier : multiplier applied to wait on each subsequent attempt
    max_wait           : upper bound on wait time (seconds)
    jitter_fraction    : adds random jitter as a fraction of wait (0.1 = ±10%)
    retryable_exceptions: only retry on these exception types
    on_retry           : optional callback(attempt, exception) fired before each retry

    Usage
    -----
    @with_retry(max_attempts=3, initial_wait=30, backoff_multiplier=2.0)
    def load_data():
        ...

    or as a one-off:
        result = retry(load_data, max_attempts=3)
    """
    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        def wrapper(*args, **kwargs) -> Any:
            last_exc = None
            for attempt in range(1, max_attempts + 1):
                try:
                    return func(*args, **kwargs)
                except retryable_exceptions as exc:
                    last_exc = exc
                    if attempt == max_attempts:
                        logger.error(
                            f"[retry] {func.__name__} FAILED after {max_attempts} attempts. "
                            f"Last error: {type(exc).__name__}: {exc}"
                        )
                        raise

                    wait = _compute_wait(
                        attempt, initial_wait, backoff_multiplier, max_wait, jitter_fraction
                    )
                    logger.warning(
                        f"[retry] {func.__name__} attempt {attempt}/{max_attempts} failed: "
                        f"{type(exc).__name__}: {exc}. Retrying in {wait:.1f}s …"
                    )
                    if on_retry:
                        try:
                            on_retry(attempt, exc)
                        except Exception:
                            pass
                    time.sleep(wait)

            raise last_exc  # unreachable, but satisfies type checkers
        return wrapper
    return decorator


def retry(
    func: Callable,
    *args,
    max_attempts: int = 3,
    initial_wait: float = 30.0,
    backoff_multiplier: float = 2.0,
    max_wait: float = 300.0,
    **kwargs,
) -> Any:
    """Functional interface for one-off retry without decorator syntax."""
    decorated = with_retry(
        max_attempts=max_attempts,
        initial_wait=initial_wait,
        backoff_multiplier=backoff_multiplier,
        max_wait=max_wait,
    )(func)
    return decorated(*args, **kwargs)


# ===========================================================================
# Delta Lake rollback helper
# ===========================================================================
def rollback_delta(spark: Any, table_name: str, logger_instance=None) -> bool:
    """
    Roll back a Delta table to its previous version after a failed write.
    Uses RESTORE TABLE … TO VERSION AS OF.

    Returns True if rollback succeeded, False otherwise.
    """
    log = logger_instance or logger
    try:
        history = spark.sql(
            f"DESCRIBE HISTORY {table_name} LIMIT 2"
        ).collect()

        if len(history) < 2:
            log.warning(f"[rollback] {table_name} has no prior version to restore to.")
            return False

        restore_version = history[1]["version"]
        log.warning(
            f"[rollback] Restoring {table_name} to version {restore_version} …"
        )
        spark.sql(
            f"RESTORE TABLE {table_name} TO VERSION AS OF {restore_version}"
        )
        log.info(f"[rollback] {table_name} restored to version {restore_version}. ✓")
        return True

    except Exception as exc:
        log.error(f"[rollback] Failed to restore {table_name}: {exc}")
        return False


# ===========================================================================
# Internal helpers
# ===========================================================================
def _compute_wait(
    attempt: int,
    initial_wait: float,
    multiplier: float,
    max_wait: float,
    jitter_fraction: float,
) -> float:
    wait = min(initial_wait * (multiplier ** (attempt - 1)), max_wait)
    jitter = random.uniform(-jitter_fraction * wait, jitter_fraction * wait)
    return max(0.0, wait + jitter)
