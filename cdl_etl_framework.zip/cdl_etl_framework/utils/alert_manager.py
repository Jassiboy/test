"""
cdl_etl_framework/utils/alert_manager.py
=========================================
Multi-channel alerting (Email / Microsoft Teams / Slack).
Channel and recipient routing is driven from cdl_alert_config metadata table.
"""

import fnmatch
import json
import logging
import os
import smtplib
import urllib.request
from datetime import datetime, timezone
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from typing import Optional

logger = logging.getLogger("cdl.alert_manager")


class AlertManager:
    """
    Reads alert routing from cdl_alert_config and dispatches notifications.
    Supports: EMAIL, TEAMS, SLACK.
    Fails silently — alerting should never block the pipeline.
    """

    def __init__(self, spark, meta_mgr):
        self.spark = spark
        self.meta_mgr = meta_mgr
        self._alert_configs: Optional[list[dict]] = None

    def send(
        self,
        table_cfg,
        run_id: str,
        status: str,
        message: str,
        severity: str = "CRITICAL",
    ):
        """Dispatch alert for a pipeline event. Never raises."""
        try:
            configs = self._get_matching_configs(
                table_id=table_cfg.table_id,
                opco=table_cfg.opco,
                severity=severity,
                status=status,
            )
            if not configs:
                return

            body = self._format_message(table_cfg, run_id, status, message, severity)

            for cfg in configs:
                channel = cfg["channel"].upper()
                recipients = cfg["recipients"]
                try:
                    if channel == "EMAIL":
                        self._send_email(recipients, body, severity, table_cfg.table_id)
                    elif channel == "TEAMS":
                        self._send_teams(recipients, body, severity, table_cfg.table_id)
                    elif channel == "SLACK":
                        self._send_slack(recipients, body, severity, table_cfg.table_id)
                    else:
                        logger.warning(f"Unknown alert channel: {channel}")
                except Exception as e:
                    logger.error(f"Alert dispatch failed [{channel}]: {e}")

        except Exception as exc:
            logger.error(f"AlertManager.send() failed (non-blocking): {exc}")

    # -----------------------------------------------------------------------
    # Config loading
    # -----------------------------------------------------------------------
    def _get_matching_configs(
        self,
        table_id: str,
        opco: str,
        severity: str,
        status: str,
    ) -> list[dict]:
        if self._alert_configs is None:
            from config.env_config import get_metadata_db
            mdb = get_metadata_db()
            rows = self.spark.sql(
                f"SELECT * FROM {mdb}.cdl_alert_config WHERE is_active = true"
            ).collect()
            self._alert_configs = [r.asDict() for r in rows]

        matched = []
        for cfg in self._alert_configs:
            # Pattern match on table_id or layer
            pattern = cfg.get("pipeline_pattern", "*")
            if not fnmatch.fnmatch(table_id, pattern):
                continue
            # OPCO scope
            cfg_opco = cfg.get("opco")
            if cfg_opco and cfg_opco.upper() != opco.upper():
                continue
            # Severity
            if cfg.get("severity", "").upper() != severity.upper():
                continue
            # Status
            alert_statuses = [s.strip().upper() for s in
                              cfg.get("alert_on_status", "FAILED").split(",")]
            if status.upper() not in alert_statuses:
                continue
            matched.append(cfg)

        return matched

    # -----------------------------------------------------------------------
    # Message formatting
    # -----------------------------------------------------------------------
    @staticmethod
    def _format_message(table_cfg, run_id, status, message, severity) -> str:
        now = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
        return (
            f"CDL ETL Alert — {severity}\n"
            f"{'='*50}\n"
            f"Status    : {status}\n"
            f"Table     : {table_cfg.table_id}\n"
            f"Layer     : {table_cfg.target_dataset_layer}\n"
            f"OPCO      : {table_cfg.opco}\n"
            f"Run ID    : {run_id}\n"
            f"Timestamp : {now}\n"
            f"{'='*50}\n"
            f"Detail:\n{message}\n"
        )

    # -----------------------------------------------------------------------
    # Email
    # -----------------------------------------------------------------------
    def _send_email(self, recipients: str, body: str, severity: str, table_id: str):
        smtp_host = os.getenv("SMTP_HOST", "smtp.office365.com")
        smtp_port = int(os.getenv("SMTP_PORT", "587"))
        from_addr = os.getenv("ALERT_FROM_EMAIL", "cdl-etl@company.com")
        smtp_user = os.getenv("SMTP_USER", from_addr)
        smtp_pass = os.getenv("SMTP_PASSWORD", "")

        subject = f"[CDL ETL] [{severity}] Pipeline Alert — {table_id}"
        to_list  = [r.strip() for r in recipients.split(",") if r.strip()]

        msg = MIMEMultipart("alternative")
        msg["Subject"] = subject
        msg["From"]    = from_addr
        msg["To"]      = ", ".join(to_list)
        msg.attach(MIMEText(body, "plain"))

        with smtplib.SMTP(smtp_host, smtp_port, timeout=10) as server:
            server.ehlo()
            server.starttls()
            if smtp_pass:
                server.login(smtp_user, smtp_pass)
            server.sendmail(from_addr, to_list, msg.as_string())

        logger.info(f"Alert email sent to {to_list}")

    # -----------------------------------------------------------------------
    # Microsoft Teams
    # -----------------------------------------------------------------------
    def _send_teams(self, webhook_url: str, body: str, severity: str, table_id: str):
        colour = "FF0000" if severity == "CRITICAL" else "FFA500"
        payload = {
            "@type": "MessageCard",
            "@context": "http://schema.org/extensions",
            "themeColor": colour,
            "summary": f"CDL ETL Alert — {table_id}",
            "sections": [{
                "activityTitle": f"CDL ETL Alert [{severity}]",
                "activitySubtitle": table_id,
                "text": body.replace("\n", "<br>"),
            }]
        }
        data = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(
            webhook_url,
            data=data,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=10) as resp:
            if resp.status not in (200, 204):
                raise RuntimeError(f"Teams webhook returned {resp.status}")
        logger.info(f"Alert sent to Teams webhook")

    # -----------------------------------------------------------------------
    # Slack
    # -----------------------------------------------------------------------
    def _send_slack(self, webhook_url: str, body: str, severity: str, table_id: str):
        icon = ":red_circle:" if severity == "CRITICAL" else ":warning:"
        payload = {
            "text": f"{icon} *CDL ETL Alert [{severity}]* — `{table_id}`\n```{body}```"
        }
        data = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(
            webhook_url,
            data=data,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=10) as resp:
            if resp.status not in (200, 204):
                raise RuntimeError(f"Slack webhook returned {resp.status}")
        logger.info("Alert sent to Slack webhook")
