"""
cdl_etl_framework/utils/schema_validator.py
============================================
Schema drift detection and enforcement.

Compares incoming DataFrame schema against the registered Delta table schema.
Detects: missing columns, new columns, type changes, nullability changes.
Actions: FAIL | WARN | AUTO_EVOLVE (configurable per table in metadata).
"""

import json
import logging
from dataclasses import dataclass
from enum import Enum
from typing import Optional

logger = logging.getLogger("cdl.schema_validator")

try:
    from pyspark.sql import DataFrame, SparkSession
    from pyspark.sql.types import StructType, StructField, DataType
    from delta.tables import DeltaTable
except ImportError:
    pass


class SchemaDriftAction(str, Enum):
    FAIL         = "FAIL"          # Raise exception — hard stop
    WARN         = "WARN"          # Log warning, continue
    AUTO_EVOLVE  = "AUTO_EVOLVE"   # Add new columns, ignore removals


@dataclass
class SchemaDriftReport:
    table_name: str
    has_drift: bool
    missing_columns: list[str]      # In target but not in source
    new_columns: list[str]          # In source but not in target
    type_changes: list[dict]        # {col, source_type, target_type}
    nullability_changes: list[dict] # {col, source_nullable, target_nullable}

    def to_dict(self) -> dict:
        return {
            "table_name":          self.table_name,
            "has_drift":           self.has_drift,
            "missing_columns":     self.missing_columns,
            "new_columns":         self.new_columns,
            "type_changes":        self.type_changes,
            "nullability_changes": self.nullability_changes,
        }

    def summary(self) -> str:
        if not self.has_drift:
            return f"[{self.table_name}] Schema OK — no drift detected"
        parts = []
        if self.missing_columns:
            parts.append(f"missing={self.missing_columns}")
        if self.new_columns:
            parts.append(f"new={self.new_columns}")
        if self.type_changes:
            parts.append(f"type_changes={len(self.type_changes)}")
        if self.nullability_changes:
            parts.append(f"nullability_changes={len(self.nullability_changes)}")
        return f"[{self.table_name}] Schema drift: {', '.join(parts)}"


class SchemaValidator:
    """
    Validates incoming DataFrames against registered Delta table schemas.
    Called by IngestionEngine before write.
    """

    def __init__(
        self,
        spark: "SparkSession",
        action: SchemaDriftAction = SchemaDriftAction.FAIL,
    ):
        self.spark = spark
        self.action = action

    def validate(
        self,
        source_df: "DataFrame",
        target_table: str,
        ignore_cols: Optional[list[str]] = None,
    ) -> tuple["DataFrame", SchemaDriftReport]:
        """
        Validate source_df schema against the existing Delta table.

        Returns:
            (adjusted_df, report)
            adjusted_df: original df, or auto-evolved df if AUTO_EVOLVE
            report: SchemaDriftReport with full diff

        Raises:
            SchemaDriftError if action=FAIL and drift is detected
        """
        ignore = set(ignore_cols or ["run_id", "created_at", "updated_at",
                                      "dq_passed", "load_date", "source_system"])

        # If target does not exist yet, skip validation
        try:
            target_schema = self.spark.table(target_table).schema
        except Exception:
            logger.info(f"Target {target_table} does not exist yet — skipping schema validation")
            report = SchemaDriftReport(
                table_name=target_table, has_drift=False,
                missing_columns=[], new_columns=[],
                type_changes=[], nullability_changes=[],
            )
            return source_df, report

        source_schema = source_df.schema
        report = self._diff(target_table, source_schema, target_schema, ignore)

        if not report.has_drift:
            return source_df, report

        logger.warning(report.summary())

        if self.action == SchemaDriftAction.FAIL:
            raise SchemaDriftError(report.summary())

        elif self.action == SchemaDriftAction.WARN:
            # Drop extra source columns that aren't in target to avoid write failure
            cols_to_keep = [
                f.name for f in target_schema
                if any(sf.name == f.name for sf in source_schema)
            ]
            adjusted = source_df.select(*cols_to_keep)
            return adjusted, report

        elif self.action == SchemaDriftAction.AUTO_EVOLVE:
            # Add missing columns as NULL, drop columns not in target
            from pyspark.sql import functions as F
            adjusted = source_df

            # Add new target columns that are missing in source (as NULL)
            for col_name in report.missing_columns:
                target_field = target_schema[col_name]
                adjusted = adjusted.withColumn(
                    col_name, F.lit(None).cast(target_field.dataType)
                )
                logger.info(f"AUTO_EVOLVE: added null column '{col_name}'")

            # Keep only columns present in target schema (avoid write errors)
            target_col_names = {f.name for f in target_schema}
            adjusted = adjusted.select(
                *[c for c in adjusted.columns if c in target_col_names]
            )
            return adjusted, report

        return source_df, report

    # -----------------------------------------------------------------------
    # Schema diff logic
    # -----------------------------------------------------------------------
    @staticmethod
    def _diff(
        table_name: str,
        source: "StructType",
        target: "StructType",
        ignore: set[str],
    ) -> SchemaDriftReport:
        source_fields = {
            f.name: f for f in source if f.name not in ignore
        }
        target_fields = {
            f.name: f for f in target if f.name not in ignore
        }

        missing_cols  = [n for n in target_fields if n not in source_fields]
        new_cols      = [n for n in source_fields if n not in target_fields]
        type_changes  = []
        null_changes  = []

        for name, t_field in target_fields.items():
            if name in source_fields:
                s_field = source_fields[name]
                # Type comparison via simpleString for readability
                if s_field.dataType.simpleString() != t_field.dataType.simpleString():
                    type_changes.append({
                        "column":      name,
                        "source_type": s_field.dataType.simpleString(),
                        "target_type": t_field.dataType.simpleString(),
                    })
                if s_field.nullable != t_field.nullable:
                    null_changes.append({
                        "column":            name,
                        "source_nullable":   s_field.nullable,
                        "target_nullable":   t_field.nullable,
                    })

        has_drift = bool(missing_cols or new_cols or type_changes or null_changes)
        return SchemaDriftReport(
            table_name=table_name,
            has_drift=has_drift,
            missing_columns=missing_cols,
            new_columns=new_cols,
            type_changes=type_changes,
            nullability_changes=null_changes,
        )


class SchemaDriftError(Exception):
    """Raised when schema drift is detected and action=FAIL."""
    pass
