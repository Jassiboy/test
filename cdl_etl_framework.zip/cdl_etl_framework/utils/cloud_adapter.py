"""
cdl_etl_framework/utils/cloud_adapter.py
=========================================
Thin abstraction layer that hides Azure vs GCP differences from the pipeline code.
All cloud-specific I/O is routed through this class.
"""

import os
import logging
from typing import Optional

logger = logging.getLogger("cdl.cloud_adapter")

try:
    from pyspark.sql import DataFrame, SparkSession
    from pyspark.sql import functions as F
except ImportError:
    pass

from config.env_config import ENV, get_cloud_config, get_storage_base


class CloudAdapter:
    """
    Routes reads/writes to the correct cloud storage and compute platform.
    Single entry point for all external I/O.
    """

    def __init__(self, spark: "SparkSession"):
        self.spark = spark
        self.env = ENV
        self.cfg = get_cloud_config()
        self.base_path = get_storage_base()

    # -----------------------------------------------------------------------
    # External source reads
    # -----------------------------------------------------------------------
    def read_external(
        self,
        source_system: str,
        table_name: str,
        options: Optional[dict] = None,
    ) -> "DataFrame":
        """
        Read data from an external source system.
        In production: replace the simulation block with your actual JDBC / API reads.
        """
        opts = options or {}
        src = source_system.upper()

        if src == "ACCOUNT_DB":
            return self._read_jdbc(
                jdbc_url=self._get_secret("ACCOUNT_DB_JDBC_URL"),
                table=table_name,
                options=opts,
            )

        elif src in ("ORACLE", "EDW"):
            return self._read_jdbc(
                jdbc_url=self._get_secret(f"{src}_JDBC_URL"),
                table=table_name,
                options={**opts, "driver": "oracle.jdbc.OracleDriver"},
            )

        elif src == "SQL_SERVER":
            return self._read_jdbc(
                jdbc_url=self._get_secret("SQLSERVER_JDBC_URL"),
                table=table_name,
                options={**opts, "driver": "com.microsoft.sqlserver.jdbc.SQLServerDriver"},
            )

        elif src.startswith("GCS_") or src.startswith("ADLS_"):
            path = f"{self.base_path}/landing/{table_name}"
            return self.read_parquet(path)

        else:
            raise ValueError(f"Unsupported source_system: {source_system}")

    # -----------------------------------------------------------------------
    # File I/O
    # -----------------------------------------------------------------------
    def read_parquet(self, path: str) -> "DataFrame":
        """Read Parquet from ADLS or GCS."""
        logger.debug(f"Reading parquet: {path}")
        return self.spark.read.format("parquet").load(path)

    def read_csv(self, path: str, header: bool = True, infer_schema: bool = True) -> "DataFrame":
        return (self.spark.read
                .option("header", str(header).lower())
                .option("inferSchema", str(infer_schema).lower())
                .csv(path))

    def write_parquet(self, df: "DataFrame", path: str, mode: str = "overwrite"):
        logger.debug(f"Writing parquet: {path} (mode={mode})")
        df.write.mode(mode).parquet(path)

    # -----------------------------------------------------------------------
    # Delta Lake helpers
    # -----------------------------------------------------------------------
    def get_delta_path(self, layer: str, table_name: str, opco: str) -> str:
        """Construct the Delta table path for a given layer/table."""
        return f"{self.base_path}/delta/{opco.lower()}/{layer.lower()}/{table_name}"

    def optimize_delta(self, table_name: str, zorder_cols: Optional[list[str]] = None):
        """Run OPTIMIZE with optional ZORDER on a Delta table."""
        sql = f"OPTIMIZE {table_name}"
        if zorder_cols:
            sql += f" ZORDER BY ({', '.join(zorder_cols)})"
        logger.info(f"Running: {sql}")
        self.spark.sql(sql)

    def vacuum_delta(self, table_name: str, retention_hours: int = 168):
        """Run VACUUM on a Delta table (default 7-day retention)."""
        logger.info(f"VACUUM {table_name} RETAIN {retention_hours} HOURS")
        self.spark.sql(
            f"VACUUM {table_name} RETAIN {retention_hours} HOURS"
        )

    # -----------------------------------------------------------------------
    # Secrets
    # -----------------------------------------------------------------------
    def _get_secret(self, secret_name: str) -> str:
        """Retrieve a secret from Azure Key Vault or GCP Secret Manager."""
        if self.env == "azure":
            return self._get_azure_secret(secret_name)
        return self._get_gcp_secret(secret_name)

    def _get_azure_secret(self, secret_name: str) -> str:
        try:
            # Databricks-native secret scope
            return self.spark.conf.get(f"spark.cdl.secret.{secret_name}")
        except Exception:
            pass
        # Fallback to env var (dev/test)
        val = os.getenv(secret_name.replace("-", "_").upper())
        if val:
            return val
        raise RuntimeError(
            f"Secret '{secret_name}' not found in Databricks secret scope or environment"
        )

    def _get_gcp_secret(self, secret_name: str) -> str:
        try:
            from google.cloud import secretmanager
            client = secretmanager.SecretManagerServiceClient()
            name = f"{self.cfg.secret_manager_prefix}/{secret_name}/versions/latest"
            response = client.access_secret_version(request={"name": name})
            return response.payload.data.decode("utf-8")
        except ImportError:
            pass
        # Fallback to env var
        val = os.getenv(secret_name.replace("-", "_").upper())
        if val:
            return val
        raise RuntimeError(
            f"Secret '{secret_name}' not found in GCP Secret Manager or environment"
        )

    # -----------------------------------------------------------------------
    # JDBC helper
    # -----------------------------------------------------------------------
    def _read_jdbc(
        self,
        jdbc_url: str,
        table: str,
        options: Optional[dict] = None,
    ) -> "DataFrame":
        opts = options or {}
        reader = (self.spark.read
                  .format("jdbc")
                  .option("url", jdbc_url)
                  .option("dbtable", table)
                  .option("fetchsize", opts.pop("fetchsize", "10000")))
        for k, v in opts.items():
            reader = reader.option(k, v)
        return reader.load()

    # -----------------------------------------------------------------------
    # BigQuery (GCP only)
    # -----------------------------------------------------------------------
    def read_bigquery(self, dataset: str, table: str) -> "DataFrame":
        if self.env != "gcp":
            raise RuntimeError("read_bigquery is only available on GCP")
        return (self.spark.read
                .format("bigquery")
                .option("table", f"{self.cfg.project_id}.{dataset}.{table}")
                .load())

    def write_bigquery(
        self,
        df: "DataFrame",
        dataset: str,
        table: str,
        mode: str = "append",
        partition_field: Optional[str] = None,
    ):
        if self.env != "gcp":
            raise RuntimeError("write_bigquery is only available on GCP")
        writer = (df.write
                  .format("bigquery")
                  .option("table", f"{self.cfg.project_id}.{dataset}.{table}")
                  .mode(mode))
        if partition_field:
            writer = writer.option("partitionField", partition_field)
        writer.save()
