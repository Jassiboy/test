# CDL ETL Framework — Operations Runbook

## 1. Pipeline Overview

The CDL ETL Framework processes data through four sequential layers — Account → Facility → Country → Global — each containing a Daily and a Monthly table. Each layer is gated: if Data Quality checks fail, all downstream layers are halted and an alert is fired.

**Typical daily run time:** 45–90 minutes (depends on data volume and cluster size)

---

## 2. Deployment Steps

### 2.1 First-time setup

```bash
# Step 1 — Create metadata + data schemas
# Azure:
databricks workspace import ddl/azure/01_metadata_tables.sql
databricks workspace import ddl/azure/02_data_tables.sql

# GCP:
bq query --use_legacy_sql=false < ddl/gcp/01_metadata_tables.sql
bq query --use_legacy_sql=false < ddl/gcp/02_data_tables.sql

# Step 2 — Upload framework to cluster-accessible storage
# Azure:
azcopy sync . abfss://cdl-data@<storage_account>.dfs.core.windows.net/cdl_etl_framework/

# GCP:
gsutil -m rsync -r . gs://<bucket>/framework/cdl_etl_framework/

# Step 3 — Configure init script on cluster
# Azure: Add init_scripts/cluster_init_azure.sh to Databricks cluster config
# GCP:   Pass --initialization-actions gs://<bucket>/init_scripts/cluster_init_gcp.sh

# Step 4 — Seed metadata tables
python config/seed_metadata.py --env azure --opco GROUND
python config/seed_metadata.py --env azure --opco FREIGHT    # when ready

# Step 5 — Deploy Airflow DAG
cp dags/cdl_master_dag.py $AIRFLOW_HOME/dags/
airflow dags unpause cdl_master_pipeline
```

### 2.2 Environment variables required

| Variable | Required | Description |
|----------|----------|-------------|
| `CDL_ENV` | Yes | `azure` or `gcp` |
| `CDL_OPCO` | Yes | e.g. `GROUND` |
| `AZURE_STORAGE_ACCOUNT` | Azure | ADLS Gen2 storage account name |
| `AZURE_CONTAINER` | Azure | ADLS container name |
| `GCP_PROJECT_ID` | GCP | GCP project ID |
| `GCS_BUCKET` | GCP | GCS bucket name |
| `CDL_METADATA_SCHEMA` | No | Default: `cdl_metadata` |
| `CDL_DATA_SCHEMA` | No | Default: `cdl_data` |
| `CDL_DQ_THRESHOLD` | No | Default: `95.0` |
| `SMTP_HOST` | No | For email alerts |
| `TEAMS_WEBHOOK_URL` | No | For Teams alerts |

---

## 3. Triggering a Run

### Manual trigger (Airflow)

```bash
# Full pipeline
airflow dags trigger cdl_master_pipeline \
  --conf '{"opco":"GROUND","run_date":"2024-01-15","env":"azure"}'

# Rerun a specific layer only
airflow dags trigger cdl_master_pipeline \
  --conf '{"opco":"GROUND","run_date":"2024-01-15","env":"azure","layer":"FACILITY"}'
```

### Manual trigger (Python)

```bash
# Full pipeline
python notebooks/04_pipeline_runner.py \
  --opco GROUND --run_date 2024-01-15 --env azure

# Single layer, daily only
python notebooks/04_pipeline_runner.py \
  --opco GROUND --run_date 2024-01-15 --env azure \
  --layer FACILITY --frequency DAILY
```

---

## 4. Monitoring & Observability

### 4.1 Check pipeline status

```sql
-- Latest run per table (today)
SELECT
    dataset_layer,
    table_name,
    status,
    attempt_number,
    rows_read,
    rows_written,
    rows_rejected,
    dq_passed,
    duration_seconds,
    error_message
FROM cdl_metadata.cdl_table_run_log
WHERE dag_run_date = CURRENT_DATE()
  AND opco = 'GROUND'
ORDER BY dataset_layer, started_at;
```

### 4.2 DQ results for a specific run

```sql
-- Parse DQ JSON results
SELECT
    table_name,
    dataset_layer,
    dq_passed,
    inline_json.rule_id,
    inline_json.severity,
    inline_json.passed,
    inline_json.failure_pct,
    inline_json.rows_failed
FROM cdl_metadata.cdl_table_run_log
LATERAL VIEW explode(from_json(dq_results, 'array<struct<rule_id:string,severity:string,passed:boolean,failure_pct:double,rows_failed:long>>')) t AS inline_json
WHERE dag_run_date = CURRENT_DATE()
  AND opco = 'GROUND';
```

### 4.3 Historical success rate

```sql
SELECT
    dataset_layer,
    table_name,
    COUNT(*)                                          AS total_runs,
    SUM(CASE WHEN status = 'SUCCESS' THEN 1 ELSE 0 END) AS success_count,
    ROUND(AVG(duration_seconds), 1)                   AS avg_duration_sec,
    ROUND(AVG(rows_written), 0)                       AS avg_rows_written,
    MAX(dag_run_date)                                 AS last_run_date
FROM cdl_metadata.cdl_table_run_log
WHERE dag_run_date >= DATE_SUB(CURRENT_DATE(), 30)
  AND opco = 'GROUND'
GROUP BY dataset_layer, table_name
ORDER BY dataset_layer, table_name;
```

### 4.4 Watermark state

```sql
SELECT * FROM cdl_metadata.cdl_watermark_state
WHERE opco = 'GROUND'
ORDER BY table_id;
```

---

## 5. Common Failure Scenarios & Remediation

### 5.1 DQ threshold not met

**Symptom:** `status = FAILED`, `error_code = DQ_THRESHOLD_NOT_MET`

**Investigation:**
```sql
SELECT dq_results FROM cdl_metadata.cdl_table_run_log
WHERE table_name = 'account_daily'
  AND dag_run_date = '<failed_date>'
  AND status = 'FAILED'
ORDER BY started_at DESC LIMIT 1;
```

**Options:**
- Temporarily lower threshold in `cdl_table_config`:
  ```sql
  UPDATE cdl_metadata.cdl_table_config
  SET dq_threshold_pct = 90.0, updated_at = CURRENT_TIMESTAMP()
  WHERE table_id = 'ground_account_daily';
  ```
- Fix source data and re-trigger
- Disable specific DQ rule if it is incorrectly calibrated

---

### 5.2 Upstream DQ gate blocking downstream

**Symptom:** Facility/Country/Global tasks show `status = HALTED`

**Root cause:** The upstream layer DQ gate prevented downstream execution.

**Remediation:**
1. Fix the upstream layer (see 5.1)
2. Re-trigger from the failed layer:
   ```bash
   airflow dags trigger cdl_master_pipeline \
     --conf '{"opco":"GROUND","run_date":"<date>","layer":"FACILITY"}'
   ```

---

### 5.3 Stale watermark / missing incremental data

**Symptom:** Rows read = 0 for INCR mode; expected data not appearing

**Check:**
```sql
SELECT * FROM cdl_metadata.cdl_watermark_state
WHERE table_id = 'ground_account_daily';
```

**Fix (reset watermark to reload last N days):**
```sql
UPDATE cdl_metadata.cdl_watermark_state
SET last_watermark_value = TIMESTAMPADD(DAY, -3, CURRENT_TIMESTAMP()),
    updated_at           = CURRENT_TIMESTAMP()
WHERE table_id = 'ground_account_daily' AND opco = 'GROUND';
```

---

### 5.4 Cluster / Spark failure

**Symptom:** `error_code = CLUSTER_ERROR` or `UNHANDLED_EXCEPTION`

**Steps:**
1. Check Spark application logs: `cluster_id` and `spark_app_id` are in `cdl_table_run_log`
2. Review Databricks / Dataproc logs for OOM, network, or dependency issues
3. Adjust cluster size if OOM: increase `spark.executor.memory` or worker nodes
4. Re-trigger failed task

---

### 5.5 Schema drift detected

**Symptom:** `error_code = SCHEMA_DRIFT` in run log

**Investigation:**
- Check `error_message` in run log for column diff details
- Review source system changes

**Remediation options:**
- If new columns should be added: update DDL + set `schema_drift_action = AUTO_EVOLVE` in table config
- If columns removed from source: update transformation logic in `03_transformation.py`

---

## 6. Adding a New OPCO

Zero code changes are required. Follow these steps:

```sql
-- 1. Insert table configs for new OPCO (copy from GROUND, change opco value)
INSERT INTO cdl_metadata.cdl_table_config
SELECT
    REPLACE(table_id, 'ground_', 'freight_') AS table_id,
    source_system, source_table_name, target_system, target_table_name,
    target_dataset_layer,
    'FREIGHT' AS opco,
    ingestion_mode, watermark_column, partition_col, merge_keys,
    source_filter, load_frequency, dq_threshold_pct, is_active,
    data_quality_rules,
    CURRENT_TIMESTAMP() AS created_at,
    CURRENT_TIMESTAMP() AS updated_at,
    'ops_team' AS created_by
FROM cdl_metadata.cdl_table_config
WHERE opco = 'GROUND';

-- 2. Insert pipeline dependencies for new OPCO
INSERT INTO cdl_metadata.cdl_pipeline_dependency
SELECT
    REPLACE(dependency_id, 'ground_', 'freight_'),
    upstream_layer,
    REPLACE(upstream_table_id, 'ground_', 'freight_'),
    downstream_layer,
    REPLACE(downstream_table_id, 'ground_', 'freight_'),
    'FREIGHT', dependency_type, threshold_value, is_active,
    CURRENT_TIMESTAMP()
FROM cdl_metadata.cdl_pipeline_dependency
WHERE opco = 'GROUND';
```

Then trigger:
```bash
airflow dags trigger cdl_master_pipeline \
  --conf '{"opco":"FREIGHT","run_date":"2024-01-15","env":"azure"}'
```

---

## 7. Maintenance Tasks

### 7.1 Weekly — Optimize Delta tables

```python
# Run via Databricks notebook or spark-submit
from utils.cloud_adapter import CloudAdapter
adapter = CloudAdapter(spark)

tables = [
    "cdl_data.account_daily",   "cdl_data.account_monthly",
    "cdl_data.facility_daily",  "cdl_data.facility_monthly",
    "cdl_data.country_daily",   "cdl_data.country_monthly",
    "cdl_data.global_daily",    "cdl_data.global_monthly",
    "cdl_metadata.cdl_table_run_log",
]
for t in tables:
    adapter.optimize_delta(t)
```

### 7.2 Monthly — Vacuum Delta tables

```python
for t in tables:
    adapter.vacuum_delta(t, retention_hours=168)   # 7-day retention
```

### 7.3 Quarterly — Archive old run logs

```sql
-- Move run logs older than 90 days to archive table
INSERT INTO cdl_metadata.cdl_table_run_log_archive
SELECT * FROM cdl_metadata.cdl_table_run_log
WHERE dag_run_date < DATE_SUB(CURRENT_DATE(), 90);

DELETE FROM cdl_metadata.cdl_table_run_log
WHERE dag_run_date < DATE_SUB(CURRENT_DATE(), 90);
```

---

## 8. Escalation Contacts

| Level | Contact | When |
|-------|---------|------|
| L1 | CDL Data Engineering on-call | Any FAILED / HALTED status |
| L2 | Senior Data Engineer | Repeated failures, data quality issues |
| L3 | Platform / Infrastructure | Cluster failures, storage issues |
| L4 | Source system team | Source data quality issues |
