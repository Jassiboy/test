"""
cdl_etl_framework/dags/cdl_master_dag.py
=========================================
Airflow DAG: Full CDL pipeline with layer-level dependency gates.

Topology (per OPCO):
  account_daily  ─┐
  account_monthly ─┤─ dq_gate_facility ─┬─ facility_daily  ─┐
                   │                     └─ facility_monthly  ┤
                   │                                          ├─ dq_gate_country ─┬─ country_daily  ─┐
                   │                                          │                    └─ country_monthly ┤
                   │                                          │                                       ├─ dq_gate_global ─┬─ global_daily
                   │                                          │                                       │                  └─ global_monthly
                   └─────────────────────────────────────────┴───────────────────────────────────────┘

Deploy:
    cp dags/cdl_master_dag.py $AIRFLOW_HOME/dags/

Trigger:
    airflow dags trigger cdl_master_pipeline \
        --conf '{"opco":"GROUND","run_date":"2024-01-15","env":"azure"}'
"""

from __future__ import annotations

import json
import os
from datetime import datetime, timedelta

from airflow import DAG
from airflow.models import Variable
from airflow.operators.python import PythonOperator, BranchPythonOperator
from airflow.operators.empty import EmptyOperator
from airflow.utils.trigger_rule import TriggerRule

# ---------------------------------------------------------------------------
# Default DAG arguments
# ---------------------------------------------------------------------------
DEFAULT_ARGS = {
    "owner":            "cdl-data-engineering",
    "depends_on_past":  False,
    "email":            ["cdl-alerts@company.com"],
    "email_on_failure": True,
    "email_on_retry":   False,
    "retries":          0,           # Retries handled inside pipeline code
    "retry_delay":      timedelta(minutes=5),
    "execution_timeout": timedelta(hours=4),
}

# ---------------------------------------------------------------------------
# Reusable task factories
# ---------------------------------------------------------------------------

def _run_layer_task(
    opco: str,
    layer: str,
    frequency: str,
    env: str,
    run_date: str,
    dag_id: str,
    **context,
) -> str:
    """
    Callable for PythonOperator.
    Imports and runs PipelineRunner for a single layer.
    Returns 'success' or 'failure' (used by downstream branch operators).
    """
    from datetime import date
    import sys, os
    framework_path = os.getenv("CDL_FRAMEWORK_PATH", "/opt/cdl_etl_framework")
    if framework_path not in sys.path:
        sys.path.insert(0, framework_path)

    os.environ["CDL_ENV"] = env

    from pyspark.sql import SparkSession
    from notebooks.04_pipeline_runner import PipelineRunner, build_spark

    spark = build_spark(env)
    runner = PipelineRunner(
        spark=spark,
        opco=opco,
        run_date=date.fromisoformat(run_date),
        dag_id=dag_id,
        target_layer=layer,
        frequency=frequency,
    )
    success = runner.run()

    # Push result to XCom for gate operators
    context["ti"].xcom_push(key=f"{layer}_dq_passed", value=success)
    return "success" if success else "failure"


def _dq_gate(
    upstream_layer: str,
    downstream_layer: str,
    **context,
) -> str:
    """
    BranchPythonOperator callable.
    Reads XCom DQ result from upstream task and decides which branch to follow.
    Returns task_id of next task to run, or halt task_id.
    """
    ti = context["ti"]
    passed = ti.xcom_pull(key=f"{upstream_layer}_dq_passed")
    if passed:
        return f"run_{downstream_layer.lower()}_daily"
    return f"halt_{downstream_layer.lower()}"


# ---------------------------------------------------------------------------
# DAG definition
# ---------------------------------------------------------------------------
with DAG(
    dag_id="cdl_master_pipeline",
    description="CDL Metadata-Driven ETL: Account → Facility → Country → Global",
    default_args=DEFAULT_ARGS,
    schedule_interval="0 3 * * *",          # 03:00 UTC daily
    start_date=datetime(2024, 1, 1),
    catchup=False,
    max_active_runs=1,
    tags=["cdl", "etl", "medallion", "production"],
    params={
        "opco":     "GROUND",
        "run_date": "{{ ds }}",
        "env":      "azure",
    },
    render_template_as_native_obj=True,
) as dag:

    # Common task kwargs
    def layer_kwargs(layer: str, frequency: str = "DAILY") -> dict:
        return dict(
            op_kwargs={
                "opco":      "{{ params.opco }}",
                "layer":     layer,
                "frequency": frequency,
                "env":       "{{ params.env }}",
                "run_date":  "{{ params.run_date }}",
                "dag_id":    "cdl_master_pipeline",
            },
            provide_context=True,
        )

    # ── Pipeline start sentinel ──────────────────────────────────────────
    pipeline_start = EmptyOperator(task_id="pipeline_start")
    pipeline_end   = EmptyOperator(
        task_id="pipeline_end",
        trigger_rule=TriggerRule.ALL_DONE,
    )

    # ── ACCOUNT layer ─────────────────────────────────────────────────────
    run_account_daily = PythonOperator(
        task_id="run_account_daily",
        python_callable=_run_layer_task,
        **layer_kwargs("ACCOUNT", "DAILY"),
    )
    run_account_monthly = PythonOperator(
        task_id="run_account_monthly",
        python_callable=_run_layer_task,
        **layer_kwargs("ACCOUNT", "MONTHLY"),
    )

    # ── DQ Gate: ACCOUNT → FACILITY ───────────────────────────────────────
    dq_gate_facility = BranchPythonOperator(
        task_id="dq_gate_facility",
        python_callable=_dq_gate,
        op_kwargs={"upstream_layer": "ACCOUNT", "downstream_layer": "FACILITY"},
        provide_context=True,
        trigger_rule=TriggerRule.ALL_SUCCESS,
    )
    halt_facility = EmptyOperator(task_id="halt_facility")

    # ── FACILITY layer ────────────────────────────────────────────────────
    run_facility_daily = PythonOperator(
        task_id="run_facility_daily",
        python_callable=_run_layer_task,
        **layer_kwargs("FACILITY", "DAILY"),
    )
    run_facility_monthly = PythonOperator(
        task_id="run_facility_monthly",
        python_callable=_run_layer_task,
        **layer_kwargs("FACILITY", "MONTHLY"),
        trigger_rule=TriggerRule.ALL_SUCCESS,
    )

    # ── DQ Gate: FACILITY → COUNTRY ───────────────────────────────────────
    dq_gate_country = BranchPythonOperator(
        task_id="dq_gate_country",
        python_callable=_dq_gate,
        op_kwargs={"upstream_layer": "FACILITY", "downstream_layer": "COUNTRY"},
        provide_context=True,
        trigger_rule=TriggerRule.ALL_SUCCESS,
    )
    halt_country = EmptyOperator(task_id="halt_country")

    # ── COUNTRY layer ─────────────────────────────────────────────────────
    run_country_daily = PythonOperator(
        task_id="run_country_daily",
        python_callable=_run_layer_task,
        **layer_kwargs("COUNTRY", "DAILY"),
    )
    run_country_monthly = PythonOperator(
        task_id="run_country_monthly",
        python_callable=_run_layer_task,
        **layer_kwargs("COUNTRY", "MONTHLY"),
        trigger_rule=TriggerRule.ALL_SUCCESS,
    )

    # ── DQ Gate: COUNTRY → GLOBAL ─────────────────────────────────────────
    dq_gate_global = BranchPythonOperator(
        task_id="dq_gate_global",
        python_callable=_dq_gate,
        op_kwargs={"upstream_layer": "COUNTRY", "downstream_layer": "GLOBAL"},
        provide_context=True,
        trigger_rule=TriggerRule.ALL_SUCCESS,
    )
    halt_global = EmptyOperator(task_id="halt_global")

    # ── GLOBAL layer ──────────────────────────────────────────────────────
    run_global_daily = PythonOperator(
        task_id="run_global_daily",
        python_callable=_run_layer_task,
        **layer_kwargs("GLOBAL", "DAILY"),
    )
    run_global_monthly = PythonOperator(
        task_id="run_global_monthly",
        python_callable=_run_layer_task,
        **layer_kwargs("GLOBAL", "MONTHLY"),
        trigger_rule=TriggerRule.ALL_SUCCESS,
    )

    # =========================================================================
    # Task dependency graph
    # =========================================================================

    # Start → Account
    pipeline_start >> [run_account_daily, run_account_monthly]

    # Account → DQ gate → Facility
    [run_account_daily, run_account_monthly] >> dq_gate_facility
    dq_gate_facility >> halt_facility >> pipeline_end
    dq_gate_facility >> run_facility_daily
    run_facility_daily >> run_facility_monthly

    # Facility → DQ gate → Country
    run_facility_monthly >> dq_gate_country
    dq_gate_country >> halt_country >> pipeline_end
    dq_gate_country >> run_country_daily
    run_country_daily >> run_country_monthly

    # Country → DQ gate → Global
    run_country_monthly >> dq_gate_global
    dq_gate_global >> halt_global >> pipeline_end
    dq_gate_global >> run_global_daily
    run_global_daily >> run_global_monthly

    # All paths → end
    run_global_monthly >> pipeline_end
