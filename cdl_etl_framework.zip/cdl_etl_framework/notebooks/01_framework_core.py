"""
cdl_etl_framework/notebooks/01_framework_core.py
=================================================
Shared framework components — imported by all other notebooks.
Contains:
  - CDLLogger       : structured logging
  - MetadataManager : reads cdl_table_config, cdl_dq_rules, dependency checks
  - RunLogger       : writes to cdl_table_run_log
  - DQEngine        : three-tier data quality validation

Designed to run as a %run or importable module on Databricks / Dataproc.
"""

import hashlib
import json
import logging
import os
import sys
import traceback
from dataclasses import dataclass, field
from datetime import date, datetime, timezone
from typing import Any, Optional

# ---------------------------------------------------------------------------
# Databricks / Spark imports — graceful degradation for unit tests
# ---------------------------------------------------------------------------
try:
    from pyspark.sql import DataFrame, SparkSession
    from pyspark.sql import functions as F
    from pyspark.sql.types import StructType
    from delta.tables import DeltaTable
    SPARK_AVAILABLE = True
except ImportError:
    SPARK_AVAILABLE = False

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from config.env_config import (
    ENV, PIPELINE_CONFIG, get_cloud_config,
    get_metadata_db, get_data_db, get_storage_base,
)


# ===========================================================================
# CDLLogger
# ===========================================================================
class CDLLogger:
    """Structured JSON logger with correlation IDs."""

    def __init__(self, name: str, run_id: str = "", opco: str = "", layer: str = ""):
        self._log = logging.getLogger(f"cdl.{name}")
        if not self._log.handlers:
            handler = logging.StreamHandler(sys.stdout)
            handler.setFormatter(logging.Formatter(
                '{"ts":"%(asctime)s","level":"%(levelname)s","logger":"%(name)s","msg":%(message)s}'
            ))
            self._log.addHandler(handler)
        self._log.setLevel(getattr(logging, os.getenv("CDL_LOG_LEVEL", "INFO")))
        self.context = {"run_id": run_id, "opco": opco, "layer": layer}

    def _fmt(self, msg: str, extra: dict = None) -> str:
        payload = {**self.context, **(extra or {}), "message": msg}
        return json.dumps(payload)

    def info(self, msg: str, **kw):    self._log.info(self._fmt(msg, kw))
    def warning(self, msg: str, **kw): self._log.warning(self._fmt(msg, kw))
    def error(self, msg: str, **kw):   self._log.error(self._fmt(msg, kw))
    def debug(self, msg: str, **kw):   self._log.debug(self._fmt(msg, kw))


# ===========================================================================
# Data classes
# ===========================================================================
@dataclass
class TableConfig:
    table_id: str
    source_system: str
    source_table_name: str
    target_system: str
    target_table_name: str
    target_dataset_layer: str
    opco: str
    ingestion_mode: str
    watermark_column: Optional[str]
    partition_col: Optional[str]
    merge_keys: Optional[str]
    source_filter: Optional[str]
    load_frequency: str
    dq_threshold_pct: float
    is_active: bool
    data_quality_rules: list


@dataclass
class DQResult:
    rule_id: str
    rule_type: str
    target_column: Optional[str]
    severity: str
    passed: bool
    rows_checked: int
    rows_failed: int
    failure_pct: float
    error_message: Optional[str] = None

    def to_dict(self) -> dict:
        return {
            "rule_id": self.rule_id,
            "rule_type": self.rule_type,
            "target_column": self.target_column,
            "severity": self.severity,
            "passed": self.passed,
            "rows_checked": self.rows_checked,
            "rows_failed": self.rows_failed,
            "failure_pct": round(self.failure_pct, 4),
            "error_message": self.error_message,
        }


@dataclass
class RunMetrics:
    rows_read: int = 0
    rows_written: int = 0
    rows_rejected: int = 0
    rows_merged: int = 0
    rows_inserted: int = 0
    rows_updated: int = 0
    rows_deleted: int = 0


# ===========================================================================
# MetadataManager
# ===========================================================================
class MetadataManager:
    """
    Reads from cdl_metadata control tables via Spark SQL.
    All pipeline behaviour is driven from here — no hardcoded config.
    """

    def __init__(self, spark: "SparkSession", opco: str, run_date: date):
        self.spark = spark
        self.opco = opco.upper()
        self.run_date = run_date
        self.metadata_db = get_metadata_db()
        self.logger = CDLLogger("MetadataManager", opco=opco)

    def get_table_configs(
        self,
        layer: Optional[str] = None,
        frequency: Optional[str] = None,
    ) -> list[TableConfig]:
        """Return active table configs for this OPCO, optionally filtered by layer/frequency."""
        where = [f"opco = '{self.opco}'", "is_active = true"]
        if layer:
            where.append(f"target_dataset_layer = '{layer.upper()}'")
        if frequency:
            where.append(
                f"load_frequency IN ('{frequency.upper()}', 'BOTH')"
            )
        sql = f"""
            SELECT * FROM {self.metadata_db}.cdl_table_config
            WHERE {' AND '.join(where)}
            ORDER BY target_dataset_layer, table_id
        """
        rows = self.spark.sql(sql).collect()
        self.logger.info(f"Loaded {len(rows)} table config(s)", layer=layer, frequency=frequency)
        return [self._row_to_config(r) for r in rows]

    def get_dq_rules(self, rule_ids: list[str]) -> list[dict]:
        """Fetch DQ rule definitions by ID list."""
        if not rule_ids:
            return []
        ids = ",".join(f"'{r}'" for r in rule_ids)
        sql = f"""
            SELECT * FROM {self.metadata_db}.cdl_dq_rules
            WHERE rule_id IN ({ids}) AND is_active = true
        """
        return [r.asDict() for r in self.spark.sql(sql).collect()]

    def get_retry_config(self, table_id: str) -> dict:
        """Return retry config for a table, falling back to global default."""
        sql = f"""
            SELECT * FROM {self.metadata_db}.cdl_retry_config
            WHERE is_active = true
              AND (table_id = '{table_id}' OR table_id IS NULL)
              AND (opco = '{self.opco}' OR opco IS NULL)
            ORDER BY table_id DESC NULLS LAST
            LIMIT 1
        """
        rows = self.spark.sql(sql).collect()
        if rows:
            return rows[0].asDict()
        # Hard-coded safety fallback
        return {
            "max_attempts": PIPELINE_CONFIG.default_max_attempts,
            "initial_wait_seconds": PIPELINE_CONFIG.default_initial_wait_sec,
            "backoff_multiplier": PIPELINE_CONFIG.default_backoff_multiplier,
            "max_wait_seconds": PIPELINE_CONFIG.default_max_wait_sec,
        }

    def check_upstream_dq_passed(self, downstream_layer: str) -> bool:
        """
        Returns True only if ALL upstream layers have DQ_PASS for today's run date.
        Queries cdl_table_run_log for the latest attempt per upstream table.
        """
        sql = f"""
            SELECT dep.upstream_table_id, MAX(log.dq_passed) AS dq_passed
            FROM {self.metadata_db}.cdl_pipeline_dependency dep
            LEFT JOIN {self.metadata_db}.cdl_table_run_log log
                ON dep.upstream_table_id = log.dataset_id
               AND log.dag_run_date = '{self.run_date}'
               AND log.opco = '{self.opco}'
               AND log.status = 'SUCCESS'
            WHERE dep.downstream_layer = '{downstream_layer.upper()}'
              AND dep.opco = '{self.opco}'
              AND dep.is_active = true
              AND dep.dependency_type = 'DQ_PASS'
            GROUP BY dep.upstream_table_id
        """
        results = self.spark.sql(sql).collect()
        if not results:
            self.logger.warning(
                f"No dependency rows found for downstream={downstream_layer} — allowing execution"
            )
            return True
        failed = [r["upstream_table_id"] for r in results if not r["dq_passed"]]
        if failed:
            self.logger.error(
                f"Upstream DQ not passed for {downstream_layer}",
                failed_tables=str(failed),
            )
            return False
        return True

    def get_watermark(self, table_id: str) -> Optional[datetime]:
        """Read last watermark from cdl_watermark_state."""
        sql = f"""
            SELECT last_watermark_value FROM {self.metadata_db}.cdl_watermark_state
            WHERE table_id = '{table_id}' AND opco = '{self.opco}'
        """
        rows = self.spark.sql(sql).collect()
        return rows[0]["last_watermark_value"] if rows else None

    def update_watermark(self, table_id: str, new_watermark: datetime):
        """Upsert watermark in cdl_watermark_state."""
        now = datetime.now(timezone.utc).isoformat()
        DeltaTable.forName(
            self.spark, f"{self.metadata_db}.cdl_watermark_state"
        ).alias("t").merge(
            self.spark.createDataFrame([{
                "table_id": table_id,
                "opco": self.opco,
                "last_watermark_value": new_watermark,
                "last_successful_run": self.run_date,
                "updated_at": now,
            }]).alias("s"),
            "t.table_id = s.table_id AND t.opco = s.opco"
        ).whenMatchedUpdateAll().whenNotMatchedInsertAll().execute()

    @staticmethod
    def _row_to_config(row) -> TableConfig:
        d = row.asDict()
        rules = []
        if d.get("data_quality_rules"):
            try:
                rules = json.loads(d["data_quality_rules"])
            except Exception:
                rules = []
        return TableConfig(
            table_id=d["table_id"],
            source_system=d["source_system"],
            source_table_name=d["source_table_name"],
            target_system=d["target_system"],
            target_table_name=d["target_table_name"],
            target_dataset_layer=d["target_dataset_layer"],
            opco=d["opco"],
            ingestion_mode=d["ingestion_mode"],
            watermark_column=d.get("watermark_column"),
            partition_col=d.get("partition_col"),
            merge_keys=d.get("merge_keys"),
            source_filter=d.get("source_filter"),
            load_frequency=d["load_frequency"],
            dq_threshold_pct=float(d.get("dq_threshold_pct") or 95.0),
            is_active=bool(d["is_active"]),
            data_quality_rules=rules,
        )


# ===========================================================================
# RunLogger
# ===========================================================================
class RunLogger:
    """Writes execution audit records to cdl_table_run_log (Delta Lake)."""

    def __init__(self, spark: "SparkSession", dag_id: str, task_id: str):
        self.spark = spark
        self.dag_id = dag_id
        self.task_id = task_id
        self.metadata_db = get_metadata_db()
        self.logger = CDLLogger("RunLogger")

    @staticmethod
    def make_run_id(dag_id: str, task_id: str, run_date: date, attempt: int) -> str:
        raw = f"{dag_id}|{task_id}|{run_date}|{attempt}"
        return hashlib.sha256(raw.encode()).hexdigest()[:32]

    def log_start(
        self,
        table_cfg: TableConfig,
        run_date: date,
        attempt: int,
        watermark_start: Optional[datetime] = None,
    ) -> str:
        run_id = self.make_run_id(self.dag_id, self.task_id, run_date, attempt)
        now = datetime.now(timezone.utc)
        row = {
            "run_id": run_id,
            "dataset_id": table_cfg.table_id,
            "dag_run_date": str(run_date),
            "dag_id": self.dag_id,
            "task_id": self.task_id,
            "dataset_layer": table_cfg.target_dataset_layer,
            "opco": table_cfg.opco,
            "table_name": table_cfg.target_table_name,
            "status": "RUNNING",
            "attempt_number": attempt,
            "rows_read": None,
            "rows_written": None,
            "rows_rejected": None,
            "rows_merged": None,
            "rows_inserted": None,
            "rows_updated": None,
            "rows_deleted": None,
            "watermark_start": watermark_start.isoformat() if watermark_start else None,
            "watermark_end": None,
            "started_at": now.isoformat(),
            "completed_at": None,
            "duration_seconds": None,
            "dq_results": None,
            "dq_passed": None,
            "error_code": None,
            "error_message": None,
            "spark_app_id": self.spark.sparkContext.applicationId,
            "cluster_id": os.getenv("CLUSTER_ID", "unknown"),
            "created_at": now.isoformat(),
            "updated_at": now.isoformat(),
        }
        self._upsert(row)
        return run_id

    def log_success(
        self,
        run_id: str,
        metrics: RunMetrics,
        dq_results: list[DQResult],
        dq_passed: bool,
        watermark_end: Optional[datetime] = None,
        started_at: Optional[datetime] = None,
    ):
        now = datetime.now(timezone.utc)
        duration = int((now - started_at).total_seconds()) if started_at else None
        self._update_status(
            run_id=run_id,
            status="SUCCESS",
            rows_read=metrics.rows_read,
            rows_written=metrics.rows_written,
            rows_rejected=metrics.rows_rejected,
            rows_merged=metrics.rows_merged,
            rows_inserted=metrics.rows_inserted,
            rows_updated=metrics.rows_updated,
            rows_deleted=metrics.rows_deleted,
            watermark_end=watermark_end.isoformat() if watermark_end else None,
            completed_at=now.isoformat(),
            duration_seconds=duration,
            dq_results=json.dumps([r.to_dict() for r in dq_results]),
            dq_passed=dq_passed,
            error_code=None,
            error_message=None,
            updated_at=now.isoformat(),
        )

    def log_failure(
        self,
        run_id: str,
        error_code: str,
        error_message: str,
        metrics: Optional[RunMetrics] = None,
        started_at: Optional[datetime] = None,
        status: str = "FAILED",
    ):
        now = datetime.now(timezone.utc)
        duration = int((now - started_at).total_seconds()) if started_at else None
        m = metrics or RunMetrics()
        self._update_status(
            run_id=run_id,
            status=status,
            rows_read=m.rows_read,
            rows_written=m.rows_written,
            rows_rejected=m.rows_rejected,
            rows_merged=m.rows_merged,
            rows_inserted=m.rows_inserted,
            rows_updated=m.rows_updated,
            rows_deleted=m.rows_deleted,
            watermark_end=None,
            completed_at=now.isoformat(),
            duration_seconds=duration,
            dq_results=None,
            dq_passed=False,
            error_code=error_code,
            error_message=error_message[:4000],
            updated_at=now.isoformat(),
        )

    def _upsert(self, row: dict):
        try:
            df = self.spark.createDataFrame([row])
            target = f"{self.metadata_db}.cdl_table_run_log"
            DeltaTable.forName(self.spark, target).alias("t").merge(
                df.alias("s"),
                "t.run_id = s.run_id AND t.attempt_number = s.attempt_number"
            ).whenNotMatchedInsertAll().execute()
        except Exception as e:
            self.logger.error(f"RunLogger._upsert failed: {e}")

    def _update_status(self, run_id: str, **fields):
        try:
            target = f"{self.metadata_db}.cdl_table_run_log"
            set_clause = ", ".join(
                f"t.{k} = '{v}'" if isinstance(v, str) else
                f"t.{k} = {v}" if v is not None else
                f"t.{k} = NULL"
                for k, v in fields.items()
            )
            self.spark.sql(f"""
                UPDATE {target}
                SET {set_clause}
                WHERE run_id = '{run_id}'
            """)
        except Exception as e:
            self.logger.error(f"RunLogger._update_status failed: {e}")


# ===========================================================================
# DQEngine  — Three-tier validation
# ===========================================================================
class DQEngine:
    """
    Tier 1 — Schema   : NOT_NULL, data type conformance
    Tier 2 — Business : RANGE, REGEX, REFERENTIAL, CUSTOM_SQL
    Tier 3 — Stats    : ROW_COUNT, UNIQUENESS, anomaly vs prior run
    """

    def __init__(self, spark: "SparkSession", logger: CDLLogger):
        self.spark = spark
        self.logger = logger

    def run(
        self,
        df: "DataFrame",
        table_cfg: TableConfig,
        rule_definitions: list[dict],
    ) -> tuple[list[DQResult], bool]:
        """
        Run all DQ rules against df.
        Returns (results_list, overall_pass).
        overall_pass = True only if no CRITICAL rule fails beyond its threshold.
        """
        results: list[DQResult] = []
        total_rows = df.count()

        for rule in rule_definitions:
            result = self._run_rule(df, rule, total_rows)
            results.append(result)
            self.logger.info(
                f"DQ rule [{rule['rule_id']}] {'PASS' if result.passed else 'FAIL'}",
                severity=rule["severity"],
                failure_pct=result.failure_pct,
            )

        # Overall pass: no CRITICAL failure
        overall = all(
            r.passed for r in results
            if r.severity == "CRITICAL"
        )
        # Also check threshold-based pass rate
        if total_rows > 0:
            passing_rows = total_rows - sum(r.rows_failed for r in results if r.severity == "CRITICAL")
            pass_pct = (passing_rows / total_rows) * 100
            if pass_pct < table_cfg.dq_threshold_pct:
                overall = False
                self.logger.error(
                    f"DQ threshold not met: {pass_pct:.2f}% < {table_cfg.dq_threshold_pct}%"
                )

        return results, overall

    def _run_rule(self, df: "DataFrame", rule: dict, total_rows: int) -> DQResult:
        rule_id = rule["rule_id"]
        rule_type = rule["rule_type"]
        column = rule.get("target_column")
        expression = rule["rule_expression"]
        severity = rule["severity"]
        threshold = float(rule.get("error_threshold_pct") or 0.0)

        try:
            if rule_type == "ROW_COUNT":
                cfg = json.loads(expression) if isinstance(expression, str) else expression
                min_rows = cfg.get("min_rows", 1)
                passed = total_rows >= min_rows
                return DQResult(
                    rule_id=rule_id, rule_type=rule_type,
                    target_column=None, severity=severity,
                    passed=passed, rows_checked=total_rows,
                    rows_failed=0 if passed else 1,
                    failure_pct=0.0 if passed else 100.0,
                )

            elif rule_type == "UNIQUENESS":
                dup_count = total_rows - df.select(column).distinct().count()
                failure_pct = (dup_count / total_rows * 100) if total_rows else 0.0
                passed = failure_pct <= threshold
                return DQResult(
                    rule_id=rule_id, rule_type=rule_type,
                    target_column=column, severity=severity,
                    passed=passed, rows_checked=total_rows,
                    rows_failed=dup_count, failure_pct=failure_pct,
                )

            else:
                # NOT_NULL, RANGE, REGEX, REFERENTIAL, CUSTOM_SQL
                # Count rows that FAIL the expression
                failed_df = df.filter(f"NOT ({expression})")
                failed_count = failed_df.count()
                failure_pct = (failed_count / total_rows * 100) if total_rows else 0.0
                passed = failure_pct <= threshold
                return DQResult(
                    rule_id=rule_id, rule_type=rule_type,
                    target_column=column, severity=severity,
                    passed=passed, rows_checked=total_rows,
                    rows_failed=failed_count, failure_pct=failure_pct,
                )

        except Exception as exc:
            self.logger.error(f"DQ rule [{rule_id}] execution error: {exc}")
            return DQResult(
                rule_id=rule_id, rule_type=rule_type,
                target_column=column, severity=severity,
                passed=False, rows_checked=total_rows,
                rows_failed=total_rows, failure_pct=100.0,
                error_message=str(exc)[:500],
            )

    def tag_dq_column(self, df: "DataFrame", rule: dict) -> "DataFrame":
        """Add dq_passed column to dataframe rows based on rule expression."""
        expression = rule["rule_expression"]
        rule_type = rule["rule_type"]
        if rule_type in ("ROW_COUNT", "UNIQUENESS"):
            return df.withColumn("dq_passed", F.lit(True))
        return df.withColumn(
            "dq_passed",
            F.when(F.expr(expression), F.lit(True)).otherwise(F.lit(False))
        )
