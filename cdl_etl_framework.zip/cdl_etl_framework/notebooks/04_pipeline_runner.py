"""
cdl_etl_framework/notebooks/04_pipeline_runner.py
==================================================
End-to-end pipeline orchestration entry point.

Responsibilities:
  1. Parse arguments (opco, run_date, layer, frequency, env)
  2. Initialise Spark with optimal configs
  3. Instantiate MetadataManager, RunLogger, AlertManager
  4. For each layer in dependency order:
       a. Check upstream DQ gate
       b. Load active TableConfig rows for this layer
       c. For each config: get transformer → transform → ingest → DQ → log
       d. Halt downstream if DQ fails
  5. Print summary report

Run modes:
  Full pipeline : python 04_pipeline_runner.py --opco GROUND --run_date 2024-01-15
  Single layer  : python 04_pipeline_runner.py --opco GROUND --run_date 2024-01-15 --layer FACILITY
  Monthly only  : python 04_pipeline_runner.py --opco GROUND --run_date 2024-01-15 --frequency MONTHLY
"""

import argparse
import os
import sys
import traceback
from datetime import date, datetime, timezone
from typing import Optional

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from config.env_config import ENV, PIPELINE_CONFIG, get_cloud_config
from notebooks.01_framework_core import (
    CDLLogger, MetadataManager, RunLogger, RunMetrics,
)
from notebooks.02_ingestion import IngestionEngine
from notebooks.03_transformation import get_transformer
from utils.alert_manager import AlertManager
from utils.cloud_adapter import CloudAdapter

try:
    from pyspark.sql import SparkSession
    from pyspark.sql import functions as F
except ImportError:
    SparkSession = None


# ===========================================================================
# Spark initialisation
# ===========================================================================
def build_spark(env: str) -> "SparkSession":
    """Build a production-grade SparkSession with platform-specific configs."""
    builder = (
        SparkSession.builder
        .appName("CDL_ETL_Pipeline")
        .config("spark.sql.shuffle.partitions",
                str(PIPELINE_CONFIG.spark_shuffle_partitions))
        .config("spark.sql.adaptive.enabled", "true")
        .config("spark.sql.adaptive.coalescePartitions.enabled", "true")
        .config("spark.sql.adaptive.skewJoin.enabled", "true")
        .config("spark.databricks.delta.optimizeWrite.enabled", "true")
        .config("spark.databricks.delta.autoCompact.enabled", "true")
        .config("spark.sql.extensions",
                "io.delta.sql.DeltaSparkSessionExtension")
        .config("spark.sql.catalog.spark_catalog",
                "org.apache.spark.sql.delta.catalog.DeltaCatalog")
    )

    if env == "azure":
        cfg = get_cloud_config()
        builder = builder.config(
            f"fs.azure.account.auth.type.{cfg.storage_account}.dfs.core.windows.net",
            "OAuth"
        )
    elif env == "gcp":
        builder = builder.config(
            "spark.hadoop.fs.gs.impl",
            "com.google.cloud.hadoop.fs.gcs.GoogleHadoopFileSystem"
        )

    return builder.getOrCreate()


# ===========================================================================
# Pipeline Runner
# ===========================================================================
class PipelineRunner:
    def __init__(
        self,
        spark: "SparkSession",
        opco: str,
        run_date: date,
        dag_id: str = "cdl_master_pipeline",
        target_layer: Optional[str] = None,
        frequency: Optional[str] = None,
    ):
        self.spark = spark
        self.opco = opco.upper()
        self.run_date = run_date
        self.dag_id = dag_id
        self.target_layer = target_layer.upper() if target_layer else None
        self.frequency = frequency.upper() if frequency else None
        self.logger = CDLLogger("PipelineRunner", opco=opco)

        self.meta_mgr = MetadataManager(spark, opco, run_date)
        self.run_logger = RunLogger(spark, dag_id=dag_id, task_id="pipeline_runner")
        self.alert_mgr = AlertManager(spark, meta_mgr=self.meta_mgr)
        self.ingestion = IngestionEngine(
            spark=spark,
            meta_mgr=self.meta_mgr,
            run_logger=self.run_logger,
            alert_mgr=self.alert_mgr,
            run_date=run_date,
            dag_id=dag_id,
            task_id="pipeline_runner",
        )

        # Summary tracking
        self.summary: list[dict] = []

    def run(self) -> bool:
        """Execute the full pipeline in layer order. Returns True if all layers pass."""
        self.logger.info(
            "=" * 60 + f"\n  CDL ETL Pipeline START"
            f"\n  OPCO={self.opco}  DATE={self.run_date}"
            f"\n  LAYER={self.target_layer or 'ALL'}  FREQ={self.frequency or 'ALL'}"
            f"\n" + "=" * 60
        )
        started = datetime.now(timezone.utc)
        overall_success = True

        layers = PIPELINE_CONFIG.layer_order
        if self.target_layer:
            layers = [self.target_layer]

        for layer in layers:
            layer_ok = self._run_layer(layer)
            overall_success = overall_success and layer_ok

            if not layer_ok and not self.target_layer:
                self.logger.error(
                    f"Layer {layer} failed — halting downstream layers",
                    layer=layer,
                )
                # Mark remaining layers as HALTED in run log
                remaining = layers[layers.index(layer) + 1:]
                for downstream in remaining:
                    self._halt_layer(downstream)
                break

        self._print_summary(started)
        return overall_success

    # -----------------------------------------------------------------------
    def _run_layer(self, layer: str) -> bool:
        self.logger.info(f"{'─'*40}\n  Processing layer: {layer}\n{'─'*40}")

        # Gate: check upstream DQ before starting this layer
        if layer != "ACCOUNT":
            if not self.meta_mgr.check_upstream_dq_passed(layer):
                self.logger.error(f"DQ gate FAILED for layer {layer} — skipping")
                self.summary.append({"layer": layer, "status": "SKIPPED_DQ_GATE",
                                     "tables": 0, "passed": 0, "failed": 0})
                return False

        # Load table configs for this layer
        configs = self.meta_mgr.get_table_configs(
            layer=layer, frequency=self.frequency
        )
        if not configs:
            self.logger.warning(f"No active configs found for layer={layer} freq={self.frequency}")
            self.summary.append({"layer": layer, "status": "NO_CONFIGS",
                                 "tables": 0, "passed": 0, "failed": 0})
            return True

        transformer = get_transformer(layer, self.spark, self.run_date, self.opco)
        passed = failed = 0

        for cfg in configs:
            self.logger.info(f"  Table: {cfg.table_id} ({cfg.load_frequency})")
            try:
                # Get transformed DataFrame
                if cfg.load_frequency == "DAILY" or cfg.load_frequency == "BOTH":
                    transformed_df = transformer.transform_daily(cfg)
                elif cfg.load_frequency == "MONTHLY":
                    transformed_df = transformer.transform_monthly(cfg)
                else:
                    transformed_df = transformer.transform_daily(cfg)

                # Register as temp view so IngestionEngine can reference it
                transformed_df.createOrReplaceTempView(f"_cdl_stage_{cfg.target_table_name}")

                # Override source to read from our temp view
                original_source = cfg.source_table_name
                cfg.source_table_name = f"_cdl_stage_{cfg.target_table_name}"
                cfg.source_system = "DELTA_LAKE"

                ok = self.ingestion.run_table(cfg)
                cfg.source_table_name = original_source   # restore

                if ok:
                    passed += 1
                    self.logger.info(f"  ✓ {cfg.table_id} SUCCESS")
                else:
                    failed += 1
                    self.logger.error(f"  ✗ {cfg.table_id} FAILED")

            except Exception as exc:
                failed += 1
                self.logger.error(
                    f"  ✗ {cfg.table_id} EXCEPTION: {exc}\n{traceback.format_exc()}"
                )

        layer_ok = failed == 0
        status = "SUCCESS" if layer_ok else "PARTIAL" if passed > 0 else "FAILED"
        self.summary.append({
            "layer": layer, "status": status,
            "tables": len(configs), "passed": passed, "failed": failed,
        })
        return layer_ok

    def _halt_layer(self, layer: str):
        """Log HALTED status for a skipped downstream layer."""
        configs = self.meta_mgr.get_table_configs(layer=layer)
        for cfg in configs:
            run_id = RunLogger.make_run_id(self.dag_id, cfg.table_id, self.run_date, 1)
            self.run_logger.log_failure(
                run_id=run_id,
                error_code="UPSTREAM_DQ_FAILED",
                error_message=f"Halted: upstream DQ gate failed for layer {layer}",
                status="HALTED",
            )

    def _print_summary(self, started: datetime):
        elapsed = (datetime.now(timezone.utc) - started).total_seconds()
        lines = [
            "",
            "=" * 60,
            f"  CDL ETL Pipeline SUMMARY — {self.run_date}",
            f"  OPCO: {self.opco}   Elapsed: {elapsed:.1f}s",
            "=" * 60,
        ]
        for s in self.summary:
            icon = "✓" if s["status"] == "SUCCESS" else "⚠" if s["status"] == "PARTIAL" else "✗"
            lines.append(
                f"  {icon} {s['layer']:10s} | {s['status']:20s} | "
                f"tables={s['tables']} pass={s['passed']} fail={s['failed']}"
            )
        lines.append("=" * 60)
        self.logger.info("\n".join(lines))


# ===========================================================================
# Entry point
# ===========================================================================
def parse_args():
    p = argparse.ArgumentParser(description="CDL ETL Pipeline Runner")
    p.add_argument("--opco",      required=True,  help="Operating company e.g. GROUND")
    p.add_argument("--run_date",  required=True,  help="Processing date YYYY-MM-DD")
    p.add_argument("--layer",     default=None,   help="Run a single layer only")
    p.add_argument("--frequency", default=None,   help="DAILY | MONTHLY | BOTH")
    p.add_argument("--env",       default="azure", choices=["azure", "gcp"])
    p.add_argument("--dag_id",    default="cdl_master_pipeline")
    return p.parse_args()


def main():
    args = parse_args()
    os.environ["CDL_ENV"] = args.env

    run_date = date.fromisoformat(args.run_date)

    spark = build_spark(args.env)
    spark.sparkContext.setLogLevel("WARN")

    runner = PipelineRunner(
        spark=spark,
        opco=args.opco,
        run_date=run_date,
        dag_id=args.dag_id,
        target_layer=args.layer,
        frequency=args.frequency,
    )

    success = runner.run()
    sys.exit(0 if success else 1)


if __name__ == "__main__":
    main()
