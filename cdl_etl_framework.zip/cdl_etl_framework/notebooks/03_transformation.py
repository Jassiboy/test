"""
cdl_etl_framework/notebooks/03_transformation.py
=================================================
Layer-specific transformation logic for all four layers.

Each transformer:
  - Reads from the previous layer's Delta tables
  - Applies business enrichment / aggregation logic
  - Returns a typed DataFrame ready for IngestionEngine to write + DQ-check

Transformers are registered in TRANSFORMER_REGISTRY and selected at runtime
from cdl_table_config.target_dataset_layer — making them metadata-driven.

OPCO=GROUND flows implemented (dummy/representative logic):
  Account  → raw source normalisation
  Facility → join Account, add operational KPIs
  Country  → aggregate Facility to country grain
  Global   → aggregate Country to global grain (daily + monthly)
"""

import os
import sys
from datetime import date, datetime, timezone
from typing import Callable, Optional

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from config.env_config import get_data_db, PIPELINE_CONFIG
from notebooks.01_framework_core import CDLLogger, TableConfig

try:
    from pyspark.sql import DataFrame, SparkSession
    from pyspark.sql import functions as F
    from pyspark.sql.window import Window
except ImportError:
    pass


DATA_DB = get_data_db()


# ===========================================================================
# Base Transformer
# ===========================================================================
class BaseTransformer:
    """Common interface for all layer transformers."""

    def __init__(self, spark: "SparkSession", run_date: date, opco: str):
        self.spark = spark
        self.run_date = run_date
        self.opco = opco.upper()
        self.logger = CDLLogger(
            self.__class__.__name__, opco=opco, layer=self.layer_name
        )

    layer_name: str = "BASE"

    def transform_daily(self, table_cfg: TableConfig) -> "DataFrame":
        raise NotImplementedError

    def transform_monthly(self, table_cfg: TableConfig) -> "DataFrame":
        raise NotImplementedError

    def _read_layer(self, table_name: str, opco: Optional[str] = None) -> "DataFrame":
        """Read from Delta table, filtering by today's load_date and OPCO."""
        op = opco or self.opco
        df = self.spark.table(f"{DATA_DB}.{table_name}")
        return df.filter(
            (F.col("load_date") == F.lit(str(self.run_date))) &
            (F.col("opco") == F.lit(op))
        )

    def _std_meta(self, df: "DataFrame", source_system: str) -> "DataFrame":
        """Append standard metadata columns."""
        now = datetime.now(timezone.utc).isoformat()
        return (df
            .withColumn("load_date", F.lit(str(self.run_date)).cast("date"))
            .withColumn("opco", F.lit(self.opco))
            .withColumn("source_system", F.lit(source_system))
            .withColumn("dq_passed", F.lit(None).cast("boolean"))
            .withColumn("created_at", F.lit(now).cast("timestamp"))
            .withColumn("updated_at", F.lit(now).cast("timestamp")))


# ===========================================================================
# 1. ACCOUNT Transformer  (Raw → Bronze)
# ===========================================================================
class AccountTransformer(BaseTransformer):
    """
    Normalises raw source data into the Account layer schema.
    Source: raw_account_transactions (external DB or landing zone).
    Applies: column standardisation, status normalisation, deduplication.
    """
    layer_name = "ACCOUNT"

    def transform_daily(self, table_cfg: TableConfig) -> "DataFrame":
        self.logger.info("Starting Account daily transformation")

        # Read from external source (simulated as a Spark temp view / Delta table)
        raw_df = self.spark.table(f"{DATA_DB}.{table_cfg.source_table_name}")

        # Filter to today's data
        raw_df = raw_df.filter(
            F.col("last_modified_ts").cast("date") == F.lit(str(self.run_date))
        )

        # --- Business logic: normalise & enrich ---
        transformed = (raw_df
            # Standardise keys
            .withColumn("account_id",       F.trim(F.upper(F.col("account_id"))))
            .withColumn("opco",             F.lit(self.opco))
            # Normalise status to valid values
            .withColumn("account_status",
                F.when(F.upper(F.col("account_status")).isin("A", "ACTIVE"),    F.lit("ACTIVE"))
                 .when(F.upper(F.col("account_status")).isin("I", "INACTIVE"),  F.lit("INACTIVE"))
                 .when(F.upper(F.col("account_status")).isin("S", "SUSPENDED"), F.lit("SUSPENDED"))
                 .otherwise(F.lit("INACTIVE")))
            # Derive effective_date from transaction timestamp
            .withColumn("effective_date",   F.col("last_modified_ts").cast("date"))
            # Ensure numeric columns are non-negative (replace NULLs / negatives)
            .withColumn("revenue",
                F.greatest(F.coalesce(F.col("revenue"), F.lit(0.0)), F.lit(0.0)))
            .withColumn("cost",
                F.greatest(F.coalesce(F.col("cost"), F.lit(0.0)), F.lit(0.0)))
            .withColumn("credit_limit",
                F.greatest(F.coalesce(F.col("credit_limit"), F.lit(0.0)), F.lit(0.0)))
            # Deduplication: keep latest record per account per day
            .withColumn("_rank", F.row_number().over(
                Window.partitionBy("account_id", "opco", "effective_date")
                      .orderBy(F.col("last_modified_ts").desc())
            ))
            .filter(F.col("_rank") == 1)
            .drop("_rank")
        )

        return self._std_meta(transformed, table_cfg.source_system)

    def transform_monthly(self, table_cfg: TableConfig) -> "DataFrame":
        self.logger.info("Starting Account monthly transformation")

        # Aggregate daily account table for the current month
        month_str = self.run_date.strftime("%Y-%m")
        daily_df = self.spark.table(f"{DATA_DB}.account_daily").filter(
            (F.date_format(F.col("effective_date"), "yyyy-MM") == F.lit(month_str)) &
            (F.col("opco") == F.lit(self.opco)) &
            (F.col("dq_passed").isNull() | F.col("dq_passed"))
        )

        monthly = (daily_df
            .groupBy(
                "account_id", "opco", "account_name", "account_type",
                "account_status", "account_category", "region_code",
                "country_code", "currency_code"
            )
            .agg(
                F.lit(month_str).alias("month_year"),
                F.avg("balance").alias("avg_daily_balance"),
                F.sum("revenue").alias("total_revenue"),
                F.sum("cost").alias("total_cost"),
                F.sum("transaction_count").alias("transaction_count"),
                F.countDistinct("effective_date").alias("active_days"),
            )
        )

        return self._std_meta(monthly, table_cfg.source_system)


# ===========================================================================
# 2. FACILITY Transformer  (Account → Silver)
# ===========================================================================
class FacilityTransformer(BaseTransformer):
    """
    Joins Account layer data with facility dimension.
    Enriches with operational KPIs (shipments, utilisation, on-time delivery).
    Source: account_daily + facility dimension (simulated inline).
    """
    layer_name = "FACILITY"

    def transform_daily(self, table_cfg: TableConfig) -> "DataFrame":
        self.logger.info("Starting Facility daily transformation")

        acc_df = self._read_layer("account_daily")

        # In production: read facility dimension from source system
        # Here: simulate via a lateral enrichment / explode pattern
        # Each account maps to 1-N facilities — we simulate a 1:1 for demonstration
        facility_df = (acc_df
            # Derive a synthetic facility_id for demo purposes
            .withColumn("facility_id",
                F.concat_ws("_", F.lit("FAC"), F.col("account_id")))
            .withColumn("facility_name",
                F.concat_ws(" ", F.col("account_name"), F.lit("Facility")))
            .withColumn("facility_type",
                F.when(F.col("account_category") == "CORPORATE", F.lit("HUB"))
                 .when(F.col("account_category") == "SME",       F.lit("DEPOT"))
                 .otherwise(F.lit("WAREHOUSE")))
            .withColumn("facility_status",
                F.when(F.col("account_status") == "ACTIVE",   F.lit("ACTIVE"))
                 .when(F.col("account_status") == "INACTIVE", F.lit("INACTIVE"))
                 .otherwise(F.lit("UNDER_MAINTENANCE")))
            .withColumn("facility_category", F.col("account_category"))
            .withColumn("city",          F.lit("UNKNOWN"))   # enrich from geo lookup in prod
            .withColumn("postal_code",   F.lit(None).cast("string"))
            # Derive operational KPIs (representative calculations)
            .withColumn("shipment_count",
                (F.col("transaction_count") * F.lit(0.8)).cast("long"))
            .withColumn("volume_kg",
                F.col("revenue") * F.lit(0.15))              # proxy: £/kg conversion
            .withColumn("on_time_delivery_pct",
                F.when(F.col("revenue") > 0,
                    F.least(
                        F.lit(100.0),
                        F.greatest(F.lit(0.0),
                            F.lit(95.0) - (F.col("cost") / (F.col("revenue") + F.lit(0.001))) * F.lit(10.0)
                        )
                    )
                ).otherwise(F.lit(0.0)))
            .withColumn("utilisation_pct",
                F.when(F.col("credit_limit") > 0,
                    F.least(F.lit(100.0),
                        (F.col("balance") / F.col("credit_limit")) * F.lit(100.0)
                    )
                ).otherwise(F.lit(0.0)))
            # Keep account-level columns for lineage
            .withColumnRenamed("account_name",   "account_name")
            .withColumnRenamed("account_type",   "account_type")
            .withColumnRenamed("account_status", "account_status")
            .withColumn("effective_date", F.col("effective_date"))
            .withColumn("last_modified_ts", F.col("last_modified_ts"))
        )

        # Select final schema columns
        facility_df = facility_df.select(
            "facility_id", "account_id", "opco",
            "facility_name", "facility_type", "facility_status", "facility_category",
            "country_code", "region_code", "city", "postal_code",
            "account_name", "account_type", "account_status",
            "shipment_count", "volume_kg", "revenue", "cost",
            "on_time_delivery_pct", "utilisation_pct",
            "effective_date", "last_modified_ts",
        )

        return self._std_meta(facility_df, "DELTA_LAKE")

    def transform_monthly(self, table_cfg: TableConfig) -> "DataFrame":
        self.logger.info("Starting Facility monthly transformation")

        month_str = self.run_date.strftime("%Y-%m")
        daily_df = self.spark.table(f"{DATA_DB}.facility_daily").filter(
            (F.date_format(F.col("effective_date"), "yyyy-MM") == F.lit(month_str)) &
            (F.col("opco") == F.lit(self.opco))
        )

        monthly = (daily_df
            .groupBy(
                "facility_id", "account_id", "opco",
                "facility_name", "facility_type", "facility_status",
                "country_code", "region_code"
            )
            .agg(
                F.lit(month_str).alias("month_year"),
                F.sum("shipment_count").alias("total_shipments"),
                F.sum("volume_kg").alias("total_volume_kg"),
                F.sum("revenue").alias("total_revenue"),
                F.sum("cost").alias("total_cost"),
                F.avg("on_time_delivery_pct").alias("avg_on_time_pct"),
                F.avg("utilisation_pct").alias("avg_utilisation_pct"),
                F.countDistinct("effective_date").alias("active_days"),
            )
        )

        return self._std_meta(monthly, "DELTA_LAKE")


# ===========================================================================
# 3. COUNTRY Transformer  (Facility → Silver+)
# ===========================================================================
class CountryTransformer(BaseTransformer):
    """
    Aggregates Facility layer to Country grain.
    Adds country descriptors (name, region, currency).
    Computes gross margin and benchmarks.
    """
    layer_name = "COUNTRY"

    # Simple lookup — in production replace with a Delta dimension table
    COUNTRY_LOOKUP = {
        "US": ("United States",  "AMERICAS", "USD"),
        "GB": ("United Kingdom", "EUROPE",   "GBP"),
        "DE": ("Germany",        "EUROPE",   "EUR"),
        "AU": ("Australia",      "APAC",     "AUD"),
        "SG": ("Singapore",      "APAC",     "SGD"),
        "IN": ("India",          "APAC",     "INR"),
        "BR": ("Brazil",         "AMERICAS", "BRL"),
    }

    def transform_daily(self, table_cfg: TableConfig) -> "DataFrame":
        self.logger.info("Starting Country daily transformation")

        fac_df = self._read_layer("facility_daily")

        country_agg = (fac_df
            .filter(F.col("facility_status") == "ACTIVE")
            .groupBy("country_code", "opco")
            .agg(
                F.lit(str(self.run_date)).cast("date").alias("effective_date"),
                F.countDistinct("facility_id").alias("total_facilities"),
                F.countDistinct("account_id").alias("total_accounts"),
                F.sum("shipment_count").alias("shipment_count"),
                F.sum("volume_kg").alias("volume_kg"),
                F.sum("revenue").alias("revenue"),
                F.sum("cost").alias("cost"),
                F.avg("on_time_delivery_pct").alias("avg_on_time_pct"),
                F.avg("utilisation_pct").alias("avg_utilisation_pct"),
            )
            .withColumn("gross_margin", F.col("revenue") - F.col("cost"))
        )

        # Enrich with country descriptors
        country_lookup_df = self.spark.createDataFrame(
            [(k, v[0], v[1], v[2]) for k, v in self.COUNTRY_LOOKUP.items()],
            schema=["country_code", "country_name", "region_name", "currency_code"]
        ).withColumn("region_code",
            F.when(F.col("region_name") == "AMERICAS", F.lit("AM"))
             .when(F.col("region_name") == "EUROPE",   F.lit("EU"))
             .when(F.col("region_name") == "APAC",     F.lit("AP"))
             .otherwise(F.lit("OTHER")))

        enriched = (country_agg
            .join(country_lookup_df, on="country_code", how="left")
            .withColumn("country_name",  F.coalesce(F.col("country_name"),  F.col("country_code")))
            .withColumn("region_code",   F.coalesce(F.col("region_code"),   F.lit("OTHER")))
            .withColumn("region_name",   F.coalesce(F.col("region_name"),   F.lit("UNKNOWN")))
            .withColumn("currency_code", F.coalesce(F.col("currency_code"), F.lit("USD")))
        )

        return self._std_meta(enriched, "DELTA_LAKE")

    def transform_monthly(self, table_cfg: TableConfig) -> "DataFrame":
        self.logger.info("Starting Country monthly transformation")

        month_str = self.run_date.strftime("%Y-%m")
        daily_df = self.spark.table(f"{DATA_DB}.country_daily").filter(
            (F.date_format(F.col("effective_date"), "yyyy-MM") == F.lit(month_str)) &
            (F.col("opco") == F.lit(self.opco))
        )

        # Year-ago data for YoY calculation
        prior_year_month = (
            self.run_date.replace(year=self.run_date.year - 1).strftime("%Y-%m")
        )
        prior_df = self.spark.table(f"{DATA_DB}.country_monthly").filter(
            (F.col("month_year") == F.lit(prior_year_month)) &
            (F.col("opco") == F.lit(self.opco))
        ).select("country_code", F.col("total_revenue").alias("prior_revenue"))

        monthly = (daily_df
            .groupBy(
                "country_code", "opco", "country_name",
                "region_code", "region_name", "currency_code"
            )
            .agg(
                F.lit(month_str).alias("month_year"),
                F.avg("total_facilities").cast("int").alias("total_facilities"),
                F.avg("total_accounts").cast("int").alias("total_accounts"),
                F.sum("shipment_count").alias("total_shipments"),
                F.sum("volume_kg").alias("total_volume_kg"),
                F.sum("revenue").alias("total_revenue"),
                F.sum("cost").alias("total_cost"),
                F.sum("gross_margin").alias("gross_margin"),
                F.avg("avg_on_time_pct").alias("avg_on_time_pct"),
                F.avg("avg_utilisation_pct").alias("avg_utilisation_pct"),
            )
            .join(prior_df, on="country_code", how="left")
            .withColumn("yoy_revenue_growth",
                F.when(F.col("prior_revenue") > 0,
                    ((F.col("total_revenue") - F.col("prior_revenue"))
                     / F.col("prior_revenue")) * F.lit(100.0)
                ).otherwise(F.lit(None).cast("double")))
            .drop("prior_revenue")
        )

        return self._std_meta(monthly, "DELTA_LAKE")


# ===========================================================================
# 4. GLOBAL Transformer  (Country → Gold)
# ===========================================================================
class GlobalTransformer(BaseTransformer):
    """
    Final aggregation layer.
    Consolidates country data to global + regional views.
    Computes gross margin %, day-over-day changes, MoM and YoY growth.
    """
    layer_name = "GLOBAL"

    def transform_daily(self, table_cfg: TableConfig) -> "DataFrame":
        self.logger.info("Starting Global daily transformation")

        cntry_df = self._read_layer("country_daily")

        # Yesterday's global total for DoD calculation
        from datetime import timedelta
        prev_date = self.run_date - timedelta(days=1)
        prev_df = self.spark.table(f"{DATA_DB}.global_daily").filter(
            (F.col("effective_date") == F.lit(str(prev_date))) &
            (F.col("opco") == F.lit(self.opco)) &
            F.col("region_code").isNull()
        ).select(F.col("revenue").alias("prev_day_revenue"))

        prev_revenue = prev_df.collect()[0]["prev_day_revenue"] if prev_df.count() > 0 else None

        def build_rollup(df: "DataFrame", region_col: Optional[str]) -> "DataFrame":
            group_cols = ["opco"]
            if region_col:
                group_cols.append(region_col)

            agg_df = (df
                .groupBy(*group_cols)
                .agg(
                    F.lit(str(self.run_date)).cast("date").alias("effective_date"),
                    F.countDistinct("country_code").alias("total_countries"),
                    F.sum("total_facilities").alias("total_facilities"),
                    F.sum("total_accounts").alias("total_accounts"),
                    F.sum("shipment_count").alias("shipment_count"),
                    F.sum("volume_kg").alias("volume_kg"),
                    F.sum("revenue").alias("revenue"),
                    F.sum("cost").alias("cost"),
                    F.sum("gross_margin").alias("gross_margin"),
                    F.avg("avg_on_time_pct").alias("avg_on_time_pct"),
                    F.avg("avg_utilisation_pct").alias("avg_utilisation_pct"),
                )
                .withColumn("gross_margin_pct",
                    F.when(F.col("revenue") > 0,
                        (F.col("gross_margin") / F.col("revenue")) * F.lit(100.0)
                    ).otherwise(F.lit(0.0)))
                .withColumn("prev_day_revenue", F.lit(prev_revenue))
                .withColumn("dod_revenue_change",
                    F.when(
                        (F.lit(prev_revenue).isNotNull()) & (F.lit(prev_revenue) > 0),
                        ((F.col("revenue") - F.lit(prev_revenue)) / F.lit(prev_revenue)) * F.lit(100.0)
                    ).otherwise(F.lit(None).cast("double")))
            )

            if region_col:
                return agg_df.withColumnRenamed(region_col, "region_code")
            else:
                return agg_df.withColumn("region_code", F.lit(None).cast("string"))

        # Global total (region_code = NULL) + regional breakdowns
        global_total = build_rollup(cntry_df, None)
        regional     = build_rollup(cntry_df, "region_code")
        combined     = global_total.unionByName(regional)

        return self._std_meta(combined, "DELTA_LAKE")

    def transform_monthly(self, table_cfg: TableConfig) -> "DataFrame":
        self.logger.info("Starting Global monthly transformation")

        month_str = self.run_date.strftime("%Y-%m")
        cntry_monthly = self.spark.table(f"{DATA_DB}.country_monthly").filter(
            (F.col("month_year") == F.lit(month_str)) &
            (F.col("opco") == F.lit(self.opco))
        )

        # Prior month for MoM
        from datetime import timedelta
        import calendar
        prev_month_date = self.run_date.replace(day=1) - timedelta(days=1)
        prev_month_str  = prev_month_date.strftime("%Y-%m")

        prev_global = self.spark.table(f"{DATA_DB}.global_monthly").filter(
            (F.col("month_year") == F.lit(prev_month_str)) &
            (F.col("opco") == F.lit(self.opco)) &
            F.col("region_code").isNull()
        ).select(F.col("total_revenue").alias("prior_month_revenue"))

        prior_rev = (
            prev_global.collect()[0]["prior_month_revenue"]
            if prev_global.count() > 0 else None
        )

        # Prior year for YoY
        prior_year_month = self.run_date.replace(
            year=self.run_date.year - 1
        ).strftime("%Y-%m")
        prev_year_global = self.spark.table(f"{DATA_DB}.global_monthly").filter(
            (F.col("month_year") == F.lit(prior_year_month)) &
            (F.col("opco") == F.lit(self.opco)) &
            F.col("region_code").isNull()
        ).select(F.col("total_revenue").alias("prior_year_revenue"))

        prior_yr_rev = (
            prev_year_global.collect()[0]["prior_year_revenue"]
            if prev_year_global.count() > 0 else None
        )

        def agg_monthly(df, region_col=None):
            group_cols = ["opco"]
            if region_col:
                group_cols.append(region_col)
            agg = (df
                .groupBy(*group_cols)
                .agg(
                    F.lit(month_str).alias("month_year"),
                    F.countDistinct("country_code").alias("total_countries"),
                    F.avg("total_facilities").cast("int").alias("total_facilities"),
                    F.avg("total_accounts").cast("int").alias("total_accounts"),
                    F.sum("total_shipments").alias("total_shipments"),
                    F.sum("total_volume_kg").alias("total_volume_kg"),
                    F.sum("total_revenue").alias("total_revenue"),
                    F.sum("total_cost").alias("total_cost"),
                    F.sum("gross_margin").alias("gross_margin"),
                    F.avg("avg_on_time_pct").alias("avg_on_time_pct"),
                    F.avg("avg_utilisation_pct").alias("avg_utilisation_pct"),
                )
                .withColumn("gross_margin_pct",
                    F.when(F.col("total_revenue") > 0,
                        (F.col("gross_margin") / F.col("total_revenue")) * F.lit(100.0)
                    ).otherwise(F.lit(0.0)))
                .withColumn("yoy_revenue_growth",
                    F.when(F.lit(prior_yr_rev).isNotNull() & (F.lit(prior_yr_rev) > 0),
                        ((F.col("total_revenue") - F.lit(prior_yr_rev)) / F.lit(prior_yr_rev)) * F.lit(100.0)
                    ).otherwise(F.lit(None).cast("double")))
                .withColumn("mom_revenue_growth",
                    F.when(F.lit(prior_rev).isNotNull() & (F.lit(prior_rev) > 0),
                        ((F.col("total_revenue") - F.lit(prior_rev)) / F.lit(prior_rev)) * F.lit(100.0)
                    ).otherwise(F.lit(None).cast("double")))
            )
            if region_col:
                return agg.withColumnRenamed(region_col, "region_code")
            return agg.withColumn("region_code", F.lit(None).cast("string"))

        combined = agg_monthly(cntry_monthly).unionByName(
            agg_monthly(cntry_monthly, "region_code")
        )

        return self._std_meta(combined, "DELTA_LAKE")


# ===========================================================================
# Transformer Registry  — maps layer name → class
# ===========================================================================
TRANSFORMER_REGISTRY: dict[str, type] = {
    "ACCOUNT":  AccountTransformer,
    "FACILITY": FacilityTransformer,
    "COUNTRY":  CountryTransformer,
    "GLOBAL":   GlobalTransformer,
}


def get_transformer(
    layer: str,
    spark: "SparkSession",
    run_date: date,
    opco: str,
) -> BaseTransformer:
    """Factory — returns the correct transformer for a given layer."""
    cls = TRANSFORMER_REGISTRY.get(layer.upper())
    if not cls:
        raise ValueError(
            f"No transformer registered for layer '{layer}'. "
            f"Available: {list(TRANSFORMER_REGISTRY.keys())}"
        )
    return cls(spark=spark, run_date=run_date, opco=opco)
