"""
cdl_etl_framework/notebooks/02_ingestion.py
============================================
Generic, metadata-driven ingestion engine.

Supports:
  - FULL  : truncate-and-reload (overwrite)
  - INCR  : watermark-based incremental append / merge
  - CDC   : Change Data Capture merge (insert/update/delete)

Works identically on Azure (ADLS + Delta Lake) and GCP (GCS + Delta Lake / BigQuery).
All source reads and target writes go through the cloud adapter in utils/cloud_adapter.py.

Not called directly — invoked from 03_transformation.py per table config.
"""

import os
import sys
from datetime import date, datetime, timezone
from typing import Optional

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from notebooks.01_framework_core import (
    CDLLogger, DQEngine, MetadataManager, RunLogger,
    RunMetrics, TableConfig,
)
from utils.retry_handler import with_retry
from utils.alert_manager import AlertManager
from utils.cloud_adapter import CloudAdapter
from config.env_config import get_data_db, PIPELINE_CONFIG

try:
    from pyspark.sql import DataFrame, SparkSession
    from pyspark.sql import functions as F
    from delta.tables import DeltaTable
except ImportError:
    pass  # tolerated in unit-test contexts


# ===========================================================================
# IngestionEngine
# ===========================================================================
class IngestionEngine:
    """
    Orchestrates one source→target table load per TableConfig row.
    Called once per active config entry; handles read, DQ, write, audit.
    """

    def __init__(
        self,
        spark: "SparkSession",
        meta_mgr: MetadataManager,
        run_logger: RunLogger,
        alert_mgr: AlertManager,
        run_date: date,
        dag_id: str,
        task_id: str,
    ):
        self.spark = spark
        self.meta_mgr = meta_mgr
        self.run_logger = run_logger
        self.alert_mgr = alert_mgr
        self.run_date = run_date
        self.data_db = get_data_db()
        self.adapter = CloudAdapter(spark)

    def run_table(self, table_cfg: TableConfig) -> bool:
        """
        Execute one table load end-to-end.
        Returns True on success, False on failure.
        """
        logger = CDLLogger(
            "IngestionEngine",
            opco=table_cfg.opco,
            layer=table_cfg.target_dataset_layer,
        )
        retry_cfg = self.meta_mgr.get_retry_config(table_cfg.table_id)
        max_attempts = retry_cfg.get("max_attempts", PIPELINE_CONFIG.default_max_attempts)

        for attempt in range(1, max_attempts + 1):
            started_at = datetime.now(timezone.utc)
            run_id = self.run_logger.log_start(
                table_cfg=table_cfg,
                run_date=self.run_date,
                attempt=attempt,
            )
            logger.info(
                f"Starting table load attempt {attempt}/{max_attempts}",
                table_id=table_cfg.table_id,
                run_id=run_id,
            )
            try:
                success = self._execute(
                    table_cfg=table_cfg,
                    run_id=run_id,
                    attempt=attempt,
                    started_at=started_at,
                    logger=logger,
                )
                if success:
                    return True

            except Exception as exc:
                error_msg = f"{type(exc).__name__}: {exc}"
                logger.error(
                    f"Attempt {attempt} failed: {error_msg}",
                    table_id=table_cfg.table_id,
                )
                self.run_logger.log_failure(
                    run_id=run_id,
                    error_code="UNHANDLED_EXCEPTION",
                    error_message=error_msg,
                    started_at=started_at,
                    status="FAILED" if attempt == max_attempts else "RUNNING",
                )
                if attempt == max_attempts:
                    self.alert_mgr.send(
                        table_cfg=table_cfg,
                        run_id=run_id,
                        status="FAILED",
                        message=error_msg,
                        severity="CRITICAL",
                    )
                    return False

                wait = self._backoff_wait(attempt, retry_cfg)
                logger.info(f"Retrying in {wait}s …")
                import time; time.sleep(wait)

        return False

    def _execute(
        self,
        table_cfg: TableConfig,
        run_id: str,
        attempt: int,
        started_at: datetime,
        logger: CDLLogger,
    ) -> bool:
        metrics = RunMetrics()
        dq_engine = DQEngine(self.spark, logger)

        # ---- 1. Read source ----
        source_df = self._read_source(table_cfg, logger)
        metrics.rows_read = source_df.count()
        logger.info(f"Source rows read: {metrics.rows_read}")

        if metrics.rows_read == 0 and table_cfg.ingestion_mode != "FULL":
            logger.info("No new source rows — skipping write")
            self.run_logger.log_success(
                run_id=run_id, metrics=metrics,
                dq_results=[], dq_passed=True,
                started_at=started_at,
            )
            return True

        # ---- 2. Add framework columns ----
        source_df = self._add_framework_cols(source_df, run_id, table_cfg)

        # ---- 3. DQ validation ----
        rule_defs = self.meta_mgr.get_dq_rules(table_cfg.data_quality_rules)
        dq_results, dq_passed = dq_engine.run(source_df, table_cfg, rule_defs)

        # Tag rows with dq_passed (last CRITICAL rule wins)
        for rd in rule_defs:
            if rd["severity"] == "CRITICAL":
                source_df = dq_engine.tag_dq_column(source_df, rd)

        # Separate clean vs rejected rows
        clean_df = source_df.filter("dq_passed = true")
        rejected_df = source_df.filter("dq_passed = false")
        metrics.rows_rejected = rejected_df.count()
        logger.info(
            f"DQ pass={dq_passed}, clean={metrics.rows_read - metrics.rows_rejected}, "
            f"rejected={metrics.rows_rejected}"
        )

        # ---- 4. Write target ----
        write_metrics = self._write_target(clean_df, table_cfg, logger)
        metrics.rows_written = write_metrics.rows_written
        metrics.rows_merged = write_metrics.rows_merged
        metrics.rows_inserted = write_metrics.rows_inserted
        metrics.rows_updated = write_metrics.rows_updated
        metrics.rows_deleted = write_metrics.rows_deleted

        # ---- 5. Update watermark ----
        if table_cfg.ingestion_mode == "INCR" and table_cfg.watermark_column:
            wm_end = clean_df.agg(
                F.max(table_cfg.watermark_column)
            ).collect()[0][0]
            if wm_end:
                self.meta_mgr.update_watermark(table_cfg.table_id, wm_end)

        # ---- 6. Log success ----
        self.run_logger.log_success(
            run_id=run_id,
            metrics=metrics,
            dq_results=dq_results,
            dq_passed=dq_passed,
            started_at=started_at,
        )

        if not dq_passed:
            self.alert_mgr.send(
                table_cfg=table_cfg,
                run_id=run_id,
                status="FAILED",
                message=f"DQ threshold not met for {table_cfg.table_id}",
                severity="CRITICAL",
            )

        return dq_passed

    # -------------------------------------------------------------------------
    # Source read
    # -------------------------------------------------------------------------
    def _read_source(self, table_cfg: TableConfig, logger: CDLLogger) -> "DataFrame":
        """Read source using ingestion mode."""
        mode = table_cfg.ingestion_mode.upper()

        if table_cfg.source_system in ("DELTA_LAKE", "BIGQUERY"):
            # Internal layer-to-layer read
            df = self.spark.table(f"{self.data_db}.{table_cfg.source_table_name}")
        else:
            # External source via adapter
            df = self.adapter.read_external(
                source_system=table_cfg.source_system,
                table_name=table_cfg.source_table_name,
            )

        # Apply optional source filter
        if table_cfg.source_filter:
            df = df.filter(table_cfg.source_filter)

        # Watermark filter for INCR
        if mode == "INCR" and table_cfg.watermark_column:
            low_wm = self.meta_mgr.get_watermark(table_cfg.table_id)
            if low_wm:
                df = df.filter(F.col(table_cfg.watermark_column) > F.lit(low_wm))
                logger.info(f"Watermark filter applied: {table_cfg.watermark_column} > {low_wm}")

        return df

    # -------------------------------------------------------------------------
    # Target write
    # -------------------------------------------------------------------------
    def _write_target(
        self,
        df: "DataFrame",
        table_cfg: TableConfig,
        logger: CDLLogger,
    ) -> RunMetrics:
        metrics = RunMetrics()
        target = f"{self.data_db}.{table_cfg.target_table_name}"
        mode = table_cfg.ingestion_mode.upper()

        if mode == "FULL":
            # Overwrite entire partition for today
            (df.write.format("delta")
               .mode("overwrite")
               .option("replaceWhere", f"load_date = '{self.run_date}' AND opco = '{table_cfg.opco}'")
               .saveAsTable(target))
            metrics.rows_written = df.count()
            metrics.rows_inserted = metrics.rows_written
            logger.info(f"FULL write: {metrics.rows_written} rows → {target}")

        elif mode in ("INCR", "CDC"):
            if not table_cfg.merge_keys:
                raise ValueError(f"merge_keys required for {mode} mode on {table_cfg.table_id}")

            merge_condition = " AND ".join(
                f"t.{k.strip()} = s.{k.strip()}"
                for k in table_cfg.merge_keys.split(",")
            )

            if DeltaTable.isDeltaTable(self.spark, target):
                delta_tbl = DeltaTable.forName(self.spark, target)
                merge_builder = (
                    delta_tbl.alias("t")
                    .merge(df.alias("s"), merge_condition)
                    .whenMatchedUpdateAll()
                    .whenNotMatchedInsertAll()
                )
                if mode == "CDC":
                    # Hard deletes: rows with cdc_op = 'D'
                    merge_builder = (
                        delta_tbl.alias("t")
                        .merge(df.alias("s"), merge_condition)
                        .whenMatchedDelete(condition="s.cdc_op = 'D'")
                        .whenMatchedUpdateAll(condition="s.cdc_op != 'D'")
                        .whenNotMatchedInsertAll(condition="s.cdc_op != 'D'")
                    )
                merge_builder.execute()

                op_metrics = delta_tbl.history(1).select(
                    "operationMetrics"
                ).collect()[0][0]
                metrics.rows_inserted = int(op_metrics.get("numTargetRowsInserted", 0))
                metrics.rows_updated  = int(op_metrics.get("numTargetRowsUpdated", 0))
                metrics.rows_deleted  = int(op_metrics.get("numTargetRowsDeleted", 0))
                metrics.rows_merged   = metrics.rows_inserted + metrics.rows_updated
                metrics.rows_written  = metrics.rows_merged
            else:
                # First load — plain insert
                df.write.format("delta").mode("append").saveAsTable(target)
                metrics.rows_written = df.count()
                metrics.rows_inserted = metrics.rows_written

            logger.info(
                f"{mode} merge → {target}: "
                f"ins={metrics.rows_inserted} upd={metrics.rows_updated} del={metrics.rows_deleted}"
            )

        return metrics

    # -------------------------------------------------------------------------
    # Helpers
    # -------------------------------------------------------------------------
    @staticmethod
    def _add_framework_cols(
        df: "DataFrame", run_id: str, table_cfg: TableConfig
    ) -> "DataFrame":
        now = datetime.now(timezone.utc).isoformat()
        return (df
            .withColumn("run_id", F.lit(run_id))
            .withColumn("source_system", F.lit(table_cfg.source_system))
            .withColumn("created_at", F.coalesce(F.col("created_at"), F.lit(now).cast("timestamp")))
            .withColumn("updated_at", F.lit(now).cast("timestamp"))
            .withColumn("load_date", F.lit(str(table_cfg.opco)).cast("string")
                        .cast("string"))   # placeholder — actual load_date set per layer
        )

    @staticmethod
    def _backoff_wait(attempt: int, retry_cfg: dict) -> int:
        import random
        base = retry_cfg.get("initial_wait_seconds", 30)
        mult = retry_cfg.get("backoff_multiplier", 2.0)
        cap  = retry_cfg.get("max_wait_seconds", 300)
        wait = min(base * (mult ** (attempt - 1)), cap)
        jitter = random.uniform(0, wait * 0.1)
        return int(wait + jitter)
