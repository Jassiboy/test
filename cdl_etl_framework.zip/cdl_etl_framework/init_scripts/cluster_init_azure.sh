#!/bin/bash
# =============================================================================
# cdl_etl_framework/init_scripts/cluster_init_azure.sh
# Databricks cluster-scoped init script.
# Place this in ADLS / DBFS and reference it in the cluster config.
# Runs as root on every node at cluster startup.
# =============================================================================

set -euo pipefail
LOG="/tmp/cdl_init_azure.log"
exec > >(tee -a "$LOG") 2>&1

echo "============================================================"
echo " CDL ETL Framework — Azure Databricks Init Script"
echo " $(date -u '+%Y-%m-%dT%H:%M:%SZ')"
echo "============================================================"

# ---------------------------------------------------------------------------
# 1. System packages
# ---------------------------------------------------------------------------
echo "[1/6] Installing system packages..."
apt-get update -qq
apt-get install -y -qq \
    build-essential \
    libssl-dev \
    libffi-dev \
    python3-dev \
    curl \
    jq

# ---------------------------------------------------------------------------
# 2. Python libraries (driver + executors)
# ---------------------------------------------------------------------------
echo "[2/6] Installing Python libraries..."

/databricks/python3/bin/pip install --quiet --upgrade pip

/databricks/python3/bin/pip install --quiet \
    "delta-spark==3.1.0" \
    "great-expectations==0.18.12" \
    "pyarrow==14.0.2" \
    "pandas==2.1.4" \
    "azure-storage-blob==12.19.0" \
    "azure-identity==1.15.0" \
    "azure-keyvault-secrets==4.7.0" \
    "opencensus-ext-azure==1.1.13" \
    "requests==2.31.0" \
    "tenacity==8.2.3" \
    "pydantic==2.5.3"

echo "  ✓ Python libraries installed"

# ---------------------------------------------------------------------------
# 3. Spark / Delta configs written to spark-defaults.conf
# ---------------------------------------------------------------------------
echo "[3/6] Configuring Spark defaults..."

SPARK_DEFAULTS="/databricks/spark/conf/spark-defaults.conf"

cat >> "$SPARK_DEFAULTS" <<'SPARK_CONF'

# CDL ETL Framework — Spark tuning
spark.sql.shuffle.partitions                        200
spark.sql.adaptive.enabled                          true
spark.sql.adaptive.coalescePartitions.enabled       true
spark.sql.adaptive.skewJoin.enabled                 true
spark.databricks.delta.optimizeWrite.enabled        true
spark.databricks.delta.autoCompact.enabled          true
spark.databricks.delta.schema.autoMerge.enabled     false
spark.sql.legacy.timeParserPolicy                   LEGACY
spark.sql.parquet.int96RebaseModeInRead             CORRECTED
spark.sql.parquet.int96RebaseModeInWrite            CORRECTED
spark.sql.parquet.datetimeRebaseModeInRead          CORRECTED
spark.sql.parquet.datetimeRebaseModeInWrite         CORRECTED
spark.databricks.delta.merge.repartitionBeforeWrite.enabled true
SPARK_CONF

echo "  ✓ Spark defaults written"

# ---------------------------------------------------------------------------
# 4. Environment variables (read from Databricks secret scope at runtime)
# ---------------------------------------------------------------------------
echo "[4/6] Setting environment variables..."

# These are populated via Databricks Secrets — the cluster policy injects them.
# Fallbacks for local/dev use only.
: "${CDL_ENV:=azure}"
: "${CDL_LOG_LEVEL:=INFO}"
: "${CDL_SHUFFLE_PARTITIONS:=200}"
: "${CDL_DQ_THRESHOLD:=95.0}"

# Write to /etc/environment for persistence across sessions
cat >> /etc/environment <<ENV_VARS
CDL_ENV=${CDL_ENV}
CDL_LOG_LEVEL=${CDL_LOG_LEVEL}
CDL_SHUFFLE_PARTITIONS=${CDL_SHUFFLE_PARTITIONS}
CDL_DQ_THRESHOLD=${CDL_DQ_THRESHOLD}
CDL_FRAMEWORK_PATH=/dbfs/cdl_etl_framework
ENV_VARS

echo "  ✓ Environment variables set"

# ---------------------------------------------------------------------------
# 5. Copy framework code from DBFS to local (executor nodes)
# ---------------------------------------------------------------------------
echo "[5/6] Syncing framework code to local path..."

FRAMEWORK_SRC="/dbfs/cdl_etl_framework"
FRAMEWORK_DST="/opt/cdl_etl_framework"

if [ -d "$FRAMEWORK_SRC" ]; then
    cp -r "$FRAMEWORK_SRC" "$FRAMEWORK_DST"
    echo "  ✓ Framework code synced to $FRAMEWORK_DST"
else
    echo "  ⚠ Framework source not found at $FRAMEWORK_SRC — skipping sync"
fi

# Add to PYTHONPATH
echo "export PYTHONPATH=${FRAMEWORK_DST}:\${PYTHONPATH:-}" >> /etc/profile.d/cdl.sh
chmod +x /etc/profile.d/cdl.sh

# ---------------------------------------------------------------------------
# 6. Health check
# ---------------------------------------------------------------------------
echo "[6/6] Running health check..."

/databricks/python3/bin/python3 -c "
import delta
import pyarrow
import pandas
print(f'  delta-spark : {delta.__version__}')
print(f'  pyarrow     : {pyarrow.__version__}')
print(f'  pandas      : {pandas.__version__}')
print('  ✓ Health check passed')
"

echo "============================================================"
echo " CDL Init Script COMPLETE — $(date -u '+%Y-%m-%dT%H:%M:%SZ')"
echo "============================================================"
