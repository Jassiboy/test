#!/bin/bash
# =============================================================================
# cdl_etl_framework/init_scripts/cluster_init_gcp.sh
# Dataproc cluster initialization action.
# Reference via: --initialization-actions gs://YOUR_BUCKET/init_scripts/cluster_init_gcp.sh
# Runs as root on master + all worker nodes.
# =============================================================================

set -euo pipefail
LOG="/tmp/cdl_init_gcp.log"
exec > >(tee -a "$LOG") 2>&1

echo "============================================================"
echo " CDL ETL Framework — GCP Dataproc Init Script"
echo " $(date -u '+%Y-%m-%dT%H:%M:%SZ')"
echo "============================================================"

# Determine if this is master or worker
ROLE="$(/usr/share/google/get_metadata_value attributes/dataproc-role)"
echo "  Node role: $ROLE"

# ---------------------------------------------------------------------------
# 1. System packages
# ---------------------------------------------------------------------------
echo "[1/6] Installing system packages..."
apt-get update -qq
apt-get install -y -qq \
    build-essential \
    libssl-dev \
    libffi-dev \
    python3-dev \
    curl \
    jq \
    python3-pip

# ---------------------------------------------------------------------------
# 2. Python libraries
# ---------------------------------------------------------------------------
echo "[2/6] Installing Python libraries..."

pip3 install --quiet --upgrade pip

pip3 install --quiet \
    "delta-spark==3.1.0" \
    "google-cloud-bigquery==3.14.1" \
    "google-cloud-storage==2.14.0" \
    "google-cloud-secret-manager==2.18.2" \
    "pyarrow==14.0.2" \
    "pandas==2.1.4" \
    "requests==2.31.0" \
    "tenacity==8.2.3" \
    "pydantic==2.5.3" \
    "google-cloud-bigquery-storage==2.24.0"

# BigQuery Spark connector
BQ_CONNECTOR_VERSION="0.37.0"
BQ_CONNECTOR_JAR="spark-bigquery-with-dependencies_2.12-${BQ_CONNECTOR_VERSION}.jar"
BQ_JAR_PATH="/usr/lib/spark/jars/${BQ_CONNECTOR_JAR}"

if [ ! -f "$BQ_JAR_PATH" ]; then
    gsutil cp \
        "gs://spark-lib/bigquery/${BQ_CONNECTOR_JAR}" \
        "$BQ_JAR_PATH" 2>/dev/null || \
    curl -sSL \
        "https://github.com/GoogleCloudDataproc/spark-bigquery-connector/releases/download/${BQ_CONNECTOR_VERSION}/${BQ_CONNECTOR_JAR}" \
        -o "$BQ_JAR_PATH"
fi
echo "  ✓ Python libraries + BQ connector installed"

# ---------------------------------------------------------------------------
# 3. Spark defaults
# ---------------------------------------------------------------------------
echo "[3/6] Configuring Spark defaults..."

SPARK_DEFAULTS="/etc/spark/conf/spark-defaults.conf"
cat >> "$SPARK_DEFAULTS" <<'SPARK_CONF'

# CDL ETL Framework — Spark tuning (GCP Dataproc)
spark.sql.shuffle.partitions                        200
spark.sql.adaptive.enabled                          true
spark.sql.adaptive.coalescePartitions.enabled       true
spark.sql.adaptive.skewJoin.enabled                 true
spark.sql.extensions                                io.delta.sql.DeltaSparkSessionExtension
spark.sql.catalog.spark_catalog                     org.apache.spark.sql.delta.catalog.DeltaCatalog
spark.hadoop.fs.gs.impl                             com.google.cloud.hadoop.fs.gcs.GoogleHadoopFileSystem
spark.hadoop.fs.AbstractFileSystem.gs.impl          com.google.cloud.hadoop.fs.gcs.GoogleHadoopFS
spark.hadoop.google.cloud.auth.service.account.enable true
SPARK_CONF

echo "  ✓ Spark defaults written"

# ---------------------------------------------------------------------------
# 4. Environment variables
# ---------------------------------------------------------------------------
echo "[4/6] Setting environment variables..."

GCP_PROJECT=$(/usr/share/google/get_metadata_value project/project-id 2>/dev/null || echo "unknown")
GCS_BUCKET=$(/usr/share/google/get_metadata_value attributes/cdl-gcs-bucket 2>/dev/null || echo "cdl-data-prod")

cat >> /etc/environment <<ENV_VARS
CDL_ENV=gcp
CDL_LOG_LEVEL=INFO
CDL_SHUFFLE_PARTITIONS=200
CDL_DQ_THRESHOLD=95.0
CDL_FRAMEWORK_PATH=/opt/cdl_etl_framework
GCP_PROJECT_ID=${GCP_PROJECT}
GCS_BUCKET=${GCS_BUCKET}
ENV_VARS

echo "  ✓ Environment variables set"

# ---------------------------------------------------------------------------
# 5. Copy framework code from GCS
# ---------------------------------------------------------------------------
echo "[5/6] Syncing framework code..."

FRAMEWORK_DST="/opt/cdl_etl_framework"
GCS_FRAMEWORK_PATH="gs://${GCS_BUCKET}/framework/cdl_etl_framework"

mkdir -p "$FRAMEWORK_DST"

if gsutil -q stat "${GCS_FRAMEWORK_PATH}/**" 2>/dev/null; then
    gsutil -m -q rsync -r "$GCS_FRAMEWORK_PATH" "$FRAMEWORK_DST"
    echo "  ✓ Framework synced from GCS to $FRAMEWORK_DST"
else
    echo "  ⚠ Framework not found at $GCS_FRAMEWORK_PATH — skipping sync"
fi

# PYTHONPATH
echo "export PYTHONPATH=${FRAMEWORK_DST}:\${PYTHONPATH:-}" >> /etc/profile.d/cdl.sh
chmod +x /etc/profile.d/cdl.sh

# ---------------------------------------------------------------------------
# 6. Health check (master only)
# ---------------------------------------------------------------------------
if [[ "$ROLE" == "Master" ]]; then
    echo "[6/6] Running health check..."
    python3 -c "
import delta, pyarrow, pandas
from google.cloud import bigquery, storage
print(f'  delta-spark  : {delta.__version__}')
print(f'  pyarrow      : {pyarrow.__version__}')
print(f'  pandas       : {pandas.__version__}')
print('  ✓ Health check passed')
"
else
    echo "[6/6] Skipping health check on worker node"
fi

echo "============================================================"
echo " CDL Init Script COMPLETE — $(date -u '+%Y-%m-%dT%H:%M:%SZ')"
echo "============================================================"
