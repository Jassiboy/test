"""
pipeline.utils
===============
Small cross-cutting helpers used across the pipeline:

* SecretResolver — resolves secrets from Databricks Secret Scopes / Azure
  Key Vault at runtime. Secrets are NEVER stored in YAML config — only the
  scope/key *names* are configuration; the actual value is fetched here.
* date_range / to_year_month / is_month_end / yesterday — date helpers for
  daily<->monthly partition handling, used by job entry points and the
  restatement framework.
"""

from __future__ import annotations

import os
from datetime import date, datetime, timedelta
from typing import List, Optional


class SecretResolver:
    def __init__(self, dbutils: Optional[object] = None, scope: str = "data-pipeline-kv"):
        self.dbutils = dbutils
        self.scope = scope

    def get(self, key: str) -> str:
        """Resolution order: (1) Databricks secret scope via injected
        dbutils, (2) environment variable (local dev / CI), so this module
        is import-safe outside Databricks without needing a live
        workspace for unit tests."""
        if self.dbutils is not None:
            return self.dbutils.secrets.get(scope=self.scope, key=key)

        env_var_name = f"{self.scope.upper().replace('-', '_')}_{key.upper()}"
        value = os.environ.get(env_var_name)
        if value is None:
            raise KeyError(
                f"Secret '{key}' not found — no dbutils available and env var '{env_var_name}' is not set."
            )
        return value

    @classmethod
    def from_databricks_notebook(cls, scope: str = "data-pipeline-kv") -> "SecretResolver":
        """Convenience constructor for use inside a Databricks notebook,
        where `dbutils` is auto-injected by the runtime."""
        try:
            dbutils = globals()["dbutils"]
        except KeyError:
            try:
                from pyspark.dbutils import DBUtils  # type: ignore
                from pyspark.sql import SparkSession

                dbutils = DBUtils(SparkSession.builder.getOrCreate())
            except Exception:
                dbutils = None
        return cls(dbutils=dbutils, scope=scope)


def to_year_month(business_date: str) -> str:
    """'2025-01-15' -> '2025-01'"""
    d = datetime.strptime(business_date, "%Y-%m-%d").date()
    return f"{d.year:04d}-{d.month:02d}"


def date_range(start_date: str, end_date: str) -> List[str]:
    """Inclusive list of YYYY-MM-DD strings between start and end."""
    start = datetime.strptime(start_date, "%Y-%m-%d").date()
    end = datetime.strptime(end_date, "%Y-%m-%d").date()
    if end < start:
        raise ValueError(f"end_date {end_date} is before start_date {start_date}")
    days = (end - start).days
    return [(start + timedelta(days=i)).isoformat() for i in range(days + 1)]


def is_month_end(business_date: str) -> bool:
    """True if business_date is the last calendar day of its month — used
    by the daily job to decide whether to also trigger the monthly chain."""
    d = datetime.strptime(business_date, "%Y-%m-%d").date()
    return (d + timedelta(days=1)).day == 1


def yesterday(reference: Optional[date] = None) -> str:
    ref = reference or date.today()
    return (ref - timedelta(days=1)).isoformat()
