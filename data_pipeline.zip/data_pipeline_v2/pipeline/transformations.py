"""
pipeline.transformations
=========================
Concrete BaseTransformation subclasses, one per layer transition:

    BaseTransformation
    ├── AccountToFacility   (account  -> facility): joins dimensions
    ├── FacilityToCountry   (facility -> country):  group-by + aggregations
    └── CountryToGlobal     (country  -> global):   group-by + final rollup

FacilityToCountry and CountryToGlobal are structurally identical (both are
"aggregate the previous layer" transformations differing only in grouping
columns and config keys) — this similarity is intentional and is exactly
what BaseTransformation's Template Method is designed to capture.
"""

from __future__ import annotations

from pyspark.sql import DataFrame
from pyspark.sql import functions as F

from .core import BaseTransformation, DeltaIOHelper
from .dq import BusinessCheckSpec, DQReport, ReferentialCheckSpec, RuleEngine, Severity

_AGG_FUNC_MAP = {
    "sum": F.sum,
    "avg": F.avg,
    "count": F.count,
    "count_distinct": F.countDistinct,
    "min": F.min,
    "max": F.max,
}


# ============================================================================
# Account -> Facility
# ============================================================================
class AccountToFacility(BaseTransformation):
    """Reads the existing Account daily/monthly tables, left-joins
    dim_facility (SCD2, filtered to is_current) and dim_country, derives
    revenue_local/load_ts, validates (schema + RI + business rule), and
    writes Facility daily/monthly."""

    @property
    def pipeline_name(self) -> str:
        return "account_to_facility"

    @property
    def layer(self) -> str:
        return "facility"

    def read(self) -> DataFrame:
        io = DeltaIOHelper(self.spark, self.config)

        if self.table_type == "daily":
            run_date = self.kwargs.get("run_date")
            account_df = io.read_layer_table("account", "daily")
            if run_date:
                account_df = account_df.filter(F.col("business_date") == run_date)
        else:
            year_month = self.kwargs.get("year_month")
            account_df = io.read_layer_table("account", "monthly")
            if year_month:
                account_df = account_df.filter(F.col("year_month") == year_month)

        # Cached on self for reuse in validate()'s referential-integrity checks.
        self._dim_facility = io.read_dimension("dim_facility")
        self._dim_country = io.read_dimension("dim_country")
        return account_df

    def transform(self, source_df: DataFrame) -> DataFrame:
        join_cfg = self.config.get_transformation_config("account_to_facility")

        result = source_df
        for join_spec in join_cfg["joins"]:
            dim_df = self._dim_facility if join_spec["dimension"] == "dim_facility" else self._dim_country
            select_cols = join_spec["on"] + join_spec["select_columns"]
            dim_select = dim_df.select(*select_cols)

            join_filter = join_spec.get("filter")
            if join_filter:
                dim_select = dim_select.filter(join_filter)

            result = result.join(dim_select, on=join_spec["on"], how=join_cfg.get("join_type", "left"))

        for derived in join_cfg.get("derived_columns", []):
            result = result.withColumn(derived["name"], F.expr(derived["expression"]))

        return result

    def validate(self, transformed_df: DataFrame) -> DQReport:
        layer_config = self.config.get_layer_config(self.layer, self.table_type)
        engine = RuleEngine(self.config, layer=self.layer, table_name=self.target_table_name)

        return engine.run_all(
            transformed_df,
            primary_keys=layer_config["primary_keys"],
            schema_name=self.target_table_name,
            referential_checks=[
                ReferentialCheckSpec("facility_id", self._dim_facility, "facility_id"),
                ReferentialCheckSpec("country_code", self._dim_country, "country_code"),
            ],
            business_checks=[
                BusinessCheckSpec("revenue_local_non_negative", "revenue_local >= 0", Severity.HIGH),
            ],
        )


# ============================================================================
# Facility -> Country
# ============================================================================
class FacilityToCountry(BaseTransformation):
    """Reads Facility daily/monthly, group-by aggregates to country grain,
    applies business calculations, validates (+ aggregate-total
    reconciliation), writes Country daily/monthly."""

    @property
    def pipeline_name(self) -> str:
        return "facility_to_country"

    @property
    def layer(self) -> str:
        return "country"

    def read(self) -> DataFrame:
        io = DeltaIOHelper(self.spark, self.config)
        if self.table_type == "daily":
            run_date = self.kwargs.get("run_date")
            df = io.read_layer_table("facility", "daily")
            if run_date:
                df = df.filter(F.col("business_date") == run_date)
        else:
            year_month = self.kwargs.get("year_month")
            df = io.read_layer_table("facility", "monthly")
            if year_month:
                df = df.filter(F.col("year_month") == year_month)
        return df

    def transform(self, source_df: DataFrame) -> DataFrame:
        self._pre_agg_df = source_df  # kept for the reconciliation check in validate()

        tf_cfg = self.config.get_transformation_config("facility_to_country")
        group_by_columns = tf_cfg[
            "group_by_columns" if self.table_type == "daily" else "group_by_columns_monthly"
        ]

        agg_exprs = [
            _AGG_FUNC_MAP[agg["agg_func"]](agg["source_column"]).alias(agg["target_column"])
            for agg in tf_cfg["aggregations"]
        ]
        result = source_df.groupBy(*group_by_columns).agg(*agg_exprs)

        for calc in tf_cfg.get("business_calculations", []):
            result = result.withColumn(calc["name"], F.expr(calc["expression"]))

        return result.withColumn("load_ts", F.current_timestamp())

    def validate(self, transformed_df: DataFrame) -> DQReport:
        layer_config = self.config.get_layer_config(self.layer, self.table_type)
        engine = RuleEngine(self.config, layer=self.layer, table_name=self.target_table_name)

        report = engine.run_all(
            transformed_df,
            primary_keys=layer_config["primary_keys"],
            schema_name=self.target_table_name,
            business_checks=[
                BusinessCheckSpec("total_revenue_non_negative", "total_revenue >= 0", Severity.HIGH)
            ],
        )
        report.add(
            engine.check_aggregate_totals(
                self._pre_agg_df, transformed_df, "revenue_local", "total_revenue", 0.01
            )
        )
        return report


# ============================================================================
# Country -> Global
# ============================================================================
class CountryToGlobal(BaseTransformation):
    """Reads Country daily/monthly, rolls up to global grain, applies
    final reporting calculations, validates (+ reconciliation), writes
    Global daily/monthly. Structurally identical to FacilityToCountry."""

    @property
    def pipeline_name(self) -> str:
        return "country_to_global"

    @property
    def layer(self) -> str:
        return "global"

    def read(self) -> DataFrame:
        io = DeltaIOHelper(self.spark, self.config)
        if self.table_type == "daily":
            run_date = self.kwargs.get("run_date")
            df = io.read_layer_table("country", "daily")
            if run_date:
                df = df.filter(F.col("business_date") == run_date)
        else:
            year_month = self.kwargs.get("year_month")
            df = io.read_layer_table("country", "monthly")
            if year_month:
                df = df.filter(F.col("year_month") == year_month)
        return df

    def transform(self, source_df: DataFrame) -> DataFrame:
        self._pre_agg_df = source_df

        tf_cfg = self.config.get_transformation_config("country_to_global")
        group_by_columns = tf_cfg[
            "group_by_columns" if self.table_type == "daily" else "group_by_columns_monthly"
        ]

        agg_exprs = [
            _AGG_FUNC_MAP[agg["agg_func"]](agg["source_column"]).alias(agg["target_column"])
            for agg in tf_cfg["aggregations"]
        ]
        result = source_df.groupBy(*group_by_columns).agg(*agg_exprs)

        for calc in tf_cfg.get("business_calculations", []):
            result = result.withColumn(calc["name"], F.expr(calc["expression"]))

        return result.withColumn("load_ts", F.current_timestamp())

    def validate(self, transformed_df: DataFrame) -> DQReport:
        layer_config = self.config.get_layer_config(self.layer, self.table_type)
        engine = RuleEngine(self.config, layer=self.layer, table_name=self.target_table_name)

        report = engine.run_all(
            transformed_df,
            primary_keys=layer_config["primary_keys"],
            schema_name=self.target_table_name,
            business_checks=[
                BusinessCheckSpec("global_revenue_non_negative", "global_revenue >= 0", Severity.HIGH)
            ],
        )
        report.add(
            engine.check_aggregate_totals(
                self._pre_agg_df, transformed_df, "total_revenue", "global_revenue", 0.01
            )
        )
        return report
