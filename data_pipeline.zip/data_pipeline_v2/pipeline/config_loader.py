"""
pipeline.config_loader
=====================
Loads environment-specific pipeline configuration from YAML and resolves
``${storage.root_path}``-style internal references so downstream code never
has to string-concatenate paths.

Design notes
------------
* Configuration is the single source of truth for table names, paths,
  join/aggregation rules, DQ thresholds, and performance knobs. No pipeline
  class should hardcode any of these.
* ``ConfigLoader`` is intentionally a thin, dependency-free class so it can
  be unit tested without a Spark session or cloud credentials.
* Secrets (storage account keys, service principal secrets) are NEVER stored
  in these YAML files — they are resolved separately via
  ``utils.secrets.SecretResolver`` which reads from Databricks Secret Scopes
  / Azure Key Vault at runtime.
"""

from __future__ import annotations

import copy
import os
import re
from pathlib import Path
from typing import Any, Dict, Optional

import yaml

_VAR_PATTERN = re.compile(r"\$\{([^}]+)\}")
_UNSET = object()  # sentinel distinguishing "no default given" from "default=None"


class ConfigError(Exception):
    """Raised for any configuration loading or resolution failure."""


class ConfigLoader:
    """
    Loads ``pipeline_config.yaml`` for a given environment and exposes
    dotted-path lookups with internal ``${a.b.c}`` reference resolution.

    Parameters
    ----------
    environment:
        One of ``dev``, ``test``, ``prod``. Can also be supplied via the
        ``PIPELINE_ENV`` environment variable if not passed explicitly.
    config_root:
        Root folder containing ``<env>/pipeline_config.yaml`` and the shared
        ``schemas.yaml``. Defaults to ``<repo_root>/config``.

    Examples
    --------
    >>> cfg = ConfigLoader(environment="dev")
    >>> cfg.get("layers.facility.daily.table_name")
    'dev_catalog.facility.facility_daily'
    >>> cfg.get("performance.shuffle_partitions")
    200
    """

    _SCHEMA_FILE = "schemas.yaml"
    _CONFIG_FILE = "pipeline_config.yaml"

    def __init__(self, environment: Optional[str] = None, config_root: Optional[str] = None):
        self.environment = environment or os.environ.get("PIPELINE_ENV", "dev")
        self.config_root = Path(config_root) if config_root else self._default_config_root()
        self._raw: Dict[str, Any] = {}
        self._resolved: Dict[str, Any] = {}
        self._schemas: Dict[str, Any] = {}
        self._load()

    def get(self, dotted_path: str, default: Any = _UNSET) -> Any:
        """
        Fetch a config value using dotted-path notation, e.g.
        ``cfg.get("layers.facility.daily.table_name")``.

        Raises ``ConfigError`` if the path doesn't exist and no ``default``
        keyword argument was supplied. Pass ``default=...`` to suppress the
        error and get that value back instead (mirrors ``dict.get``).
        """
        node: Any = self._resolved
        for part in dotted_path.split("."):
            if isinstance(node, dict) and part in node:
                node = node[part]
            else:
                if default is not _UNSET:
                    return default
                raise ConfigError(
                    f"Config path '{dotted_path}' not found in environment '{self.environment}'"
                )
        return node

    def get_layer_config(self, layer: str, table_type: str) -> Dict[str, Any]:
        """Convenience accessor: ``get_layer_config('facility', 'daily')``."""
        return self.get(f"layers.{layer}.{table_type}")

    def get_dimension_config(self, dimension_name: str) -> Dict[str, Any]:
        return self.get(f"dimensions.{dimension_name}")

    def get_transformation_config(self, transformation_name: str) -> Dict[str, Any]:
        return self.get(f"transformations.{transformation_name}")

    def get_schema(self, schema_name: str) -> Dict[str, Any]:
        """Fetch a schema definition (column name/type/nullable) by name."""
        if schema_name not in self._schemas.get("schemas", {}):
            raise ConfigError(f"Schema '{schema_name}' not defined in {self._SCHEMA_FILE}")
        return self._schemas["schemas"][schema_name]

    def get_dq_thresholds(self) -> Dict[str, Any]:
        return self.get("data_quality.thresholds")

    def get_mandatory_columns(self, layer: str) -> list:
        return self.get(f"data_quality.mandatory_columns.{layer}", default=[])

    def as_dict(self) -> Dict[str, Any]:
        """Return a deep copy of the fully-resolved config dict."""
        return copy.deepcopy(self._resolved)

    # ------------------------------------------------------------------ #
    # Internal loading / resolution
    # ------------------------------------------------------------------ #
    def _default_config_root(self) -> Path:
        # pipeline/config_loader.py -> repo_root/config
        return Path(__file__).resolve().parents[1] / "config"

    def _load(self) -> None:
        env_file = self.config_root / self.environment / self._CONFIG_FILE
        schema_file = self.config_root / self._SCHEMA_FILE

        if not env_file.exists():
            raise ConfigError(f"Config file not found: {env_file}")

        with open(env_file, "r") as f:
            self._raw = yaml.safe_load(f) or {}

        if schema_file.exists():
            with open(schema_file, "r") as f:
                self._schemas = yaml.safe_load(f) or {}

        self._resolved = self._resolve_references(copy.deepcopy(self._raw))

    def _resolve_references(self, node: Any, _root: Optional[Dict[str, Any]] = None) -> Any:
        """
        Recursively walk the config tree and substitute ``${a.b.c}``
        references with their resolved values from the same document.
        Resolution is iterated up to 5 passes to allow nested references.
        """
        root = _root if _root is not None else node

        def resolve_value(value: Any) -> Any:
            if isinstance(value, str):
                matches = _VAR_PATTERN.findall(value)
                if not matches:
                    return value
                resolved = value
                for ref_path in matches:
                    ref_value = self._lookup(root, ref_path)
                    resolved = resolved.replace(f"${{{ref_path}}}", str(ref_value))
                return resolved
            if isinstance(value, dict):
                return {k: resolve_value(v) for k, v in value.items()}
            if isinstance(value, list):
                return [resolve_value(v) for v in value]
            return value

        result = node
        for _ in range(5):  # support nested ${} chains
            result = resolve_value(result)
        return result

    @staticmethod
    def _lookup(root: Dict[str, Any], dotted_path: str) -> Any:
        node = root
        for part in dotted_path.split("."):
            if isinstance(node, dict) and part in node:
                node = node[part]
            else:
                raise ConfigError(f"Cannot resolve reference '${{{dotted_path}}}' — path not found")
        return node
