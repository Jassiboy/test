"""
pipeline.logging_utils
========================
Centralized execution logging for every pipeline stage.

Every transformation run produces exactly one ``PipelineLogger`` context
that captures pipeline name, layer, table, timestamps, row counts, status,
and error detail, then persists a single row to the Delta audit table
(``logging.table_name`` in config) on exit — success or failure.

Usage
-----
    with PipelineLogger(spark, config, pipeline_name="account_to_facility",
                         layer="facility", table_name="facility_daily") as log:
        log.set_records_read(1_000_000)
        ... do work ...
        log.set_records_written(998_500)
        log.set_records_failed(1_500)
    # row is written automatically on __exit__, status inferred from
    # whether an exception propagated through the `with` block.
"""

from __future__ import annotations

import logging as _stdlib_logging
import traceback
import uuid
from contextlib import AbstractContextManager
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Optional

# Module-level Python logger for console/driver-log output, separate from
# the Delta audit table. Databricks captures stdout/stderr automatically
# into the cluster driver logs.
_logger = _stdlib_logging.getLogger("pipeline")
_logger.setLevel(_stdlib_logging.INFO)
if not _logger.handlers:
    _handler = _stdlib_logging.StreamHandler()
    _handler.setFormatter(_stdlib_logging.Formatter("%(asctime)s | %(levelname)s | %(name)s | %(message)s"))
    _logger.addHandler(_handler)


@dataclass
class ExecutionRecord:
    """Single row written to the pipeline_execution_log Delta table."""

    run_id: str
    pipeline_name: str
    layer: str
    table_name: str
    environment: str
    start_time: datetime
    end_time: Optional[datetime] = None
    status: str = "RUNNING"  # RUNNING | SUCCESS | FAILED
    records_read: int = 0
    records_written: int = 0
    records_failed: int = 0
    error_message: Optional[str] = None
    execution_duration_seconds: Optional[float] = None
    triggered_by: str = "scheduler"
    is_restatement: bool = False

    def to_row_dict(self) -> dict:
        return {
            "run_id": self.run_id,
            "pipeline_name": self.pipeline_name,
            "layer": self.layer,
            "table_name": self.table_name,
            "environment": self.environment,
            "start_time": self.start_time,
            "end_time": self.end_time,
            "status": self.status,
            "records_read": self.records_read,
            "records_written": self.records_written,
            "records_failed": self.records_failed,
            "error_message": self.error_message,
            "execution_duration_seconds": self.execution_duration_seconds,
            "triggered_by": self.triggered_by,
            "is_restatement": self.is_restatement,
        }


class PipelineLogger(AbstractContextManager):
    """
    Context manager that times a pipeline stage, captures metrics, and
    persists a single audit row to Delta on exit (success or failure).

    Parameters
    ----------
    spark: SparkSession
    config: ConfigLoader
    pipeline_name: logical name, e.g. "account_to_facility"
    layer: "account" | "facility" | "country" | "global"
    table_name: "facility_daily", etc.
    triggered_by: "scheduler" | "manual" | "restatement" | "backfill"
    is_restatement: flag for filtering restatement runs in the audit table
    """

    def __init__(
        self,
        spark,
        config,
        pipeline_name: str,
        layer: str,
        table_name: str,
        triggered_by: str = "scheduler",
        is_restatement: bool = False,
    ):
        self.spark = spark
        self.config = config
        self.record = ExecutionRecord(
            run_id=str(uuid.uuid4()),
            pipeline_name=pipeline_name,
            layer=layer,
            table_name=table_name,
            environment=getattr(config, "environment", "unknown"),
            start_time=datetime.now(timezone.utc),
            triggered_by=triggered_by,
            is_restatement=is_restatement,
        )
        self._start_perf = None

    # ------------------------------------------------------------------ #
    # Metric setters used by transformation classes
    # ------------------------------------------------------------------ #
    def set_records_read(self, n: int) -> None:
        self.record.records_read = int(n)

    def set_records_written(self, n: int) -> None:
        self.record.records_written = int(n)

    def set_records_failed(self, n: int) -> None:
        self.record.records_failed = int(n)

    def info(self, message: str) -> None:
        _logger.info(f"[{self.record.run_id[:8]}] [{self.record.pipeline_name}] {message}")

    def warning(self, message: str) -> None:
        _logger.warning(f"[{self.record.run_id[:8]}] [{self.record.pipeline_name}] {message}")

    def error(self, message: str) -> None:
        _logger.error(f"[{self.record.run_id[:8]}] [{self.record.pipeline_name}] {message}")

    # ------------------------------------------------------------------ #
    # Context manager protocol
    # ------------------------------------------------------------------ #
    def __enter__(self) -> "PipelineLogger":
        import time

        self._start_perf = time.perf_counter()
        self.info(
            f"START layer={self.record.layer} table={self.record.table_name} "
            f"env={self.record.environment} run_id={self.record.run_id}"
        )
        return self

    def __exit__(self, exc_type, exc_value, exc_tb) -> bool:
        import time

        self.record.end_time = datetime.now(timezone.utc)
        self.record.execution_duration_seconds = round(time.perf_counter() - self._start_perf, 3)

        if exc_type is not None:
            self.record.status = "FAILED"
            self.record.error_message = "".join(traceback.format_exception(exc_type, exc_value, exc_tb))[
                :8000
            ]  # cap message length for storage
            self.error(f"FAILED after {self.record.execution_duration_seconds}s — {exc_value}")
        else:
            self.record.status = "SUCCESS"
            self.info(
                f"SUCCESS in {self.record.execution_duration_seconds}s — "
                f"read={self.record.records_read} written={self.record.records_written} "
                f"failed={self.record.records_failed}"
            )

        self._persist()
        # Returning False re-raises any exception that occurred — logging
        # should observe failures, never swallow them.
        return False

    # ------------------------------------------------------------------ #
    # Persistence
    # ------------------------------------------------------------------ #
    def _persist(self) -> None:
        """Append one row to the Delta audit table. Never raises — a logging
        failure must not mask the real pipeline outcome."""
        try:
            log_path = self.config.get("logging.path")
            row = self.record.to_row_dict()
            df = self.spark.createDataFrame([row])
            (df.write.format("delta").mode("append").option("mergeSchema", "true").save(log_path))
        except Exception as persist_exc:  # noqa: BLE001 - intentional broad catch
            _logger.error(f"Failed to persist execution log for run_id={self.record.run_id}: {persist_exc}")


def get_logger() -> _stdlib_logging.Logger:
    """Expose the shared module-level stdlib logger for components that
    only need console/driver logging without a Delta audit row (e.g. a
    helper function inside a transformation)."""
    return _logger
