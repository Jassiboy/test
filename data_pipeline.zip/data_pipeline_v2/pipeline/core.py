"""
pipeline.core
=============
Core infrastructure shared by every layer transformation:

* ``BaseTransformation`` — abstract Template Method base class. ``run()``
  fixes the read -> transform -> validate -> quarantine -> write -> log
  skeleton; concrete subclasses (in ``transformations.py``) override only
  ``read()``, ``transform()``, and ``validate()``.
* ``SparkSessionFactory`` — centralizes performance-conf tuning so every
  entry point gets identical Spark settings.
* ``DeltaIOHelper`` — reusable read/cache/broadcast helpers so each
  transformation's ``read()`` stays short and declarative.

Why one BaseTransformation instead of three independent scripts: the three
layer transitions share identical operational concerns (schema validation,
quarantine routing, idempotent partition writes, audit logging). Putting
that orchestration in exactly one place makes drift between layers
structurally impossible — a bug fix here fixes all three layers at once.
"""

from __future__ import annotations

import uuid
from abc import ABC, abstractmethod
from typing import Any, Dict, List, Optional

from pyspark.sql import DataFrame, SparkSession
from pyspark.sql import functions as F

from .dq import DQMetricsWriter, DQReport, QuarantineHandler


# ============================================================================
# SparkSessionFactory
# ============================================================================
class SparkSessionFactory:
    @staticmethod
    def get_or_create(config: Any, app_name: str = "data_pipeline") -> SparkSession:
        """Returns the active SparkSession (Databricks reuses the cluster's
        session) with performance settings applied from config."""
        spark = SparkSession.builder.appName(app_name).getOrCreate()
        SparkSessionFactory.apply_performance_settings(spark, config)
        return spark

    @staticmethod
    def apply_performance_settings(spark: SparkSession, config: Any) -> None:
        perf = config.get("performance", default={})

        if "shuffle_partitions" in perf:
            spark.conf.set("spark.sql.shuffle.partitions", str(perf["shuffle_partitions"]))
        if "broadcast_threshold_bytes" in perf:
            spark.conf.set("spark.sql.autoBroadcastJoinThreshold", str(perf["broadcast_threshold_bytes"]))
        if perf.get("enable_aqe", True):
            spark.conf.set("spark.sql.adaptive.enabled", "true")
            spark.conf.set("spark.sql.adaptive.coalescePartitions.enabled", "true")
        if perf.get("enable_skew_join_optimization", True):
            spark.conf.set("spark.sql.adaptive.skewJoin.enabled", "true")
        if perf.get("optimize_write", True):
            spark.conf.set("spark.databricks.delta.optimizeWrite.enabled", "true")
        if perf.get("auto_compact", True):
            spark.conf.set("spark.databricks.delta.autoCompact.enabled", "true")


# ============================================================================
# DeltaIOHelper
# ============================================================================
class DeltaIOHelper:
    def __init__(self, spark: SparkSession, config: Any):
        self.spark = spark
        self.config = config

    def read_table(self, path: str) -> DataFrame:
        return self.spark.read.format("delta").load(path)

    def read_layer_table(self, layer: str, table_type: str) -> DataFrame:
        layer_config = self.config.get_layer_config(layer, table_type)
        return self.read_table(layer_config["path"])

    def read_layer_table_for_date_range(
        self, layer: str, table_type: str, date_column: str, start_date: str, end_date: str
    ) -> DataFrame:
        """Reads only partitions in [start_date, end_date] — partition
        pruning skips files outside the range entirely."""
        df = self.read_layer_table(layer, table_type)
        return df.filter((F.col(date_column) >= start_date) & (F.col(date_column) <= end_date))

    def read_dimension(self, dimension_name: str, cache: bool = True) -> DataFrame:
        """Reads a dimension table, applies the SCD2 active-row filter if
        configured, and optionally caches/broadcasts it (small dimension
        tables are reused across many joins within a job)."""
        dim_config = self.config.get_dimension_config(dimension_name)
        df = self.read_table(dim_config["path"])

        active_flag_col = dim_config.get("active_flag_column")
        if active_flag_col and dim_config.get("scd_type") == 2:
            df = df.filter(F.col(active_flag_col) == True)  # noqa: E712

        if cache and self.config.get("performance.cache_dimension_tables", default=True):
            df = df.cache()
        if dim_config.get("broadcast", False):
            df = F.broadcast(df)
        return df

    @staticmethod
    def select_columns(df: DataFrame, columns: List[str]) -> DataFrame:
        missing = [c for c in columns if c not in df.columns]
        if missing:
            raise ValueError(f"Columns not found in DataFrame: {missing}")
        return df.select(*columns)


# ============================================================================
# BaseTransformation
# ============================================================================
class BaseTransformation(ABC):
    """
    Parameters
    ----------
    spark, config: injected, never created inside the class — this is what
        makes unit testing with a local Spark session possible.
    table_type: "daily" | "monthly".
    triggered_by: "scheduler" | "manual" | "restatement" | "backfill".
    kwargs: run_date=... for daily, year_month=... for monthly.
    """

    def __init__(
        self,
        spark: SparkSession,
        config: Any,
        table_type: str = "daily",
        triggered_by: str = "scheduler",
        is_restatement: bool = False,
        **kwargs: Any,
    ):
        self.spark = spark
        self.config = config
        self.table_type = table_type
        self.triggered_by = triggered_by
        self.is_restatement = is_restatement
        self.run_id = str(uuid.uuid4())
        self.kwargs = kwargs

        self._source_df: Optional[DataFrame] = None
        self._transformed_df: Optional[DataFrame] = None
        self._dq_report: Optional[DQReport] = None
        self._final_df: Optional[DataFrame] = None

    # ------------------------------------------------------------------ #
    # Identity — subclasses define these
    # ------------------------------------------------------------------ #
    @property
    @abstractmethod
    def pipeline_name(self) -> str:
        """e.g. 'account_to_facility'"""

    @property
    @abstractmethod
    def layer(self) -> str:
        """'facility' | 'country' | 'global'"""

    @property
    def target_table_name(self) -> str:
        return f"{self.layer}_{self.table_type}"

    # ------------------------------------------------------------------ #
    # Template steps — subclasses implement these
    # ------------------------------------------------------------------ #
    @abstractmethod
    def read(self) -> DataFrame:
        """Read and return the source DataFrame(s), joined as needed."""

    @abstractmethod
    def transform(self, source_df: DataFrame) -> DataFrame:
        """Pure function: DataFrame in, DataFrame out. No I/O — this is
        what makes the aggregation/business logic unit-testable without
        Delta or a cloud connection."""

    @abstractmethod
    def validate(self, transformed_df: DataFrame) -> DQReport:
        """Run the layer's DQ rule set (pipeline.dq.RuleEngine) and return
        a DQReport."""

    def write(self, validated_df: DataFrame) -> None:
        """Default implementation: idempotent partition-level overwrite
        via Delta's `replaceWhere`. Subclasses rarely need to override
        this — adjust config (`write_mode`, `partition_columns`) instead."""
        layer_config = self.config.get_layer_config(self.layer, self.table_type)
        path = layer_config["path"]
        partition_columns = layer_config.get("partition_columns", [])
        write_mode = layer_config.get("write_mode", "overwrite")

        writer = validated_df.write.format("delta").mode(write_mode)
        if partition_columns:
            writer = writer.partitionBy(*partition_columns)
            writer = writer.option(
                "replaceWhere", self._replace_where_clause(validated_df, partition_columns)
            )
        writer.option("mergeSchema", "true").save(path)

        z_order_cols = layer_config.get("z_order_columns")
        if z_order_cols and self.config.get("performance.optimize_write", default=True):
            cols = ", ".join(z_order_cols)
            self.spark.sql(f"OPTIMIZE delta.`{path}` ZORDER BY ({cols})")

    def _replace_where_clause(self, df: DataFrame, partition_columns: list) -> str:
        """Builds a replaceWhere predicate covering exactly the distinct
        partition values present in `df`, so writing one date never
        touches another (idempotent reruns + restatement-safe)."""
        distinct_values = df.select(*partition_columns).distinct().collect()
        if not distinct_values:
            return "1=0"  # no data -> safe no-op, never an accidental full overwrite

        clauses = []
        for row in distinct_values:
            per_col = []
            for col in partition_columns:
                val = row[col]
                literal = f"'{val}'" if isinstance(val, str) else str(val)
                per_col.append(f"{col} = {literal}")
            clauses.append("(" + " AND ".join(per_col) + ")")
        return " OR ".join(clauses)

    # ------------------------------------------------------------------ #
    # Template Method — fixed skeleton, subclasses never override this.
    # ------------------------------------------------------------------ #
    def run(self) -> Dict[str, Any]:
        from .logging_utils import PipelineLogger  # local import avoids a circular import

        with PipelineLogger(
            self.spark,
            self.config,
            pipeline_name=self.pipeline_name,
            layer=self.layer,
            table_name=self.target_table_name,
            triggered_by=self.triggered_by,
            is_restatement=self.is_restatement,
        ) as log:

            log.info("Reading source data")
            self._source_df = self.read()
            records_read = self._source_df.count()
            log.set_records_read(records_read)

            log.info("Applying transformation logic")
            self._transformed_df = self.transform(self._source_df)

            log.info("Running data quality validation")
            self._dq_report = self.validate(self._transformed_df)
            log.info(self._dq_report.summary())
            DQMetricsWriter(self.spark, self.config).write(self._dq_report, self.run_id)

            layer_config = self.config.get_layer_config(self.layer, self.table_type)
            quarantine = QuarantineHandler(
                self.spark, self.config, self.layer, self.target_table_name, self.run_id
            )
            self._final_df = quarantine.enforce(
                self._transformed_df, self._dq_report, primary_keys=layer_config.get("primary_keys")
            )

            records_failed = self._dq_report.total_records_failed
            log.set_records_failed(records_failed)

            log.info("Writing validated output")
            self.write(self._final_df)
            records_written = self._final_df.count()
            log.set_records_written(records_written)
            log.info(f"Wrote {records_written} records to {self.target_table_name}")

            return {
                "run_id": self.run_id,
                "pipeline_name": self.pipeline_name,
                "layer": self.layer,
                "table_name": self.target_table_name,
                "records_read": records_read,
                "records_written": records_written,
                "records_failed": records_failed,
                "dq_passed": not self._dq_report.has_any_failure,
            }
