"""
pipeline.jobs
=============
Orchestrator-callable entry points, consolidated into one module with
three subcommands. This is what a Databricks Job / Airflow task / ADF
pipeline activity invokes.

Usage
-----
    python -m pipeline.jobs daily   --env prod --run-date 2025-01-15 --also-run-monthly
    python -m pipeline.jobs monthly --env prod --year-month 2025-01
    python -m pipeline.jobs restate --env prod --layer facility --table-type daily \\
        --start-date 2025-01-01 --end-date 2025-01-31 --cascade
"""

from __future__ import annotations

import argparse
import sys
from typing import Optional

from .config_loader import ConfigLoader
from .core import SparkSessionFactory
from .restatement import RestatementEngine
from .transformations import AccountToFacility, CountryToGlobal, FacilityToCountry
from .utils import is_month_end, to_year_month


# ============================================================================
# Daily / monthly chain runners (shared by the `daily` and `monthly` subcommands)
# ============================================================================
def run_daily_chain(spark, config, run_date: str) -> dict:
    """Runs Account->Facility->Country->Global sequentially for one date.
    CRITICAL DQ failures already raise inside BaseTransformation.run();
    this additionally surfaces HIGH-severity failures via a warning log so
    the chain doesn't silently compound on already-flagged data."""
    results = {}

    results["facility"] = AccountToFacility(spark, config, table_type="daily", run_date=run_date).run()
    if not results["facility"]["dq_passed"]:
        print(f"[WARN] facility_daily DQ check reported failures for {run_date}; continuing per policy")

    results["country"] = FacilityToCountry(spark, config, table_type="daily", run_date=run_date).run()
    results["global"] = CountryToGlobal(spark, config, table_type="daily", run_date=run_date).run()
    return results


def run_monthly_chain(spark, config, year_month: str) -> dict:
    results = {}
    results["facility"] = AccountToFacility(spark, config, table_type="monthly", year_month=year_month).run()
    results["country"] = FacilityToCountry(spark, config, table_type="monthly", year_month=year_month).run()
    results["global"] = CountryToGlobal(spark, config, table_type="monthly", year_month=year_month).run()
    return results


# ============================================================================
# Subcommand handlers
# ============================================================================
def _cmd_daily(args: argparse.Namespace) -> int:
    config = ConfigLoader(environment=args.env)
    spark = SparkSessionFactory.get_or_create(config, app_name="daily_pipeline")

    print(f"Starting daily chain | env={args.env} run_date={args.run_date}")
    daily_results = run_daily_chain(spark, config, args.run_date)
    for layer, result in daily_results.items():
        print(f"  {layer}: {result}")

    if args.also_run_monthly and is_month_end(args.run_date):
        year_month = to_year_month(args.run_date)
        print(f"Month-end detected ({year_month}); running monthly chain")
        monthly_results = run_monthly_chain(spark, config, year_month)
        for layer, result in monthly_results.items():
            print(f"  {layer}: {result}")

    return 1 if any(not r["dq_passed"] for r in daily_results.values()) else 0


def _cmd_monthly(args: argparse.Namespace) -> int:
    config = ConfigLoader(environment=args.env)
    spark = SparkSessionFactory.get_or_create(config, app_name="monthly_pipeline")

    print(f"Starting monthly chain | env={args.env} year_month={args.year_month}")
    results = run_monthly_chain(spark, config, args.year_month)
    for layer, result in results.items():
        print(f"  {layer}: {result}")

    return 1 if any(not r["dq_passed"] for r in results.values()) else 0


def _cmd_restate(args: argparse.Namespace) -> int:
    config = ConfigLoader(environment=args.env)
    spark = SparkSessionFactory.get_or_create(config, app_name="restatement")

    if config.get("restatement.require_confirmation", default=True) and args.env == "prod":
        confirm = input(
            f"You are about to restate {args.layer}.{args.table_type} in PROD "
            f"({args.start_date or args.month} to {args.end_date or ''}). Type 'yes' to confirm: "
        )
        if confirm.strip().lower() != "yes":
            print("Restatement cancelled.")
            return 1

    engine = RestatementEngine(spark, config)
    results = engine.run(
        layer=args.layer,
        table_type=args.table_type,
        start_date=args.start_date,
        end_date=args.end_date,
        month=args.month,
        cascade=args.cascade,
        requested_by=args.requested_by,
    )

    print(f"Restatement complete — {len(results)} transformation run(s) executed:")
    for r in results:
        print(f"  {r}")
    return 0


# ============================================================================
# CLI wiring
# ============================================================================
def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="pipeline.jobs", description="Pipeline job entry points")
    subparsers = parser.add_subparsers(dest="command", required=True)

    daily = subparsers.add_parser("daily", help="Run the daily Account->Facility->Country->Global chain")
    daily.add_argument("--env", default="dev", choices=["dev", "test", "prod"])
    daily.add_argument("--run-date", required=True, help="Business date, YYYY-MM-DD")
    daily.add_argument("--also-run-monthly", action="store_true")
    daily.set_defaults(func=_cmd_daily)

    monthly = subparsers.add_parser("monthly", help="Run the monthly chain standalone")
    monthly.add_argument("--env", default="dev", choices=["dev", "test", "prod"])
    monthly.add_argument("--year-month", required=True, help="Format YYYY-MM")
    monthly.set_defaults(func=_cmd_monthly)

    restate = subparsers.add_parser("restate", help="Run a generic restatement for one layer/date-range")
    restate.add_argument("--env", default="dev", choices=["dev", "test", "prod"])
    restate.add_argument("--layer", required=True, choices=["facility", "country", "global"])
    restate.add_argument("--table-type", required=True, choices=["daily", "monthly"])
    restate.add_argument("--start-date", help="YYYY-MM-DD, required for daily")
    restate.add_argument("--end-date", help="YYYY-MM-DD, required for daily")
    restate.add_argument("--month", help="YYYY-MM, required for monthly")
    restate.add_argument("--cascade", action="store_true", help="Recompute downstream layers too")
    restate.add_argument("--requested-by", default="manual")
    restate.set_defaults(func=_cmd_restate)

    return parser


def main(argv: Optional[list] = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
