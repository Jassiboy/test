"""
pipeline
========
Multi-layer (Account -> Facility -> Country -> Global) data transformation
pipeline for Azure Databricks + Delta Lake.

Modules
-------
config_loader     YAML-backed ConfigLoader with ${a.b.c} reference resolution
core              BaseTransformation (Template Method), SparkSessionFactory, DeltaIOHelper
transformations   AccountToFacility, FacilityToCountry, CountryToGlobal
dq                Schema validation, rule engine, quarantine handling, metrics
restatement       Generic selective reprocessing framework
logging_utils     Centralized execution audit logging (PipelineLogger)
utils             Secrets resolution, date helpers
jobs              CLI entry points (daily / monthly / restate subcommands)
"""

from .config_loader import ConfigError, ConfigLoader
from .core import BaseTransformation, DeltaIOHelper, SparkSessionFactory
from .dq import (
    BusinessCheckSpec,
    CheckCategory,
    CheckResult,
    DataQualityError,
    DQCheckOutcome,
    DQMetricsWriter,
    DQReport,
    QuarantineHandler,
    ReferentialCheckSpec,
    RuleEngine,
    SchemaValidator,
    Severity,
)
from .logging_utils import ExecutionRecord, PipelineLogger, get_logger
from .restatement import RestatementEngine, RestatementError
from .transformations import AccountToFacility, CountryToGlobal, FacilityToCountry

__version__ = "1.0.0"

__all__ = [
    "ConfigLoader",
    "ConfigError",
    "BaseTransformation",
    "SparkSessionFactory",
    "DeltaIOHelper",
    "AccountToFacility",
    "FacilityToCountry",
    "CountryToGlobal",
    "Severity",
    "CheckCategory",
    "CheckResult",
    "DQCheckOutcome",
    "DQReport",
    "DataQualityError",
    "SchemaValidator",
    "RuleEngine",
    "BusinessCheckSpec",
    "ReferentialCheckSpec",
    "QuarantineHandler",
    "DQMetricsWriter",
    "RestatementEngine",
    "RestatementError",
    "PipelineLogger",
    "ExecutionRecord",
    "get_logger",
]
