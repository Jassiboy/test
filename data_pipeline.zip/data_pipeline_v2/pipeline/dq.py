"""
pipeline.dq
===========
Data Quality framework, consolidated into one module:

* Models       — Severity, CheckResult, DQCheckOutcome, DQReport, exceptions
* SchemaValidator — validates DataFrame schema against config/schemas.yaml
* RuleEngine   — null / duplicate / referential-integrity / business-rule /
                  aggregate-reconciliation checks
* QuarantineHandler — graduated failed-record policy (CRITICAL halts,
                  HIGH quarantines, MEDIUM flags, LOW logs only)
* DQMetricsWriter — persists every check outcome to the Delta audit table
"""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Dict, List, Optional

from pyspark.sql import DataFrame
from pyspark.sql import functions as F
from pyspark.sql.types import DataType, DateType, DoubleType, IntegerType, LongType, StringType, TimestampType
from pyspark.sql.window import Window


# ============================================================================
# Models
# ============================================================================
class Severity(str, Enum):
    CRITICAL = "CRITICAL"  # halts the pipeline
    HIGH = "HIGH"  # quarantines offending records, pipeline continues
    MEDIUM = "MEDIUM"  # flags records, included in output
    LOW = "LOW"  # logged only


class CheckCategory(str, Enum):
    RECORD_VALIDATION = "RECORD_VALIDATION"
    BUSINESS_VALIDATION = "BUSINESS_VALIDATION"


class CheckResult(str, Enum):
    PASSED = "PASSED"
    FAILED = "FAILED"
    WARNING = "WARNING"


@dataclass
class DQCheckOutcome:
    check_name: str
    category: CheckCategory
    result: CheckResult
    severity: Severity
    records_checked: int
    records_failed: int
    threshold_pct: float
    details: str = ""
    check_timestamp: datetime = field(default_factory=lambda: datetime.now(timezone.utc))

    @property
    def fail_rate_pct(self) -> float:
        if self.records_checked == 0:
            return 0.0
        return round(100.0 * self.records_failed / self.records_checked, 4)

    def to_row_dict(self, dq_log_id: str, run_id: str, layer: str, table_name: str) -> dict:
        return {
            "dq_log_id": dq_log_id,
            "run_id": run_id,
            "layer": layer,
            "table_name": table_name,
            "check_name": self.check_name,
            "check_category": self.category.value,
            "check_result": self.result.value,
            "records_checked": self.records_checked,
            "records_failed": self.records_failed,
            "fail_rate_pct": self.fail_rate_pct,
            "threshold_pct": self.threshold_pct,
            "severity": self.severity.value,
            "check_timestamp": self.check_timestamp,
            "details": self.details,
        }


@dataclass
class DQReport:
    layer: str
    table_name: str
    outcomes: List[DQCheckOutcome] = field(default_factory=list)

    def add(self, outcome: DQCheckOutcome) -> None:
        self.outcomes.append(outcome)

    @property
    def has_critical_failure(self) -> bool:
        return any(o.result == CheckResult.FAILED and o.severity == Severity.CRITICAL for o in self.outcomes)

    @property
    def has_any_failure(self) -> bool:
        return any(o.result == CheckResult.FAILED for o in self.outcomes)

    @property
    def total_records_failed(self) -> int:
        return sum(o.records_failed for o in self.outcomes if o.result != CheckResult.PASSED)

    def summary(self) -> str:
        lines = [f"DQ Report — layer={self.layer} table={self.table_name}"]
        for o in self.outcomes:
            lines.append(
                f"  [{o.severity.value:8s}] {o.check_name:35s} "
                f"{o.result.value:8s} ({o.records_failed}/{o.records_checked} = {o.fail_rate_pct}%)"
            )
        return "\n".join(lines)


class DataQualityError(Exception):
    """Raised when a CRITICAL check fails and the pipeline is configured
    to halt on critical failures (the production default)."""

    def __init__(self, report: DQReport):
        self.report = report
        super().__init__(f"Critical DQ failure in {report.layer}.{report.table_name}:\n{report.summary()}")


# ============================================================================
# SchemaValidator
# ============================================================================
_TYPE_MAP: Dict[str, DataType] = {
    "string": StringType(),
    "integer": IntegerType(),
    "long": LongType(),
    "double": DoubleType(),
    "date": DateType(),
    "timestamp": TimestampType(),
}


class SchemaValidator:
    """Validates a DataFrame's schema (names, types) against the column
    list in ``config/schemas.yaml``. Always CRITICAL severity — a schema
    mismatch means something upstream fundamentally changed and no
    data-level check can compensate."""

    def __init__(self, schema_definition: dict):
        self.expected_columns: List[dict] = schema_definition.get("columns", [])

    def validate(self, df: DataFrame) -> DQCheckOutcome:
        actual_fields = {f.name: f for f in df.schema.fields}
        errors: List[str] = []

        for col_def in self.expected_columns:
            name = col_def["name"]
            expected_type = col_def["type"]

            if name not in actual_fields:
                errors.append(f"missing column '{name}'")
                continue

            actual_field = actual_fields[name]
            expected_spark_type = _TYPE_MAP.get(expected_type)
            if expected_spark_type is not None and actual_field.dataType != expected_spark_type:
                errors.append(
                    f"column '{name}' expected type {expected_type} "
                    f"but found {actual_field.dataType.simpleString()}"
                )
            # Nullability mismatches are deliberately not flagged here —
            # Spark schema nullability is unreliable after joins; the
            # actual null check is RuleEngine.check_nulls() on row data.

        passed = len(errors) == 0
        return DQCheckOutcome(
            check_name="schema_validation",
            category=CheckCategory.RECORD_VALIDATION,
            result=CheckResult.PASSED if passed else CheckResult.FAILED,
            severity=Severity.CRITICAL,
            records_checked=0,
            records_failed=0 if passed else 1,
            threshold_pct=0.0,
            details="; ".join(errors) if errors else "schema matches expected definition",
        )


# ============================================================================
# RuleEngine spec objects
# ============================================================================
class ReferentialCheckSpec:
    def __init__(self, fk_column: str, dimension_df: DataFrame, dim_key_column: str):
        self.fk_column = fk_column
        self.dimension_df = dimension_df
        self.dim_key_column = dim_key_column


class BusinessCheckSpec:
    def __init__(
        self, name: str, condition: str, severity: Severity = Severity.HIGH, threshold_pct: float = 0.0
    ):
        self.name = name
        self.condition = condition
        self.severity = severity
        self.threshold_pct = threshold_pct


# ============================================================================
# RuleEngine
# ============================================================================
class RuleEngine:
    """Executes record-validation and business-validation checks against a
    DataFrame, producing a DQReport. Each check is a small, independently
    testable method rather than one large function."""

    def __init__(self, config, layer: str, table_name: str):
        self.config = config
        self.layer = layer
        self.table_name = table_name
        self.thresholds = config.get_dq_thresholds()
        self.mandatory_columns = config.get_mandatory_columns(layer)

    # ---------------- Orchestration ---------------- #
    def run_all(
        self,
        df: DataFrame,
        primary_keys: List[str],
        schema_name: Optional[str] = None,
        referential_checks: Optional[List[ReferentialCheckSpec]] = None,
        business_checks: Optional[List[BusinessCheckSpec]] = None,
    ) -> DQReport:
        report = DQReport(layer=self.layer, table_name=self.table_name)

        if schema_name:
            report.add(SchemaValidator(self.config.get_schema(schema_name)).validate(df))

        report.add(self.check_nulls(df))
        report.add(self.check_duplicates(df, primary_keys))

        for spec in referential_checks or []:
            report.add(self.check_referential_integrity(df, spec))
        for spec in business_checks or []:
            report.add(self.check_business_rule(df, spec))

        return report

    def run_record_validations(self, df: DataFrame, primary_keys: List[str]) -> DQReport:
        report = DQReport(layer=self.layer, table_name=self.table_name)
        report.add(self.check_nulls(df))
        report.add(self.check_duplicates(df, primary_keys))
        return report

    # ---------------- Record-level checks ---------------- #
    def check_nulls(self, df: DataFrame) -> DQCheckOutcome:
        total = df.count()
        threshold = self.thresholds.get("null_rate_max_pct", 1.0)
        if total == 0 or not self.mandatory_columns:
            return DQCheckOutcome(
                "null_check_mandatory_columns",
                CheckCategory.RECORD_VALIDATION,
                CheckResult.PASSED,
                Severity.HIGH,
                total,
                0,
                threshold,
                "no rows or no mandatory columns configured",
            )

        null_condition = None
        for col in self.mandatory_columns:
            cond = F.col(col).isNull()
            null_condition = cond if null_condition is None else (null_condition | cond)

        failed = df.filter(null_condition).count()
        fail_rate = round(100.0 * failed / total, 4)
        passed = fail_rate <= threshold

        return DQCheckOutcome(
            "null_check_mandatory_columns",
            CheckCategory.RECORD_VALIDATION,
            CheckResult.PASSED if passed else CheckResult.FAILED,
            Severity.HIGH,
            total,
            failed,
            threshold,
            f"checked columns: {', '.join(self.mandatory_columns)}",
        )

    def check_duplicates(self, df: DataFrame, primary_keys: List[str]) -> DQCheckOutcome:
        total = df.count()
        threshold = self.thresholds.get("duplicate_rate_max_pct", 0.0)
        if total == 0 or not primary_keys:
            return DQCheckOutcome(
                "duplicate_check_primary_key",
                CheckCategory.RECORD_VALIDATION,
                CheckResult.PASSED,
                Severity.HIGH,
                total,
                0,
                threshold,
                "no rows or no primary keys configured",
            )

        distinct_count = df.select(*primary_keys).distinct().count()
        duplicate_count = total - distinct_count
        fail_rate = round(100.0 * duplicate_count / total, 4)
        passed = fail_rate <= threshold

        return DQCheckOutcome(
            "duplicate_check_primary_key",
            CheckCategory.RECORD_VALIDATION,
            CheckResult.PASSED if passed else CheckResult.FAILED,
            Severity.HIGH,
            total,
            duplicate_count,
            threshold,
            f"primary keys: {', '.join(primary_keys)}",
        )

    # ---------------- Business-level checks ---------------- #
    def check_referential_integrity(self, df: DataFrame, spec: ReferentialCheckSpec) -> DQCheckOutcome:
        """Confirms every value of spec.fk_column in df exists in
        spec.dimension_df's spec.dim_key_column — no orphaned FKs after a join."""
        total = df.count()
        if total == 0:
            return DQCheckOutcome(
                f"referential_integrity_{spec.fk_column}",
                CheckCategory.BUSINESS_VALIDATION,
                CheckResult.PASSED,
                Severity.HIGH,
                0,
                0,
                0.0,
                "no rows to check",
            )

        valid_keys = spec.dimension_df.select(F.col(spec.dim_key_column).alias("_valid_key")).distinct()
        orphans = (
            df.select(F.col(spec.fk_column).alias("_fk"))
            .distinct()
            .join(valid_keys, F.col("_fk") == F.col("_valid_key"), "left_anti")
        )
        orphan_count = orphans.count()
        passed = orphan_count == 0

        return DQCheckOutcome(
            f"referential_integrity_{spec.fk_column}",
            CheckCategory.BUSINESS_VALIDATION,
            CheckResult.PASSED if passed else CheckResult.FAILED,
            Severity.HIGH,
            total,
            orphan_count,
            0.0,
            f"{spec.fk_column} -> {spec.dim_key_column}; {orphan_count} orphaned key(s)",
        )

    def check_business_rule(self, df: DataFrame, spec: BusinessCheckSpec) -> DQCheckOutcome:
        """spec.condition is a SQL boolean expression that should be TRUE
        for valid rows, e.g. 'total_revenue >= 0'."""
        total = df.count()
        if total == 0:
            return DQCheckOutcome(
                spec.name,
                CheckCategory.BUSINESS_VALIDATION,
                CheckResult.PASSED,
                spec.severity,
                0,
                0,
                spec.threshold_pct,
                "no rows to check",
            )

        failed = df.filter(f"NOT ({spec.condition})").count()
        fail_rate = round(100.0 * failed / total, 4)
        passed = fail_rate <= spec.threshold_pct

        return DQCheckOutcome(
            spec.name,
            CheckCategory.BUSINESS_VALIDATION,
            CheckResult.PASSED if passed else CheckResult.FAILED,
            spec.severity,
            total,
            failed,
            spec.threshold_pct,
            f"condition: {spec.condition}",
        )

    def check_aggregate_totals(
        self,
        source_df: DataFrame,
        aggregated_df: DataFrame,
        source_column: str,
        aggregated_column: str,
        tolerance_pct: float = 0.01,
    ) -> DQCheckOutcome:
        """Confirms SUM(source_column) pre-aggregation equals
        SUM(aggregated_column) post-aggregation within tolerance — catches
        silent row loss in Facility->Country->Global rollups."""
        source_total = source_df.agg(F.sum(source_column)).first()[0] or 0.0
        agg_total = aggregated_df.agg(F.sum(aggregated_column)).first()[0] or 0.0

        variance_pct = (
            0.0
            if source_total == 0 and agg_total == 0
            else (
                100.0
                if source_total == 0
                else round(100.0 * abs(source_total - agg_total) / abs(source_total), 4)
            )
        )
        passed = variance_pct <= tolerance_pct

        return DQCheckOutcome(
            f"aggregate_total_reconciliation_{aggregated_column}",
            CheckCategory.BUSINESS_VALIDATION,
            CheckResult.PASSED if passed else CheckResult.FAILED,
            Severity.CRITICAL,
            1,
            0 if passed else 1,
            tolerance_pct,
            f"source_sum({source_column})={source_total:.4f} vs "
            f"aggregated_sum({aggregated_column})={agg_total:.4f} variance={variance_pct}%",
        )


# ============================================================================
# QuarantineHandler
# ============================================================================
class QuarantineHandler:
    """Failed-record handling policy:
       CRITICAL -> raise DataQualityError, halt pipeline, nothing written.
       HIGH     -> offending rows quarantined to Delta, clean rows proceed.
       MEDIUM   -> offending rows tagged dq_flag=WARNING, included in output.
       LOW      -> logged only.

    Deliberately graduated, not all-or-nothing: a single malformed row in
    a 2M-row load shouldn't block everything, but a CRITICAL failure means
    the whole batch is untrustworthy and must halt.
    """

    def __init__(self, spark, config, layer: str, table_name: str, run_id: str):
        self.spark = spark
        self.config = config
        self.layer = layer
        self.table_name = table_name
        self.run_id = run_id
        self.quarantine_base_path = config.get("data_quality.quarantine.path")

    def enforce(self, df: DataFrame, report: DQReport, primary_keys: Optional[list] = None) -> DataFrame:
        if report.has_critical_failure and self.config.get(
            "data_quality.fail_pipeline_on_critical", default=True
        ):
            raise DataQualityError(report)

        result_df = df

        high_failures = [
            o for o in report.outcomes if o.result == CheckResult.FAILED and o.severity == Severity.HIGH
        ]
        if high_failures and primary_keys:
            result_df = self._quarantine_null_or_duplicate_rows(result_df, primary_keys)

        medium_failures = [
            o for o in report.outcomes if o.result == CheckResult.FAILED and o.severity == Severity.MEDIUM
        ]
        if medium_failures:
            result_df = result_df.withColumn("dq_flag", F.lit("WARNING"))
        elif "dq_flag" not in result_df.columns:
            result_df = result_df.withColumn("dq_flag", F.lit(None).cast("string"))

        return result_df

    def _quarantine_null_or_duplicate_rows(self, df: DataFrame, primary_keys: list) -> DataFrame:
        mandatory_columns = self.config.get_mandatory_columns(self.layer)

        null_condition = None
        for col in mandatory_columns:
            if col in df.columns:
                cond = F.col(col).isNull()
                null_condition = cond if null_condition is None else (null_condition | cond)

        if null_condition is not None:
            offending_nulls = df.filter(null_condition)
            clean_df = df.filter(~null_condition)
        else:
            offending_nulls = df.limit(0)
            clean_df = df

        # Keep first occurrence of a duplicated key, quarantine the rest —
        # never drop ALL copies of a duplicated key.
        if primary_keys:
            ranked = clean_df.withColumn(
                "_dq_rn", F.row_number().over(Window.partitionBy(*primary_keys).orderBy(F.lit(1)))
            )
            offending_dupes = ranked.filter(F.col("_dq_rn") > 1).drop("_dq_rn")
            clean_df = ranked.filter(F.col("_dq_rn") == 1).drop("_dq_rn")
        else:
            offending_dupes = df.limit(0)

        offending = offending_nulls.unionByName(offending_dupes, allowMissingColumns=True)
        if offending.limit(1).count() > 0:
            self._write_quarantine(offending)

        return clean_df

    def _write_quarantine(self, offending_df: DataFrame) -> None:
        tagged = (
            offending_df.withColumn("_quarantine_run_id", F.lit(self.run_id))
            .withColumn("_quarantine_layer", F.lit(self.layer))
            .withColumn("_quarantine_table", F.lit(self.table_name))
            .withColumn("_quarantine_timestamp", F.current_timestamp())
        )
        path = f"{self.quarantine_base_path}/{self.layer}/{self.table_name}"
        tagged.write.format("delta").mode("append").option("mergeSchema", "true").save(path)


# ============================================================================
# DQMetricsWriter
# ============================================================================
class DQMetricsWriter:
    """Persists every check outcome in a DQReport as one row each in the
    dq_execution_log Delta table, linked to the parent run via run_id."""

    def __init__(self, spark, config):
        self.spark = spark
        self.config = config

    def write(self, report: DQReport, run_id: str) -> None:
        if not report.outcomes:
            return
        rows = [
            outcome.to_row_dict(
                dq_log_id=str(uuid.uuid4()), run_id=run_id, layer=report.layer, table_name=report.table_name
            )
            for outcome in report.outcomes
        ]
        df = self.spark.createDataFrame(rows)
        path = self.config.get("logging.dq_path")
        df.write.format("delta").mode("append").option("mergeSchema", "true").save(path)
