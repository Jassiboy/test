"""
pipeline.restatement
=====================
Generic restatement (reprocessing) framework.

Allows reprocessing a single layer/table for an arbitrary date range (daily)
or month (monthly) without rerunning the entire pipeline from Account
forward — while still using exactly the same transformation classes used
by the regular scheduled run, so restated data is computed by identical
logic (no special "restatement-only" code path that could drift from the
normal path and silently produce different numbers).

Usage
-----
    restatement = RestatementEngine(spark, config)
    restatement.run(
        layer="facility",
        table_type="daily",
        start_date="2025-01-01",
        end_date="2025-01-31",
        cascade=True,        # also recompute country + global for these dates
    )

    restatement.run(layer="country", table_type="monthly", month="2025-01")

Idempotency & duplicate prevention
-----------------------------------
Restatement reuses ``BaseTransformation.write()``'s ``replaceWhere``
partition-overwrite logic — re-running a restatement for the same range
twice produces the exact same end state, never duplicate rows, because
each partition is fully replaced rather than appended.
"""

from __future__ import annotations

import uuid
from datetime import datetime, timezone
from typing import Any, List, Optional

from pyspark.sql import functions as F

from .transformations import AccountToFacility, CountryToGlobal, FacilityToCountry

# Defines, for a given layer, which transformation class produces it and
# which layer (if any) is immediately downstream — this is what enables
# automatic cascading recomputation.
_LAYER_PIPELINE = {
    "facility": {"transformation_cls": AccountToFacility, "downstream": "country"},
    "country": {"transformation_cls": FacilityToCountry, "downstream": "global"},
    "global": {"transformation_cls": CountryToGlobal, "downstream": None},
}


class RestatementError(Exception):
    pass


class RestatementEngine:
    def __init__(self, spark, config):
        self.spark = spark
        self.config = config

    # ------------------------------------------------------------------ #
    def run(
        self,
        layer: str,
        table_type: str,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        month: Optional[str] = None,
        cascade: Optional[bool] = None,
        requested_by: str = "manual",
    ) -> List[dict]:
        """
        Reprocesses `layer`/`table_type` for the given date range (daily) or
        month (monthly), then optionally cascades to downstream layers for
        the same dates.

        Returns a list of result dicts, one per transformation run executed
        (the restated layer plus any cascaded downstream layers).
        """
        self._validate_inputs(layer, table_type, start_date, end_date, month)

        if cascade is None:
            cascade = self.config.get("restatement.cascade_default", default=False)

        restatement_id = str(uuid.uuid4())
        start_time = datetime.now(timezone.utc)
        results: List[dict] = []
        status = "RUNNING"
        error_message = None
        rows_deleted = 0

        try:
            self._log_start(
                restatement_id,
                layer,
                table_type,
                start_date,
                end_date,
                month,
                cascade,
                requested_by,
                start_time,
            )

            # Step 1: delete/overwrite the target partitions for `layer` so
            # a restatement that *removes* rows (e.g. a source correction
            # that drops records) doesn't leave stale data behind even
            # before the new write happens.
            rows_deleted = self._delete_target_partitions(layer, table_type, start_date, end_date, month)

            # Step 2: recompute `layer` using the standard transformation
            # class, for each affected date individually (so each partition
            # gets its own clean replaceWhere write).
            dates = self._resolve_dates(table_type, start_date, end_date, month)
            current_layer = layer
            current_table_type = table_type

            for date_value in dates:
                result = self._run_transformation_for_layer(
                    current_layer, current_table_type, date_value, is_restatement=True
                )
                results.append(result)

            # Step 3: cascade downstream if requested — recompute country
            # then global (or just global) for the same dates.
            if cascade:
                downstream_layer = _LAYER_PIPELINE[layer]["downstream"]
                while downstream_layer is not None:
                    for date_value in dates:
                        result = self._run_transformation_for_layer(
                            downstream_layer, table_type, date_value, is_restatement=True
                        )
                        results.append(result)
                    downstream_layer = _LAYER_PIPELINE[downstream_layer]["downstream"]

            status = "SUCCESS"
            return results

        except Exception as exc:  # noqa: BLE001
            status = "FAILED"
            error_message = str(exc)
            raise RestatementError(f"Restatement failed for {layer}.{table_type}: {exc}") from exc

        finally:
            self._log_end(
                restatement_id,
                layer,
                table_type,
                start_date,
                end_date,
                month,
                cascade,
                status,
                rows_deleted,
                results,
                start_time,
                error_message,
            )

    # ------------------------------------------------------------------ #
    # Validation
    # ------------------------------------------------------------------ #
    def _validate_inputs(self, layer, table_type, start_date, end_date, month) -> None:
        if layer not in _LAYER_PIPELINE:
            raise RestatementError(f"Unsupported layer '{layer}'. Valid layers: {list(_LAYER_PIPELINE)}")
        if table_type not in ("daily", "monthly"):
            raise RestatementError(f"table_type must be 'daily' or 'monthly', got '{table_type}'")

        if table_type == "daily":
            if not (start_date and end_date):
                raise RestatementError("Daily restatement requires both start_date and end_date")
            max_days = self.config.get("restatement.max_date_range_days", default=366)
            days_requested = (
                datetime.strptime(end_date, "%Y-%m-%d") - datetime.strptime(start_date, "%Y-%m-%d")
            ).days + 1
            if days_requested > max_days:
                raise RestatementError(
                    f"Requested range of {days_requested} days exceeds max allowed "
                    f"({max_days}). Split into smaller restatement calls."
                )
        else:
            if not month:
                raise RestatementError("Monthly restatement requires `month` (format YYYY-MM)")

    # ------------------------------------------------------------------ #
    # Partition deletion (handles shrinking restatements, not just updates)
    # ------------------------------------------------------------------ #
    def _delete_target_partitions(self, layer, table_type, start_date, end_date, month) -> int:
        layer_config = self.config.get_layer_config(layer, table_type)
        path = layer_config["path"]
        date_col = "business_date" if table_type == "daily" else "year_month"

        try:
            from delta.tables import DeltaTable

            delta_table = DeltaTable.forPath(self.spark, path)
        except Exception:
            # Path doesn't exist yet (first-ever run) — nothing to delete.
            return 0

        if table_type == "daily":
            predicate = f"{date_col} >= '{start_date}' AND {date_col} <= '{end_date}'"
        else:
            predicate = f"{date_col} = '{month}'"

        before_count = self.spark.read.format("delta").load(path).filter(predicate).count()
        delta_table.delete(predicate)
        return before_count

    # ------------------------------------------------------------------ #
    # Date resolution
    # ------------------------------------------------------------------ #
    def _resolve_dates(self, table_type, start_date, end_date, month) -> List[str]:
        if table_type == "monthly":
            return [month]

        dates = (
            self.spark.sql(f"SELECT explode(sequence(to_date('{start_date}'), to_date('{end_date}'))) AS d")
            .select(F.col("d").cast("string"))
            .rdd.flatMap(lambda r: r)
            .collect()
        )
        return dates

    # ------------------------------------------------------------------ #
    # Transformation execution
    # ------------------------------------------------------------------ #
    def _run_transformation_for_layer(
        self, layer: str, table_type: str, date_value: str, is_restatement: bool
    ) -> dict:
        transformation_cls = _LAYER_PIPELINE[layer]["transformation_cls"]
        kwargs: Any = {"run_date": date_value} if table_type == "daily" else {"year_month": date_value}

        transformation = transformation_cls(
            spark=self.spark,
            config=self.config,
            table_type=table_type,
            triggered_by="restatement",
            is_restatement=is_restatement,
            **kwargs,
        )
        return transformation.run()

    # ------------------------------------------------------------------ #
    # Restatement audit logging
    # ------------------------------------------------------------------ #
    def _log_start(
        self,
        restatement_id,
        layer,
        table_type,
        start_date,
        end_date,
        month,
        cascade,
        requested_by,
        start_time,
    ):
        from .logging_utils import get_logger

        get_logger().info(
            f"[restatement {restatement_id[:8]}] START layer={layer} table_type={table_type} "
            f"range=({start_date}..{end_date}) month={month} cascade={cascade} by={requested_by}"
        )

    def _log_end(
        self,
        restatement_id,
        layer,
        table_type,
        start_date,
        end_date,
        month,
        cascade,
        status,
        rows_deleted,
        results,
        start_time,
        error_message,
    ):
        from .logging_utils import get_logger

        end_time = datetime.now(timezone.utc)
        duration = (end_time - start_time).total_seconds()
        rows_written = sum(r.get("records_written", 0) for r in results)

        get_logger().info(
            f"[restatement {restatement_id[:8]}] {status} in {duration:.1f}s — "
            f"rows_deleted={rows_deleted} rows_written={rows_written} runs={len(results)}"
            + (f" error={error_message}" if error_message else "")
        )

        try:
            row = {
                "restatement_id": restatement_id,
                "layer": layer,
                "table_name": f"{layer}_{table_type}",
                "start_date": start_date,
                "end_date": end_date,
                "month_value": month,
                "cascade_downstream": cascade,
                "partitions_affected": len(results),
                "rows_deleted": rows_deleted,
                "rows_written": rows_written,
                "status": status,
                "requested_by": "manual",
                "start_time": start_time,
                "end_time": end_time,
                "error_message": error_message,
            }
            restatement_log_path = self.config.get("logging.path").rsplit("/", 1)[0] + "/restatement_log"
            df = self.spark.createDataFrame([row])
            df.write.format("delta").mode("append").option("mergeSchema", "true").save(restatement_log_path)
        except Exception as persist_exc:  # noqa: BLE001
            get_logger().error(f"Failed to persist restatement log: {persist_exc}")
