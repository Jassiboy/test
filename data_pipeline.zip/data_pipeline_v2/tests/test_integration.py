"""
tests.test_integration
========================
Integration tests requiring real Delta I/O (spark_with_delta fixture,
resolves io.delta:delta-spark from Maven on first run — cached under
~/.ivy2 afterwards). Run separately from the unit suite:

    pytest tests/test_integration.py -m integration

In network-restricted environments, either pre-cache the Delta jars,
vendor them under lib/, or rely on a Databricks cluster (Delta
pre-installed) for this coverage instead.
"""

import shutil
import tempfile

import pytest
from pyspark.sql import Row

from pipeline.core import BaseTransformation
from pipeline.dq import CheckCategory, CheckResult, DQCheckOutcome, DQReport, Severity
from pipeline.restatement import RestatementEngine

pytestmark = pytest.mark.integration


# ============================================================================
# Shared fixtures
# ============================================================================
@pytest.fixture
def tmp_path_for_delta():
    path = tempfile.mkdtemp(prefix="pipeline_it_")
    yield path
    shutil.rmtree(path, ignore_errors=True)


# ============================================================================
# Write idempotency
# ============================================================================
class _FakeConfig:
    """Minimal config double exposing only what BaseTransformation.write()
    and the DQ/quarantine/logging steps need."""

    def __init__(self, base_path: str):
        self.environment = "test"
        self._base_path = base_path

    def get_layer_config(self, layer, table_type):
        return {
            "path": f"{self._base_path}/{layer}_{table_type}",
            "partition_columns": ["business_date"],
            "write_mode": "overwrite",
            "primary_keys": ["facility_id", "business_date"],
        }

    def get(self, dotted_path, default=None):
        values = {
            "performance.optimize_write": False,
            "logging.path": f"{self._base_path}/_audit/pipeline_execution_log",
            "logging.dq_path": f"{self._base_path}/_audit/dq_execution_log",
            "data_quality.fail_pipeline_on_critical": True,
            "data_quality.quarantine.path": f"{self._base_path}/_quarantine",
        }
        return values.get(dotted_path, default)

    def get_mandatory_columns(self, layer):
        return ["facility_id", "business_date"]


class _NoOpTransformation(BaseTransformation):
    """Concrete subclass exposing only write() — read()/transform() are
    stubbed since this test targets write() in isolation."""

    def __init__(self, spark, config, df_to_write, table_type="daily"):
        super().__init__(spark, config, table_type=table_type)
        self._df_to_write = df_to_write

    @property
    def pipeline_name(self):
        return "noop"

    @property
    def layer(self):
        return "facility"

    def read(self):
        return self._df_to_write

    def transform(self, source_df):
        return source_df

    def validate(self, transformed_df):
        report = DQReport(layer=self.layer, table_name=self.target_table_name)
        report.add(
            DQCheckOutcome(
                "noop",
                CheckCategory.RECORD_VALIDATION,
                CheckResult.PASSED,
                Severity.LOW,
                transformed_df.count(),
                0,
                0.0,
            )
        )
        return report


class TestWriteIdempotency:

    def test_rerun_same_date_does_not_duplicate_rows(self, spark_with_delta, tmp_path_for_delta):
        config = _FakeConfig(tmp_path_for_delta)

        df_v1 = spark_with_delta.createDataFrame(
            [
                Row(facility_id="F1", business_date="2025-01-01", revenue_local=100.0),
                Row(facility_id="F2", business_date="2025-01-01", revenue_local=200.0),
            ]
        )
        result_v1 = _NoOpTransformation(spark_with_delta, config, df_v1).run()
        assert result_v1["records_written"] == 2

        # Rerun for the SAME date with corrected data — must replace, not append.
        df_v2 = spark_with_delta.createDataFrame(
            [Row(facility_id="F1", business_date="2025-01-01", revenue_local=150.0)]
        )
        result_v2 = _NoOpTransformation(spark_with_delta, config, df_v2).run()
        assert result_v2["records_written"] == 1

        final_path = config.get_layer_config("facility", "daily")["path"]
        rows = (
            spark_with_delta.read.format("delta")
            .load(final_path)
            .filter("business_date = '2025-01-01'")
            .collect()
        )
        assert len(rows) == 1
        assert rows[0]["revenue_local"] == 150.0

    def test_writing_new_date_does_not_affect_other_dates(self, spark_with_delta, tmp_path_for_delta):
        config = _FakeConfig(tmp_path_for_delta)

        df_day1 = spark_with_delta.createDataFrame(
            [Row(facility_id="F1", business_date="2025-01-01", revenue_local=100.0)]
        )
        _NoOpTransformation(spark_with_delta, config, df_day1).run()

        df_day2 = spark_with_delta.createDataFrame(
            [Row(facility_id="F1", business_date="2025-01-02", revenue_local=999.0)]
        )
        _NoOpTransformation(spark_with_delta, config, df_day2).run()

        final_path = config.get_layer_config("facility", "daily")["path"]
        final_df = spark_with_delta.read.format("delta").load(final_path)
        assert final_df.count() == 2
        day1_row = final_df.filter("business_date = '2025-01-01'").collect()[0]
        assert day1_row["revenue_local"] == 100.0  # untouched by day-2 write


# ============================================================================
# Restatement partition deletion
# ============================================================================
class _FakeConfigForRestatement:
    def __init__(self, base_path: str):
        self.environment = "test"
        self._base = base_path

    def get_layer_config(self, layer, table_type):
        pk_map = {
            "account": ["account_id", "business_date"],
            "facility": ["facility_id", "business_date"],
            "country": ["country_code", "business_date"],
            "global": ["business_date"],
        }
        return {
            "path": f"{self._base}/{layer}_{table_type}",
            "partition_columns": ["business_date"],
            "write_mode": "overwrite",
            "primary_keys": pk_map[layer],
        }

    def get(self, dotted_path, default=None):
        values = {
            "performance.optimize_write": False,
            "performance.cache_dimension_tables": False,
            "logging.path": f"{self._base}/_audit/pipeline_execution_log",
            "logging.dq_path": f"{self._base}/_audit/dq_execution_log",
            "data_quality.fail_pipeline_on_critical": True,
            "data_quality.quarantine.path": f"{self._base}/_quarantine",
            "restatement.max_date_range_days": 366,
            "restatement.cascade_default": False,
        }
        return values.get(dotted_path, default)

    def get_mandatory_columns(self, layer):
        return {"facility": ["facility_id", "business_date"], "country": ["country_code"], "global": []}.get(
            layer, []
        )


class TestRestatementPartitionDeletion:

    def test_restating_a_range_only_touches_those_dates(self, spark_with_delta, tmp_path_for_delta):
        """Restating only Jan 2 must leave Jan 1 and Jan 3 untouched."""
        config = _FakeConfigForRestatement(tmp_path_for_delta)
        facility_path = config.get_layer_config("facility", "daily")["path"]

        seed_df = spark_with_delta.createDataFrame(
            [
                Row(facility_id="F1", business_date="2025-01-01", facility_name="Original"),
                Row(facility_id="F1", business_date="2025-01-02", facility_name="Original"),
                Row(facility_id="F1", business_date="2025-01-03", facility_name="Original"),
            ]
        )
        seed_df.write.format("delta").mode("overwrite").partitionBy("business_date").save(facility_path)

        engine = RestatementEngine(spark_with_delta, config)
        # We call the partition-delete primitive directly rather than
        # engine.run() — run() drives the full AccountToFacility chain,
        # which needs an `account` source table this lightweight fixture
        # doesn't seed. The rewrite-after-delete path reuses
        # BaseTransformation.write, already covered above.
        rows_deleted = engine._delete_target_partitions(
            layer="facility", table_type="daily", start_date="2025-01-02", end_date="2025-01-02", month=None
        )
        assert rows_deleted == 1

        remaining = spark_with_delta.read.format("delta").load(facility_path)
        remaining_dates = sorted(
            r["business_date"] for r in remaining.select("business_date").distinct().collect()
        )
        assert remaining_dates == ["2025-01-01", "2025-01-03"]

    def test_delete_on_nonexistent_path_returns_zero(self, spark_with_delta, tmp_path_for_delta):
        config = _FakeConfigForRestatement(tmp_path_for_delta)
        engine = RestatementEngine(spark_with_delta, config)
        rows_deleted = engine._delete_target_partitions(
            layer="country", table_type="daily", start_date="2025-01-01", end_date="2025-01-01", month=None
        )
        assert rows_deleted == 0


class TestRestatementValidation:
    """Pure validation logic — doesn't actually need Delta, but kept here
    alongside the other restatement tests for discoverability."""

    def test_rejects_unsupported_layer(self, spark_with_delta, tmp_path_for_delta):
        engine = RestatementEngine(spark_with_delta, _FakeConfigForRestatement(tmp_path_for_delta))
        with pytest.raises(Exception):
            engine.run(layer="account", table_type="daily", start_date="2025-01-01", end_date="2025-01-01")

    def test_rejects_range_exceeding_max_days(self, spark_with_delta, tmp_path_for_delta):
        engine = RestatementEngine(spark_with_delta, _FakeConfigForRestatement(tmp_path_for_delta))
        with pytest.raises(Exception):
            engine.run(layer="facility", table_type="daily", start_date="2020-01-01", end_date="2025-01-01")
