"""
tests.conftest
================
Shared pytest fixtures: a local-mode SparkSession (reused across the
session) and a ConfigLoader pointed at the `dev` config.
"""

import os
import sys

import pytest
from pyspark.sql import SparkSession

_REPO_ROOT = os.path.join(os.path.dirname(__file__), "..")
sys.path.insert(0, os.path.abspath(_REPO_ROOT))


@pytest.fixture(scope="session")
def spark():
    """Local-mode SparkSession for unit tests — no Delta, no network.
    Tests that need real Delta I/O use `spark_with_delta` instead."""
    session = (
        SparkSession.builder.master("local[2]")
        .appName("pipeline-tests")
        .config("spark.sql.shuffle.partitions", "2")
        .config("spark.driver.host", "127.0.0.1")
        .config("spark.ui.enabled", "false")
        .getOrCreate()
    )
    session.sparkContext.setLogLevel("ERROR")
    yield session
    session.stop()


@pytest.fixture(scope="session")
def spark_with_delta():
    """Delta-enabled SparkSession for integration tests. Requires network
    access to resolve io.delta:delta-spark from Maven on first run."""
    session = (
        SparkSession.builder.master("local[2]")
        .appName("pipeline-integration-tests")
        .config("spark.sql.shuffle.partitions", "2")
        .config("spark.driver.host", "127.0.0.1")
        .config("spark.ui.enabled", "false")
        .config("spark.jars.packages", "io.delta:delta-spark_2.13:3.2.0")
        .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension")
        .config("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog")
        .getOrCreate()
    )
    session.sparkContext.setLogLevel("ERROR")
    yield session
    session.stop()


@pytest.fixture(scope="session")
def config():
    from pipeline import ConfigLoader

    config_root = os.path.join(os.path.dirname(__file__), "..", "config")
    return ConfigLoader(environment="dev", config_root=config_root)
