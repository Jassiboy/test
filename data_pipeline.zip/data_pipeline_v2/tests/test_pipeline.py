"""
tests.test_pipeline
=====================
Unit tests — pure logic, local Spark session, no Delta/network required.
Covers: ConfigLoader, RuleEngine checks, SchemaValidator, and
FacilityToCountry's transform() logic in isolation.

Run with: pytest tests/test_pipeline.py
"""

import pytest
from pyspark.sql import Row
from pyspark.sql.types import DoubleType, StringType, StructField, StructType

from pipeline import (
    BusinessCheckSpec,
    CheckResult,
    ConfigError,
    ReferentialCheckSpec,
    RuleEngine,
    SchemaValidator,
    Severity,
)
from pipeline.transformations import FacilityToCountry


# ============================================================================
# ConfigLoader
# ============================================================================
class TestConfigLoader:

    def test_loads_dev_environment(self, config):
        assert config.environment == "dev"

    def test_dotted_path_lookup(self, config):
        assert config.get("layers.facility.daily.table_name") == "dev_catalog.facility.facility_daily"

    def test_variable_resolution(self, config):
        path = config.get("layers.facility.daily.path")
        assert path.startswith("abfss://")
        assert "/facility/daily" in path
        assert "${" not in path

    def test_missing_path_raises_without_default(self, config):
        with pytest.raises(ConfigError):
            config.get("does.not.exist")

    def test_missing_path_returns_default_when_supplied(self, config):
        assert config.get("does.not.exist", default="fallback") == "fallback"

    def test_get_layer_config_convenience_method(self, config):
        layer_cfg = config.get_layer_config("country", "monthly")
        assert layer_cfg["primary_keys"] == ["country_code", "year_month"]

    def test_get_dimension_config(self, config):
        dim_cfg = config.get_dimension_config("dim_facility")
        assert dim_cfg["join_keys"] == ["facility_id"]
        assert dim_cfg["broadcast"] is True

    def test_get_mandatory_columns(self, config):
        cols = config.get_mandatory_columns("facility")
        assert "facility_id" in cols
        assert "business_date" in cols

    def test_get_schema_returns_column_list(self, config):
        schema = config.get_schema("facility_daily")
        column_names = [c["name"] for c in schema["columns"]]
        assert "facility_id" in column_names
        assert "revenue_local" in column_names

    def test_get_schema_raises_for_unknown_schema(self, config):
        with pytest.raises(ConfigError):
            config.get_schema("does_not_exist")

    def test_as_dict_returns_independent_copy(self, config):
        d1 = config.as_dict()
        d1["environment"] = "mutated"
        assert config.as_dict()["environment"] == "dev"


# ============================================================================
# RuleEngine
# ============================================================================
@pytest.fixture
def facility_df(spark):
    return spark.createDataFrame(
        [
            Row(facility_id="F1", business_date="2025-01-01", revenue_local=100.0),
            Row(facility_id="F2", business_date="2025-01-01", revenue_local=200.0),
            Row(facility_id="F3", business_date="2025-01-01", revenue_local=None),  # null mandatory col
            Row(facility_id="F1", business_date="2025-01-01", revenue_local=50.0),  # duplicate PK
        ]
    )


class TestNullCheck:

    def test_passes_when_no_nulls(self, spark, config):
        df = spark.createDataFrame(
            [
                Row(facility_id="F1", business_date="2025-01-01", revenue_local=100.0),
                Row(facility_id="F2", business_date="2025-01-01", revenue_local=200.0),
            ]
        )
        outcome = RuleEngine(config, "facility", "facility_daily").check_nulls(df)
        assert outcome.result == CheckResult.PASSED
        assert outcome.records_failed == 0

    def test_fails_when_nulls_exceed_threshold(self, spark, config, facility_df):
        outcome = RuleEngine(config, "facility", "facility_daily").check_nulls(facility_df)
        assert outcome.result == CheckResult.FAILED  # 1/4 rows null > 1.0% dev threshold
        assert outcome.records_failed == 1

    def test_empty_dataframe_passes(self, spark, config):
        df = spark.createDataFrame([], "facility_id string, business_date string, revenue_local double")
        outcome = RuleEngine(config, "facility", "facility_daily").check_nulls(df)
        assert outcome.result == CheckResult.PASSED


class TestDuplicateCheck:

    def test_passes_with_unique_keys(self, spark, config):
        df = spark.createDataFrame(
            [
                Row(facility_id="F1", business_date="2025-01-01"),
                Row(facility_id="F2", business_date="2025-01-01"),
            ]
        )
        outcome = RuleEngine(config, "facility", "facility_daily").check_duplicates(
            df, primary_keys=["facility_id", "business_date"]
        )
        assert outcome.result == CheckResult.PASSED

    def test_fails_with_duplicate_keys(self, spark, config, facility_df):
        outcome = RuleEngine(config, "facility", "facility_daily").check_duplicates(
            facility_df, primary_keys=["facility_id", "business_date"]
        )
        assert outcome.result == CheckResult.FAILED
        assert outcome.records_failed == 1


class TestReferentialIntegrity:

    def test_passes_when_all_keys_exist(self, spark, config):
        df = spark.createDataFrame([Row(facility_id="F1"), Row(facility_id="F2")])
        dim_df = spark.createDataFrame([Row(facility_id="F1"), Row(facility_id="F2"), Row(facility_id="F3")])
        spec = ReferentialCheckSpec("facility_id", dim_df, "facility_id")
        outcome = RuleEngine(config, "facility", "facility_daily").check_referential_integrity(df, spec)
        assert outcome.result == CheckResult.PASSED

    def test_fails_with_orphaned_key(self, spark, config):
        df = spark.createDataFrame([Row(facility_id="F1"), Row(facility_id="F99")])
        dim_df = spark.createDataFrame([Row(facility_id="F1"), Row(facility_id="F2")])
        spec = ReferentialCheckSpec("facility_id", dim_df, "facility_id")
        outcome = RuleEngine(config, "facility", "facility_daily").check_referential_integrity(df, spec)
        assert outcome.result == CheckResult.FAILED
        assert outcome.records_failed == 1


class TestBusinessRuleCheck:

    def test_passes_when_condition_holds(self, spark, config):
        df = spark.createDataFrame([Row(total_revenue=100.0), Row(total_revenue=0.0)])
        spec = BusinessCheckSpec("non_negative", "total_revenue >= 0")
        outcome = RuleEngine(config, "country", "country_daily").check_business_rule(df, spec)
        assert outcome.result == CheckResult.PASSED

    def test_fails_when_condition_violated(self, spark, config):
        df = spark.createDataFrame([Row(total_revenue=-5.0), Row(total_revenue=10.0)])
        spec = BusinessCheckSpec("non_negative", "total_revenue >= 0")
        outcome = RuleEngine(config, "country", "country_daily").check_business_rule(df, spec)
        assert outcome.result == CheckResult.FAILED
        assert outcome.records_failed == 1


class TestAggregateTotalsReconciliation:

    def test_passes_when_sums_match(self, spark, config):
        source_df = spark.createDataFrame([Row(revenue_local=100.0), Row(revenue_local=200.0)])
        agg_df = spark.createDataFrame([Row(total_revenue=300.0)])
        outcome = RuleEngine(config, "country", "country_daily").check_aggregate_totals(
            source_df, agg_df, "revenue_local", "total_revenue"
        )
        assert outcome.result == CheckResult.PASSED

    def test_fails_when_sums_diverge(self, spark, config):
        source_df = spark.createDataFrame([Row(revenue_local=100.0), Row(revenue_local=200.0)])
        agg_df = spark.createDataFrame([Row(total_revenue=250.0)])  # lost 50 somewhere
        outcome = RuleEngine(config, "country", "country_daily").check_aggregate_totals(
            source_df, agg_df, "revenue_local", "total_revenue"
        )
        assert outcome.result == CheckResult.FAILED
        assert outcome.severity == Severity.CRITICAL


# ============================================================================
# SchemaValidator
# ============================================================================
_SCHEMA_DEF = {
    "columns": [
        {"name": "facility_id", "type": "string", "nullable": False},
        {"name": "revenue_local", "type": "double", "nullable": False},
    ]
}


class TestSchemaValidator:

    def test_passes_for_matching_schema(self, spark):
        schema = StructType(
            [StructField("facility_id", StringType(), True), StructField("revenue_local", DoubleType(), True)]
        )
        df = spark.createDataFrame([Row(facility_id="F1", revenue_local=1.0)], schema)
        assert SchemaValidator(_SCHEMA_DEF).validate(df).result == CheckResult.PASSED

    def test_fails_for_missing_column(self, spark):
        df = spark.createDataFrame([Row(facility_id="F1")])
        outcome = SchemaValidator(_SCHEMA_DEF).validate(df)
        assert outcome.result == CheckResult.FAILED
        assert "missing column 'revenue_local'" in outcome.details

    def test_fails_for_type_mismatch(self, spark):
        schema = StructType(
            [StructField("facility_id", StringType(), True), StructField("revenue_local", StringType(), True)]
        )
        df = spark.createDataFrame([Row(facility_id="F1", revenue_local="not_a_number")], schema)
        outcome = SchemaValidator(_SCHEMA_DEF).validate(df)
        assert outcome.result == CheckResult.FAILED
        assert "expected type double" in outcome.details


# ============================================================================
# FacilityToCountry.transform() — pure logic, no I/O
# ============================================================================
class _StubFacilityToCountry(FacilityToCountry):
    """Bypasses BaseTransformation.__init__'s run_id/kwargs setup since
    this test only exercises transform(), never read()/write()/run()."""

    def __init__(self, spark, config):
        self.spark = spark
        self.config = config
        self.table_type = "daily"
        self.kwargs = {}


class TestFacilityToCountryTransform:

    def test_aggregates_revenue_by_country(self, spark, config):
        df = spark.createDataFrame(
            [
                Row(
                    country_code="US",
                    business_date="2025-01-01",
                    facility_id="F1",
                    revenue_local=100.0,
                    transaction_count=10,
                ),
                Row(
                    country_code="US",
                    business_date="2025-01-01",
                    facility_id="F2",
                    revenue_local=200.0,
                    transaction_count=20,
                ),
                Row(
                    country_code="CA",
                    business_date="2025-01-01",
                    facility_id="F3",
                    revenue_local=50.0,
                    transaction_count=5,
                ),
            ]
        )
        result = {r["country_code"]: r for r in _StubFacilityToCountry(spark, config).transform(df).collect()}

        assert result["US"]["total_revenue"] == 300.0
        assert result["US"]["total_transactions"] == 30
        assert result["US"]["facility_count"] == 2
        assert result["CA"]["total_revenue"] == 50.0
        assert result["CA"]["facility_count"] == 1

    def test_business_calculation_revenue_per_transaction(self, spark, config):
        df = spark.createDataFrame(
            [
                Row(
                    country_code="US",
                    business_date="2025-01-01",
                    facility_id="F1",
                    revenue_local=300.0,
                    transaction_count=30,
                )
            ]
        )
        result = _StubFacilityToCountry(spark, config).transform(df).collect()[0]
        assert result["revenue_per_transaction"] == 10.0

    def test_output_has_load_timestamp(self, spark, config):
        df = spark.createDataFrame(
            [
                Row(
                    country_code="US",
                    business_date="2025-01-01",
                    facility_id="F1",
                    revenue_local=100.0,
                    transaction_count=10,
                )
            ]
        )
        assert "load_ts" in _StubFacilityToCountry(spark, config).transform(df).columns
