# Multi-Layer Data Pipeline — Azure Databricks + Delta Lake

Object-oriented PySpark pipeline transforming data through four hierarchical
layers, each producing daily + monthly Delta tables:

```
Account (existing)  →  Facility  →  Country  →  Global
```

Config-driven, idempotent (Delta `replaceWhere` partition overwrite),
unit-tested, with a generic restatement framework, severity-graduated data
quality/quarantine policy, and centralized Delta-backed audit logging.

## Project structure

```
pipeline/
├── config_loader.py     # YAML config + ${a.b.c} reference resolution
├── core.py               # BaseTransformation (Template Method), SparkSessionFactory, DeltaIOHelper
├── transformations.py    # AccountToFacility, FacilityToCountry, CountryToGlobal
├── dq.py                  # Schema validation, RuleEngine, QuarantineHandler, DQMetricsWriter
├── restatement.py         # RestatementEngine — selective reprocessing
├── logging_utils.py       # PipelineLogger (Delta audit logging context manager)
├── utils.py               # SecretResolver, date helpers
└── jobs.py                # CLI entry points: daily / monthly / restate

config/
├── dev|test|prod/pipeline_config.yaml   # tables, joins, aggregations, DQ thresholds, perf tuning
└── schemas.yaml                          # shared schema definitions

tests/
├── test_pipeline.py       # unit tests — ConfigLoader, RuleEngine, SchemaValidator, transform() logic
└── test_integration.py    # Delta I/O tests — write idempotency, restatement partition deletion

scripts/ddl_audit_tables.sql   # DDL for pipeline_execution_log, dq_execution_log, restatement_log
docs/class_diagram.mermaid     # full class diagram
```

## Quickstart

```bash
pip install -r requirements.txt
pip install -e .

# Unit tests (fast, no Delta/network needed)
pytest tests/test_pipeline.py

# Run the daily chain
python -m pipeline.jobs daily --env dev --run-date 2025-01-15

# Restate a date range, cascading to downstream layers
python -m pipeline.jobs restate --env prod --layer facility --table-type daily \
    --start-date 2025-01-01 --end-date 2025-01-31 --cascade
```

## Design in one paragraph

`BaseTransformation.run()` fixes the orchestration skeleton (read → transform
→ validate → quarantine → write → log) once; `AccountToFacility`,
`FacilityToCountry`, and `CountryToGlobal` override only `read()`,
`transform()`, and `validate()`. `transform()` is a pure DataFrame-in/
DataFrame-out function — no I/O — so the aggregation logic is unit tested
directly with a local Spark session (`tests/test_pipeline.py`). DQ failures
are handled by severity: CRITICAL halts the pipeline, HIGH quarantines
offending rows to Delta and continues, MEDIUM flags rows but writes them.
`RestatementEngine` reuses the exact same transformation classes for ad-hoc
reprocessing — never a parallel code path that could drift. Every run writes
exactly one audit row to `pipeline_execution_log` via the `PipelineLogger`
context manager, success or failure.

## Platform portability (GCP / AWS)

Only three modules touch cloud-specific APIs: `core.py` (Delta read/write
paths — swap `abfss://` for `gs://`/`s3://`, a config change not a code
change), `core.SparkSessionFactory` (Databricks-specific Spark confs), and
`utils.SecretResolver` (`dbutils.secrets` → Secret Manager / Secrets
Manager). `transformations.py`, `dq.py`, `restatement.py`, and
`logging_utils.py` import nothing cloud-specific and port unchanged.
