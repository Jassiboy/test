"""
Build a wheel for Databricks deployment: python setup.py bdist_wheel
Local dev install:                       pip install -e .
"""

from setuptools import find_packages, setup

setup(
    name="data_pipeline",
    version="1.0.0",
    description=(
        "Multi-layer (Account -> Facility -> Country -> Global) data "
        "transformation pipeline for Azure Databricks + Delta Lake."
    ),
    packages=find_packages(include=["pipeline", "pipeline.*"]),
    python_requires=">=3.10",
    install_requires=["pyyaml==6.0.1"],
    entry_points={"console_scripts": ["pipeline-job=pipeline.jobs:main"]},
)
