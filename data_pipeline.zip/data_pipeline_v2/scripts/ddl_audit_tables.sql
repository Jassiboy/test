-- =============================================================================
-- DDL: Centralized audit/logging tables
-- Run once per environment via Databricks SQL or as part of CI/CD bootstrap.
-- Paths/catalogs are environment-specific — substitute ${...} before running,
-- or execute via scripts/bootstrap_environment.py which does this for you.
-- =============================================================================

CREATE TABLE IF NOT EXISTS ${catalog}.audit.pipeline_execution_log (
    run_id                      STRING      COMMENT 'UUID for this execution',
    pipeline_name               STRING      COMMENT 'e.g. account_to_facility',
    layer                       STRING      COMMENT 'account | facility | country | global',
    table_name                  STRING      COMMENT 'e.g. facility_daily',
    environment                 STRING      COMMENT 'dev | test | prod',
    start_time                  TIMESTAMP,
    end_time                    TIMESTAMP,
    status                      STRING      COMMENT 'RUNNING | SUCCESS | FAILED',
    records_read                BIGINT,
    records_written             BIGINT,
    records_failed              BIGINT,
    error_message                STRING,
    execution_duration_seconds  DOUBLE,
    triggered_by                STRING      COMMENT 'scheduler | manual | restatement | backfill',
    is_restatement               BOOLEAN
)
USING DELTA
LOCATION '${storage_root}/_audit/pipeline_execution_log'
PARTITIONED BY (layer)
TBLPROPERTIES (
    'delta.autoOptimize.optimizeWrite' = 'true',
    'delta.autoOptimize.autoCompact'   = 'true',
    'delta.logRetentionDuration'       = 'interval 30 days',
    'delta.deletedFileRetentionDuration' = 'interval 30 days'
);

CREATE TABLE IF NOT EXISTS ${catalog}.audit.dq_execution_log (
    dq_log_id           STRING      COMMENT 'UUID for this DQ check execution',
    run_id               STRING      COMMENT 'FK -> pipeline_execution_log.run_id',
    layer                STRING,
    table_name           STRING,
    check_name           STRING      COMMENT 'e.g. null_check_account_id',
    check_category       STRING      COMMENT 'RECORD_VALIDATION | BUSINESS_VALIDATION',
    check_result         STRING      COMMENT 'PASSED | FAILED | WARNING',
    records_checked      BIGINT,
    records_failed       BIGINT,
    fail_rate_pct        DOUBLE,
    threshold_pct        DOUBLE,
    severity             STRING      COMMENT 'CRITICAL | HIGH | MEDIUM | LOW',
    check_timestamp      TIMESTAMP,
    details               STRING      COMMENT 'JSON-encoded sample failed keys / message'
)
USING DELTA
LOCATION '${storage_root}/_audit/dq_execution_log'
PARTITIONED BY (layer)
TBLPROPERTIES (
    'delta.autoOptimize.optimizeWrite' = 'true',
    'delta.autoOptimize.autoCompact'   = 'true'
);

CREATE TABLE IF NOT EXISTS ${catalog}.audit.restatement_log (
    restatement_id        STRING      COMMENT 'UUID for this restatement execution',
    layer                 STRING,
    table_name            STRING,
    start_date            DATE,
    end_date              DATE,
    month_value            STRING      COMMENT 'YYYY-MM, populated for monthly restatements',
    cascade_downstream    BOOLEAN,
    partitions_affected   INT,
    rows_deleted          BIGINT,
    rows_written          BIGINT,
    status                STRING      COMMENT 'RUNNING | SUCCESS | FAILED',
    requested_by          STRING,
    start_time            TIMESTAMP,
    end_time              TIMESTAMP,
    error_message          STRING
)
USING DELTA
LOCATION '${storage_root}/_audit/restatement_log'
TBLPROPERTIES (
    'delta.autoOptimize.optimizeWrite' = 'true',
    'delta.autoOptimize.autoCompact'   = 'true'
);
