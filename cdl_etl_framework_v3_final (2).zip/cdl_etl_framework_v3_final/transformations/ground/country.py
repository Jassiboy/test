# Databricks notebook source
# MAGIC %skip
# MAGIC %sql
# MAGIC INSERT INTO MKVW_COMN_SCHEMA.FXG_CTRY_ENTI_BILL_DLY_HIST
# MAGIC                     (
# MAGIC                         ratemnth, shp_dt, dlvr_dt, 
# MAGIC                         se_shpr_glbl_enti_nbr, se_shpr_ctry_enti_nbr, se_shpr_sls_seg_cd, se_shpr_sub_industry_cd, 
# MAGIC                         se_payr_glbl_enti_nbr, se_payr_ctry_enti_nbr, se_payr_sls_seg_cd, se_payr_sub_industry_cd, 
# MAGIC                         ce_payr_glbl_enti_nbr, ce_payr_ctry_enti_nbr, ce_payr_sls_seg_cd, 
# MAGIC                         svc_cat_cd, product, orig_ctry_cd, orig_st_cd, orig_msa, dest_ctry_cd, dest_st_cd, dest_msa, zone_cd, wgtcat, 
# MAGIC                         rsd_flg, lrnn_flg, ec_flg, dim_avail_flg, rev_dt,
# MAGIC                         packages, netrev, fgtchrg, discount, fuelsch, totalsch, apounds, rpounds, pkg_cubic_size, 
# MAGIC                         adh_amt, das_amt, oth_amt, ovs_amt, dlg_amt, dresi_amt, resi_amt, 
# MAGIC                         adh_qty, das_qty, oth_qty, ovs_qty, dlg_qty, dresi_qty, resi_qty            
# MAGIC                     )
# MAGIC                     SELECT 
# MAGIC                         ratemnth, shp_dt, dlvr_dt, 
# MAGIC                         se_shpr_glbl_enti_nbr,
# MAGIC                         se_shpr_ctry_enti_nbr,
# MAGIC                         se_shpr_sls_seg_cd, 
# MAGIC                         se_shpr_sub_industry_cd, 
# MAGIC                         se_payr_glbl_enti_nbr,
# MAGIC                         se_payr_ctry_enti_nbr,
# MAGIC                         se_payr_sls_seg_cd, 
# MAGIC                         se_payr_sub_industry_cd, 
# MAGIC                         ce_payr_glbl_enti_nbr, 
# MAGIC                         ce_payr_ctry_enti_nbr,
# MAGIC                         ce_payr_sls_seg_cd, 
# MAGIC                         svc_cat_cd, product, orig_ctry_cd, orig_st_cd, orig_msa, dest_ctry_cd, dest_st_cd, dest_msa, zone_cd, wgtcat, 
# MAGIC                         rsd_flg, lrnn_flg, ec_flg, dim_avail_flg, rev_dt,
# MAGIC                         SUM(packages) AS packages, 
# MAGIC                         SUM(netrev) AS netrev, SUM(fgtchrg) AS fgtchrg, 
# MAGIC                         SUM(discount) AS discount, 
# MAGIC                         SUM(fuelsch) AS fuelsch, SUM(totalsch) AS totalsch, 
# MAGIC                         SUM(apounds) AS apounds, SUM(rpounds) AS rpounds, 
# MAGIC                         SUM(pkg_cubic_size) AS pkg_cubic_size,
# MAGIC                         SUM(adh_amt), SUM(das_amt), SUM(oth_amt), SUM(ovs_amt), SUM(dlg_amt), SUM(dresi_amt), SUM(resi_amt), 
# MAGIC                         SUM(adh_qty), SUM(das_qty), SUM(oth_qty), SUM(ovs_qty), SUM(dlg_qty), SUM(dresi_qty), SUM(resi_qty)            
# MAGIC                     FROM MKVW_COMN_SCHEMA.FXG_FAC_ENTI_BILL_DLY_HIST ship
# MAGIC                     WHERE ship.ratemnth = v_load_ym
# MAGIC                     AND ship.svc_cat_cd <> 'SP'
# MAGIC                     GROUP BY  ratemnth, shp_dt, dlvr_dt,
# MAGIC                         se_shpr_glbl_enti_nbr,
# MAGIC                         se_shpr_ctry_enti_nbr,
# MAGIC                         se_shpr_sls_seg_cd, 
# MAGIC                         se_shpr_sub_industry_cd, 
# MAGIC                         se_payr_glbl_enti_nbr,
# MAGIC                         se_payr_ctry_enti_nbr,
# MAGIC                         se_payr_sls_seg_cd, 
# MAGIC                         se_payr_sub_industry_cd, 
# MAGIC                         ce_payr_glbl_enti_nbr, 
# MAGIC                         ce_payr_ctry_enti_nbr,
# MAGIC                         ce_payr_sls_seg_cd, 
# MAGIC                         ship.svc_cat_cd, product, orig_ctry_cd, orig_st_cd, orig_msa, dest_ctry_cd, dest_st_cd, dest_msa, zone_cd, wgtcat, 
# MAGIC                         rsd_flg, lrnn_flg, ec_flg, dim_avail_flg, rev_dt;
# MAGIC                                           
# MAGIC                     COMMIT;
# MAGIC

# COMMAND ----------

# MAGIC %skip
# MAGIC %sql
# MAGIC INSERT INTO MKVW_COMN_SCHEMA.FXG_CTRY_ENTI_BILL_DLY_HIST
# MAGIC                     (
# MAGIC                         ratemnth, shp_dt, dlvr_dt,
# MAGIC                         se_shpr_glbl_enti_nbr, se_shpr_ctry_enti_nbr, se_shpr_sls_seg_cd, se_shpr_sub_industry_cd, 
# MAGIC                         se_payr_glbl_enti_nbr, se_payr_ctry_enti_nbr, se_payr_sls_seg_cd, se_payr_sub_industry_cd, 
# MAGIC                         ce_payr_glbl_enti_nbr, ce_payr_ctry_enti_nbr, ce_payr_sls_seg_cd, 
# MAGIC                         svc_cat_cd, product, orig_ctry_cd, orig_st_cd, orig_msa, dest_ctry_cd, dest_st_cd, dest_msa, zone_cd, wgtcat, 
# MAGIC                         rsd_flg, lrnn_flg, ec_flg, dim_avail_flg, 
# MAGIC                         packages, netrev, fgtchrg, discount, fuelsch, totalsch, apounds, rpounds, pkg_cubic_size, 
# MAGIC                         adh_amt, das_amt, oth_amt, ovs_amt, dlg_amt, dresi_amt, resi_amt, 
# MAGIC                         adh_qty, das_qty, oth_qty, ovs_qty, dlg_qty, dresi_qty, resi_qty
# MAGIC                     )
# MAGIC                     SELECT 
# MAGIC                         ratemnth, shp_dt, dlvr_dt,
# MAGIC                         se_shpr_glbl_enti_nbr,
# MAGIC                         se_shpr_ctry_enti_nbr,
# MAGIC                         se_shpr_sls_seg_cd, 
# MAGIC                         se_shpr_sub_industry_cd, 
# MAGIC                         se_payr_glbl_enti_nbr,
# MAGIC                         se_payr_ctry_enti_nbr,
# MAGIC                         se_payr_sls_seg_cd, 
# MAGIC                         se_payr_sub_industry_cd, 
# MAGIC                         ce_payr_glbl_enti_nbr, 
# MAGIC                         ce_payr_ctry_enti_nbr, 
# MAGIC                         ce_payr_sls_seg_cd, 
# MAGIC                         svc_cat_cd, product, orig_ctry_cd, orig_st_cd, orig_msa, dest_ctry_cd, dest_st_cd, dest_msa, zone_cd, wgtcat, 
# MAGIC                         rsd_flg, lrnn_flg, ec_flg,dim_avail_flg, 
# MAGIC                         SUM(packages) AS packages, 
# MAGIC                         SUM(netrev) AS netrev, SUM(fgtchrg) AS fgtchrg, 
# MAGIC                         SUM(discount) AS discount, 
# MAGIC                         SUM(fuelsch) AS fuelsch, SUM(totalsch) AS totalsch, 
# MAGIC                         SUM(apounds) AS apounds, SUM(rpounds) AS rpounds, 
# MAGIC                         SUM(pkg_cubic_size) AS pkg_cubic_size,
# MAGIC                         SUM(adh_amt), SUM(das_amt), SUM(oth_amt), SUM(ovs_amt), SUM(dlg_amt), SUM(dresi_amt), SUM(resi_amt), 
# MAGIC                         SUM(adh_qty), SUM(das_qty), SUM(oth_qty), SUM(ovs_qty), SUM(dlg_qty), SUM(dresi_qty), SUM(resi_qty) 
# MAGIC                     FROM MKVW_COMN_SCHEMA.FXG_FAC_ENTI_BILL_DLY_HIST ship
# MAGIC                     WHERE ship.ratemnth = v_load_ym 
# MAGIC                     AND svc_cat_cd = 'SP'
# MAGIC                     GROUP BY  ratemnth, shp_dt, dlvr_dt,
# MAGIC                         se_shpr_glbl_enti_nbr,
# MAGIC                         se_shpr_ctry_enti_nbr,
# MAGIC                         se_shpr_sls_seg_cd, 
# MAGIC                         se_shpr_sub_industry_cd, 
# MAGIC                         se_payr_glbl_enti_nbr,
# MAGIC                         se_payr_ctry_enti_nbr,
# MAGIC                         se_payr_sls_seg_cd, 
# MAGIC                         se_payr_sub_industry_cd, 
# MAGIC                         ce_payr_glbl_enti_nbr, 
# MAGIC                         ce_payr_ctry_enti_nbr, 
# MAGIC                         ce_payr_sls_seg_cd, 
# MAGIC                         svc_cat_cd, product, orig_ctry_cd, orig_st_cd, orig_msa, dest_ctry_cd, dest_st_cd, dest_msa, zone_cd, wgtcat, 
# MAGIC                         rsd_flg, lrnn_flg, ec_flg, dim_avail_flg;
# MAGIC                                           
# MAGIC                     COMMIT;

# COMMAND ----------

from pyspark.sql import DataFrame, SparkSession

def get_fxg_country_entity_billing_monthly_history_non_sp(
    v_load_ym: str,
    source_facility_table: str = "MKVW_COMN_SCHEMA.FXG_FAC_ENTI_BILL_MTH_HIST"
) -> DataFrame:
    """
    Aggregates facility-level billing monthly history to country-level entity billing history for non-SP records.
    
    Args:
        v_load_ym (str): The rate month (YYYYMM format) to filter the source data.
        source_facility_table (str): Dynamic table name for the source facility history table.
        
    Returns:
        DataFrame: The aggregated PySpark DataFrame.
    """
    # Get active Spark session
    spark = SparkSession.builder.getOrCreate()
    
    # Core SQL aggregation logic matching your schema
    query = f"""
        SELECT 
            ratemnth, shipmnth, dlvrmnth, 
            se_shpr_glbl_enti_nbr, se_shpr_ctry_enti_nbr, se_shpr_sls_seg_cd, se_shpr_sub_industry_cd, 
            se_payr_glbl_enti_nbr, se_payr_ctry_enti_nbr, se_payr_sls_seg_cd, se_payr_sub_industry_cd, 
            ce_payr_glbl_enti_nbr, ce_payr_ctry_enti_nbr, ce_payr_sls_seg_cd, 
            svc_cat_cd, product, orig_ctry_cd, orig_st_cd, orig_msa, dest_ctry_cd, dest_st_cd, dest_msa, 
            zone_cd, wgtcat, rsd_flg, lrnn_flg, ec_flg, dim_avail_flg, revmnth, autogrp,
            SUM(packages) AS packages, 
            SUM(netrev) AS netrev, 
            SUM(fgtchrg) AS fgtchrg, 
            SUM(discount) AS discount, 
            SUM(fuelsch) AS fuelsch, 
            SUM(totalsch) AS totalsch, 
            SUM(apounds) AS apounds, 
            SUM(rpounds) AS rpounds,
            SUM(pkg_cubic_size) AS pkg_cubic_size,
            SUM(adh_amt) AS adh_amt, 
            SUM(das_amt) AS das_amt, 
            SUM(oth_amt) AS oth_amt, 
            SUM(ovs_amt) AS ovs_amt, 
            SUM(dlg_amt) AS dlg_amt, 
            SUM(dresi_amt) AS dresi_amt, 
            SUM(resi_amt) AS resi_amt, 
            SUM(adh_qty) AS adh_qty, 
            SUM(das_qty) AS das_qty, 
            SUM(oth_qty) AS oth_qty, 
            SUM(ovs_qty) AS ovs_qty, 
            SUM(dlg_qty) AS dlg_qty, 
            SUM(dresi_qty) AS dresi_qty, 
            SUM(resi_qty) AS resi_qty            
        FROM {source_facility_table} ship
        WHERE ship.ratemnth = '{v_load_ym}'
          AND ship.svc_cat_cd <> 'SP'
        GROUP BY ratemnth, shipmnth, dlvrmnth,
            se_shpr_glbl_enti_nbr,
            se_shpr_ctry_enti_nbr,
            se_shpr_sls_seg_cd, 
            se_shpr_sub_industry_cd, 
            se_payr_glbl_enti_nbr,
            se_payr_ctry_enti_nbr,
            se_payr_sls_seg_cd, 
            se_payr_sub_industry_cd, 
            ce_payr_glbl_enti_nbr, 
            ce_payr_ctry_enti_nbr,
            ce_payr_sls_seg_cd, 
            ship.svc_cat_cd, product, orig_ctry_cd, orig_st_cd, orig_msa, dest_ctry_cd, dest_st_cd, dest_msa, zone_cd, wgtcat, 
            rsd_flg, lrnn_flg, ec_flg, revmnth, dim_avail_flg, autogrp
    """
    
    return spark.sql(query)
# Execute and return non-SP country-level DataFrame
country_non_sp_df = get_fxg_country_entity_billing_monthly_history_non_sp(
    v_load_ym="202607",
    source_facility_table="MKVW_COMN_SCHEMA.FXG_FAC_ENTI_BILL_MTH_HIST"
)

# Display Spark DataFrame output
display(country_non_sp_df)


# COMMAND ----------

from pyspark.sql import DataFrame, SparkSession

def get_fxg_country_entity_billing_monthly_history(
    v_load_ym: str,
    source_facility_table: str = "MKVW_COMN_SCHEMA.FXG_FAC_ENTI_BILL_MTH_HIST"
) -> DataFrame:
    """
    Aggregates facility-level billing monthly history to country-level entity billing history for 'SP'.
    
    Args:
        v_load_ym (str): The rate month (YYYYMM format) to filter the source data.
        source_facility_table (str): Dynamic table name for the source facility history table.
        
    Returns:
        DataFrame: The aggregated PySpark DataFrame.
    """
    # Get active Spark session
    spark = SparkSession.builder.getOrCreate()
    
    # Core SQL aggregation logic matching your schema
    query = f"""
        SELECT 
            ratemnth, shipmnth, dlvrmnth,
            se_shpr_glbl_enti_nbr,
            se_shpr_ctry_enti_nbr,
            se_shpr_sls_seg_cd, 
            se_shpr_sub_industry_cd, 
            se_payr_glbl_enti_nbr,
            se_payr_ctry_enti_nbr,
            se_payr_sls_seg_cd, 
            se_payr_sub_industry_cd, 
            ce_payr_glbl_enti_nbr, 
            ce_payr_ctry_enti_nbr, 
            ce_payr_sls_seg_cd, 
            svc_cat_cd, product, orig_ctry_cd, orig_st_cd, orig_msa, dest_ctry_cd, dest_st_cd, dest_msa, zone_cd, wgtcat, 
            rsd_flg, lrnn_flg, ec_flg, dim_avail_flg,
            autogrp,
            SUM(packages) AS packages, 
            SUM(netrev) AS netrev, 
            SUM(fgtchrg) AS fgtchrg, 
            SUM(discount) AS discount, 
            SUM(fuelsch) AS fuelsch, 
            SUM(totalsch) AS totalsch, 
            SUM(apounds) AS apounds, 
            SUM(rpounds) AS rpounds,
            SUM(pkg_cubic_size) AS pkg_cubic_size,
            SUM(adh_amt) AS adh_amt, 
            SUM(das_amt) AS das_amt, 
            SUM(oth_amt) AS oth_amt, 
            SUM(ovs_amt) AS ovs_amt, 
            SUM(dlg_amt) AS dlg_amt, 
            SUM(dresi_amt) AS dresi_amt, 
            SUM(resi_amt) AS resi_amt, 
            SUM(adh_qty) AS adh_qty, 
            SUM(das_qty) AS das_qty, 
            SUM(oth_qty) AS oth_qty, 
            SUM(ovs_qty) AS ovs_qty, 
            SUM(dlg_qty) AS dlg_qty, 
            SUM(dresi_qty) AS dresi_qty, 
            SUM(resi_qty) AS resi_qty
        FROM {source_facility_table} ship
        WHERE ship.ratemnth = '{v_load_ym}' 
          AND ship.svc_cat_cd = 'SP'
        GROUP BY ratemnth, shipmnth, dlvrmnth,
            se_shpr_glbl_enti_nbr,
            se_shpr_ctry_enti_nbr,
            se_shpr_sls_seg_cd, 
            se_shpr_sub_industry_cd, 
            se_payr_glbl_enti_nbr,
            se_payr_ctry_enti_nbr,
            se_payr_sls_seg_cd, 
            se_payr_sub_industry_cd, 
            ce_payr_glbl_enti_nbr, 
            ce_payr_ctry_enti_nbr, 
            ce_payr_sls_seg_cd, 
            svc_cat_cd, product, orig_ctry_cd, orig_st_cd, orig_msa, dest_ctry_cd, dest_st_cd, dest_msa, zone_cd, wgtcat, 
            rsd_flg, lrnn_flg, ec_flg, dim_avail_flg, autogrp
    """
    
    return spark.sql(query)
# Obtain the country-level aggregated DataFrame
country_aggregated_df = get_fxg_country_entity_billing_monthly_history(
    v_load_ym="202607",
    source_facility_table="MKVW_COMN_SCHEMA.FXG_FAC_ENTI_BILL_MTH_HIST"
)

# Preview DataFrame content
display(country_aggregated_df)
