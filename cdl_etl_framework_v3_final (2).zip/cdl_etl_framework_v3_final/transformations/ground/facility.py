"""
transformations/ground/facility.py
==================================
Facility-level billing transformations for FXG (FedEx Ground).
Each function signature: fn(spark, load_mnth) -> DataFrame
"""

from pyspark.sql import DataFrame, SparkSession
from pyspark.sql.types import StructType, StructField, StringType, DoubleType
from pyspark.sql.functions import *

# Default table references
_BASE_HISTORY_TABLE = "MKVW_COMN_SCHEMA.FXG_ACCT_BILL_MTH_HIST"
_CUST_SE_SEG_MAP    = "MKVW_COMN_SCHEMA.CUST_SE_SEG_MAP"
_CUST_CE_SEG_MAP    = "MKVW_COMN_SCHEMA.CUST_CE_SEG_MAP"
_MTR_GROUP_TABLE    = "MKVW_COMN_SCHEMA.CDL_MTR_GROUP_DEFINITION"

def load_fxg_fac_enti_bill_mth_hist_non_sp(spark: SparkSession, load_mnth: str):
    return int(load_mnth)+20

def load_cdl_testing_table_1(spark: SparkSession, source_table :list,load_mnth: str):
    schema = StructType([
        StructField("shipment_id", StringType(), True),
        StructField("origin", StringType(), True),
        StructField("destination", StringType(), True),
        StructField("weight_kg", DoubleType(), True),
        StructField("status", StringType(), True),
        StructField("ratemnth", StringType(), True) # yyyymm format
    ])

    # 3. Create Sample Data for 6 distinct months
    data = [
        ("SHP-101", "New York", "London", 12.5, "Delivered", "202601"),
        ("SHP-102", "Chicago", "Tokyo", 45.0, "Delivered", "202602"),
        ("SHP-103", "Los Angeles", "Sydney", 8.2, "In Transit", "202606"),
        ("SHP-104", "Houston", "Paris", 22.1, "Delivered", "202606"),
        ("SHP-105", "Miami", "Berlin", 15.3, "Pending", "202605"),
        ("SHP-106", "Seattle", "Mumbai", 30.0, "Delivered", "202607"),
        ("SHP-107", "Seasasattle", "Mumbai", 33.0, "Delivered", "202607")
    ]

    # 4. Create the DataFrame
    df = spark.createDataFrame(data, schema)
    # df = df.withColumn('source', lit(source_table))\
    #        .withColumn('load_mnth',lit(load_mnth))
    df = df.filter(col('ratemnth')== load_mnth)

    return df
    
# def load_fxg_fac_enti_bill_mth_hist_non_sp(spark: SparkSession, load_mnth: str) -> DataFrame:
#     """
#     Facility-level monthly billing history — NON-SP services.
#     Filters: svc_cat_cd <> 'SP'
#     """
#     query = f"""
#         SELECT
#             ratemnth, shipmnth, dlvrmnth,
#             se_shpr_glbl_enti_nbr, se_shpr_ctry_enti_nbr, se_shpr_fac_enti_nbr, se_shpr_sls_seg_cd, se_shpr_sub_industry_cd,
#             se_payr_glbl_enti_nbr, se_payr_ctry_enti_nbr, se_payr_fac_enti_nbr, se_payr_sls_seg_cd, se_payr_sub_industry_cd,
#             ce_payr_glbl_enti_nbr, ce_payr_ctry_enti_nbr, ce_payr_fac_enti_nbr, ce_payr_sls_seg_cd,
#             svc_cat_cd, product, orig_ctry_cd, orig_st_cd, orig_msa, dest_ctry_cd, dest_st_cd, dest_msa, zone_cd, wgtcat,
#             rsd_flg, lrnn_flg, ec_flg, dim_avail_flg, revmnth, autogrp, orig_cbsa, dest_cbsa,
#             SUM(packages) AS packages,
#             SUM(netrev) AS netrev,
#             SUM(fgtchrg) AS fgtchrg,
#             SUM(discount) AS discount,
#             SUM(fuelsch) AS fuelsch,
#             SUM(totalsch) AS totalsch,
#             SUM(apounds) AS apounds,
#             SUM(rpounds) AS rpounds,
#             SUM(pkg_cubic_size) AS pkg_cubic_size,
#             SUM(adh_amt) AS adh_amt,
#             SUM(das_amt) AS das_amt,
#             SUM(oth_amt) AS oth_amt,
#             SUM(ovs_amt) AS ovs_amt,
#             SUM(dlg_amt) AS dlg_amt,
#             SUM(dresi_amt) AS dresi_amt,
#             SUM(resi_amt) AS resi_amt,
#             SUM(adh_qty) AS adh_qty,
#             SUM(das_qty) AS das_qty,
#             SUM(oth_qty) AS oth_qty,
#             SUM(ovs_qty) AS ovs_qty,
#             SUM(dlg_qty) AS dlg_qty,
#             SUM(dresi_qty) AS dresi_qty,
#             SUM(resi_qty) AS resi_qty
#         FROM
#         (
#             SELECT
#                 ratemnth, shipmnth, dlvrmnth,
#                 ses.glbl_enti_nbr AS se_shpr_glbl_enti_nbr,
#                 ses.ctry_enti_nbr AS se_shpr_ctry_enti_nbr,
#                 ses.fac_enti_nbr AS se_shpr_fac_enti_nbr,
#                 ses.ctry_seg_cd AS se_shpr_sls_seg_cd,
#                 ses.sub_industry_cd AS se_shpr_sub_industry_cd,
#                 sep.glbl_enti_nbr AS se_payr_glbl_enti_nbr,
#                 sep.ctry_enti_nbr AS se_payr_ctry_enti_nbr,
#                 sep.fac_enti_nbr AS se_payr_fac_enti_nbr,
#                 sep.ctry_seg_cd AS se_payr_sls_seg_cd,
#                 sep.sub_industry_cd AS se_payr_sub_industry_cd,
#                 cep.glbl_enti_nbr AS ce_payr_glbl_enti_nbr,
#                 cep.ctry_enti_nbr AS ce_payr_ctry_enti_nbr,
#                 cep.fac_enti_nbr AS ce_payr_fac_enti_nbr,
#                 cep.seg_cd AS ce_payr_sls_seg_cd,
#                 svc_cat_cd, product, orig_ctry_cd, orig_st_cd, orig_msa, dest_ctry_cd, dest_st_cd, dest_msa, zone_cd, wgtcat, rsd_flg, lrnn_flg,
#                 CASE
#                     WHEN (ses.ec_flg = 'Y' OR sep.ec_flg = 'Y') AND rsd_flg = 'Y'
#                     AND NOT (SVC_CAT_CD='09' OR (SVC_CAT_CD = 'SP' AND product IN ('918', '919')))
#                     THEN 'Y'
#                     ELSE 'N'
#                 END AS ec_flg,
#                 dim_avail_flg, revmnth, autogrp, orig_cbsa, dest_cbsa,
#                 packages, netrev, fgtchrg, discount, fuelsch, totalsch, apounds, rpounds, pkg_cubic_size,
#                 adh_amt, das_amt, oth_amt, ovs_amt, dlg_amt, dresi_amt, resi_amt,
#                 adh_qty, das_qty, oth_qty, ovs_qty, dlg_qty, dresi_qty, resi_qty
#             FROM {_BASE_HISTORY_TABLE} ship
#             LEFT OUTER JOIN (
#                 SELECT * FROM {_CUST_SE_SEG_MAP} WHERE assoc_company_cd = 'FXG'
#             ) ses ON ship.shpr_ean = ses.ent_acct_nbr
#             LEFT OUTER JOIN (
#                 SELECT * FROM {_CUST_SE_SEG_MAP} WHERE assoc_company_cd = 'FXG'
#             ) sep ON ship.payr_ean = sep.ent_acct_nbr
#             LEFT OUTER JOIN {_CUST_CE_SEG_MAP} cep ON ship.payr_ean = cep.ent_acct_nbr
#             LEFT OUTER JOIN {_MTR_GROUP_TABLE} mtr ON ship.SW_PGM = mtr.SW_PGM
#             WHERE ship.ratemnth = '{load_mnth}'
#               AND ship.svc_cat_cd <> 'SP'
#         )
#         GROUP BY ratemnth, shipmnth, dlvrmnth,
#             se_shpr_glbl_enti_nbr, se_shpr_ctry_enti_nbr, se_shpr_fac_enti_nbr, se_shpr_sls_seg_cd, se_shpr_sub_industry_cd,
#             se_payr_glbl_enti_nbr, se_payr_ctry_enti_nbr, se_payr_fac_enti_nbr, se_payr_sls_seg_cd, se_payr_sub_industry_cd,
#             ce_payr_glbl_enti_nbr, ce_payr_ctry_enti_nbr, ce_payr_fac_enti_nbr, ce_payr_sls_seg_cd,
#             svc_cat_cd, product, orig_ctry_cd, orig_st_cd, orig_msa, dest_ctry_cd, dest_st_cd, dest_msa, zone_cd, wgtcat,
#             rsd_flg, lrnn_flg, ec_flg, dim_avail_flg, revmnth, autogrp, orig_cbsa, dest_cbsa
#     """
#     return spark.sql(query)


# def load_fxg_fac_enti_bill_mth_hist_sp(spark: SparkSession, load_mnth: str) -> DataFrame:
#     """
#     Facility-level monthly billing history — SP (SmartPost) services.
#     Filters: svc_cat_cd = 'SP'
#     """
#     query = f"""
#         SELECT
#             ratemnth, shipmnth, dlvrmnth,
#             se_shpr_glbl_enti_nbr, se_shpr_ctry_enti_nbr, se_shpr_fac_enti_nbr, se_shpr_sls_seg_cd, se_shpr_sub_industry_cd,
#             se_payr_glbl_enti_nbr, se_payr_ctry_enti_nbr, se_payr_fac_enti_nbr, se_payr_sls_seg_cd, se_payr_sub_industry_cd,
#             ce_payr_glbl_enti_nbr, ce_payr_ctry_enti_nbr, ce_payr_fac_enti_nbr, ce_payr_sls_seg_cd,
#             svc_cat_cd, product, orig_ctry_cd, orig_st_cd, orig_msa, dest_ctry_cd, dest_st_cd, dest_msa, zone_cd, wgtcat,
#             rsd_flg, lrnn_flg, ec_flg, dim_avail_flg, autogrp, orig_cbsa, dest_cbsa,
#             SUM(packages) AS packages,
#             SUM(netrev) AS netrev,
#             SUM(fgtchrg) AS fgtchrg,
#             SUM(discount) AS discount,
#             SUM(fuelsch) AS fuelsch,
#             SUM(totalsch) AS totalsch,
#             SUM(apounds) AS apounds,
#             SUM(rpounds) AS rpounds,
#             SUM(pkg_cubic_size) AS pkg_cubic_size,
#             SUM(adh_amt) AS adh_amt,
#             SUM(das_amt) AS das_amt,
#             SUM(oth_amt) AS oth_amt,
#             SUM(ovs_amt) AS ovs_amt,
#             SUM(dlg_amt) AS dlg_amt,
#             SUM(dresi_amt) AS dresi_amt,
#             SUM(resi_amt) AS resi_amt,
#             SUM(adh_qty) AS adh_qty,
#             SUM(das_qty) AS das_qty,
#             SUM(oth_qty) AS oth_qty,
#             SUM(ovs_qty) AS ovs_qty,
#             SUM(dlg_qty) AS dlg_qty,
#             SUM(dresi_qty) AS dresi_qty,
#             SUM(resi_qty) AS resi_qty
#         FROM
#         (
#             SELECT
#                 ratemnth, shipmnth, dlvrmnth,
#                 ses.glbl_enti_nbr AS se_shpr_glbl_enti_nbr,
#                 ses.ctry_enti_nbr AS se_shpr_ctry_enti_nbr,
#                 ses.fac_enti_nbr AS se_shpr_fac_enti_nbr,
#                 ses.ctry_seg_cd AS se_shpr_sls_seg_cd,
#                 ses.sub_industry_cd AS se_shpr_sub_industry_cd,
#                 sep.glbl_enti_nbr AS se_payr_glbl_enti_nbr,
#                 sep.ctry_enti_nbr AS se_payr_ctry_enti_nbr,
#                 sep.fac_enti_nbr AS se_payr_fac_enti_nbr,
#                 sep.ctry_seg_cd AS se_payr_sls_seg_cd,
#                 sep.sub_industry_cd AS se_payr_sub_industry_cd,
#                 cep.glbl_enti_nbr AS ce_payr_glbl_enti_nbr,
#                 cep.ctry_enti_nbr AS ce_payr_ctry_enti_nbr,
#                 cep.fac_enti_nbr AS ce_payr_fac_enti_nbr,
#                 cep.seg_cd AS ce_payr_sls_seg_cd,
#                 svc_cat_cd, product, orig_ctry_cd, orig_st_cd, orig_msa, dest_ctry_cd, dest_st_cd, dest_msa, zone_cd, wgtcat, rsd_flg, lrnn_flg, dim_avail_flg, autogrp, orig_cbsa, dest_cbsa,
#                 CASE
#                     WHEN (ses.ec_flg = 'Y' OR sep.ec_flg = 'Y') AND product NOT IN ('918', '919')
#                     THEN 'Y'
#                     ELSE 'N'
#                 END AS ec_flg,
#                 packages, netrev, fgtchrg, discount, fuelsch, totalsch, apounds, rpounds, pkg_cubic_size,
#                 adh_amt, das_amt, oth_amt, ovs_amt, dlg_amt, dresi_amt, resi_amt,
#                 adh_qty, das_qty, oth_qty, ovs_qty, dlg_qty, dresi_qty, resi_qty
#             FROM {_BASE_HISTORY_TABLE} ship
#             LEFT OUTER JOIN (
#                 SELECT * FROM {_CUST_SE_SEG_MAP} WHERE assoc_company_cd = 'FXG'
#             ) ses ON ship.shpr_ean = ses.ent_acct_nbr
#             LEFT OUTER JOIN (
#                 SELECT * FROM {_CUST_SE_SEG_MAP} WHERE assoc_company_cd = 'FXG'
#             ) sep ON ship.payr_ean = sep.ent_acct_nbr
#             LEFT OUTER JOIN {_CUST_CE_SEG_MAP} cep ON ship.payr_ean = cep.ent_acct_nbr
#             LEFT OUTER JOIN {_MTR_GROUP_TABLE} mtr ON ship.SW_PGM = mtr.SW_PGM
#             WHERE ship.ratemnth = '{load_mnth}'
#               AND ship.svc_cat_cd = 'SP'
#         )
#         GROUP BY ratemnth, shipmnth, dlvrmnth,
#             se_shpr_glbl_enti_nbr, se_shpr_ctry_enti_nbr, se_shpr_fac_enti_nbr, se_shpr_sls_seg_cd, se_shpr_sub_industry_cd,
#             se_payr_glbl_enti_nbr, se_payr_ctry_enti_nbr, se_payr_fac_enti_nbr, se_payr_sls_seg_cd, se_payr_sub_industry_cd,
#             ce_payr_glbl_enti_nbr, ce_payr_ctry_enti_nbr, ce_payr_fac_enti_nbr, ce_payr_sls_seg_cd,
#             svc_cat_cd, product, orig_ctry_cd, orig_st_cd, orig_msa, dest_ctry_cd, dest_st_cd, dest_msa, zone_cd, wgtcat,
#             rsd_flg, lrnn_flg, ec_flg, dim_avail_flg, autogrp, orig_cbsa, dest_cbsa
#     """
#     return spark.sql(query)
