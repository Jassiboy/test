# Databricks notebook source
def load_fxg_fac_enti_bill_mth_hist_non_sp(load_mnth):
    return int(load_mnth)+20

# COMMAND ----------

# MAGIC %skip
# MAGIC from pyspark.sql import SparkSession
# MAGIC from pyspark.sql import DataFrame
# MAGIC
# MAGIC def get_transformed_billing_history(
# MAGIC     spark: SparkSession,
# MAGIC     v_load_ym: str,
# MAGIC     source_schema: str = "ds_fcst_de_prod",
# MAGIC     ship_table: str = "FXG_ACCT_BILL_DLY_HIST",
# MAGIC     se_seg_map_table: str = "CUST_SE_SEG_MAP",
# MAGIC     ce_seg_map_table: str = "CUST_CE_SEG_MAP"
# MAGIC ) -> DataFrame:
# MAGIC     """
# MAGIC     Executes the FXG billing history transformation using raw Spark SQL.
# MAGIC     Returns the transformed PySpark DataFrame.
# MAGIC     """
# MAGIC     
# MAGIC     # We define the raw SQL logic, dynamically parameterized with your schemas and tables
# MAGIC     query = f"""
# MAGIC         SELECT 
# MAGIC             ratemnth, shp_dt, dlvr_dt, 
# MAGIC             se_shpr_glbl_enti_nbr, se_shpr_ctry_enti_nbr, se_shpr_fac_enti_nbr, se_shpr_sls_seg_cd, se_shpr_sub_industry_cd, 
# MAGIC             se_payr_glbl_enti_nbr, se_payr_ctry_enti_nbr, se_payr_fac_enti_nbr, se_payr_sls_seg_cd, se_payr_sub_industry_cd, 
# MAGIC             ce_payr_glbl_enti_nbr, ce_payr_ctry_enti_nbr, ce_payr_fac_enti_nbr, ce_payr_sls_seg_cd, 
# MAGIC             svc_cat_cd, product, orig_ctry_cd, orig_st_cd, orig_msa, dest_ctry_cd, dest_st_cd, dest_msa, zone_cd, wgtcat, 
# MAGIC             rsd_flg, lrnn_flg, ec_flg, dim_avail_flg, rev_dt,
# MAGIC             SUM(packages) AS packages, 
# MAGIC             SUM(netrev) AS netrev, 
# MAGIC             SUM(fgtchrg) AS fgtchrg, 
# MAGIC             SUM(discount) AS discount, 
# MAGIC             SUM(fuelsch) AS fuelsch, 
# MAGIC             SUM(totalsch) AS totalsch, 
# MAGIC             SUM(apounds) AS apounds, 
# MAGIC             SUM(rpounds) AS rpounds, 
# MAGIC             SUM(pkg_cubic_size) AS pkg_cubic_size,
# MAGIC             SUM(adh_amt) AS adh_amt, 
# MAGIC             SUM(das_amt) AS das_amt, 
# MAGIC             SUM(oth_amt) AS oth_amt, 
# MAGIC             SUM(ovs_amt) AS ovs_amt, 
# MAGIC             SUM(dlg_amt) AS dlg_amt, 
# MAGIC             SUM(dresi_amt) AS dresi_amt, 
# MAGIC             SUM(resi_amt) AS resi_amt, 
# MAGIC             SUM(adh_qty) AS adh_qty, 
# MAGIC             SUM(das_qty) AS das_qty, 
# MAGIC             SUM(oth_qty) AS oth_qty, 
# MAGIC             SUM(ovs_qty) AS ovs_qty, 
# MAGIC             SUM(dlg_qty) AS dlg_qty, 
# MAGIC             SUM(dresi_qty) AS dresi_qty, 
# MAGIC             SUM(resi_qty) AS resi_qty            
# MAGIC         FROM
# MAGIC         (
# MAGIC             SELECT 
# MAGIC                 ship.ratemnth, ship.shp_dt, ship.dlvr_dt, 
# MAGIC                 ses.glbl_enti_nbr AS se_shpr_glbl_enti_nbr,
# MAGIC                 ses.ctry_enti_nbr AS se_shpr_ctry_enti_nbr,
# MAGIC                 ses.fac_enti_nbr AS se_shpr_fac_enti_nbr, 
# MAGIC                 ses.ctry_seg_cd AS se_shpr_sls_seg_cd, 
# MAGIC                 ses.sub_industry_cd AS se_shpr_sub_industry_cd, 
# MAGIC                 sep.glbl_enti_nbr AS se_payr_glbl_enti_nbr,
# MAGIC                 sep.ctry_enti_nbr AS se_payr_ctry_enti_nbr,
# MAGIC                 sep.fac_enti_nbr AS se_payr_fac_enti_nbr, 
# MAGIC                 sep.ctry_seg_cd AS se_payr_sls_seg_cd, 
# MAGIC                 sep.sub_industry_cd AS se_payr_sub_industry_cd, 
# MAGIC                 cep.glbl_enti_nbr AS ce_payr_glbl_enti_nbr, 
# MAGIC                 cep.ctry_enti_nbr AS ce_payr_ctry_enti_nbr, 
# MAGIC                 cep.fac_enti_nbr AS ce_payr_fac_enti_nbr,
# MAGIC                 cep.seg_cd AS ce_payr_sls_seg_cd, 
# MAGIC                 ship.svc_cat_cd, ship.product, ship.orig_ctry_cd, ship.orig_st_cd, ship.orig_msa, 
# MAGIC                 ship.dest_ctry_cd, ship.dest_st_cd, ship.dest_msa, ship.zone_cd, ship.wgtcat, 
# MAGIC                 ship.rsd_flg, ship.lrnn_flg,
# MAGIC                 CASE 
# MAGIC                     WHEN (ses.ec_flg = 'Y' OR sep.ec_flg = 'Y') AND ship.rsd_flg = 'Y'
# MAGIC                     AND NOT (ship.SVC_CAT_CD='09' OR (ship.SVC_CAT_CD = 'SP' AND ship.product IN ('918', '919'))) 
# MAGIC                     THEN 'Y'                                
# MAGIC                     ELSE 'N'
# MAGIC                 END AS ec_flg, 
# MAGIC                 ship.dim_avail_flg, ship.rev_dt,                    
# MAGIC                 ship.packages, ship.netrev, ship.fgtchrg, ship.discount, ship.fuelsch, ship.totalsch, 
# MAGIC                 ship.apounds, ship.rpounds, ship.pkg_cubic_size, 
# MAGIC                 ship.adh_amt, ship.das_amt, ship.oth_amt, ship.ovs_amt, ship.dlg_amt, ship.dresi_amt, ship.resi_amt, 
# MAGIC                 ship.adh_qty, ship.das_qty, ship.oth_qty, ship.ovs_qty, ship.dlg_qty, ship.dresi_qty, ship.resi_qty            
# MAGIC             FROM {source_schema}.{ship_table} ship
# MAGIC             LEFT OUTER JOIN (
# MAGIC                 SELECT *
# MAGIC                 FROM {source_schema}.{se_seg_map_table}
# MAGIC                 WHERE assoc_company_cd = 'FXG'
# MAGIC             ) ses
# MAGIC             ON (ship.shpr_ean = ses.ent_acct_nbr)
# MAGIC             LEFT OUTER JOIN (
# MAGIC                 SELECT *
# MAGIC                 FROM {source_schema}.{se_seg_map_table}
# MAGIC                 WHERE assoc_company_cd = 'FXG'
# MAGIC             ) sep
# MAGIC             ON (ship.payr_ean = sep.ent_acct_nbr)
# MAGIC             LEFT OUTER JOIN {source_schema}.{ce_seg_map_table} cep
# MAGIC             ON (ship.payr_ean = cep.ent_acct_nbr)                
# MAGIC             WHERE ship.ratemnth = '{v_load_ym}'
# MAGIC             AND ship.svc_cat_cd <> 'SP'
# MAGIC         )
# MAGIC         GROUP BY 
# MAGIC             ratemnth, shp_dt, dlvr_dt, 
# MAGIC             se_shpr_glbl_enti_nbr, se_shpr_ctry_enti_nbr, se_shpr_fac_enti_nbr, se_shpr_sls_seg_cd, se_shpr_sub_industry_cd, 
# MAGIC             se_payr_glbl_enti_nbr, se_payr_ctry_enti_nbr, se_payr_fac_enti_nbr, se_payr_sls_seg_cd, se_payr_sub_industry_cd, 
# MAGIC             ce_payr_glbl_enti_nbr, ce_payr_ctry_enti_nbr, ce_payr_fac_enti_nbr, ce_payr_sls_seg_cd, 
# MAGIC             svc_cat_cd, product, orig_ctry_cd, orig_st_cd, orig_msa, dest_ctry_cd, dest_st_cd, dest_msa, zone_cd, wgtcat, 
# MAGIC             rsd_flg, lrnn_flg, ec_flg, dim_avail_flg, rev_dt
# MAGIC     """
# MAGIC     
# MAGIC     # Spark compiles this into the exact same logical execution plan as native DataFrame API
# MAGIC     return spark.sql(query)
# MAGIC
# MAGIC transformed_df = get_transformed_billing_history(spark, v_load_ym="202606")
# MAGIC display(transformed_df)
# MAGIC print(transformed_df.count())
# MAGIC

# COMMAND ----------

# MAGIC %skip
# MAGIC from pyspark.sql import SparkSession
# MAGIC from pyspark.sql import DataFrame
# MAGIC
# MAGIC def get_transformed_billing_history_sp(
# MAGIC     spark: SparkSession,
# MAGIC     v_load_ym: str,
# MAGIC     source_schema: str = "ds_fcst_de_prod",
# MAGIC     ship_table: str = "FXG_ACCT_BILL_DLY_HIST",
# MAGIC     se_seg_map_table: str = "CUST_SE_SEG_MAP",
# MAGIC     ce_seg_map_table: str = "CUST_CE_SEG_MAP"
# MAGIC ) -> DataFrame:
# MAGIC     """
# MAGIC     Executes the FXG billing history transformation for 'SP' service category 
# MAGIC     using raw Spark SQL with broadcast optimizations.
# MAGIC     
# MAGIC     Returns the transformed PySpark DataFrame.
# MAGIC     """
# MAGIC     
# MAGIC     # Core SQL transformation logic utilizing dynamic parameters and broadcast join hints
# MAGIC     query = f"""
# MAGIC         SELECT 
# MAGIC             ratemnth, shp_dt, dlvr_dt, 
# MAGIC             se_shpr_glbl_enti_nbr, se_shpr_ctry_enti_nbr, se_shpr_fac_enti_nbr, se_shpr_sls_seg_cd, se_shpr_sub_industry_cd, 
# MAGIC             se_payr_glbl_enti_nbr, se_payr_ctry_enti_nbr, se_payr_fac_enti_nbr, se_payr_sls_seg_cd, se_payr_sub_industry_cd, 
# MAGIC             ce_payr_glbl_enti_nbr, ce_payr_ctry_enti_nbr, ce_payr_fac_enti_nbr, ce_payr_sls_seg_cd, 
# MAGIC             svc_cat_cd, product, orig_ctry_cd, orig_st_cd, orig_msa, dest_ctry_cd, dest_st_cd, dest_msa, zone_cd, wgtcat, 
# MAGIC             rsd_flg, lrnn_flg, ec_flg, dim_avail_flg,
# MAGIC             SUM(packages) AS packages, 
# MAGIC             SUM(netrev) AS netrev, 
# MAGIC             SUM(fgtchrg) AS fgtchrg, 
# MAGIC             SUM(discount) AS discount, 
# MAGIC             SUM(fuelsch) AS fuelsch, 
# MAGIC             SUM(totalsch) AS totalsch, 
# MAGIC             SUM(apounds) AS apounds, 
# MAGIC             SUM(rpounds) AS rpounds, 
# MAGIC             SUM(pkg_cubic_size) AS pkg_cubic_size,
# MAGIC             SUM(adh_amt) AS adh_amt, 
# MAGIC             SUM(das_amt) AS das_amt, 
# MAGIC             SUM(oth_amt) AS oth_amt, 
# MAGIC             SUM(ovs_amt) AS ovs_amt, 
# MAGIC             SUM(dlg_amt) AS dlg_amt, 
# MAGIC             SUM(dresi_amt) AS dresi_amt, 
# MAGIC             SUM(resi_amt) AS resi_amt, 
# MAGIC             SUM(adh_qty) AS adh_qty, 
# MAGIC             SUM(das_qty) AS das_qty, 
# MAGIC             SUM(oth_qty) AS oth_qty, 
# MAGIC             SUM(ovs_qty) AS ovs_qty, 
# MAGIC             SUM(dlg_qty) AS dlg_qty, 
# MAGIC             SUM(dresi_qty) AS dresi_qty, 
# MAGIC             SUM(resi_qty) AS resi_qty            
# MAGIC         FROM
# MAGIC         (
# MAGIC             SELECT /*+ BROADCAST(ses, sep, cep) */
# MAGIC                 ship.ratemnth, ship.shp_dt, ship.dlvr_dt,
# MAGIC                 ses.glbl_enti_nbr AS se_shpr_glbl_enti_nbr,
# MAGIC                 ses.ctry_enti_nbr AS se_shpr_ctry_enti_nbr,
# MAGIC                 ses.fac_enti_nbr AS se_shpr_fac_enti_nbr, 
# MAGIC                 ses.ctry_seg_cd AS se_shpr_sls_seg_cd, 
# MAGIC                 ses.sub_industry_cd AS se_shpr_sub_industry_cd, 
# MAGIC                 sep.glbl_enti_nbr AS se_payr_glbl_enti_nbr,
# MAGIC                 sep.ctry_enti_nbr AS se_payr_ctry_enti_nbr,
# MAGIC                 sep.fac_enti_nbr AS se_payr_fac_enti_nbr, 
# MAGIC                 sep.ctry_seg_cd AS se_payr_sls_seg_cd, 
# MAGIC                 sep.sub_industry_cd AS se_payr_sub_industry_cd, 
# MAGIC                 cep.glbl_enti_nbr AS ce_payr_glbl_enti_nbr, 
# MAGIC                 cep.ctry_enti_nbr AS ce_payr_ctry_enti_nbr,
# MAGIC                 cep.fac_enti_nbr AS ce_payr_fac_enti_nbr,                                            
# MAGIC                 cep.seg_cd AS ce_payr_sls_seg_cd, 
# MAGIC                 ship.svc_cat_cd, ship.product, ship.orig_ctry_cd, ship.orig_st_cd, ship.orig_msa, 
# MAGIC                 ship.dest_ctry_cd, ship.dest_st_cd, ship.dest_msa, ship.zone_cd, ship.wgtcat, 
# MAGIC                 ship.rsd_flg, ship.lrnn_flg, ship.dim_avail_flg,
# MAGIC                 CASE 
# MAGIC                     WHEN (ses.ec_flg = 'Y' OR sep.ec_flg = 'Y') AND ship.product NOT IN ('918', '919')
# MAGIC                     THEN 'Y'                                
# MAGIC                     ELSE 'N'
# MAGIC                 END AS ec_flg,                    
# MAGIC                 ship.packages, ship.netrev, ship.fgtchrg, ship.discount, ship.fuelsch, ship.totalsch, 
# MAGIC                 ship.apounds, ship.rpounds, ship.pkg_cubic_size, 
# MAGIC                 ship.adh_amt, ship.das_amt, ship.oth_amt, ship.ovs_amt, ship.dlg_amt, ship.dresi_amt, ship.resi_amt, 
# MAGIC                 ship.adh_qty, ship.das_qty, ship.oth_qty, ship.ovs_qty, ship.dlg_qty, ship.dresi_qty, ship.resi_qty          
# MAGIC             FROM {source_schema}.{ship_table} ship
# MAGIC             LEFT OUTER JOIN (
# MAGIC                 SELECT *
# MAGIC                 FROM {source_schema}.{se_seg_map_table}
# MAGIC                 WHERE assoc_company_cd = 'FXG'
# MAGIC             ) ses
# MAGIC             ON (ship.shpr_ean = ses.ent_acct_nbr)
# MAGIC             LEFT OUTER JOIN (
# MAGIC                 SELECT *
# MAGIC                 FROM {source_schema}.{se_seg_map_table}
# MAGIC                 WHERE assoc_company_cd = 'FXG'
# MAGIC             ) sep
# MAGIC             ON (ship.payr_ean = sep.ent_acct_nbr)
# MAGIC             LEFT OUTER JOIN {source_schema}.{ce_seg_map_table} cep
# MAGIC             ON (ship.payr_ean = cep.ent_acct_nbr)
# MAGIC             WHERE ship.ratemnth = '{v_load_ym}' 
# MAGIC             AND ship.svc_cat_cd = 'SP'
# MAGIC         )
# MAGIC         GROUP BY 
# MAGIC             ratemnth, shp_dt, dlvr_dt,
# MAGIC             se_shpr_glbl_enti_nbr, se_shpr_ctry_enti_nbr, se_shpr_fac_enti_nbr, se_shpr_sls_seg_cd, se_shpr_sub_industry_cd, 
# MAGIC             se_payr_glbl_enti_nbr, se_payr_ctry_enti_nbr, se_payr_fac_enti_nbr, se_payr_sls_seg_cd, se_payr_sub_industry_cd, 
# MAGIC             ce_payr_glbl_enti_nbr, ce_payr_ctry_enti_nbr, ce_payr_fac_enti_nbr, ce_payr_sls_seg_cd, 
# MAGIC             svc_cat_cd, product, orig_ctry_cd, orig_st_cd, orig_msa, dest_ctry_cd, dest_st_cd, dest_msa, zone_cd, wgtcat, 
# MAGIC             rsd_flg, lrnn_flg, ec_flg, dim_avail_flg
# MAGIC     """
# MAGIC     
# MAGIC     return spark.sql(query)
# MAGIC
# MAGIC
# MAGIC
# MAGIC transformed_df = get_transformed_billing_history_sp(spark, v_load_ym="202606")
# MAGIC display(transformed_df)
# MAGIC print(transformed_df.count())

# COMMAND ----------

# MAGIC %sql
# MAGIC -- select count(*) from ds_fcst_de_prod.FXG_FAC_ENTI_BILL_DLY_HIST where ratemnth = '202606'

# COMMAND ----------

# MAGIC %skip
# MAGIC %sql
# MAGIC show create table ds_fcst_de_prod.fxg_glbl_enti_bill_mth_hist

# COMMAND ----------

from pyspark.sql import DataFrame, SparkSession

def get_fxg_facility_billing_monthly_history(
    v_load_ym: str,
    base_history_table: str = "MKVW_COMN_SCHEMA.FXG_ACCT_BILL_MTH_HIST",
    cust_se_seg_map_table: str = "MKVW_COMN_SCHEMA.CUST_SE_SEG_MAP",
    cust_ce_seg_map_table: str = "MKVW_COMN_SCHEMA.CUST_CE_SEG_MAP",
    mtr_group_table: str = "MKVW_COMN_SCHEMA.CDL_MTR_GROUP_DEFINITION"
) -> DataFrame:
    """
    Transforms and aggregates FedEx Ground (FXG) account billing monthly history.
    
    Args:
        v_load_ym (str): The rate month (YYYYMM format) to filter the data.
        base_history_table (str): Dynamic name for the base billing history table.
        cust_se_seg_map_table (str): Dynamic name for the SE customer segment map.
        cust_ce_seg_map_table (str): Dynamic name for the CE customer segment map.
        mtr_group_table (str): Dynamic name for the CDL meter group definition table.
        
    Returns:
        DataFrame: The transformed and aggregated PySpark DataFrame.
    """
    # Grab the active Spark session
    spark = SparkSession.builder.getOrCreate()
    
    # Core SQL transformation logic matching your specifications
    query = f"""
        SELECT 
            ratemnth, shipmnth, dlvrmnth,
            se_shpr_glbl_enti_nbr, se_shpr_ctry_enti_nbr, se_shpr_fac_enti_nbr, se_shpr_sls_seg_cd, se_shpr_sub_industry_cd, 
            se_payr_glbl_enti_nbr, se_payr_ctry_enti_nbr, se_payr_fac_enti_nbr, se_payr_sls_seg_cd, se_payr_sub_industry_cd, 
            ce_payr_glbl_enti_nbr, ce_payr_ctry_enti_nbr, ce_payr_fac_enti_nbr, ce_payr_sls_seg_cd, 
            svc_cat_cd, product, orig_ctry_cd, orig_st_cd, orig_msa, dest_ctry_cd, dest_st_cd, dest_msa, zone_cd, wgtcat, 
            rsd_flg, lrnn_flg, ec_flg, dim_avail_flg, revmnth, autogrp, orig_cbsa, dest_cbsa,
            SUM(packages) AS packages, 
            SUM(netrev) AS netrev, 
            SUM(fgtchrg) AS fgtchrg, 
            SUM(discount) AS discount, 
            SUM(fuelsch) AS fuelsch, 
            SUM(totalsch) AS totalsch, 
            SUM(apounds) AS apounds, 
            SUM(rpounds) AS rpounds,
            SUM(pkg_cubic_size) AS pkg_cubic_size,
            SUM(adh_amt) AS adh_amt, 
            SUM(das_amt) AS das_amt, 
            SUM(oth_amt) AS oth_amt, 
            SUM(ovs_amt) AS ovs_amt, 
            SUM(dlg_amt) AS dlg_amt, 
            SUM(dresi_amt) AS dresi_amt, 
            SUM(resi_amt) AS resi_amt, 
            SUM(adh_qty) AS adh_qty, 
            SUM(das_qty) AS das_qty, 
            SUM(oth_qty) AS oth_qty, 
            SUM(ovs_qty) AS ovs_qty, 
            SUM(dlg_qty) AS dlg_qty, 
            SUM(dresi_qty) AS dresi_qty, 
            SUM(resi_qty) AS resi_qty            
        FROM
        (
            SELECT 
                ratemnth, shipmnth, dlvrmnth,
                ses.glbl_enti_nbr AS se_shpr_glbl_enti_nbr,
                ses.ctry_enti_nbr AS se_shpr_ctry_enti_nbr,
                ses.fac_enti_nbr AS se_shpr_fac_enti_nbr, 
                ses.ctry_seg_cd AS se_shpr_sls_seg_cd, 
                ses.sub_industry_cd AS se_shpr_sub_industry_cd, 
                sep.glbl_enti_nbr AS se_payr_glbl_enti_nbr,
                sep.ctry_enti_nbr AS se_payr_ctry_enti_nbr,
                sep.fac_enti_nbr AS se_payr_fac_enti_nbr, 
                sep.ctry_seg_cd AS se_payr_sls_seg_cd, 
                sep.sub_industry_cd AS se_payr_sub_industry_cd, 
                cep.glbl_enti_nbr AS ce_payr_glbl_enti_nbr,
                cep.ctry_enti_nbr AS ce_payr_ctry_enti_nbr, 
                cep.fac_enti_nbr AS ce_payr_fac_enti_nbr, 
                cep.seg_cd AS ce_payr_sls_seg_cd, 
                svc_cat_cd, product, orig_ctry_cd, orig_st_cd, orig_msa, dest_ctry_cd, dest_st_cd, dest_msa, zone_cd, wgtcat, rsd_flg, lrnn_flg,
                CASE 
                    WHEN (ses.ec_flg = 'Y' OR sep.ec_flg = 'Y') AND rsd_flg = 'Y'
                    AND NOT (SVC_CAT_CD='09' OR (SVC_CAT_CD = 'SP' AND product IN ('918', '919'))) 
                    THEN 'Y'                                 
                    ELSE 'N'
                END AS ec_flg, 
                dim_avail_flg, revmnth, autogrp, orig_cbsa, dest_cbsa,                
                packages, netrev, fgtchrg, discount, fuelsch, totalsch, apounds, rpounds, pkg_cubic_size, 
                adh_amt, das_amt, oth_amt, ovs_amt, dlg_amt, dresi_amt, resi_amt, 
                adh_qty, das_qty, oth_qty, ovs_qty, dlg_qty, dresi_qty, resi_qty            
            FROM {base_history_table} ship
            LEFT OUTER JOIN (
                SELECT *
                FROM {cust_se_seg_map_table}
                WHERE assoc_company_cd = 'FXG'
            ) ses
            ON (
                ship.shpr_ean = ses.ent_acct_nbr 
            )
            LEFT OUTER JOIN (
                SELECT *
                FROM {cust_se_seg_map_table}
                WHERE assoc_company_cd = 'FXG'
            ) sep
            ON (
                ship.payr_ean = sep.ent_acct_nbr 
            )
            LEFT OUTER JOIN {cust_ce_seg_map_table} cep
            ON (
                ship.payr_ean = cep.ent_acct_nbr 
            )   
            LEFT OUTER JOIN {mtr_group_table} mtr
            ON (
                ship.SW_PGM = mtr.SW_PGM
            )             
            WHERE ship.ratemnth = '{v_load_ym}'
              AND ship.svc_cat_cd <> 'SP'
       )
       GROUP BY ratemnth, shipmnth, dlvrmnth,
            se_shpr_glbl_enti_nbr, se_shpr_ctry_enti_nbr, se_shpr_fac_enti_nbr, se_shpr_sls_seg_cd, se_shpr_sub_industry_cd, 
            se_payr_glbl_enti_nbr, se_payr_ctry_enti_nbr, se_payr_fac_enti_nbr, se_payr_sls_seg_cd, se_payr_sub_industry_cd, 
            ce_payr_glbl_enti_nbr, ce_payr_ctry_enti_nbr, ce_payr_fac_enti_nbr, ce_payr_sls_seg_cd, 
            svc_cat_cd, product, orig_ctry_cd, orig_st_cd, orig_msa, dest_ctry_cd, dest_st_cd, dest_msa, zone_cd, wgtcat, 
            rsd_flg, lrnn_flg, ec_flg, dim_avail_flg, revmnth, autogrp, orig_cbsa, dest_cbsa
    """
    
    # Evaluate query and return DataFrame directly
    return spark.sql(query)

# Call function to get transformed DataFrame
transformed_df = get_fxg_facility_billing_monthly_history(
    v_load_ym="202607", 
    base_history_table="MKVW_COMN_SCHEMA.FXG_ACCT_BILL_MTH_HIST"
)

# You can now save it back to a target table or show it
# transformed_df.write.mode("append").insertInto("MKVW_COMN_SCHEMA.FXG_FAC_ENTI_BILL_MTH_HIST")
display(transformed_df)


# COMMAND ----------

from pyspark.sql import DataFrame, SparkSession

def get_fxg_facility_billing_monthly_history_sp(
    v_load_ym: str,
    base_history_table: str = "MKVW_COMN_SCHEMA.FXG_ACCT_BILL_MTH_HIST",
    cust_se_seg_map_table: str = "MKVW_COMN_SCHEMA.CUST_SE_SEG_MAP",
    cust_ce_seg_map_table: str = "MKVW_COMN_SCHEMA.CUST_CE_SEG_MAP",
    mtr_group_table: str = "MKVW_COMN_SCHEMA.CDL_MTR_GROUP_DEFINITION"
) -> DataFrame:
    """
    Transforms and aggregates FedEx Ground (FXG) account billing monthly history specifically for SP (SmartPost).
    
    Args:
        v_load_ym (str): The rate month (YYYYMM format) to filter the data.
        base_history_table (str): Dynamic name for the base billing history table.
        cust_se_seg_map_table (str): Dynamic name for the SE customer segment map.
        cust_ce_seg_map_table (str): Dynamic name for the CE customer segment map.
        mtr_group_table (str): Dynamic name for the CDL meter group definition table.
        
    Returns:
        DataFrame: The transformed and aggregated PySpark DataFrame.
    """
    # Grab the active Spark session
    spark = SparkSession.builder.getOrCreate()
    
    # Core SQL transformation logic matching your specifications
    query = f"""
        SELECT 
            ratemnth, shipmnth, dlvrmnth,
            se_shpr_glbl_enti_nbr, se_shpr_ctry_enti_nbr, se_shpr_fac_enti_nbr, se_shpr_sls_seg_cd, se_shpr_sub_industry_cd, 
            se_payr_glbl_enti_nbr, se_payr_ctry_enti_nbr, se_payr_fac_enti_nbr, se_payr_sls_seg_cd, se_payr_sub_industry_cd, 
            ce_payr_glbl_enti_nbr, ce_payr_ctry_enti_nbr, ce_payr_fac_enti_nbr, ce_payr_sls_seg_cd, 
            svc_cat_cd, product, orig_ctry_cd, orig_st_cd, orig_msa, dest_ctry_cd, dest_st_cd, dest_msa, zone_cd, wgtcat, 
            rsd_flg, lrnn_flg, ec_flg, dim_avail_flg, autogrp, orig_cbsa, dest_cbsa,
            SUM(packages) AS packages, 
            SUM(netrev) AS netrev, 
            SUM(fgtchrg) AS fgtchrg, 
            SUM(discount) AS discount, 
            SUM(fuelsch) AS fuelsch, 
            SUM(totalsch) AS totalsch, 
            SUM(apounds) AS apounds, 
            SUM(rpounds) AS rpounds,
            SUM(pkg_cubic_size) AS pkg_cubic_size,
            SUM(adh_amt) AS adh_amt, 
            SUM(das_amt) AS das_amt, 
            SUM(oth_amt) AS oth_amt, 
            SUM(ovs_amt) AS ovs_amt, 
            SUM(dlg_amt) AS dlg_amt, 
            SUM(dresi_amt) AS dresi_amt, 
            SUM(resi_amt) AS resi_amt, 
            SUM(adh_qty) AS adh_qty, 
            SUM(das_qty) AS das_qty, 
            SUM(oth_qty) AS oth_qty, 
            SUM(ovs_qty) AS ovs_qty, 
            SUM(dlg_qty) AS dlg_qty, 
            SUM(dresi_qty) AS dresi_qty, 
            SUM(resi_qty) AS resi_qty            
        FROM
        (
            SELECT 
                ratemnth, shipmnth, dlvrmnth,
                ses.glbl_enti_nbr AS se_shpr_glbl_enti_nbr,
                ses.ctry_enti_nbr AS se_shpr_ctry_enti_nbr,
                ses.fac_enti_nbr AS se_shpr_fac_enti_nbr, 
                ses.ctry_seg_cd AS se_shpr_sls_seg_cd, 
                ses.sub_industry_cd AS se_shpr_sub_industry_cd, 
                sep.glbl_enti_nbr AS se_payr_glbl_enti_nbr,
                sep.ctry_enti_nbr AS se_payr_ctry_enti_nbr,
                sep.fac_enti_nbr AS se_payr_fac_enti_nbr, 
                sep.ctry_seg_cd AS se_payr_sls_seg_cd, 
                sep.sub_industry_cd AS se_payr_sub_industry_cd, 
                cep.glbl_enti_nbr AS ce_payr_glbl_enti_nbr,
                cep.ctry_enti_nbr AS ce_payr_ctry_enti_nbr, 
                cep.fac_enti_nbr AS ce_payr_fac_enti_nbr, 
                cep.seg_cd AS ce_payr_sls_seg_cd, 
                svc_cat_cd, product, orig_ctry_cd, orig_st_cd, orig_msa, dest_ctry_cd, dest_st_cd, dest_msa, zone_cd, wgtcat, rsd_flg, lrnn_flg, dim_avail_flg, autogrp, orig_cbsa, dest_cbsa,
                CASE 
                    WHEN (ses.ec_flg = 'Y' OR sep.ec_flg = 'Y') AND product NOT IN ('918', '919') 
                    THEN 'Y'                                 
                    ELSE 'N'
                END AS ec_flg, 
                packages, netrev, fgtchrg, discount, fuelsch, totalsch, apounds, rpounds, pkg_cubic_size, 
                adh_amt, das_amt, oth_amt, ovs_amt, dlg_amt, dresi_amt, resi_amt, 
                adh_qty, das_qty, oth_qty, ovs_qty, dlg_qty, dresi_qty, resi_qty            
            FROM {base_history_table} ship
            LEFT OUTER JOIN (
                SELECT *
                FROM {cust_se_seg_map_table}
                WHERE assoc_company_cd = 'FXG'
            ) ses
            ON (
                ship.shpr_ean = ses.ent_acct_nbr 
            )
            LEFT OUTER JOIN (
                SELECT *
                FROM {cust_se_seg_map_table}
                WHERE assoc_company_cd = 'FXG'
            ) sep
            ON (
                ship.payr_ean = sep.ent_acct_nbr 
            )
            LEFT OUTER JOIN {cust_ce_seg_map_table} cep
            ON (
                ship.payr_ean = cep.ent_acct_nbr 
            )   
            LEFT OUTER JOIN {mtr_group_table} mtr
            ON (
                ship.SW_PGM = mtr.SW_PGM
            )             
            WHERE ship.ratemnth = '{v_load_ym}'
              AND ship.svc_cat_cd = 'SP'
       )
       GROUP BY ratemnth, shipmnth, dlvrmnth,
            se_shpr_glbl_enti_nbr, se_shpr_ctry_enti_nbr, se_shpr_fac_enti_nbr, se_shpr_sls_seg_cd, se_shpr_sub_industry_cd, 
            se_payr_glbl_enti_nbr, se_payr_ctry_enti_nbr, se_payr_fac_enti_nbr, se_payr_sls_seg_cd, se_payr_sub_industry_cd, 
            ce_payr_glbl_enti_nbr, ce_payr_ctry_enti_nbr, ce_payr_fac_enti_nbr, ce_payr_sls_seg_cd, 
            svc_cat_cd, product, orig_ctry_cd, orig_st_cd, orig_msa, dest_ctry_cd, dest_st_cd, dest_msa, zone_cd, wgtcat, 
            rsd_flg, lrnn_flg, ec_flg, dim_avail_flg, autogrp, orig_cbsa, dest_cbsa
    """
    
    # Run the SQL syntax against the spark engine and return the DataFrame
    return spark.sql(query)
# Call function to get transformed SP DataFrame
sp_transformed_df = get_fxg_facility_billing_monthly_history_sp(
    v_load_ym="202607"
)

# Preview results
display(sp_transformed_df)
