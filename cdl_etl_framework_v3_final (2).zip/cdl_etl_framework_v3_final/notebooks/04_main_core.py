# Databricks notebook source
# MAGIC %md
# MAGIC =============================================

# COMMAND ----------

# DBTITLE 1,Cell 5
import importlib
import json
import sys
import os
import uuid
from datetime import date, timedelta
from typing import Optional

# Force reload — clear cached modules so updated files are picked up
for _mod in ['notebooks.01_framework_core', 'notebooks.02_ingestion', 'notebooks.03_transformation', 'config.env_config','dq.dq_rule']:
    sys.modules.pop(_mod, None)

# Add parent directory to path for imports
sys.path.insert(0, os.path.abspath(os.path.join(os.getcwd(), "..")))

# Import framework_core module using importlib
framework_core = importlib.import_module('notebooks.01_framework_core')
ingestion_core = importlib.import_module('notebooks.02_ingestion')
transformation_core = importlib.import_module('notebooks.03_transformation')
_env_config_mod = importlib.import_module('config.env_config')
PIPELINE_CONFIG = _env_config_mod.PIPELINE_CONFIG
# Extract commonly used functions
log = framework_core.log
read_table_configs = framework_core.read_table_configs
check_dq_gate = framework_core.check_dq_gate
log_start = framework_core.log_start
log_end_success = framework_core.log_end_success
log_end_failure = framework_core.log_end_failure

TableConfig = framework_core.TableConfig
run_ingestion = ingestion_core.run_ingestion
_reset_stage = ingestion_core._reset_stage
get_transformed_df = transformation_core.get_transformed_df
_dq_rules_module = importlib.import_module("dq.dq_rules")

LAYER_ORDER  = PIPELINE_CONFIG.layer_order       # e.g. ["ACCOUNT","FACILITY","COUNTRY","GLOBAL"]
CONFIG_PATH  = "../config/run_config.json"
DATA_DB = 'f6180854'

# COMMAND ----------

# DBTITLE 1,Cell 6
from dateutil.relativedelta import relativedelta
from datetime import datetime, timezone

# DBTITLE 1,Month splitting — load month-wise instead of one big range
def month_chunks(start_date: int, end_date: int) -> list[int]:
    """Return list of YYYYMM ints between start_date and end_date (inclusive)."""
    chunks = []
    cur_y, cur_m = start_date // 100, start_date % 100
    end_y, end_m = end_date // 100, end_date % 100
    while (cur_y, cur_m) <= (end_y, end_m):
        chunks.append(cur_y * 100 + cur_m)
        cur_m += 1
        if cur_m > 12:
            cur_m = 1
            cur_y += 1
    return chunks

# COMMAND ----------

# DBTITLE 1,Run one (opco, layer) for one window
# DBTITLE 1,Run one (opco, layer) for one window
def run_layer(
    run_batch_id: str, opco: str, layer: str,   table_id: list[str],
    start_date: Optional[date] = None, end_date: Optional[date] = None, stage: Optional[str] = "False") -> bool:

    all_ok = True
    configs = read_table_configs(table_id=table_id, schedule_group=None)
    print(configs)
    
    if not configs:
        log("WARN", "No configs found", layer=layer, opco=opco)
        return 

    log("INFO", "═" * 55)
    for cfg in configs:
        windows = [] if start_date is None else month_chunks(int(start_date), int(end_date))
        mode = "incremental" if start_date is None else "monthly_backfill"

        run_date = date.today()
        
        if mode == 'incremental':
            current_month_str = run_date.strftime("%Y%m")
            if run_date.day <= int(cfg.incremental_cutoff_day):
                prev_month_date = run_date - relativedelta(months=1)
                prev_month_str = prev_month_date.strftime("%Y%m")
                windows = [prev_month_str, current_month_str]
            else:
                windows = [current_month_str]
        print(windows)
        # return
        if not windows:
            log("WARN", f"No months to process for table {cfg.table_id}.")
            continue

        temp_table  = f"{DATA_DB}.{cfg.target_table}_temp"

        print(temp_table)

               
        completed_staged_months = set()
        completed_ingested_months = set()
        for attempt in range(1, retry_max_attempts+1):
            month_summaries = []
            started_at = log_start(
            run_batch_id    = run_batch_id,
            cfg             = cfg,
            opco            = opco,
            load_mnth_start = windows[0],
            load_mnth_end   = windows[-1],
            attempt         = attempt,
            # watermark_start = watermark_start,
            )
            try:
                if attempt == 1:
                    _reset_stage(temp_table)
                # ── 1. Load every month into stage ────────────────────────────────
                for mnth in windows:
                    if mnth in completed_staged_months:
                        log("INFO", f"Skipping stage load for {mnth} — already staged in prior attempt.")
                        continue
                    tdf = get_transformed_df(opco, layer, cfg.target_table, cfg.source_table, cfg.load_process, mnth)
                    tdf.write.format("delta").mode("append").saveAsTable(temp_table)
                    # log("INFO", f"Loaded {mnth} → stage", table=cfg.table_id)
                # ── 2 & 3. DQ each month, promote only the ones that pass ─────────
                total_rows_written = 0
                for mnth in windows:
                    if mnth in completed_ingested_months:
                        log("INFO", f"Skipping stage load for {mnth} — already staged in prior attempt.")
                        continue
                    dq_passed,mnth_summary = run_ingestion(run_batch_id, cfg, opco, mnth, temp_table)
                    month_summaries.append(mnth_summary)
                # 2. LOG SUCCESS: Updates this attempt's row with the JSON execution summary
                log_end_success(
                    run_batch_id=run_batch_id, cfg=cfg, opco=opco, 
                    load_mnth_start=windows[0], load_mnth_end=windows[-1], 
                    attempt=attempt, started_at=started_at, 
                    rows_read=0, rows_written=total_rows_written, 
                    month_summaries=month_summaries
                )
                
                # Adjusted log message since everything is promoted now
                log("INFO", f"{cfg.table_id}: Execution complete. ")
                
                break # Execution finished without system exceptions, exit retry loop
                # return
                
            except Exception as exc:
                msg = f"{type(exc).__name__}: {exc}\n{traceback.format_exc()}"
                is_last = (attempt == retry_max_attempts)
                log("ERROR", f"Attempt {attempt} failed: {exc}", table_id=cfg.table_id)
                
                # 3. LOG FAILURE: Updates this attempt's row with failure and any partial JSON summary collected
                log_end_failure(
                    run_batch_id=run_batch_id, cfg=cfg, opco=opco, 
                    load_mnth_start=windows[0], load_mnth_end=windows[-1], 
                    attempt=attempt, started_at=started_at, 
                    error_code="UNHANDLED_EXCEPTION", error_message=msg, 
                    is_final=is_last, month_summaries=month_summaries
                )
                
                if is_last:
                    all_ok = False
                    break # Break retry loop, move to the next config table
                    
                log("INFO", f"Retrying in 10s …")
                time.sleep(10)

    return 

# COMMAND ----------

# DBTITLE 1,Halt bookkeeping for tables skipped after an upstream failure
def _halt_downstream(groups: list[tuple[str, str]], ref_date: date, dag_id: str, table_names: Optional[list[str]]):
    for g_opco, g_layer in groups:
        for cfg in read_table_configs(g_opco, g_layer, table_names=table_names):
            run_id = make_run_id(dag_id, cfg.table_id, ref_date, 1)
            log_run(run_id, cfg, ref_date, dag_id, 1, "HALTED",
                    error_code="UPSTREAM_DQ_FAILED",
                    error_message=f"Halted: upstream failed — layer {g_layer} ref={ref_date}")

# COMMAND ----------
# DBTITLE 1,Scope resolution — which (opco, layer) pairs to run
def resolve_groups( opco: str,table_ids: list[int]) -> list[tuple[str, str, list[int]]]:
    """
    Returns:[(opco, layer, [table_ids]), ]
    """
    configs = read_table_configs( table_id=table_id, schedule_group = None )
    if not configs: return []

    table_order = {table_id: idx for idx, table_id in enumerate(table_ids)}
    configs.sort(key=lambda c: table_order[c.table_id])

    grouped = defaultdict(list)
    for config in configs:
        grouped[(config.opco, config.target_dataset_layer)].append(config.table_id)

    layer_order = {
        layer: idx
        for idx, layer in enumerate(LAYER_ORDER)
    }

    return sorted(
        [
            (opco, layer, ids)
            for (opco, layer), ids in grouped.items()
        ],
        key=lambda grp: layer_order.get(grp[1], 99),
    )

# DBTITLE 1,Single entry point — incremental, backfill, or table-scoped, all in one
def run_opco(
    batch_run_id: str, opco: str, 
    table_id:[list[str]],
    start_date: Optional[date] = None, end_date: Optional[date] = None, stage: Optional[str] = "False") -> dict:
 
    groups = resolve_groups(opco, table_id)
    print(groups)
    # return
    
    if not groups:
        log("WARN", "No matching tables for this run", opco=opco)
        return {"opco": opco, "period": "n/a", "mode": "none", "ok": False}

    overall_ok = True
    for i, (g_opco, g_layer,g_table_id) in enumerate(groups):
        log("INFO", "─" * 45)
        log("INFO", f"(opco={g_opco}) Layer: {g_layer} Table_id :(g_table_id)  ")
        run_layer(batch_run_id, g_opco, g_layer, run_date,
                        skip_gate=(i == 0), table_id=g_table_id,
                        start_date =  start_date, end_date  = end_date,stage = stage)


# COMMAND ----------
def _params_from_widgets(dbutils) -> Optional[dict]:
    """
    Read run parameters from Databricks widgets, if `opco` was actually set.
    Returns None (→ caller falls back to run_config.json) when no widget
    values are present, so this notebook works unchanged when triggered
    without parameters.
    """
    try:
        for name, default in [
             ("table_id", ""),("schedule_group", ""),  
             ("start_month", ""), ("end_month", ""), ("stage","False")
        # ("opco", ""),("start_layer", "ACCOUNT"),  ("run_downstream", "True"),
        ]:
            dbutils.widgets.text(name, default)


        table_id = [t.strip() for t in dbutils.widgets.get("table_id").split(",") if t.strip()]
        schedule_group = dbutils.widgets.get("schedule_group").strip()

        if not table_id and not schedule_group:
            return None

        start_month = dbutils.widgets.get("start_month").strip()
        end_month   = dbutils.widgets.get("end_month").strip()

        return {
            "table_id"      :      table_id,
            "schedule_group":      schedule_group or None,
            "start_date"    :      f"{start_month}" if start_month else None,
            "end_date"      :      f"{end_month}"if end_month else None,
            "load_to_stage" :      dbutils.widgets.get("stage").strip() or "False"

            # "start_layer" : dbutils.widgets.get("start_layer").strip() or "ACCOUNT",
            # "run_downstream":   dbutils.widgets.get("run_downstream").strip() or "True",   
        }

    except Exception as e:
        log("WARN", f"Widgets unavailable, falling back to config file: {e}")
        return None

# DBTITLE 1,Summary
def print_summary(results: list[dict], started: "datetime"):
    from datetime import datetime, timezone
    elapsed = (datetime.now(timezone.utc) - started).total_seconds()
    total, passed = len(results), sum(1 for r in results if r["ok"])

    log("INFO", "╔" + "═" * 60 + "╗")
    log("INFO", "║        CDL ETL — GRAND SUMMARY" + " " * 29 + "║")
    log("INFO", f"║  Runs:{total}  Pass:{passed}  Fail:{total-passed}  Elapsed:{elapsed:.0f}s" + " " * 24 + "║")
    log("INFO", "╠" + "═" * 60 + "╣")
    for r in results:
        icon = "✓" if r["ok"] else "✗"
        log("INFO", f"║  {r['opco']:<10}  {r['period']:<25}  {r['mode']:<18}  {icon}  ║")
    log("INFO", "╚" + "═" * 60 + "╝")

# COMMAND ----------
# DBTITLE 1,Entry point

def main() -> bool:
    dbutils = globals().get("dbutils")   
    params = _params_from_widgets(dbutils) if dbutils is not None else None
    # print(params)
    # return
    
    if params:
        log("INFO", "Parameters supplied via widgets — skipping reading from run_config.json")
    else:
        log("INFO", "No widget parameters set — reading config/run_config.json")
        with open(CONFIG_PATH) as f:
            file_cfg = json.load(f)
        params = file_cfg.get('runs',[])[0]
        # run_blocks = [r for r in file_cfg.get("runs", []) if set(r.keys()) != {"_comment"}]

    # print(run_blocks)
    # return
    
    # Creating batch_run_id
    current_time_str       = datetime.now().strftime("%Y%m%d_%H%M%S")
    short_uuid             = uuid.uuid4().hex[:6].upper() 
    batch_run_id           = f"BATCH_{current_time_str}_{short_uuid}_{PIPELINE_CONFIG.environment}"

    results = []

    configs = read_table_configs(table_id=params['table_id'], schedule_group=params['schedule_group'])
    
    if not configs:
        log("WARN", "No configs found — nothing to run")
        return []

    distinct_opcos      = list({c.opco for c in configs})
    distinct_table_id   = list(dict.fromkeys(c.table_id for c in configs if c.table_id))


    # log("INFO", f"Distinct OPCOs from configs: {distinct_opcos}")
    # log("INFO", f"Distinct OPCOs from configs: {distinct_table_id}")

    # print(configs)
    for opco in distinct_opcos:
        results.append(run_opco(     
            batch_run_id   = batch_run_id,
            opco           = opco,
            table_id       = distinct_table_id,
            start_date     = params["start_date"] if params["start_date"] else None,
            end_date       = params["end_date"]   if params["end_date"]  else None,
            stage          = params["stage"]   if params["stage"]  else "False",        
        ))
    print(results)
    # return
    print_summary(results, datetime.now(timezone.utc))
    # return all(r["ok"] for r in results)

if __name__ == "__main__":
    # main()
    pass
