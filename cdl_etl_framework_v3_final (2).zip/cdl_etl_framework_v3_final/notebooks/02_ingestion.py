"""
notebooks/02_ingestion.py
===========================
Writes a transformed DataFrame to a Delta Lake target table for one
(opco, load_mnth) scope:

    1. delete any existing rows for this opco + load_mnth
    2. append the new rows

No MERGE, no merge_keys, no FULL/INCR/CDC branching, no watermark —
every run for a given month fully replaces that month's data, so a plain
delete + append is all that's needed.

Public function:
    run_ingestion(df, cfg, load_mnth, dag_id, run_date) -> bool
"""

import random
import time
import traceback
from datetime import datetime, timezone

from pyspark.sql import DataFrame, SparkSession
from pyspark.sql import functions as F
from delta.tables import DeltaTable

import importlib
import importlib.util

# from config.env_config import get_data_db

# Dynamic import to handle module names starting with digits
_spec = importlib.util.spec_from_file_location(
    '01_framework_core',
    '/Workspace/Users/shubham.jaiswal@fedex.com/MKVW_CDL/CDL/cdl_etl_framework_v3_final/cdl_etl_framework_v3_final/notebooks/01_framework_core.py'
)
_framework_core = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(_framework_core)

TableConfig  = _framework_core.TableConfig
log          = _framework_core.log
log_start    = _framework_core.log_start
log_success  = _framework_core.log_end_success
log_failure  = _framework_core.log_end_failure
run_dq_on_stage = _framework_core.run_dq_on_stage

# from utils.alert_manager import AlertManager

# DATA_DB  = get_data_db()
DATA_DB = 'f6180854'
retry_max_attempts = 2
# _alerter = AlertManager()


# ─────────────────────────────────────────────────────────────────────────────
# Public entry point
# ─────────────────────────────────────────────────────────────────────────────
def run_ingestion(
    run_batch_id:      str,
    cfg:         "TableConfig",
    opco:        str,
    load_mnth:   str,
    temp_table: str,
) -> bool:

    target = f"{DATA_DB}.{cfg.target_table}"
    scope  = f"{cfg.watermark_column} = '{load_mnth}'"

    try:
        dq_passed, dq_message = run_dq_on_stage(
            cfg, opco, load_mnth, temp_table,
            f"{cfg.source_system}.{cfg.source_table}")

        rows_written = _promote_to_target(cfg, target, temp_table, scope)
        summary = {
            "month": load_mnth,
            "dq_status": "PASS" if dq_passed else "FAIL",
            "Loaded": True,
            "rows_written": rows_written,
            "message": dq_message  # e.g.,  or "Duplicate percentage exceeded threshold"
        }
        
        return dq_passed, summary

    except Exception as exc:
        summary = {
            "month": load_mnth,
            "dq_status": "PASS" if dq_passed else "FAIL",
            "Loaded": False,
            "rows_written": 0,
            "message": f"EXCEPTION: {exc}"
        }
        return dq_passed, summary



# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────
def _reset_stage(temp_table: str):
    spark = SparkSession.getActiveSession()
    # if DeltaTable.isDeltaTable(spark, temp_table):
    spark.sql(f"TRUNCATE TABLE {temp_table}")
    log("INFO", f"Truncated {temp_table}")


def _promote_to_target(cfg: "TableConfig", target: str, temp_table: str, scope: str) -> int:
    """Atomic overwrite of just this month's partition in target, from stage."""
    spark = SparkSession.getActiveSession()
    stage_df = spark.table(temp_table).where(scope)
    (stage_df.write.format("delta").mode("overwrite")
        .option("replaceWhere", scope)
        .saveAsTable(target))
    ct = stage_df.count()
    log("INFO", f"Promoted {scope} → {target}: {ct} rows", table=cfg.table_id)
    return ct


# ─────────────────────────────────────────────────────────────────────────────
# Delete + append
# ─────────────────────────────────────────────────────────────────────────────
def _delete_and_append(df: DataFrame, cfg: TableConfig, target: str, load_mnth: str) -> int:
    """
    Delete rows WHERE opco = cfg.opco AND load_mnth = load_mnth, then append
    df. Returns the number of rows appended.
    """
    spark = SparkSession.getActiveSession()
    delete_cond = f"opco = '{cfg.opco}' AND load_mnth = '{load_mnth}'"

    if DeltaTable.isDeltaTable(spark, target):
        DeltaTable.forName(spark, target).delete(delete_cond)
        log("INFO", f"Deleted existing rows → {target} WHERE {delete_cond}")
    else:
        log("INFO", f"{target} doesn't exist yet — first load, nothing to delete")

    df.write.format("delta").mode("append").saveAsTable(target)
    ct = df.count()
    log("INFO", f"Appended {ct} rows → {target}")
    return ct


# ─────────────────────────────────────────────────────────────────────────────
# Metadata columns
# ─────────────────────────────────────────────────────────────────────────────
def _add_meta(df: DataFrame, run_id: str, cfg: TableConfig) -> DataFrame:
    now = datetime.now(timezone.utc).isoformat()
    return (df
        .withColumn("run_id",        F.lit(run_id))
        .withColumn("source_system", F.lit(cfg.source_system))
        .withColumn("created_at",    F.lit(now).cast("timestamp"))
        .withColumn("updated_at",    F.lit(now).cast("timestamp"))
    )
