"""
notebooks/01_framework_core.py
================================
Shared helpers used by all other notebooks.
Kept intentionally simple — plain functions and small classes, no inheritance.

Contains:
  - log(msg)                  : structured print logger
  - read_table_configs()      : reads cdl_table_config for an OPCO + layer
  - check_dq_gate()           : checks upstream DQ passed in run log
  - run_dq()                  : runs inline DQ rules on a DataFrame
  - log_start() / log_success() / log_failure() : write to cdl_table_run_log
  - update_watermark()        : persists watermark back to cdl_table_config
"""

import hashlib
import importlib
import json
import os
from dataclasses import dataclass
from datetime import date, datetime, timezone
from typing import Optional

from pyspark.sql import DataFrame, SparkSession
from pyspark.sql import functions as F
from pyspark.sql.types import (
    StructType, StructField, StringType, IntegerType, LongType,
    TimestampType, DateType,
)
from delta.tables import DeltaTable

# from config.env_config import get_metadata_db

# METADATA_DB = get_metadata_db()
METADATA_DB = 'f6180854'
RUN_LOG_TABLE = 'f6180854.cdl_table_run_log'
_dq_rules_module = None  # loaded lazily, cached after first use


spark = SparkSession.builder.getOrCreate()


# ─────────────────────────────────────────────────────────────────────────────
# Logger — simple structured print
# ─────────────────────────────────────────────────────────────────────────────
def log(level: str, msg: str, **ctx):
    now = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
    extra = "  ".join(f"{k}={v}" for k, v in ctx.items())
    print(f"[{now}] [{level.upper()}]  {msg}  {extra}".strip())


# ─────────────────────────────────────────────────────────────────────────────
# TableConfig — one row from cdl_table_config
# ─────────────────────────────────────────────────────────────────────────────
@dataclass
class TableConfig:
    table_id:             str
    opco:                 str
    target_dataset_layer: str
    source_system:        str
    source_table:         list
    target_system:        str
    target_table:         str
    load_process:         str
    schedule_group:       Optional[str]
    ingestion_mode:       str
    incremental_cutoff_day:       str
    load_frequency:       str
    watermark_column:     Optional[str]
    last_watermark_value: Optional[datetime]
    partition_col:        Optional[str]
    dq_rules:             list
    dq_status:            bool
    is_active:            bool



# ─────────────────────────────────────────────────────────────────────────────
# Read configs from cdl_table_config
# ─────────────────────────────────────────────────────────────────────────────
def read_table_configs(
    table_id: Optional[list[str]] = None,
    schedule_group: Optional[str] = None,
) -> list[TableConfig]:

    clauses = ["is_active = true"]
    if schedule_group:
        # schedule_group takes precedence
        clauses.append(f"schedule_group = '{schedule_group}'")

    elif table_id:
        table_ids = ",".join(f"'{t}'" for t in table_id)
        clauses.append(f"table_id IN ({table_ids})")

    else:
        raise ValueError(
            "Either schedule_group or table_id must be provided."
        )

    where = " AND ".join(clauses)

    rows = spark.sql(
        f"SELECT * FROM f6180854.cdl_table_config WHERE {where}"
    ).collect()

    # Preserve input order only when querying by table_id
    if table_id and not schedule_group:
        order_map = {tid: idx for idx, tid in enumerate(table_id)}
        rows = sorted(rows, key=lambda r: order_map.get(r.table_id, float("inf")))

    log(
        "INFO",
        f"Loaded {len(rows)} config(s)",
        schedule_group=schedule_group,
        table_id=table_id,
    )

    return [_to_config(r) for r in rows]


def _to_config(row) -> TableConfig:
    d = row.asDict()
    def parse_json(v, default):
        if not v:
            return default
        v = v.strip()
        if v.startswith(("[", "{")):
            return json.loads(v)
        return [x.strip() for x in v.split(",") if x.strip()]

    return TableConfig(
        table_id=d["table_id"],
        opco=d["opco"],
        target_dataset_layer=d["target_dataset_layer"],
        source_system=d["source_system"],
        source_table=parse_json(d.get("source_table"), []),
        target_system=d["target_system"],
        target_table=d["target_table"],
        load_process=d["load_process"],
        schedule_group=d.get("schedule_group"),
        ingestion_mode=d["ingestion_mode"],
        incremental_cutoff_day=d["incremental_cutoff_day"],
        load_frequency=d["load_frequency"],
        watermark_column=d.get("watermark_column"),
        last_watermark_value=d.get("last_watermark_value"),
        partition_col=d.get("partition_col"),
        dq_rules=parse_json(d.get("data_quality_rules"), []),
        dq_status=bool(d["dq_status"]),
        is_active=bool(d["is_active"]),
    )

# ─────────────────────────────────────────────────────────────────────────────
# DQ gate — check upstream layer passed before running this layer
# ─────────────────────────────────────────────────────────────────────────────
def check_dq_gate(
    configs: list[TableConfig],
    run_date: date,
    opco: str,
) -> tuple[bool, list[str]]:
    """
    For each config, check all its depends_on table_ids have
    dq_passed = TRUE in today's run log.
    Returns (all_clear, list_of_failed_upstream_ids).
    """
    spark = SparkSession.getActiveSession()
    needed = set()
    for cfg in configs:
        needed.update(cfg.depends_on)

    if not needed:
        return True, []

    ids = ",".join(f"'{x}'" for x in needed)
    rows = spark.sql(f"""
        SELECT dataset_id, MAX(CAST(dq_passed AS INT)) AS ok
        FROM {METADATA_DB}.cdl_table_run_log
        WHERE dag_run_date = '{run_date}'
          AND opco         = '{opco.upper()}'
          AND status       = 'SUCCESS'
          AND dataset_id   IN ({ids})
        GROUP BY dataset_id
    """).collect()

    passed  = {r["dataset_id"] for r in rows if r["ok"] == 1}
    failed  = [x for x in needed if x not in passed]

    if failed:
        log("ERROR", "DQ gate blocked", failed_upstream=str(failed))
        return False, failed
    return True, []


# ─────────────────────────────────────────────────────────────────────────────
# DQ engine — run inline rules, tag rows, return results
# ─────────────────────────────────────────────────────────────────────────────
def run_dq_on_stage(cfg: "TableConfig", opco: str, load_mnth: str,
                     stage_table: str, source_table: str) -> tuple[bool, list[dict]]:
    """
    Run every rule in cfg.dq_rules against (stage_table, source_table) for
    this (opco, load_mnth). Returns (all_rules_passed, per_rule_results).

    Each rule dict looks like {"dq_rule": "dq_net_rev", "error_threshold_pct": 0.0}.
    `dq_rule` is the function name to look up in dq_rules.py; the framework
    calls it and compares its returned diff_pct to error_threshold_pct — the
    rule function itself only measures, it doesn't decide pass/fail.
    """
    source_table = 'f6180854.cdl_testing_table_1_stage'
    global _dq_rules_module
    if _dq_rules_module is None:
        _dq_rules_module = importlib.import_module("dq.dq_rules")

    if not cfg.dq_rules:
        return( True, [])

    # spark = SparkSession.getActiveSession()
    results = []
    overall_ok = True

    if cfg.dq_rules is None or cfg.dq_status is False:
        return True,[{'Either there is not DQ rule or DQ status is inactive'}]

    for rule in cfg.dq_rules:
        rule_name = rule["dq_rule"]
        threshold = float(rule.get("error_threshold_pct", 0.0))
        fn = getattr(_dq_rules_module, rule_name, None)

        if fn is None:
            log("ERROR", f"DQ rule '{rule_name}' not found in dq_rules.py", table=cfg.table_id)
            results.append({"dq_rule": rule_name, "threshold_pct": threshold,
                                "diff_pct": None, "passed": False, "error": "rule not found"})
            overall_ok = False
            continue

        try:
            diff_pct = fn(spark, stage_table, source_table, opco, load_mnth)
            print(diff_pct)
            passed = diff_pct <= threshold
        except Exception as exc:
            log("ERROR", f"DQ rule '{rule_name}' raised: {exc}", table=cfg.table_id)
            diff_pct, passed = None, False

        results.append({"dq_rule": rule_name, "threshold_pct": threshold,
                            "diff_pct": diff_pct, "passed": passed})
        overall_ok = overall_ok and passed

    return overall_ok, results


# ─────────────────────────────────────────────────────────────────────────────
# Run log helpers
# ─────────────────────────────────────────────────────────────────────────────
# ─── Core logger functions ─────────────────────────────────────────────────────

def log_start(
    run_batch_id:    str,
    cfg,                           # TableConfig
    opco:            str,
    load_mnth_start: str,
    load_mnth_end:   str,
    attempt:         int,
    watermark_start: Optional[datetime] = None ) -> datetime:
    """
    Write the initial RUNNING row.
    Returns started_at so the caller can pass it back to log_end_*.
    """
    started_at = datetime.now(timezone.utc)

    row = {
        "run_batch_id":    run_batch_id,
        "log_time":        started_at.isoformat(),
        "opco":            opco,
        "dataset_layer":   cfg.target_dataset_layer,
        "table_name":     cfg.target_table,
        "table_id":        cfg.table_id,
        "load_process":    cfg.load_process,
        "load_mnth_start": load_mnth_start,
        "load_mnth_end":   load_mnth_end,
        "status":          "RUNNING",
        "message":         None,
        "attempt_number":  attempt,
        "watermark_start": watermark_start.isoformat() if watermark_start else None,
        "watermark_end":   None,
        "started_at":      started_at.isoformat(),
        "completed_at":    None,
        "duration_seconds": None,
        "rows_read":       None,
        "rows_written":    None,
        "dq_result":       None,
        "execution_summary":      None,
    }
    _upsert_log(run_batch_id, cfg.table_id, load_mnth_start, attempt, row)
    return started_at


def log_end_success(
    run_batch_id:     str,
    cfg:              "TableConfig",
    opco:             str,
    load_mnth_start:  str,
    load_mnth_end:    str,
    attempt:          int,
    started_at:       datetime,
    rows_read:        int,
    rows_written:     int,
    month_summaries:  list     ) -> None:
    """
    Update row to SUCCESS (or PARTIAL if some months failed DQ).
    All DQ detail is collapsed into dq_result + dq_message.
    """
    now      = datetime.now(timezone.utc)
    duration = int((now - started_at).total_seconds())

    # Use the new JSON builder
    dq_result, execution_summary_json, status = _build_execution_summary(month_summaries)
    row = {
        "run_batch_id":    run_batch_id,
        "log_time":        now.isoformat(),
        "opco":            opco,
        "dataset_layer":   cfg.target_dataset_layer,
        "table_name":      cfg.target_table,
        "table_id":        cfg.table_id,
        "load_process":    cfg.load_process,
        "load_mnth_start": load_mnth_start,
        "load_mnth_end":   load_mnth_end,
        "status":          status,
        "message":         "Completed successfully",
        "attempt_number":  attempt,
        "watermark_start": None,
        "watermark_end":   None,
        "started_at":      started_at.isoformat(),
        "completed_at":    now.isoformat(),
        "duration_seconds": duration,
        "rows_read":       rows_read,
        "rows_written":    rows_written,
        "dq_result":       dq_result,
        "execution_summary":      execution_summary_json,
    }
    _upsert_log(run_batch_id, cfg.table_id, load_mnth_start, attempt, row)

def log_end_failure(
    run_batch_id:    str,
    cfg,
    opco:            str,
    load_mnth_start: str,
    load_mnth_end:   str,
    attempt:         int,
    started_at:      Optional[datetime],
    error_code:      str,
    error_message:   str,
    is_final:        bool = True,
    month_summaries: list = None,  # list[MonthDQSummary] — pass if DQ ran before failure
) -> None:
    """
    Update row to FAILED or RETRYING.
    Optionally includes partial DQ summary if DQ had already run.
    """
    now      = datetime.now(timezone.utc)
    duration = int((now - started_at).total_seconds()) if started_at else 0
    status   = "FAILED" if is_final else "RETRYING"

    dq_result = "SKIPPED"
    execution_summary_json = json.dumps({"error": "DQ did not complete"})
    if month_summaries:
        dq_result, execution_summary_json, _ = _build_execution_summary(month_summaries)

    row = {
        "run_batch_id":    run_batch_id,
        "log_time":        now.isoformat(),
        "opco":            opco,
        "dataset_layer":   cfg.target_dataset_layer,
        "table_name":      cfg.target_table,
        "table_id":        cfg.table_id,
        "load_process":    cfg.load_process,
        "load_mnth_start": load_mnth_start,
        "load_mnth_end":   load_mnth_end,
        "status":          status,
        "message":         f"{error_code}: {error_message[:500]}",
        "attempt_number":  attempt,
        "watermark_start": None,
        "watermark_end":   None,
        "started_at":      started_at.isoformat() if started_at else None,
        "completed_at":    now.isoformat(),
        "duration_seconds": duration,
        "rows_read":       None,
        "rows_written":    None,
        "dq_result":       dq_result,
        "execution_summary": execution_summary_json,
    }
    _upsert_log(run_batch_id, cfg.table_id, load_mnth_start, attempt, row)

# ─── Upsert helper ────────────────────────────────────────────────────────────

# Target schema for cdl_table_run_log — used to build typed DataFrames
_RUN_LOG_TYPES = {
    "run_batch_id":     StringType(),
    "log_time":         TimestampType(),
    "opco":             StringType(),
    "dataset_layer":    StringType(),
    "table_name":       StringType(),
    "table_id":         StringType(),
    "load_process":     StringType(),
    "load_mnth_start":  StringType(),
    "load_mnth_end":    StringType(),
    "status":           StringType(),
    "message":          StringType(),
    "attempt_number":   IntegerType(),
    "watermark_start":  TimestampType(),
    "watermark_end":    TimestampType(),
    "started_at":       TimestampType(),
    "completed_at":     TimestampType(),
    "duration_seconds": IntegerType(),
    "rows_read":        LongType(),
    "rows_written":     LongType(),
    "dq_result":        StringType(),
    "execution_summary": StringType(),
}


def _upsert_log(
    run_batch_id:    str,
    table_id:        str,
    load_mnth_start: str,
    attempt:         int,
    row:             dict,
) -> None:
    """
    MERGE on (run_batch_id, table_id, load_mnth_start, attempt_number).
    First call inserts (RUNNING). Subsequent calls update in place.
    Sink failures are non-fatal — logged to stdout only.
    """
    spark = SparkSession.getActiveSession()
    try:
        # Build schema: use StringType for all columns initially to avoid
        # CANNOT_DETERMINE_TYPE errors when values are None.
        str_schema = StructType([
            StructField(k, StringType(), True) for k in row
        ])
        # Convert all values to strings (None stays None)
        str_row = {k: (str(v) if v is not None else None) for k, v in row.items()}
        df = spark.createDataFrame([str_row], schema=str_schema)

        # Cast each column to the target table's actual type
        for col_name in df.columns:
            target_type = _RUN_LOG_TYPES.get(col_name)
            if target_type and not isinstance(target_type, StringType):
                df = df.withColumn(col_name, F.col(col_name).cast(target_type))

        (
            DeltaTable
            .forName(spark, RUN_LOG_TABLE)
            .alias("t")
            .merge(
                df.alias("s"),
                """t.run_batch_id    = s.run_batch_id
               AND t.table_id      = s.table_id
               AND t.load_mnth_start = s.load_mnth_start
               AND t.attempt_number  = s.attempt_number""",
            )
            .whenMatchedUpdateAll()
            .whenNotMatchedInsertAll()
            .execute()
        )
    except Exception as e:
        print(f"[WARN] _upsert_log failed (non-fatal): {e}")

def _build_execution_summary(month_summaries: list) -> tuple[str, str, str]:
    """
    Returns: (dq_result_status, execution_summary_json, pipeline_status)
    """
    if not month_summaries:
        return "N/A", json.dumps({"month_details": []}), "RUNNING"
        
    good_months = [s["month"] for s in month_summaries if s["dq_status"] == "PASS"]
    bad_months = [s["month"] for s in month_summaries if s["dq_status"] == "FAIL"]
    
    # Construct the exact JSON structure requested
    execution_summary_dict = {
        "month_details": month_summaries
    }
    
    # Convert to JSON string (indent=2 for pretty formatting in the DB, optional)
    execution_summary_json = json.dumps(execution_summary_dict, indent=2)
    
    # Determine overall status
    if not bad_months:
        return "PASS", execution_summary_json, "SUCCESS"
    elif good_months:
        return "PARTIAL", execution_summary_json, "PARTIAL_SUCCESS"
    else:
        return "FAIL", execution_summary_json, "FAILED"


# ─────────────────────────────────────────────────────────────────────────────
# Watermark — persisted back into cdl_table_config
# ─────────────────────────────────────────────────────────────────────────────
# def update_watermark(table_id: str, new_value: datetime, run_date: date):
#     spark = SparkSession.getActiveSession()
#     now = datetime.now(timezone.utc).isoformat()
#     spark.sql(f"""
#         UPDATE {METADATA_DB}.cdl_table_config
#         SET last_watermark_value = '{new_value.isoformat()}',
#             last_successful_run  = '{run_date}',
#             updated_at           = '{now}'
#         WHERE table_id = '{table_id}'
#     """)
#     log("INFO", f"Watermark updated → {new_value}", table_id=table_id)
