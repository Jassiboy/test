"""
cdl_etl_framework/dags/cdl_master_dag.py
=========================================
Airflow DAG — CDL pipeline with DQ-gated layer progression.
All config (retry, alerts, DQ rules, dependency) lives in cdl_table_config.

Topology:
  account_daily ──┐
  account_monthly ─┤─► dq_gate_facility ─► facility_daily ──┐
                                            facility_monthly ─┤─► dq_gate_country ─► country_daily ──┐
                                                                                      country_monthly ─┤─► dq_gate_global ─► global_daily
                                                                                                                              global_monthly

Deploy : cp dags/cdl_master_dag.py $AIRFLOW_HOME/dags/
Trigger: airflow dags trigger cdl_master_pipeline \
             --conf '{"opco":"GROUND","run_date":"2024-01-15","env":"azure"}'
"""

from __future__ import annotations

from datetime import datetime, timedelta

from airflow import DAG
from airflow.operators.python import PythonOperator, BranchPythonOperator
from airflow.operators.empty import EmptyOperator
from airflow.utils.trigger_rule import TriggerRule

DEFAULT_ARGS = {
    "owner":             "cdl-data-engineering",
    "depends_on_past":   False,
    "email":             ["cdl-alerts@company.com"],
    "email_on_failure":  True,
    "email_on_retry":    False,
    "retries":           0,          # retries handled inside IngestionEngine
    "execution_timeout": timedelta(hours=4),
}


# ---------------------------------------------------------------------------
# Callable helpers
# ---------------------------------------------------------------------------
def _run_layer(opco, layer, frequency, env, run_date, dag_id, **ctx):
    """PythonOperator callable — runs one layer via PipelineRunner."""
    import os, sys
    sys.path.insert(0, os.getenv("CDL_FRAMEWORK_PATH", "/opt/cdl_etl_framework"))
    os.environ["CDL_ENV"] = env

    from datetime import date
    from notebooks.04_pipeline_runner import PipelineRunner, build_spark

    spark   = build_spark(env)
    runner  = PipelineRunner(
        spark=spark, opco=opco, run_date=date.fromisoformat(run_date),
        dag_id=dag_id, target_layer=layer, frequency=frequency,
    )
    success = runner.run()
    ctx["ti"].xcom_push(key=f"{layer}_ok", value=success)
    return "success" if success else "failure"


def _dq_gate(upstream_layer, pass_task, halt_task, **ctx):
    """BranchPythonOperator — reads XCom from upstream layer task."""
    ok = ctx["ti"].xcom_pull(key=f"{upstream_layer}_ok")
    return pass_task if ok else halt_task


# ---------------------------------------------------------------------------
# DAG
# ---------------------------------------------------------------------------
with DAG(
    dag_id="cdl_master_pipeline",
    description="CDL Metadata-Driven ETL: Account → Facility → Country → Global",
    default_args=DEFAULT_ARGS,
    schedule_interval="0 3 * * *",
    start_date=datetime(2024, 1, 1),
    catchup=False,
    max_active_runs=1,
    tags=["cdl", "etl", "medallion"],
    params={"opco": "GROUND", "run_date": "{{ ds }}", "env": "azure"},
    render_template_as_native_obj=True,
) as dag:

    def layer_op(layer: str, frequency: str) -> PythonOperator:
        return PythonOperator(
            task_id=f"run_{layer.lower()}_{frequency.lower()}",
            python_callable=_run_layer,
            op_kwargs={
                "opco":      "{{ params.opco }}",
                "layer":     layer,
                "frequency": frequency,
                "env":       "{{ params.env }}",
                "run_date":  "{{ params.run_date }}",
                "dag_id":    "cdl_master_pipeline",
            },
            provide_context=True,
        )

    def gate_op(upstream: str, pass_tid: str, halt_tid: str) -> BranchPythonOperator:
        return BranchPythonOperator(
            task_id=f"dq_gate_{upstream.lower()}_to_{pass_tid.split('_')[1]}",
            python_callable=_dq_gate,
            op_kwargs={"upstream_layer": upstream,
                       "pass_task": pass_tid, "halt_task": f"halt_{pass_tid.split('_')[1]}"},
            provide_context=True,
            trigger_rule=TriggerRule.ALL_SUCCESS,
        )

    # ── Sentinels ─────────────────────────────────────────────────────────
    start = EmptyOperator(task_id="pipeline_start")
    end   = EmptyOperator(task_id="pipeline_end", trigger_rule=TriggerRule.ALL_DONE)

    # ── Account ───────────────────────────────────────────────────────────
    acc_daily   = layer_op("ACCOUNT",  "DAILY")
    acc_monthly = layer_op("ACCOUNT",  "MONTHLY")

    # ── Gate → Facility ───────────────────────────────────────────────────
    gate_fac     = gate_op("ACCOUNT",  "run_facility_daily", "halt_facility")
    halt_fac     = EmptyOperator(task_id="halt_facility")
    fac_daily    = layer_op("FACILITY", "DAILY")
    fac_monthly  = layer_op("FACILITY", "MONTHLY")

    # ── Gate → Country ────────────────────────────────────────────────────
    gate_cntry   = gate_op("FACILITY", "run_country_daily", "halt_country")
    halt_cntry   = EmptyOperator(task_id="halt_country")
    cntry_daily  = layer_op("COUNTRY",  "DAILY")
    cntry_monthly= layer_op("COUNTRY",  "MONTHLY")

    # ── Gate → Global ─────────────────────────────────────────────────────
    gate_global  = gate_op("COUNTRY",  "run_global_daily", "halt_global")
    halt_global  = EmptyOperator(task_id="halt_global")
    glb_daily    = layer_op("GLOBAL",   "DAILY")
    glb_monthly  = layer_op("GLOBAL",   "MONTHLY")

    # ── Dependency graph ──────────────────────────────────────────────────
    start >> [acc_daily, acc_monthly] >> gate_fac
    gate_fac >> halt_fac >> end
    gate_fac >> fac_daily >> fac_monthly >> gate_cntry
    gate_cntry >> halt_cntry >> end
    gate_cntry >> cntry_daily >> cntry_monthly >> gate_global
    gate_global >> halt_global >> end
    gate_global >> glb_daily >> glb_monthly >> end
