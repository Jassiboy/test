"""
cdl_etl_framework/tests/test_framework.py
==========================================
Full test suite for the 2-table design.
Run: pytest tests/test_framework.py -v

Covers:
  - DQEngine  : NOT_NULL, RANGE, ROW_COUNT, tag_rows, overall pass/fail
  - MetadataManager : config loading, dependency gate, watermark update
  - RunLogger : run_id generation
  - Transformer registry
  - Retry handler
"""

import json
import pytest
from datetime import date
from unittest.mock import MagicMock, patch


# ===========================================================================
# Shared fixtures
# ===========================================================================
@pytest.fixture(scope="session")
def spark():
    from pyspark.sql import SparkSession
    s = (SparkSession.builder
         .master("local[2]")
         .appName("cdl_test")
         .config("spark.sql.extensions",
                 "io.delta.sql.DeltaSparkSessionExtension")
         .config("spark.sql.catalog.spark_catalog",
                 "org.apache.spark.sql.delta.catalog.DeltaCatalog")
         .config("spark.sql.shuffle.partitions", "2")
         .getOrCreate())
    s.sparkContext.setLogLevel("ERROR")
    return s


@pytest.fixture
def logger(spark):
    from notebooks.01_framework_core import CDLLogger
    return CDLLogger("test", run_id="r1", opco="GROUND", layer="ACCOUNT")


@pytest.fixture
def base_cfg():
    from notebooks.01_framework_core import TableConfig
    return TableConfig(
        table_id="ground_account_daily",
        source_system="ACCOUNT_DB",
        source_table_name="raw_account_transactions",
        source_filter=None,
        target_system="DELTA_LAKE",
        target_table_name="account_daily",
        target_dataset_layer="ACCOUNT",
        opco="GROUND",
        ingestion_mode="INCR",
        load_frequency="DAILY",
        watermark_column="last_modified_ts",
        last_watermark_value=None,
        partition_col="load_date",
        merge_keys="account_id,opco,effective_date",
        data_quality_rules=[
            {"rule_id": "not_null_account_id", "rule_type": "NOT_NULL",
             "target_column": "account_id",
             "rule_expression": "account_id IS NOT NULL",
             "severity": "CRITICAL", "error_threshold_pct": 0.0},
            {"rule_id": "non_neg_revenue", "rule_type": "RANGE",
             "target_column": "revenue",
             "rule_expression": "revenue >= 0",
             "severity": "WARNING", "error_threshold_pct": 1.0},
        ],
        dq_threshold_pct=95.0,
        depends_on_table_ids=[],
        retry_max_attempts=3,
        retry_initial_wait_sec=1,
        retry_backoff_multiplier=2.0,
        retry_max_wait_sec=5,
        alert_config=[],
        is_active=True,
    )


def make_df(spark, rows, schema):
    return spark.createDataFrame(rows, schema)


# ===========================================================================
# DQEngine tests
# ===========================================================================
class TestDQEngine:

    # ── NOT_NULL ─────────────────────────────────────────────────────────
    def test_not_null_all_pass(self, spark, logger, base_cfg):
        from notebooks.01_framework_core import DQEngine
        df = make_df(spark, [("A1","GROUND",100.0),("A2","GROUND",200.0)],
                     "account_id STRING, opco STRING, revenue DOUBLE")
        eng = DQEngine(spark, logger)
        results, overall = eng.run(df, base_cfg)
        assert overall is True
        assert all(r.passed for r in results if r.severity == "CRITICAL")

    def test_not_null_critical_fails_overall(self, spark, logger, base_cfg):
        from notebooks.01_framework_core import DQEngine
        df = make_df(spark, [(None,"GROUND",100.0),("A2","GROUND",200.0)],
                     "account_id STRING, opco STRING, revenue DOUBLE")
        eng = DQEngine(spark, logger)
        results, overall = eng.run(df, base_cfg)
        assert overall is False
        crit = [r for r in results if r.rule_id == "not_null_account_id"][0]
        assert crit.passed is False
        assert crit.rows_failed == 1

    def test_warning_failure_does_not_fail_overall(self, spark, logger, base_cfg):
        from notebooks.01_framework_core import DQEngine
        # All account_ids present (CRITICAL OK), one negative revenue (WARNING)
        df = make_df(spark, [("A1","GROUND",-50.0),("A2","GROUND",200.0)],
                     "account_id STRING, opco STRING, revenue DOUBLE")
        eng = DQEngine(spark, logger)
        results, overall = eng.run(df, base_cfg)
        # CRITICAL rule passes → overall True despite WARNING failure
        assert overall is True
        warn = [r for r in results if r.rule_id == "non_neg_revenue"][0]
        assert warn.passed is False

    # ── ROW_COUNT ─────────────────────────────────────────────────────────
    def test_row_count_pass(self, spark, logger):
        from notebooks.01_framework_core import DQEngine, TableConfig
        cfg = TableConfig(
            table_id="t", source_system="S", source_table_name="s",
            source_filter=None, target_system="T", target_table_name="t",
            target_dataset_layer="ACCOUNT", opco="GROUND",
            ingestion_mode="FULL", load_frequency="DAILY",
            watermark_column=None, last_watermark_value=None,
            partition_col=None, merge_keys=None,
            data_quality_rules=[
                {"rule_id": "row_min", "rule_type": "ROW_COUNT",
                 "target_column": None,
                 "rule_expression": '{"min_rows": 1}',
                 "severity": "CRITICAL", "error_threshold_pct": 0.0}
            ],
            dq_threshold_pct=95.0, depends_on_table_ids=[],
            retry_max_attempts=3, retry_initial_wait_sec=1,
            retry_backoff_multiplier=2.0, retry_max_wait_sec=5,
            alert_config=[], is_active=True,
        )
        df  = make_df(spark, [("A1",)], "account_id STRING")
        eng = DQEngine(spark, logger)
        results, overall = eng.run(df, cfg)
        assert overall is True
        assert results[0].passed is True

    def test_row_count_fail_empty_df(self, spark, logger):
        from notebooks.01_framework_core import DQEngine, TableConfig
        from pyspark.sql.types import StructType, StructField, StringType
        cfg = TableConfig(
            table_id="t", source_system="S", source_table_name="s",
            source_filter=None, target_system="T", target_table_name="t",
            target_dataset_layer="ACCOUNT", opco="GROUND",
            ingestion_mode="FULL", load_frequency="DAILY",
            watermark_column=None, last_watermark_value=None,
            partition_col=None, merge_keys=None,
            data_quality_rules=[
                {"rule_id": "row_min", "rule_type": "ROW_COUNT",
                 "target_column": None,
                 "rule_expression": '{"min_rows": 1}',
                 "severity": "CRITICAL", "error_threshold_pct": 0.0}
            ],
            dq_threshold_pct=95.0, depends_on_table_ids=[],
            retry_max_attempts=3, retry_initial_wait_sec=1,
            retry_backoff_multiplier=2.0, retry_max_wait_sec=5,
            alert_config=[], is_active=True,
        )
        schema = StructType([StructField("account_id", StringType(), True)])
        df     = spark.createDataFrame([], schema)
        eng    = DQEngine(spark, logger)
        results, overall = eng.run(df, cfg)
        assert overall is False

    # ── tag_rows ─────────────────────────────────────────────────────────
    def test_tag_rows_marks_failures(self, spark, logger, base_cfg):
        from notebooks.01_framework_core import DQEngine
        df  = make_df(spark, [(None,"GROUND",100.0),("A2","GROUND",200.0)],
                      "account_id STRING, opco STRING, revenue DOUBLE")
        eng = DQEngine(spark, logger)
        tagged = eng.tag_rows(df, base_cfg.data_quality_rules)
        results = {r["account_id"]: r["dq_passed"]
                   for r in tagged.collect()}
        assert results["A2"] is True
        assert results[None] is False

    # ── threshold ────────────────────────────────────────────────────────
    def test_threshold_blocks_overall(self, spark, logger):
        from notebooks.01_framework_core import DQEngine, TableConfig
        cfg = TableConfig(
            table_id="t", source_system="S", source_table_name="s",
            source_filter=None, target_system="T", target_table_name="t",
            target_dataset_layer="ACCOUNT", opco="GROUND",
            ingestion_mode="FULL", load_frequency="DAILY",
            watermark_column=None, last_watermark_value=None,
            partition_col=None, merge_keys=None,
            data_quality_rules=[
                {"rule_id": "not_null_id", "rule_type": "NOT_NULL",
                 "target_column": "account_id",
                 "rule_expression": "account_id IS NOT NULL",
                 "severity": "CRITICAL", "error_threshold_pct": 0.0}
            ],
            dq_threshold_pct=99.0,   # very high threshold
            depends_on_table_ids=[],
            retry_max_attempts=3, retry_initial_wait_sec=1,
            retry_backoff_multiplier=2.0, retry_max_wait_sec=5,
            alert_config=[], is_active=True,
        )
        # 50% null → fails 99% threshold
        df = make_df(spark, [(None,),(None,),("A3",),("A4",)], "account_id STRING")
        eng = DQEngine(spark, logger)
        _, overall = eng.run(df, cfg)
        assert overall is False


# ===========================================================================
# MetadataManager tests  (mocked Spark SQL)
# ===========================================================================
class TestMetadataManager:

    def _mock_spark(self, row_dict: dict):
        row = MagicMock()
        row.asDict.return_value = row_dict
        spark = MagicMock()
        spark.sql.return_value.collect.return_value = [row]
        return spark

    def test_parse_row_full(self):
        from notebooks.01_framework_core import MetadataManager
        spark = self._mock_spark({
            "table_id": "ground_account_daily",
            "source_system": "ACCOUNT_DB",
            "source_table_name": "raw_t",
            "source_filter": None,
            "target_system": "DELTA_LAKE",
            "target_table_name": "account_daily",
            "target_dataset_layer": "ACCOUNT",
            "opco": "GROUND",
            "ingestion_mode": "INCR",
            "load_frequency": "DAILY",
            "watermark_column": "last_modified_ts",
            "last_watermark_value": None,
            "partition_col": "load_date",
            "merge_keys": "account_id,opco,effective_date",
            "data_quality_rules": json.dumps([
                {"rule_id": "not_null_account_id", "rule_type": "NOT_NULL",
                 "target_column": "account_id",
                 "rule_expression": "account_id IS NOT NULL",
                 "severity": "CRITICAL", "error_threshold_pct": 0.0}
            ]),
            "dq_threshold_pct": 95.0,
            "depends_on_table_ids": None,
            "retry_max_attempts": 3, "retry_initial_wait_sec": 30,
            "retry_backoff_multiplier": 2.0, "retry_max_wait_sec": 300,
            "alert_config": json.dumps([
                {"channel": "EMAIL", "recipients": "a@b.com", "on_status": ["FAILED"]}
            ]),
            "is_active": True,
        })
        mgr     = MetadataManager(spark, "GROUND", date(2024, 1, 15))
        configs = mgr.get_table_configs(layer="ACCOUNT")
        assert len(configs) == 1
        cfg = configs[0]
        assert cfg.table_id == "ground_account_daily"
        assert len(cfg.data_quality_rules) == 1
        assert cfg.depends_on_table_ids == []
        assert cfg.alert_config[0]["channel"] == "EMAIL"
        assert cfg.retry_max_attempts == 3

    def test_null_dq_rules_returns_empty_list(self):
        from notebooks.01_framework_core import MetadataManager
        spark = self._mock_spark({
            "table_id": "t", "source_system": "S", "source_table_name": "s",
            "source_filter": None, "target_system": "T",
            "target_table_name": "t", "target_dataset_layer": "GLOBAL",
            "opco": "GROUND", "ingestion_mode": "FULL", "load_frequency": "DAILY",
            "watermark_column": None, "last_watermark_value": None,
            "partition_col": None, "merge_keys": None,
            "data_quality_rules": None,          # NULL in DB
            "dq_threshold_pct": 99.0,
            "depends_on_table_ids": None,
            "retry_max_attempts": 3, "retry_initial_wait_sec": 30,
            "retry_backoff_multiplier": 2.0, "retry_max_wait_sec": 300,
            "alert_config": None,
            "is_active": True,
        })
        mgr     = MetadataManager(spark, "GROUND", date(2024, 1, 15))
        configs = mgr.get_table_configs()
        assert configs[0].data_quality_rules == []
        assert configs[0].alert_config == []

    def test_dependency_gate_all_pass(self):
        from notebooks.01_framework_core import MetadataManager, TableConfig
        row = MagicMock()
        row.__getitem__ = lambda s, k: {"dataset_id": "ground_account_daily", "dq_ok": 1}[k]
        spark = MagicMock()
        spark.sql.return_value.collect.return_value = [row]

        mgr = MetadataManager(spark, "GROUND", date(2024, 1, 15))
        cfg = MagicMock()
        cfg.depends_on_table_ids = ["ground_account_daily"]
        ok, failed = mgr.check_upstream_dq_passed([cfg])
        assert ok is True
        assert failed == []

    def test_dependency_gate_upstream_missing(self):
        from notebooks.01_framework_core import MetadataManager
        spark = MagicMock()
        spark.sql.return_value.collect.return_value = []   # no SUCCESS rows in log

        mgr = MetadataManager(spark, "GROUND", date(2024, 1, 15))
        cfg = MagicMock()
        cfg.depends_on_table_ids = ["ground_account_daily"]
        ok, failed = mgr.check_upstream_dq_passed([cfg])
        assert ok is False
        assert "ground_account_daily" in failed

    def test_no_dependencies_always_pass(self):
        from notebooks.01_framework_core import MetadataManager
        spark = MagicMock()
        mgr   = MetadataManager(spark, "GROUND", date(2024, 1, 15))
        cfg   = MagicMock()
        cfg.depends_on_table_ids = []
        ok, failed = mgr.check_upstream_dq_passed([cfg])
        assert ok is True


# ===========================================================================
# RunLogger tests
# ===========================================================================
class TestRunLogger:

    def test_run_id_deterministic(self):
        from notebooks.01_framework_core import RunLogger
        r1 = RunLogger.make_run_id("dag", "task", date(2024, 1, 15), 1)
        r2 = RunLogger.make_run_id("dag", "task", date(2024, 1, 15), 1)
        assert r1 == r2

    def test_run_id_differs_by_attempt(self):
        from notebooks.01_framework_core import RunLogger
        r1 = RunLogger.make_run_id("dag", "task", date(2024, 1, 15), 1)
        r2 = RunLogger.make_run_id("dag", "task", date(2024, 1, 15), 2)
        assert r1 != r2

    def test_run_id_is_32_hex_chars(self):
        from notebooks.01_framework_core import RunLogger
        rid = RunLogger.make_run_id("dag", "task", date(2024, 1, 15), 1)
        assert len(rid) == 32
        assert all(c in "0123456789abcdef" for c in rid)


# ===========================================================================
# Transformer registry tests
# ===========================================================================
class TestTransformerRegistry:

    def test_all_four_layers_registered(self):
        from notebooks.03_transformation import TRANSFORMER_REGISTRY
        for layer in ["ACCOUNT", "FACILITY", "COUNTRY", "GLOBAL"]:
            assert layer in TRANSFORMER_REGISTRY, f"Missing: {layer}"

    def test_factory_returns_correct_types(self):
        from notebooks.03_transformation import (
            get_transformer, AccountTransformer, FacilityTransformer,
            CountryTransformer, GlobalTransformer,
        )
        spark = MagicMock()
        rd    = date(2024, 1, 15)
        assert isinstance(get_transformer("ACCOUNT",  spark, rd, "GROUND"), AccountTransformer)
        assert isinstance(get_transformer("FACILITY", spark, rd, "GROUND"), FacilityTransformer)
        assert isinstance(get_transformer("COUNTRY",  spark, rd, "GROUND"), CountryTransformer)
        assert isinstance(get_transformer("GLOBAL",   spark, rd, "GROUND"), GlobalTransformer)

    def test_case_insensitive(self):
        from notebooks.03_transformation import get_transformer, AccountTransformer
        spark = MagicMock()
        assert isinstance(get_transformer("account", spark, date(2024,1,1), "GROUND"),
                          AccountTransformer)

    def test_unknown_layer_raises(self):
        from notebooks.03_transformation import get_transformer
        with pytest.raises(ValueError, match="No transformer"):
            get_transformer("BRONZE", MagicMock(), date(2024, 1, 1), "GROUND")


# ===========================================================================
# Retry handler tests
# ===========================================================================
class TestRetryHandler:

    def test_success_first_attempt(self):
        from utils.retry_handler import with_retry
        calls = {"n": 0}
        @with_retry(max_attempts=3, initial_wait=0.01)
        def fn():
            calls["n"] += 1
            return "ok"
        assert fn() == "ok"
        assert calls["n"] == 1

    def test_retries_then_succeeds(self):
        from utils.retry_handler import with_retry
        calls = {"n": 0}
        @with_retry(max_attempts=3, initial_wait=0.01, backoff_multiplier=1.0)
        def fn():
            calls["n"] += 1
            if calls["n"] < 3:
                raise RuntimeError("transient")
            return "ok"
        assert fn() == "ok"
        assert calls["n"] == 3

    def test_raises_after_max_attempts(self):
        from utils.retry_handler import with_retry
        calls = {"n": 0}
        @with_retry(max_attempts=2, initial_wait=0.01, backoff_multiplier=1.0)
        def fn():
            calls["n"] += 1
            raise ValueError("permanent")
        with pytest.raises(ValueError, match="permanent"):
            fn()
        assert calls["n"] == 2

    def test_backoff_caps_at_max(self):
        from utils.retry_handler import _wait
        w = _wait(10, 30.0, 2.0, 300.0, 0.0)
        assert w == 300.0

    def test_backoff_grows_exponentially(self):
        from utils.retry_handler import _wait
        w1 = _wait(1, 30.0, 2.0, 9999.0, 0.0)
        w2 = _wait(2, 30.0, 2.0, 9999.0, 0.0)
        w3 = _wait(3, 30.0, 2.0, 9999.0, 0.0)
        assert abs(w1 - 30.0) < 0.01
        assert abs(w2 - 60.0) < 0.01
        assert abs(w3 - 120.0) < 0.01
