# CDL Metadata-Driven ETL Framework  (2-Table Design)

## Overview

Production-ready, metadata-driven ETL framework on **Azure Databricks + Delta Lake + ADLS Gen2**, portable to **GCP Dataproc + BigQuery + GCS**.

Implements the **Medallion Architecture** across four transformation layers:

```
Account (Bronze) → Facility (Silver) → Country (Silver+) → Global (Gold)
```

Each layer has a **Daily** and **Monthly** table. A downstream layer executes only after the upstream layer's Data Quality checks pass.

### Key design decision — 2 control tables only

All framework behaviour — DQ rules, retry policy, alert routing, watermark state, and dependency gates — is encoded **directly in `cdl_table_config`**. No separate lookup tables.

| What | Where it lives |
|------|---------------|
| DQ rules | `cdl_table_config.data_quality_rules` (JSON array) |
| Retry policy | `cdl_table_config.retry_*` columns |
| Alert routing | `cdl_table_config.alert_config` (JSON array) |
| Watermark state | `cdl_table_config.last_watermark_value` (updated in-place) |
| Dependency gate | `cdl_table_config.depends_on_table_ids` (comma-separated) |
| Execution audit | `cdl_table_run_log` (one row per task attempt) |

---

## Project Structure

```
cdl_etl_framework/
│
├── README.md
│
├── ddl/
│   ├── azure/
│   │   ├── 01_control_tables.sql   ← cdl_table_config + cdl_table_run_log (Delta)
│   │   └── 02_data_tables.sql      ← 8 pipeline tables (Delta)
│   └── gcp/
│       ├── 01_control_tables.sql   ← same 2 tables (BigQuery syntax)
│       └── 02_data_tables.sql      ← 8 pipeline tables (BigQuery syntax)
│
├── config/
│   ├── env_config.py               ← Azure/GCP config, switches on CDL_ENV
│   └── seed_metadata.py            ← Seeds cdl_table_config for one OPCO
│
├── notebooks/
│   ├── 01_framework_core.py        ← CDLLogger, MetadataManager, RunLogger, DQEngine
│   ├── 02_ingestion.py             ← Generic FULL/INCR/CDC ingestion engine
│   ├── 03_transformation.py        ← All 4 layer transformers + registry
│   └── 04_pipeline_runner.py       ← End-to-end orchestration entry point
│
├── utils/
│   ├── alert_manager.py            ← Email / Teams / Slack (config from TableConfig)
│   ├── cloud_adapter.py            ← ADLS/GCS/JDBC/BigQuery abstraction
│   └── retry_handler.py            ← Exponential backoff decorator + Delta rollback
│
├── dags/
│   └── cdl_master_dag.py           ← Airflow DAG with BranchOperator DQ gates
│
├── init_scripts/
│   ├── cluster_init_azure.sh       ← Databricks cluster init
│   └── cluster_init_gcp.sh         ← Dataproc cluster init
│
└── tests/
    └── test_framework.py           ← Full test suite (30+ tests)
```

---

## cdl_table_config — Column Reference

| Column | Type | Purpose |
|--------|------|---------|
| `table_id` | STRING | Unique mapping ID e.g. `ground_account_daily` |
| `source_system` | STRING | `ACCOUNT_DB` \| `DELTA_LAKE` \| `ORACLE` \| `EDW` \| `SQL_SERVER` |
| `source_table_name` | STRING | Physical source table name |
| `source_filter` | STRING | Optional SQL WHERE clause applied at read time |
| `target_system` | STRING | `DELTA_LAKE` \| `BIGQUERY` |
| `target_table_name` | STRING | Physical target table name |
| `target_dataset_layer` | STRING | `ACCOUNT` \| `FACILITY` \| `COUNTRY` \| `GLOBAL` |
| `opco` | STRING | `GROUND` \| `FREIGHT` \| `INTERNATIONAL` |
| `ingestion_mode` | STRING | `FULL` \| `INCR` \| `CDC` |
| `load_frequency` | STRING | `DAILY` \| `MONTHLY` \| `BOTH` |
| `watermark_column` | STRING | Column for incremental tracking e.g. `last_modified_ts` |
| `last_watermark_value` | TIMESTAMP | **Persisted watermark** — updated after each INCR run |
| `last_successful_run` | DATE | Date of last successful run |
| `partition_col` | STRING | Target partition column e.g. `load_date` |
| `merge_keys` | STRING | Comma-separated PK for MERGE e.g. `account_id,opco,effective_date` |
| `data_quality_rules` | STRING | **JSON array of DQ rule objects** (see below) |
| `dq_threshold_pct` | DOUBLE | Min % CRITICAL-passing rows to unblock downstream (0–100) |
| `depends_on_table_ids` | STRING | Comma-separated upstream `table_id`s that must DQ-pass first |
| `retry_max_attempts` | INT | Total attempts including first try |
| `retry_initial_wait_sec` | INT | Seconds before first retry |
| `retry_backoff_multiplier` | DOUBLE | Exponential multiplier per retry |
| `retry_max_wait_sec` | INT | Max wait cap between retries |
| `alert_config` | STRING | **JSON array of alert channel objects** (see below) |
| `is_active` | BOOLEAN | Enable/disable this mapping |

### data_quality_rules JSON schema

```json
[
  {
    "rule_id":             "not_null_account_id",
    "rule_type":           "NOT_NULL",
    "target_column":       "account_id",
    "rule_expression":     "account_id IS NOT NULL",
    "severity":            "CRITICAL",
    "error_threshold_pct": 0.0
  }
]
```

`rule_type` values: `NOT_NULL` | `RANGE` | `REGEX` | `CUSTOM_SQL` | `ROW_COUNT` | `UNIQUENESS`  
`severity` values: `CRITICAL` (blocks downstream) | `WARNING` | `INFO`

### alert_config JSON schema

```json
[
  {
    "channel":    "EMAIL",
    "recipients": "oncall@company.com,lead@company.com",
    "on_status":  ["FAILED", "HALTED"]
  },
  {
    "channel":    "TEAMS",
    "recipients": "https://company.webhook.office.com/...",
    "on_status":  ["FAILED"]
  }
]
```

---

## Quick Start

### 1. Create tables

```sql
-- Azure Databricks
%run ddl/azure/01_control_tables
%run ddl/azure/02_data_tables
```

### 2. Seed metadata

```bash
python config/seed_metadata.py --env azure --opco GROUND
```

### 3. Run pipeline

```bash
# Full pipeline — all layers
python notebooks/04_pipeline_runner.py \
  --opco GROUND --run_date 2024-01-15 --env azure

# Single layer
python notebooks/04_pipeline_runner.py \
  --opco GROUND --run_date 2024-01-15 --env azure --layer FACILITY

# Monthly only
python notebooks/04_pipeline_runner.py \
  --opco GROUND --run_date 2024-01-15 --env azure --frequency MONTHLY
```

### 4. Deploy Airflow DAG

```bash
cp dags/cdl_master_dag.py $AIRFLOW_HOME/dags/
airflow dags trigger cdl_master_pipeline \
  --conf '{"opco":"GROUND","run_date":"2024-01-15","env":"azure"}'
```

---

## Adding a New OPCO

Zero code changes. Insert rows into `cdl_table_config`:

```sql
INSERT INTO cdl_metadata.cdl_table_config
SELECT
    REPLACE(table_id, 'ground_', 'freight_')    AS table_id,
    source_system, source_table_name, source_filter,
    target_system, target_table_name, target_dataset_layer,
    'FREIGHT'                                    AS opco,
    ingestion_mode, load_frequency,
    watermark_column, NULL AS last_watermark_value, NULL AS last_successful_run,
    partition_col, merge_keys, data_quality_rules, dq_threshold_pct,
    REPLACE(depends_on_table_ids, 'ground_', 'freight_') AS depends_on_table_ids,
    retry_max_attempts, retry_initial_wait_sec,
    retry_backoff_multiplier, retry_max_wait_sec,
    alert_config, is_active,
    CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP(), 'ops_team'
FROM cdl_metadata.cdl_table_config
WHERE opco = 'GROUND';
```

Then trigger the pipeline with `--opco FREIGHT`.

---

## Monitoring

```sql
-- Today's run status per table
SELECT dataset_layer, table_name, status, attempt_number,
       rows_read, rows_written, rows_rejected, dq_passed, duration_seconds
FROM   cdl_metadata.cdl_table_run_log
WHERE  dag_run_date = CURRENT_DATE() AND opco = 'GROUND'
ORDER  BY dataset_layer, started_at;

-- DQ results for a failed run
SELECT table_name, dq_results
FROM   cdl_metadata.cdl_table_run_log
WHERE  dag_run_date = CURRENT_DATE() AND status = 'FAILED';

-- Current watermark state
SELECT table_id, last_watermark_value, last_successful_run
FROM   cdl_metadata.cdl_table_config
WHERE  opco = 'GROUND' AND ingestion_mode = 'INCR';
```

---

## Running Tests

```bash
pytest tests/test_framework.py -v
```

---

## Cloud Portability

| Concern | Azure | GCP |
|---------|-------|-----|
| Compute | Databricks (Spark) | Dataproc (Spark) |
| Storage | ADLS Gen2 | GCS |
| Table format | Delta Lake | Delta Lake on GCS |
| Orchestration | Airflow / ADF | Cloud Composer |
| Secrets | Azure Key Vault | Secret Manager |

Set `CDL_ENV=gcp` — `cloud_adapter.py` handles the rest.
