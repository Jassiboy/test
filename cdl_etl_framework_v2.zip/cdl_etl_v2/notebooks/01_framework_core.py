"""
cdl_etl_framework/notebooks/01_framework_core.py
=================================================
Framework core — 2-table design.

MetadataManager reads EVERYTHING from cdl_table_config:
  - Pipeline topology (source/target/layer/opco)
  - DQ rules          (data_quality_rules JSON column)
  - Retry policy      (retry_* columns)
  - Alert config      (alert_config JSON column)
  - Watermark state   (last_watermark_value column — updated in-place)
  - Dependency gate   (depends_on_table_ids column)

RunLogger writes to cdl_table_run_log only.
DQEngine runs inline rules parsed from cdl_table_config.
"""

import hashlib
import json
import logging
import os
import sys
import traceback
from dataclasses import dataclass, field
from datetime import date, datetime, timezone
from typing import Any, Optional

try:
    from pyspark.sql import DataFrame, SparkSession
    from pyspark.sql import functions as F
    from delta.tables import DeltaTable
    SPARK_AVAILABLE = True
except ImportError:
    SPARK_AVAILABLE = False

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from config.env_config import PIPELINE_CONFIG, get_metadata_db, get_data_db


# ===========================================================================
# CDLLogger
# ===========================================================================
class CDLLogger:
    def __init__(self, name: str, run_id: str = "", opco: str = "", layer: str = ""):
        self._log = logging.getLogger(f"cdl.{name}")
        if not self._log.handlers:
            h = logging.StreamHandler(sys.stdout)
            h.setFormatter(logging.Formatter(
                '{"ts":"%(asctime)s","level":"%(levelname)s","msg":%(message)s}'
            ))
            self._log.addHandler(h)
        self._log.setLevel(getattr(logging, os.getenv("CDL_LOG_LEVEL", "INFO")))
        self.ctx = {"run_id": run_id, "opco": opco, "layer": layer}

    def _fmt(self, msg, extra=None):
        return json.dumps({**self.ctx, **(extra or {}), "message": msg})

    def info(self, msg, **kw):    self._log.info(self._fmt(msg, kw))
    def warning(self, msg, **kw): self._log.warning(self._fmt(msg, kw))
    def error(self, msg, **kw):   self._log.error(self._fmt(msg, kw))
    def debug(self, msg, **kw):   self._log.debug(self._fmt(msg, kw))


# ===========================================================================
# Data classes
# ===========================================================================
@dataclass
class TableConfig:
    """All pipeline config for one source→target mapping, read from cdl_table_config."""
    table_id: str
    source_system: str
    source_table_name: str
    source_filter: Optional[str]
    target_system: str
    target_table_name: str
    target_dataset_layer: str
    opco: str
    ingestion_mode: str
    load_frequency: str
    watermark_column: Optional[str]
    last_watermark_value: Optional[datetime]
    partition_col: Optional[str]
    merge_keys: Optional[str]
    data_quality_rules: list          # parsed from JSON
    dq_threshold_pct: float
    depends_on_table_ids: list[str]   # parsed from comma-separated string
    retry_max_attempts: int
    retry_initial_wait_sec: int
    retry_backoff_multiplier: float
    retry_max_wait_sec: int
    alert_config: list                # parsed from JSON
    is_active: bool


@dataclass
class DQResult:
    rule_id: str
    rule_type: str
    target_column: Optional[str]
    severity: str
    passed: bool
    rows_checked: int
    rows_failed: int
    failure_pct: float
    error_message: Optional[str] = None

    def to_dict(self):
        return {
            "rule_id": self.rule_id, "rule_type": self.rule_type,
            "target_column": self.target_column, "severity": self.severity,
            "passed": self.passed, "rows_checked": self.rows_checked,
            "rows_failed": self.rows_failed,
            "failure_pct": round(self.failure_pct, 4),
            "error_message": self.error_message,
        }


@dataclass
class RunMetrics:
    rows_read: int = 0
    rows_written: int = 0
    rows_rejected: int = 0
    rows_merged: int = 0
    rows_inserted: int = 0
    rows_updated: int = 0
    rows_deleted: int = 0


# ===========================================================================
# MetadataManager  — single source of truth: cdl_table_config
# ===========================================================================
class MetadataManager:
    """
    All config comes from cdl_table_config.
    No other control tables are read.
    """

    def __init__(self, spark: "SparkSession", opco: str, run_date: date):
        self.spark = spark
        self.opco = opco.upper()
        self.run_date = run_date
        self.mdb = get_metadata_db()
        self.logger = CDLLogger("MetadataManager", opco=opco)

    # ── Config loading ────────────────────────────────────────────────────
    def get_table_configs(
        self,
        layer: Optional[str] = None,
        frequency: Optional[str] = None,
    ) -> list[TableConfig]:
        where = [f"opco = '{self.opco}'", "is_active = true"]
        if layer:
            where.append(f"target_dataset_layer = '{layer.upper()}'")
        if frequency:
            where.append(f"load_frequency IN ('{frequency.upper()}', 'BOTH')")
        rows = self.spark.sql(
            f"SELECT * FROM {self.mdb}.cdl_table_config WHERE {' AND '.join(where)}"
            f" ORDER BY target_dataset_layer, table_id"
        ).collect()
        self.logger.info(f"Loaded {len(rows)} config(s)", layer=layer)
        return [self._parse_row(r) for r in rows]

    # ── Dependency gate ───────────────────────────────────────────────────
    def check_upstream_dq_passed(self, configs: list[TableConfig]) -> tuple[bool, list[str]]:
        """
        For each config, look up its depends_on_table_ids and verify
        all upstream tables have dq_passed=TRUE in today's run log.
        Returns (all_passed, list_of_failed_upstream_ids).
        """
        # Collect all upstream IDs needed
        all_upstream: set[str] = set()
        for cfg in configs:
            all_upstream.update(cfg.depends_on_table_ids)
        if not all_upstream:
            return True, []

        ids_sql = ",".join(f"'{uid}'" for uid in all_upstream)
        rows = self.spark.sql(f"""
            SELECT dataset_id, MAX(CAST(dq_passed AS INT)) AS dq_ok
            FROM {self.mdb}.cdl_table_run_log
            WHERE dag_run_date = '{self.run_date}'
              AND opco         = '{self.opco}'
              AND status       = 'SUCCESS'
              AND dataset_id   IN ({ids_sql})
            GROUP BY dataset_id
        """).collect()

        passed_ids = {r["dataset_id"] for r in rows if r["dq_ok"] == 1}
        failed     = [uid for uid in all_upstream if uid not in passed_ids]

        if failed:
            self.logger.error(f"Upstream DQ not passed: {failed}")
            return False, failed
        return True, []

    # ── Watermark ─────────────────────────────────────────────────────────
    def update_watermark(self, table_id: str, new_watermark: datetime):
        """
        Persist watermark back into cdl_table_config.last_watermark_value.
        No separate watermark table needed.
        """
        now = datetime.now(timezone.utc).isoformat()
        self.spark.sql(f"""
            UPDATE {self.mdb}.cdl_table_config
            SET    last_watermark_value = '{new_watermark.isoformat()}',
                   last_successful_run  = '{self.run_date}',
                   updated_at           = '{now}'
            WHERE  table_id = '{table_id}'
        """)
        self.logger.debug(f"Watermark updated for {table_id}: {new_watermark}")

    # ── Row parser ────────────────────────────────────────────────────────
    @staticmethod
    def _parse_row(row) -> TableConfig:
        d = row.asDict()

        # DQ rules
        dq_rules = []
        if d.get("data_quality_rules"):
            try:
                dq_rules = json.loads(d["data_quality_rules"])
            except Exception:
                pass

        # Dependency IDs
        dep_ids = []
        if d.get("depends_on_table_ids"):
            dep_ids = [x.strip() for x in d["depends_on_table_ids"].split(",") if x.strip()]

        # Alert config
        alerts = []
        if d.get("alert_config"):
            try:
                alerts = json.loads(d["alert_config"])
            except Exception:
                pass

        return TableConfig(
            table_id=d["table_id"],
            source_system=d["source_system"],
            source_table_name=d["source_table_name"],
            source_filter=d.get("source_filter"),
            target_system=d["target_system"],
            target_table_name=d["target_table_name"],
            target_dataset_layer=d["target_dataset_layer"],
            opco=d["opco"],
            ingestion_mode=d["ingestion_mode"],
            load_frequency=d["load_frequency"],
            watermark_column=d.get("watermark_column"),
            last_watermark_value=d.get("last_watermark_value"),
            partition_col=d.get("partition_col"),
            merge_keys=d.get("merge_keys"),
            data_quality_rules=dq_rules,
            dq_threshold_pct=float(d.get("dq_threshold_pct") or 95.0),
            depends_on_table_ids=dep_ids,
            retry_max_attempts=int(d.get("retry_max_attempts") or 3),
            retry_initial_wait_sec=int(d.get("retry_initial_wait_sec") or 30),
            retry_backoff_multiplier=float(d.get("retry_backoff_multiplier") or 2.0),
            retry_max_wait_sec=int(d.get("retry_max_wait_sec") or 300),
            alert_config=alerts,
            is_active=bool(d["is_active"]),
        )


# ===========================================================================
# RunLogger — writes only to cdl_table_run_log
# ===========================================================================
class RunLogger:
    def __init__(self, spark: "SparkSession", dag_id: str, task_id: str):
        self.spark = spark
        self.dag_id = dag_id
        self.task_id = task_id
        self.mdb = get_metadata_db()
        self.logger = CDLLogger("RunLogger")

    @staticmethod
    def make_run_id(dag_id: str, task_id: str, run_date: date, attempt: int) -> str:
        raw = f"{dag_id}|{task_id}|{run_date}|{attempt}"
        return hashlib.sha256(raw.encode()).hexdigest()[:32]

    def log_start(self, cfg: TableConfig, run_date: date, attempt: int,
                  watermark_start: Optional[datetime] = None) -> str:
        run_id = self.make_run_id(self.dag_id, self.task_id, run_date, attempt)
        now = datetime.now(timezone.utc)
        self._upsert({
            "run_id": run_id, "dataset_id": cfg.table_id,
            "dag_run_date": str(run_date), "dag_id": self.dag_id,
            "task_id": self.task_id, "dataset_layer": cfg.target_dataset_layer,
            "opco": cfg.opco, "table_name": cfg.target_table_name,
            "status": "RUNNING", "attempt_number": attempt,
            "rows_read": None, "rows_written": None, "rows_rejected": None,
            "rows_merged": None, "rows_inserted": None, "rows_updated": None,
            "rows_deleted": None,
            "watermark_start": watermark_start.isoformat() if watermark_start else None,
            "watermark_end": None, "started_at": now.isoformat(),
            "completed_at": None, "duration_seconds": None,
            "dq_results": None, "dq_passed": None,
            "error_code": None, "error_message": None,
            "spark_app_id": self.spark.sparkContext.applicationId,
            "cluster_id": os.getenv("CLUSTER_ID", "unknown"),
            "created_at": now.isoformat(), "updated_at": now.isoformat(),
        })
        return run_id

    def log_success(self, run_id: str, metrics: RunMetrics,
                    dq_results: list[DQResult], dq_passed: bool,
                    watermark_end: Optional[datetime] = None,
                    started_at: Optional[datetime] = None):
        now = datetime.now(timezone.utc)
        duration = int((now - started_at).total_seconds()) if started_at else None
        self._update(run_id, status="SUCCESS",
                     rows_read=metrics.rows_read, rows_written=metrics.rows_written,
                     rows_rejected=metrics.rows_rejected, rows_merged=metrics.rows_merged,
                     rows_inserted=metrics.rows_inserted, rows_updated=metrics.rows_updated,
                     rows_deleted=metrics.rows_deleted,
                     watermark_end=watermark_end.isoformat() if watermark_end else None,
                     completed_at=now.isoformat(), duration_seconds=duration,
                     dq_results=json.dumps([r.to_dict() for r in dq_results]),
                     dq_passed=dq_passed, error_code=None, error_message=None,
                     updated_at=now.isoformat())

    def log_failure(self, run_id: str, error_code: str, error_message: str,
                    metrics: Optional[RunMetrics] = None,
                    started_at: Optional[datetime] = None, status: str = "FAILED"):
        now = datetime.now(timezone.utc)
        m = metrics or RunMetrics()
        duration = int((now - started_at).total_seconds()) if started_at else None
        self._update(run_id, status=status,
                     rows_read=m.rows_read, rows_written=m.rows_written,
                     rows_rejected=m.rows_rejected, rows_merged=m.rows_merged,
                     rows_inserted=m.rows_inserted, rows_updated=m.rows_updated,
                     rows_deleted=m.rows_deleted,
                     watermark_end=None, completed_at=now.isoformat(),
                     duration_seconds=duration, dq_results=None, dq_passed=False,
                     error_code=error_code, error_message=error_message[:4000],
                     updated_at=now.isoformat())

    def _upsert(self, row: dict):
        try:
            df = self.spark.createDataFrame([row])
            DeltaTable.forName(self.spark, f"{self.mdb}.cdl_table_run_log").alias("t").merge(
                df.alias("s"),
                "t.run_id = s.run_id AND t.attempt_number = s.attempt_number"
            ).whenNotMatchedInsertAll().execute()
        except Exception as e:
            self.logger.error(f"_upsert failed: {e}")

    def _update(self, run_id: str, **fields):
        try:
            parts = []
            for k, v in fields.items():
                if v is None:
                    parts.append(f"t.{k} = NULL")
                elif isinstance(v, bool):
                    parts.append(f"t.{k} = {str(v)}")
                elif isinstance(v, (int, float)):
                    parts.append(f"t.{k} = {v}")
                else:
                    escaped = str(v).replace("'", "\\'")
                    parts.append(f"t.{k} = '{escaped}'")
            self.spark.sql(
                f"UPDATE {self.mdb}.cdl_table_run_log SET {', '.join(parts)}"
                f" WHERE run_id = '{run_id}'"
            )
        except Exception as e:
            self.logger.error(f"_update failed: {e}")


# ===========================================================================
# DQEngine — Three-tier inline validation
# ===========================================================================
class DQEngine:
    """
    Runs DQ rules that are embedded directly in cdl_table_config.data_quality_rules.
    Tier 1 — Schema   : NOT_NULL
    Tier 2 — Business : RANGE, REGEX, CUSTOM_SQL
    Tier 3 — Stats    : ROW_COUNT, UNIQUENESS
    """
    def __init__(self, spark: "SparkSession", logger: CDLLogger):
        self.spark = spark
        self.logger = logger

    def run(self, df: "DataFrame", cfg: TableConfig) -> tuple[list[DQResult], bool]:
        """Run all rules in cfg.data_quality_rules. Returns (results, overall_pass)."""
        total = df.count()
        results: list[DQResult] = []

        for rule in cfg.data_quality_rules:
            result = self._run_rule(df, rule, total)
            results.append(result)
            self.logger.info(
                f"DQ [{rule['rule_id']}] {'PASS' if result.passed else 'FAIL'}",
                severity=rule.get("severity"), failure_pct=result.failure_pct,
            )

        # Overall: no CRITICAL rule failure AND pass rate ≥ threshold
        critical_ok = all(r.passed for r in results if r.severity == "CRITICAL")
        if total > 0:
            crit_failed = sum(r.rows_failed for r in results if r.severity == "CRITICAL")
            pass_pct = ((total - crit_failed) / total) * 100
            threshold_ok = pass_pct >= cfg.dq_threshold_pct
        else:
            threshold_ok = False

        overall = critical_ok and threshold_ok
        if not threshold_ok:
            self.logger.error(
                f"DQ threshold not met for {cfg.table_id}: "
                f"pass_pct={pass_pct:.1f}% < {cfg.dq_threshold_pct}%"
            )
        return results, overall

    def _run_rule(self, df: "DataFrame", rule: dict, total: int) -> DQResult:
        rid  = rule["rule_id"]
        rtype = rule["rule_type"]
        col  = rule.get("target_column")
        expr = rule["rule_expression"]
        sev  = rule.get("severity", "WARNING")
        thr  = float(rule.get("error_threshold_pct") or 0.0)
        try:
            if rtype == "ROW_COUNT":
                cfg = json.loads(expr) if isinstance(expr, str) and expr.startswith("{") else {"min_rows": 1}
                passed = total >= int(cfg.get("min_rows", 1))
                return DQResult(rid, rtype, col, sev, passed, total, 0 if passed else 1,
                                0.0 if passed else 100.0)
            elif rtype == "UNIQUENESS":
                dups = total - df.select(col).distinct().count()
                pct  = (dups / total * 100) if total else 0.0
                return DQResult(rid, rtype, col, sev, pct <= thr, total, dups, pct)
            else:
                failed_count = df.filter(f"NOT ({expr})").count()
                pct = (failed_count / total * 100) if total else 0.0
                return DQResult(rid, rtype, col, sev, pct <= thr, total, failed_count, pct)
        except Exception as exc:
            self.logger.error(f"DQ rule [{rid}] error: {exc}")
            return DQResult(rid, rtype, col, sev, False, total, total, 100.0, str(exc)[:500])

    def tag_rows(self, df: "DataFrame", rules: list[dict]) -> "DataFrame":
        """Add dq_passed=False to rows failing any CRITICAL rule."""
        crit = [r for r in rules if r.get("severity") == "CRITICAL"
                and r["rule_type"] not in ("ROW_COUNT", "UNIQUENESS")]
        if not crit:
            return df.withColumn("dq_passed", F.lit(True))
        # A row passes if it satisfies ALL critical rules
        combined = " AND ".join(f"({r['rule_expression']})" for r in crit)
        return df.withColumn(
            "dq_passed",
            F.when(F.expr(combined), F.lit(True)).otherwise(F.lit(False))
        )
