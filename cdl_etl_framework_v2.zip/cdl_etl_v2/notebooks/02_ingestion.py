"""
cdl_etl_framework/notebooks/02_ingestion.py
============================================
Generic ingestion engine — 2-table design.

Reads ALL config from cdl_table_config (via TableConfig dataclass).
No auxiliary tables. Watermark written back to cdl_table_config directly.

Supports: FULL | INCR | CDC
"""

import os
import sys
import time
import random
import traceback
from datetime import date, datetime, timezone
from typing import Optional

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from notebooks.01_framework_core import (
    CDLLogger, DQEngine, MetadataManager, RunLogger,
    RunMetrics, TableConfig,
)
from utils.alert_manager import AlertManager
from utils.cloud_adapter import CloudAdapter
from config.env_config import get_data_db

try:
    from pyspark.sql import DataFrame, SparkSession
    from pyspark.sql import functions as F
    from delta.tables import DeltaTable
except ImportError:
    pass


class IngestionEngine:
    """
    Executes one source→target table load per TableConfig.
    Retry policy, DQ rules, alert config all come from the TableConfig object
    (which was read from cdl_table_config) — no other tables consulted.
    """

    def __init__(
        self,
        spark: "SparkSession",
        meta_mgr: MetadataManager,
        run_logger: RunLogger,
        alert_mgr: AlertManager,
        run_date: date,
        dag_id: str,
    ):
        self.spark    = spark
        self.meta_mgr = meta_mgr
        self.run_log  = run_logger
        self.alert    = alert_mgr
        self.run_date = run_date
        self.dag_id   = dag_id
        self.data_db  = get_data_db()
        self.adapter  = CloudAdapter(spark)

    # ─────────────────────────────────────────────────────────────────────
    def run_table(self, cfg: TableConfig) -> bool:
        """
        Execute one table load with retry.
        Returns True on success, False after all attempts exhausted.
        """
        logger = CDLLogger("Ingestion", opco=cfg.opco, layer=cfg.target_dataset_layer)

        for attempt in range(1, cfg.retry_max_attempts + 1):
            started_at = datetime.now(timezone.utc)
            run_id = self.run_log.log_start(cfg, self.run_date, attempt)
            logger.info(
                f"Attempt {attempt}/{cfg.retry_max_attempts} — {cfg.table_id}",
                run_id=run_id,
            )
            try:
                ok = self._execute(cfg, run_id, attempt, started_at, logger)
                if ok:
                    return True
            except Exception as exc:
                msg = f"{type(exc).__name__}: {exc}\n{traceback.format_exc()}"
                logger.error(f"Unhandled exception: {msg}")
                is_last = (attempt == cfg.retry_max_attempts)
                self.run_log.log_failure(
                    run_id=run_id,
                    error_code="UNHANDLED_EXCEPTION",
                    error_message=msg,
                    started_at=started_at,
                    status="FAILED" if is_last else "RUNNING",
                )
                if is_last:
                    self.alert.send(cfg, run_id, "FAILED", msg, "CRITICAL")
                    return False

            wait = self._backoff(attempt, cfg)
            logger.info(f"Retrying in {wait}s …")
            time.sleep(wait)

        return False

    # ─────────────────────────────────────────────────────────────────────
    def _execute(
        self,
        cfg: TableConfig,
        run_id: str,
        attempt: int,
        started_at: datetime,
        logger: CDLLogger,
    ) -> bool:
        metrics   = RunMetrics()
        dq_engine = DQEngine(self.spark, logger)

        # 1. Read source
        df = self._read(cfg, logger)
        metrics.rows_read = df.count()
        logger.info(f"Rows read: {metrics.rows_read}")

        if metrics.rows_read == 0 and cfg.ingestion_mode != "FULL":
            logger.info("No new rows — nothing to write")
            self.run_log.log_success(
                run_id, metrics, [], True, started_at=started_at
            )
            return True

        # 2. Add framework columns
        df = self._add_meta_cols(df, run_id, cfg)

        # 3. DQ validation
        dq_results, dq_passed = dq_engine.run(df, cfg)

        # 4. Tag rows, split clean / rejected
        df = dq_engine.tag_rows(df, cfg.data_quality_rules)
        clean_df    = df.filter("dq_passed = true")
        rejected_df = df.filter("dq_passed = false")
        metrics.rows_rejected = rejected_df.count()

        logger.info(
            f"DQ overall={'PASS' if dq_passed else 'FAIL'} "
            f"clean={metrics.rows_read - metrics.rows_rejected} "
            f"rejected={metrics.rows_rejected}"
        )

        # 5. Write clean rows
        write_m = self._write(clean_df, cfg, logger)
        metrics.rows_written  = write_m.rows_written
        metrics.rows_merged   = write_m.rows_merged
        metrics.rows_inserted = write_m.rows_inserted
        metrics.rows_updated  = write_m.rows_updated
        metrics.rows_deleted  = write_m.rows_deleted

        # 6. Update watermark in cdl_table_config
        wm_end = None
        if cfg.ingestion_mode == "INCR" and cfg.watermark_column:
            wm_val = clean_df.agg(F.max(cfg.watermark_column)).collect()[0][0]
            if wm_val:
                wm_end = wm_val
                self.meta_mgr.update_watermark(cfg.table_id, wm_val)

        # 7. Log result
        self.run_log.log_success(
            run_id, metrics, dq_results, dq_passed,
            watermark_end=wm_end, started_at=started_at,
        )

        if not dq_passed:
            self.alert.send(
                cfg, run_id, "FAILED",
                f"DQ threshold not met for {cfg.table_id}", "CRITICAL",
            )
        return dq_passed

    # ─────────────────────────────────────────────────────────────────────
    # Source read
    # ─────────────────────────────────────────────────────────────────────
    def _read(self, cfg: TableConfig, logger: CDLLogger) -> "DataFrame":
        if cfg.source_system in ("DELTA_LAKE", "BIGQUERY"):
            df = self.spark.table(f"{self.data_db}.{cfg.source_table_name}")
        else:
            df = self.adapter.read_external(cfg.source_system, cfg.source_table_name)

        if cfg.source_filter:
            df = df.filter(cfg.source_filter)

        if cfg.ingestion_mode == "INCR" and cfg.watermark_column and cfg.last_watermark_value:
            df = df.filter(
                F.col(cfg.watermark_column) > F.lit(cfg.last_watermark_value)
            )
            logger.info(f"Watermark filter: {cfg.watermark_column} > {cfg.last_watermark_value}")

        return df

    # ─────────────────────────────────────────────────────────────────────
    # Target write
    # ─────────────────────────────────────────────────────────────────────
    def _write(self, df: "DataFrame", cfg: TableConfig, logger: CDLLogger) -> RunMetrics:
        m      = RunMetrics()
        target = f"{self.data_db}.{cfg.target_table_name}"
        mode   = cfg.ingestion_mode.upper()

        if mode == "FULL":
            (df.write.format("delta").mode("overwrite")
               .option("replaceWhere",
                       f"load_date = '{self.run_date}' AND opco = '{cfg.opco}'")
               .saveAsTable(target))
            m.rows_written = m.rows_inserted = df.count()
            logger.info(f"FULL overwrite → {target}: {m.rows_written} rows")

        elif mode in ("INCR", "CDC"):
            if not cfg.merge_keys:
                raise ValueError(f"merge_keys required for {mode} on {cfg.table_id}")

            condition = " AND ".join(
                f"t.{k.strip()} = s.{k.strip()}"
                for k in cfg.merge_keys.split(",")
            )

            if DeltaTable.isDeltaTable(self.spark, target):
                dt = DeltaTable.forName(self.spark, target)
                if mode == "CDC":
                    (dt.alias("t").merge(df.alias("s"), condition)
                       .whenMatchedDelete(condition="s.cdc_op = 'D'")
                       .whenMatchedUpdateAll(condition="s.cdc_op != 'D'")
                       .whenNotMatchedInsertAll(condition="s.cdc_op != 'D'")
                       .execute())
                else:
                    (dt.alias("t").merge(df.alias("s"), condition)
                       .whenMatchedUpdateAll()
                       .whenNotMatchedInsertAll()
                       .execute())
                ops = dt.history(1).select("operationMetrics").collect()[0][0]
                m.rows_inserted = int(ops.get("numTargetRowsInserted", 0))
                m.rows_updated  = int(ops.get("numTargetRowsUpdated",  0))
                m.rows_deleted  = int(ops.get("numTargetRowsDeleted",  0))
                m.rows_merged   = m.rows_inserted + m.rows_updated
                m.rows_written  = m.rows_merged
            else:
                df.write.format("delta").mode("append").saveAsTable(target)
                m.rows_written = m.rows_inserted = df.count()

            logger.info(
                f"{mode} merge → {target}: "
                f"ins={m.rows_inserted} upd={m.rows_updated} del={m.rows_deleted}"
            )
        return m

    # ─────────────────────────────────────────────────────────────────────
    # Helpers
    # ─────────────────────────────────────────────────────────────────────
    @staticmethod
    def _add_meta_cols(df: "DataFrame", run_id: str, cfg: TableConfig) -> "DataFrame":
        now = datetime.now(timezone.utc).isoformat()
        return (df
            .withColumn("run_id",       F.lit(run_id))
            .withColumn("source_system",F.lit(cfg.source_system))
            .withColumn("load_date",    F.lit(None).cast("date"))   # set by transformer
            .withColumn("created_at",
                F.coalesce(F.col("created_at"), F.lit(now).cast("timestamp")))
            .withColumn("updated_at",   F.lit(now).cast("timestamp"))
        )

    @staticmethod
    def _backoff(attempt: int, cfg: TableConfig) -> float:
        wait = min(
            cfg.retry_initial_wait_sec * (cfg.retry_backoff_multiplier ** (attempt - 1)),
            cfg.retry_max_wait_sec,
        )
        return wait + random.uniform(0, wait * 0.1)
