"""
cdl_etl_framework/notebooks/03_transformation.py
=================================================
Layer-specific transformation logic — 2-table design.
All four layers (Account → Facility → Country → Global), daily + monthly.
Selected at runtime via TRANSFORMER_REGISTRY keyed on target_dataset_layer.
"""

import os
import sys
from datetime import date, datetime, timedelta, timezone
from typing import Optional

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from notebooks.01_framework_core import CDLLogger, TableConfig
from config.env_config import get_data_db

try:
    from pyspark.sql import DataFrame, SparkSession
    from pyspark.sql import functions as F
    from pyspark.sql.window import Window
except ImportError:
    pass

DATA_DB = get_data_db()

# Country reference — replace with a Delta dimension table in production
COUNTRY_REF = {
    "US": ("United States",  "AMERICAS", "AM", "USD"),
    "GB": ("United Kingdom", "EUROPE",   "EU", "GBP"),
    "DE": ("Germany",        "EUROPE",   "EU", "EUR"),
    "AU": ("Australia",      "APAC",     "AP", "AUD"),
    "SG": ("Singapore",      "APAC",     "AP", "SGD"),
    "IN": ("India",          "APAC",     "AP", "INR"),
    "BR": ("Brazil",         "AMERICAS", "AM", "BRL"),
    "FR": ("France",         "EUROPE",   "EU", "EUR"),
    "CA": ("Canada",         "AMERICAS", "AM", "CAD"),
    "JP": ("Japan",          "APAC",     "AP", "JPY"),
}


# ===========================================================================
# Base transformer
# ===========================================================================
class BaseTransformer:
    layer_name: str = "BASE"

    def __init__(self, spark: "SparkSession", run_date: date, opco: str):
        self.spark    = spark
        self.run_date = run_date
        self.opco     = opco.upper()
        self.logger   = CDLLogger(self.__class__.__name__, opco=opco, layer=self.layer_name)

    def transform_daily(self, cfg: TableConfig) -> "DataFrame":
        raise NotImplementedError

    def transform_monthly(self, cfg: TableConfig) -> "DataFrame":
        raise NotImplementedError

    def _read_delta(self, table_name: str, filter_today: bool = True) -> "DataFrame":
        df = self.spark.table(f"{DATA_DB}.{table_name}")
        if filter_today:
            df = df.filter(
                (F.col("load_date") == F.lit(str(self.run_date))) &
                (F.col("opco")      == F.lit(self.opco))
            )
        return df

    def _meta(self, df: "DataFrame", source: str) -> "DataFrame":
        now = datetime.now(timezone.utc).isoformat()
        return (df
            .withColumn("load_date",    F.lit(str(self.run_date)).cast("date"))
            .withColumn("opco",         F.lit(self.opco))
            .withColumn("source_system",F.lit(source))
            .withColumn("dq_passed",    F.lit(None).cast("boolean"))
            .withColumn("created_at",   F.lit(now).cast("timestamp"))
            .withColumn("updated_at",   F.lit(now).cast("timestamp")))


# ===========================================================================
# 1. ACCOUNT  (Raw → Bronze)
# ===========================================================================
class AccountTransformer(BaseTransformer):
    """
    Reads raw source transactions.
    Normalises status, deduplicates, derives effective_date.
    """
    layer_name = "ACCOUNT"

    def transform_daily(self, cfg: TableConfig) -> "DataFrame":
        self.logger.info("Account daily transform start")
        raw = self.spark.table(f"{DATA_DB}.{cfg.source_table_name}")

        # Filter to today's modified records
        raw = raw.filter(
            F.col("last_modified_ts").cast("date") == F.lit(str(self.run_date))
        )

        transformed = (raw
            # Normalise keys
            .withColumn("account_id",    F.trim(F.upper(F.col("account_id"))))
            .withColumn("opco",          F.lit(self.opco))
            # Standardise status
            .withColumn("account_status",
                F.when(F.upper(F.col("account_status")).isin("A","ACTIVE"),    F.lit("ACTIVE"))
                 .when(F.upper(F.col("account_status")).isin("I","INACTIVE"),  F.lit("INACTIVE"))
                 .when(F.upper(F.col("account_status")).isin("S","SUSPENDED"), F.lit("SUSPENDED"))
                 .otherwise(F.lit("INACTIVE")))
            # Derive effective_date from transaction timestamp
            .withColumn("effective_date", F.col("last_modified_ts").cast("date"))
            # Clamp numeric columns to >= 0
            .withColumn("revenue",
                F.greatest(F.coalesce(F.col("revenue"),     F.lit(0.0)), F.lit(0.0)))
            .withColumn("cost",
                F.greatest(F.coalesce(F.col("cost"),        F.lit(0.0)), F.lit(0.0)))
            .withColumn("credit_limit",
                F.greatest(F.coalesce(F.col("credit_limit"),F.lit(0.0)), F.lit(0.0)))
            # Dedup: keep latest record per account per day
            .withColumn("_rn", F.row_number().over(
                Window.partitionBy("account_id", "opco", "effective_date")
                      .orderBy(F.col("last_modified_ts").desc())
            ))
            .filter(F.col("_rn") == 1)
            .drop("_rn")
        )
        return self._meta(transformed, cfg.source_system)

    def transform_monthly(self, cfg: TableConfig) -> "DataFrame":
        self.logger.info("Account monthly transform start")
        month_str = self.run_date.strftime("%Y-%m")
        daily = (self.spark.table(f"{DATA_DB}.account_daily")
            .filter((F.date_format("effective_date", "yyyy-MM") == month_str) &
                    (F.col("opco") == self.opco))
        )
        monthly = (daily
            .groupBy("account_id","opco","account_name","account_type",
                     "account_status","account_category","region_code",
                     "country_code","currency_code")
            .agg(
                F.lit(month_str).alias("month_year"),
                F.avg("balance").alias("avg_daily_balance"),
                F.sum("revenue").alias("total_revenue"),
                F.sum("cost").alias("total_cost"),
                F.sum("transaction_count").alias("transaction_count"),
                F.countDistinct("effective_date").alias("active_days"),
            )
        )
        return self._meta(monthly, cfg.source_system)


# ===========================================================================
# 2. FACILITY  (Account → Silver)
# ===========================================================================
class FacilityTransformer(BaseTransformer):
    """
    Joins Account data with facility dimension.
    Enriches with operational KPIs: shipments, utilisation, on-time delivery.
    """
    layer_name = "FACILITY"

    def transform_daily(self, cfg: TableConfig) -> "DataFrame":
        self.logger.info("Facility daily transform start")
        acc = self._read_delta("account_daily")

        fac = (acc
            # Derive facility attributes from account (in prod: join real facility dim)
            .withColumn("facility_id",
                F.concat_ws("_", F.lit("FAC"), F.col("account_id")))
            .withColumn("facility_name",
                F.concat_ws(" ", F.col("account_name"), F.lit("Facility")))
            .withColumn("facility_type",
                F.when(F.col("account_category") == "CORPORATE", F.lit("HUB"))
                 .when(F.col("account_category") == "SME",       F.lit("DEPOT"))
                 .otherwise(F.lit("WAREHOUSE")))
            .withColumn("facility_status",
                F.when(F.col("account_status") == "ACTIVE",   F.lit("ACTIVE"))
                 .when(F.col("account_status") == "INACTIVE", F.lit("INACTIVE"))
                 .otherwise(F.lit("UNDER_MAINTENANCE")))
            .withColumn("facility_category", F.col("account_category"))
            .withColumn("city",        F.lit("UNKNOWN"))
            .withColumn("postal_code", F.lit(None).cast("string"))
            # Operational KPIs (representative formulas)
            .withColumn("shipment_count",
                (F.col("transaction_count") * F.lit(0.8)).cast("long"))
            .withColumn("volume_kg", F.col("revenue") * F.lit(0.15))
            .withColumn("on_time_delivery_pct",
                F.least(F.lit(100.0),
                    F.greatest(F.lit(0.0),
                        F.lit(95.0) - (F.col("cost") / (F.col("revenue") + F.lit(0.001))) * F.lit(10.0)
                    )))
            .withColumn("utilisation_pct",
                F.when(F.col("credit_limit") > 0,
                    F.least(F.lit(100.0), (F.col("balance") / F.col("credit_limit")) * F.lit(100.0))
                ).otherwise(F.lit(0.0)))
            .withColumn("effective_date",    F.col("effective_date"))
            .withColumn("last_modified_ts",  F.col("last_modified_ts"))
        )

        fac = fac.select(
            "facility_id","account_id","opco",
            "facility_name","facility_type","facility_status","facility_category",
            "country_code","region_code","city","postal_code",
            "account_name","account_type","account_status",
            "shipment_count","volume_kg","revenue","cost",
            "on_time_delivery_pct","utilisation_pct",
            "effective_date","last_modified_ts",
        )
        return self._meta(fac, "DELTA_LAKE")

    def transform_monthly(self, cfg: TableConfig) -> "DataFrame":
        self.logger.info("Facility monthly transform start")
        month_str = self.run_date.strftime("%Y-%m")
        daily = (self.spark.table(f"{DATA_DB}.facility_daily")
            .filter((F.date_format("effective_date", "yyyy-MM") == month_str) &
                    (F.col("opco") == self.opco))
        )
        monthly = (daily
            .groupBy("facility_id","account_id","opco","facility_name",
                     "facility_type","facility_status","country_code","region_code")
            .agg(
                F.lit(month_str).alias("month_year"),
                F.sum("shipment_count").alias("total_shipments"),
                F.sum("volume_kg").alias("total_volume_kg"),
                F.sum("revenue").alias("total_revenue"),
                F.sum("cost").alias("total_cost"),
                F.avg("on_time_delivery_pct").alias("avg_on_time_pct"),
                F.avg("utilisation_pct").alias("avg_utilisation_pct"),
                F.countDistinct("effective_date").alias("active_days"),
            )
        )
        return self._meta(monthly, "DELTA_LAKE")


# ===========================================================================
# 3. COUNTRY  (Facility → Silver+)
# ===========================================================================
class CountryTransformer(BaseTransformer):
    """
    Aggregates Facility data to country grain.
    Enriches with country name, region, currency from reference lookup.
    Computes gross_margin; adds YoY growth on monthly grain.
    """
    layer_name = "COUNTRY"

    def _country_ref_df(self) -> "DataFrame":
        rows = [(cc, cn, rn, rc, cur) for cc, (cn, rn, rc, cur) in COUNTRY_REF.items()]
        return self.spark.createDataFrame(
            rows, "country_code STRING, country_name STRING, "
                  "region_name STRING, region_code STRING, currency_code STRING"
        )

    def transform_daily(self, cfg: TableConfig) -> "DataFrame":
        self.logger.info("Country daily transform start")
        fac = self._read_delta("facility_daily")

        agg = (fac.filter(F.col("facility_status") == "ACTIVE")
            .groupBy("country_code","opco")
            .agg(
                F.lit(str(self.run_date)).cast("date").alias("effective_date"),
                F.countDistinct("facility_id").alias("total_facilities"),
                F.countDistinct("account_id").alias("total_accounts"),
                F.sum("shipment_count").alias("shipment_count"),
                F.sum("volume_kg").alias("volume_kg"),
                F.sum("revenue").alias("revenue"),
                F.sum("cost").alias("cost"),
                F.avg("on_time_delivery_pct").alias("avg_on_time_pct"),
                F.avg("utilisation_pct").alias("avg_utilisation_pct"),
            )
            .withColumn("gross_margin", F.col("revenue") - F.col("cost"))
        )

        enriched = (agg.join(self._country_ref_df(), on="country_code", how="left")
            .withColumn("country_name",  F.coalesce("country_name",  F.col("country_code")))
            .withColumn("region_code",   F.coalesce("region_code",   F.lit("OTHER")))
            .withColumn("region_name",   F.coalesce("region_name",   F.lit("UNKNOWN")))
            .withColumn("currency_code", F.coalesce("currency_code", F.lit("USD")))
        )
        return self._meta(enriched, "DELTA_LAKE")

    def transform_monthly(self, cfg: TableConfig) -> "DataFrame":
        self.logger.info("Country monthly transform start")
        month_str = self.run_date.strftime("%Y-%m")

        daily = (self.spark.table(f"{DATA_DB}.country_daily")
            .filter((F.date_format("effective_date", "yyyy-MM") == month_str) &
                    (F.col("opco") == self.opco))
        )

        # YoY: same month prior year
        prior_ym = self.run_date.replace(year=self.run_date.year - 1).strftime("%Y-%m")
        prior = (self.spark.table(f"{DATA_DB}.country_monthly")
            .filter((F.col("month_year") == prior_ym) & (F.col("opco") == self.opco))
            .select("country_code", F.col("total_revenue").alias("prior_yr_rev"))
        )

        monthly = (daily
            .groupBy("country_code","opco","country_name",
                     "region_code","region_name","currency_code")
            .agg(
                F.lit(month_str).alias("month_year"),
                F.avg("total_facilities").cast("int").alias("total_facilities"),
                F.avg("total_accounts").cast("int").alias("total_accounts"),
                F.sum("shipment_count").alias("total_shipments"),
                F.sum("volume_kg").alias("total_volume_kg"),
                F.sum("revenue").alias("total_revenue"),
                F.sum("cost").alias("total_cost"),
                F.sum("gross_margin").alias("gross_margin"),
                F.avg("avg_on_time_pct").alias("avg_on_time_pct"),
                F.avg("avg_utilisation_pct").alias("avg_utilisation_pct"),
            )
            .join(prior, on="country_code", how="left")
            .withColumn("yoy_revenue_growth",
                F.when((F.col("prior_yr_rev").isNotNull()) & (F.col("prior_yr_rev") > 0),
                    ((F.col("total_revenue") - F.col("prior_yr_rev")) / F.col("prior_yr_rev")) * 100
                ).otherwise(F.lit(None).cast("double")))
            .drop("prior_yr_rev")
        )
        return self._meta(monthly, "DELTA_LAKE")


# ===========================================================================
# 4. GLOBAL  (Country → Gold)
# ===========================================================================
class GlobalTransformer(BaseTransformer):
    """
    Rolls up Country data to global + regional views.
    Computes gross_margin_pct, DoD revenue change (daily),
    MoM and YoY revenue growth (monthly).
    """
    layer_name = "GLOBAL"

    def transform_daily(self, cfg: TableConfig) -> "DataFrame":
        self.logger.info("Global daily transform start")
        cntry = self._read_delta("country_daily")

        # Prior day for DoD
        prev_date = self.run_date - timedelta(days=1)
        prev_rows = (self.spark.table(f"{DATA_DB}.global_daily")
            .filter((F.col("effective_date") == str(prev_date)) &
                    (F.col("opco") == self.opco) &
                    F.col("region_code").isNull())
            .select(F.col("revenue").alias("prev_rev"))
            .collect()
        )
        prev_rev = prev_rows[0]["prev_rev"] if prev_rows else None

        def _rollup(df: "DataFrame", grp_col: Optional[str]) -> "DataFrame":
            cols = ["opco"] + ([grp_col] if grp_col else [])
            agg = (df.groupBy(*cols)
                .agg(
                    F.lit(str(self.run_date)).cast("date").alias("effective_date"),
                    F.countDistinct("country_code").alias("total_countries"),
                    F.sum("total_facilities").alias("total_facilities"),
                    F.sum("total_accounts").alias("total_accounts"),
                    F.sum("shipment_count").alias("shipment_count"),
                    F.sum("volume_kg").alias("volume_kg"),
                    F.sum("revenue").alias("revenue"),
                    F.sum("cost").alias("cost"),
                    F.sum("gross_margin").alias("gross_margin"),
                    F.avg("avg_on_time_pct").alias("avg_on_time_pct"),
                    F.avg("avg_utilisation_pct").alias("avg_utilisation_pct"),
                )
                .withColumn("gross_margin_pct",
                    F.when(F.col("revenue") > 0,
                        (F.col("gross_margin") / F.col("revenue")) * 100
                    ).otherwise(F.lit(0.0)))
                .withColumn("prev_day_revenue", F.lit(prev_rev))
                .withColumn("dod_revenue_change",
                    F.when(F.lit(prev_rev).isNotNull() & (F.lit(prev_rev) > 0),
                        ((F.col("revenue") - F.lit(prev_rev)) / F.lit(prev_rev)) * 100
                    ).otherwise(F.lit(None).cast("double")))
            )
            if grp_col:
                return agg.withColumnRenamed(grp_col, "region_code")
            return agg.withColumn("region_code", F.lit(None).cast("string"))

        combined = _rollup(cntry, None).unionByName(_rollup(cntry, "region_code"))
        return self._meta(combined, "DELTA_LAKE")

    def transform_monthly(self, cfg: TableConfig) -> "DataFrame":
        self.logger.info("Global monthly transform start")
        month_str = self.run_date.strftime("%Y-%m")

        cntry_m = (self.spark.table(f"{DATA_DB}.country_monthly")
            .filter((F.col("month_year") == month_str) & (F.col("opco") == self.opco))
        )

        # Prior month (MoM)
        prev_m_date  = self.run_date.replace(day=1) - timedelta(days=1)
        prev_m_str   = prev_m_date.strftime("%Y-%m")
        # Prior year (YoY)
        prev_y_str   = self.run_date.replace(year=self.run_date.year - 1).strftime("%Y-%m")

        def _scalar_rev(month_filter: str) -> Optional[float]:
            rows = (self.spark.table(f"{DATA_DB}.global_monthly")
                .filter((F.col("month_year") == month_filter) &
                        (F.col("opco") == self.opco) &
                        F.col("region_code").isNull())
                .select("total_revenue").collect()
            )
            return rows[0]["total_revenue"] if rows else None

        prev_m_rev = _scalar_rev(prev_m_str)
        prev_y_rev = _scalar_rev(prev_y_str)

        def _rollup(df: "DataFrame", grp_col: Optional[str]) -> "DataFrame":
            cols = ["opco"] + ([grp_col] if grp_col else [])
            agg = (df.groupBy(*cols)
                .agg(
                    F.lit(month_str).alias("month_year"),
                    F.countDistinct("country_code").alias("total_countries"),
                    F.avg("total_facilities").cast("int").alias("total_facilities"),
                    F.avg("total_accounts").cast("int").alias("total_accounts"),
                    F.sum("total_shipments").alias("total_shipments"),
                    F.sum("total_volume_kg").alias("total_volume_kg"),
                    F.sum("total_revenue").alias("total_revenue"),
                    F.sum("total_cost").alias("total_cost"),
                    F.sum("gross_margin").alias("gross_margin"),
                    F.avg("avg_on_time_pct").alias("avg_on_time_pct"),
                    F.avg("avg_utilisation_pct").alias("avg_utilisation_pct"),
                )
                .withColumn("gross_margin_pct",
                    F.when(F.col("total_revenue") > 0,
                        (F.col("gross_margin") / F.col("total_revenue")) * 100
                    ).otherwise(F.lit(0.0)))
                .withColumn("mom_revenue_growth",
                    F.when(F.lit(prev_m_rev).isNotNull() & (F.lit(prev_m_rev) > 0),
                        ((F.col("total_revenue") - F.lit(prev_m_rev)) / F.lit(prev_m_rev)) * 100
                    ).otherwise(F.lit(None).cast("double")))
                .withColumn("yoy_revenue_growth",
                    F.when(F.lit(prev_y_rev).isNotNull() & (F.lit(prev_y_rev) > 0),
                        ((F.col("total_revenue") - F.lit(prev_y_rev)) / F.lit(prev_y_rev)) * 100
                    ).otherwise(F.lit(None).cast("double")))
            )
            if grp_col:
                return agg.withColumnRenamed(grp_col, "region_code")
            return agg.withColumn("region_code", F.lit(None).cast("string"))

        combined = _rollup(cntry_m, None).unionByName(_rollup(cntry_m, "region_code"))
        return self._meta(combined, "DELTA_LAKE")


# ===========================================================================
# Registry + factory
# ===========================================================================
TRANSFORMER_REGISTRY: dict[str, type] = {
    "ACCOUNT":  AccountTransformer,
    "FACILITY": FacilityTransformer,
    "COUNTRY":  CountryTransformer,
    "GLOBAL":   GlobalTransformer,
}


def get_transformer(layer: str, spark, run_date: date, opco: str) -> BaseTransformer:
    cls = TRANSFORMER_REGISTRY.get(layer.upper())
    if not cls:
        raise ValueError(
            f"No transformer for layer '{layer}'. Available: {list(TRANSFORMER_REGISTRY)}"
        )
    return cls(spark=spark, run_date=run_date, opco=opco)
