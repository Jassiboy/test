"""
cdl_etl_framework/notebooks/04_pipeline_runner.py
==================================================
End-to-end orchestration entry point — 2-table design.

Flow per layer:
  1. Load TableConfig rows from cdl_table_config
  2. Check depends_on_table_ids gate against cdl_table_run_log
  3. Run transformer → get DataFrame
  4. Run IngestionEngine (DQ + write + watermark update)
  5. If any layer fails → halt downstream, log HALTED

Usage:
    # Full pipeline
    python 04_pipeline_runner.py --opco GROUND --run_date 2024-01-15 --env azure

    # Single layer
    python 04_pipeline_runner.py --opco GROUND --run_date 2024-01-15 --layer FACILITY

    # Monthly only
    python 04_pipeline_runner.py --opco GROUND --run_date 2024-01-15 --frequency MONTHLY
"""

import argparse
import os
import sys
import traceback
from datetime import date, datetime, timezone
from typing import Optional

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from config.env_config import PIPELINE_CONFIG
from notebooks.01_framework_core import CDLLogger, MetadataManager, RunLogger
from notebooks.02_ingestion import IngestionEngine
from notebooks.03_transformation import get_transformer
from utils.alert_manager import AlertManager
from utils.cloud_adapter import CloudAdapter

try:
    from pyspark.sql import SparkSession
except ImportError:
    SparkSession = None


# ===========================================================================
# Spark builder
# ===========================================================================
def build_spark(env: str) -> "SparkSession":
    builder = (
        SparkSession.builder
        .appName("CDL_ETL_Pipeline")
        .config("spark.sql.shuffle.partitions", str(PIPELINE_CONFIG.spark_shuffle_partitions))
        .config("spark.sql.adaptive.enabled", "true")
        .config("spark.sql.adaptive.coalescePartitions.enabled", "true")
        .config("spark.sql.adaptive.skewJoin.enabled", "true")
        .config("spark.databricks.delta.optimizeWrite.enabled", "true")
        .config("spark.databricks.delta.autoCompact.enabled", "true")
        .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension")
        .config("spark.sql.catalog.spark_catalog",
                "org.apache.spark.sql.delta.catalog.DeltaCatalog")
    )
    if env == "gcp":
        builder = builder.config(
            "spark.hadoop.fs.gs.impl",
            "com.google.cloud.hadoop.fs.gcs.GoogleHadoopFileSystem"
        )
    return builder.getOrCreate()


# ===========================================================================
# PipelineRunner
# ===========================================================================
class PipelineRunner:

    def __init__(
        self,
        spark: "SparkSession",
        opco: str,
        run_date: date,
        dag_id: str = "cdl_master_pipeline",
        target_layer: Optional[str] = None,
        frequency: Optional[str] = None,
    ):
        self.spark        = spark
        self.opco         = opco.upper()
        self.run_date     = run_date
        self.dag_id       = dag_id
        self.target_layer = target_layer.upper() if target_layer else None
        self.frequency    = frequency.upper() if frequency else None
        self.logger       = CDLLogger("PipelineRunner", opco=opco)

        self.meta_mgr  = MetadataManager(spark, opco, run_date)
        self.run_logger = RunLogger(spark, dag_id=dag_id, task_id="pipeline_runner")
        self.alert_mgr  = AlertManager(spark)
        self.engine     = IngestionEngine(
            spark=spark, meta_mgr=self.meta_mgr,
            run_logger=self.run_logger, alert_mgr=self.alert_mgr,
            run_date=run_date, dag_id=dag_id,
        )
        self.summary: list[dict] = []

    # ─────────────────────────────────────────────────────────────────────
    def run(self) -> bool:
        started = datetime.now(timezone.utc)
        self.logger.info(
            f"Pipeline START | OPCO={self.opco} DATE={self.run_date} "
            f"LAYER={self.target_layer or 'ALL'} FREQ={self.frequency or 'ALL'}"
        )

        layers = [self.target_layer] if self.target_layer else PIPELINE_CONFIG.layer_order
        overall_ok = True

        for layer in layers:
            ok = self._run_layer(layer)
            overall_ok = overall_ok and ok

            if not ok and not self.target_layer:
                # Halt all remaining downstream layers
                remaining = layers[layers.index(layer) + 1:]
                self.logger.error(
                    f"Layer {layer} FAILED — halting downstream: {remaining}"
                )
                for downstream in remaining:
                    self._halt_downstream(downstream)
                break

        self._print_summary(started)
        return overall_ok

    # ─────────────────────────────────────────────────────────────────────
    def _run_layer(self, layer: str) -> bool:
        self.logger.info(f"{'─'*50}\n  Layer: {layer}\n{'─'*50}")

        configs = self.meta_mgr.get_table_configs(layer=layer, frequency=self.frequency)
        if not configs:
            self.logger.warning(f"No active configs for layer={layer}")
            self.summary.append({"layer": layer, "status": "NO_CONFIGS",
                                  "tables": 0, "passed": 0, "failed": 0})
            return True

        # ── Dependency gate ──────────────────────────────────────────────
        # Only skip for the very first layer (ACCOUNT has no upstream deps)
        if layer != PIPELINE_CONFIG.layer_order[0]:
            gate_ok, failed_ids = self.meta_mgr.check_upstream_dq_passed(configs)
            if not gate_ok:
                self.logger.error(
                    f"DQ gate BLOCKED for {layer} — upstream failed: {failed_ids}"
                )
                self.summary.append({"layer": layer, "status": "BLOCKED_BY_DQ_GATE",
                                      "tables": len(configs), "passed": 0,
                                      "failed": len(configs)})
                return False

        transformer = get_transformer(layer, self.spark, self.run_date, self.opco)
        passed = failed = 0

        for cfg in configs:
            self.logger.info(f"  Processing: {cfg.table_id} ({cfg.load_frequency})")
            try:
                # Transform
                if cfg.load_frequency == "MONTHLY":
                    stage_df = transformer.transform_monthly(cfg)
                else:
                    stage_df = transformer.transform_daily(cfg)

                # Register as temp view so IngestionEngine reads it cleanly
                view_name = f"_cdl_{cfg.target_table_name}_stage"
                stage_df.createOrReplaceTempView(view_name)

                # Point ingestion at the temp view
                original_src  = cfg.source_table_name
                original_sys  = cfg.source_system
                cfg.source_table_name = view_name
                cfg.source_system     = "DELTA_LAKE"

                ok = self.engine.run_table(cfg)

                # Restore
                cfg.source_table_name = original_src
                cfg.source_system     = original_sys

                if ok:
                    passed += 1
                    self.logger.info(f"  ✓ {cfg.table_id}")
                else:
                    failed += 1
                    self.logger.error(f"  ✗ {cfg.table_id}")

            except Exception as exc:
                failed += 1
                self.logger.error(
                    f"  ✗ {cfg.table_id} — {type(exc).__name__}: {exc}\n"
                    f"{traceback.format_exc()}"
                )

        status = ("SUCCESS" if failed == 0
                  else "PARTIAL" if passed > 0
                  else "FAILED")
        self.summary.append({"layer": layer, "status": status,
                              "tables": len(configs), "passed": passed, "failed": failed})
        return failed == 0

    # ─────────────────────────────────────────────────────────────────────
    def _halt_downstream(self, layer: str):
        configs = self.meta_mgr.get_table_configs(layer=layer)
        for cfg in configs:
            run_id = RunLogger.make_run_id(self.dag_id, cfg.table_id, self.run_date, 1)
            self.run_logger.log_failure(
                run_id=run_id,
                error_code="UPSTREAM_DQ_FAILED",
                error_message=f"Halted: upstream DQ gate failed — layer {layer}",
                status="HALTED",
            )
        self.summary.append({"layer": layer, "status": "HALTED",
                              "tables": len(configs), "passed": 0, "failed": len(configs)})

    # ─────────────────────────────────────────────────────────────────────
    def _print_summary(self, started: datetime):
        elapsed = (datetime.now(timezone.utc) - started).total_seconds()
        lines = [
            "", "=" * 55,
            f"  CDL Pipeline SUMMARY  |  OPCO={self.opco}  DATE={self.run_date}",
            f"  Elapsed: {elapsed:.1f}s",
            "=" * 55,
        ]
        for s in self.summary:
            icon = "✓" if s["status"] == "SUCCESS" else \
                   "⚠" if s["status"] == "PARTIAL"  else "✗"
            lines.append(
                f"  {icon}  {s['layer']:10s}  {s['status']:22s}  "
                f"tables={s['tables']}  pass={s['passed']}  fail={s['failed']}"
            )
        lines.append("=" * 55)
        self.logger.info("\n".join(lines))


# ===========================================================================
# CLI entry point
# ===========================================================================
def parse_args():
    p = argparse.ArgumentParser(description="CDL ETL Pipeline Runner")
    p.add_argument("--opco",      required=True)
    p.add_argument("--run_date",  required=True, help="YYYY-MM-DD")
    p.add_argument("--layer",     default=None,  help="Run a single layer only")
    p.add_argument("--frequency", default=None,  help="DAILY | MONTHLY | BOTH")
    p.add_argument("--env",       default="azure", choices=["azure", "gcp"])
    p.add_argument("--dag_id",    default="cdl_master_pipeline")
    return p.parse_args()


def main():
    args = parse_args()
    os.environ["CDL_ENV"] = args.env
    run_date = date.fromisoformat(args.run_date)
    spark    = build_spark(args.env)
    spark.sparkContext.setLogLevel("WARN")

    runner  = PipelineRunner(
        spark=spark, opco=args.opco, run_date=run_date,
        dag_id=args.dag_id, target_layer=args.layer, frequency=args.frequency,
    )
    success = runner.run()
    sys.exit(0 if success else 1)


if __name__ == "__main__":
    main()
