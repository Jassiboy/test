"""
notebooks/01_framework.py
================================
All shared framework logic in ONE notebook:

  Config
    read_table_configs()   : reads cdl_table_config, optionally filtered by
                              opco / layer / frequency / an explicit list of
                              table names (table_id or target_table_name)
  Dependency gate
    check_dq_gate()        : upstream tables must have dq_passed=TRUE today
  Data quality
    run_dq()                : runs inline DQ rules on a DataFrame
  Audit log
    log_run()                : single upsert into cdl_table_run_log for
                              RUNNING / SUCCESS / FAILED / HALTED states
    make_run_id()
    update_watermark()
  Transformation loader
    get_transformed_df()    : imports transformations/{opco}/{layer}.py and
                              calls transform_daily()/transform_monthly()
  Ingestion / write
    run_ingestion()          : filter → DQ → write → watermark → audit, with
                              retry, for both incremental and a date-window
                              (used for month-wise loads — see notebooks/02_pipeline.py)

This file used to be split across 01_framework_core.py, 02_ingestion.py and
03_transformation.py. It's merged here (and each function's internal helpers
inlined where they were only used once) to keep the framework to a single
notebook with a small, flat function list.
"""

import hashlib
import importlib
import json
import os
import random
import time
import traceback
from dataclasses import dataclass
from datetime import date, datetime, timezone
from typing import Optional

from pyspark.sql import DataFrame, SparkSession
from pyspark.sql import functions as F
from delta.tables import DeltaTable

from config.env_config import get_metadata_db, get_data_db
from utils.alert_manager import AlertManager

# METADATA_DB = get_metadata_db()
METADATA_DB = 'f6180854'
DATA_DB     = get_data_db()
_alerter    = AlertManager()


# ─────────────────────────────────────────────────────────────────────────────
# Logger — simple structured print
# ─────────────────────────────────────────────────────────────────────────────
def log(level: str, msg: str, **ctx):
    now = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
    extra = "  ".join(f"{k}={v}" for k, v in ctx.items())
    print(f"[{now}] [{level.upper()}]  {msg}  {extra}".strip())


# ─────────────────────────────────────────────────────────────────────────────
# TableConfig — one row from cdl_table_config
# ─────────────────────────────────────────────────────────────────────────────
@dataclass
class TableConfig:
    table_id:             str
    source_system:        str
    source_table_name:    str
    source_filter:        Optional[str]
    target_system:        str
    target_table_name:    str
    target_dataset_layer: str
    opco:                 str
    ingestion_mode:       str
    load_frequency:       str
    watermark_column:     Optional[str]
    last_watermark_value: Optional[datetime]
    partition_col:        Optional[str]
    merge_keys:           Optional[str]
    dq_rules:             list          # parsed from data_quality_rules JSON
    dq_threshold_pct:     float
    depends_on:           list[str]     # parsed from depends_on_table_ids
    retry_max_attempts:   int
    retry_wait_sec:       int
    retry_backoff:        float
    retry_max_wait:       int
    alert_config:         list          # parsed from alert_config JSON
    is_active:            bool


# ─────────────────────────────────────────────────────────────────────────────
# Read configs from cdl_table_config
# ─────────────────────────────────────────────────────────────────────────────
def read_table_configs(
    opco:        Optional[str] = None,
    layer:       Optional[str] = None,
    frequency:   Optional[str] = None,
    table_names: Optional[list[str]] = None,
) -> list[TableConfig]:
    """
    Return active TableConfig rows, filtered by whichever of these are given:

      opco        : "GROUND" | "FREIGHT" | ...
      layer       : "ACCOUNT" | "FACILITY" | "COUNTRY" | "GLOBAL"
      frequency   : "DAILY" | "MONTHLY" | "BOTH" (BOTH / None = no filter)
      table_names : explicit list of table_id or target_table_name values —
                    when given, the pipeline runs ONLY these tables, whatever
                    opco/layer they belong to. opco/layer can still be passed
                    alongside table_names to further narrow the match.
    """
    spark = SparkSession.getActiveSession()
    clauses = ["is_active = true"]
    if opco:
        clauses.append(f"opco = '{opco.upper()}'")
    if layer:
        clauses.append(f"target_dataset_layer = '{layer.upper()}'")
    if frequency and frequency.upper() != "BOTH":
        clauses.append(f"load_frequency IN ('{frequency.upper()}', 'BOTH')")
    if table_names:
        names = ",".join(f"'{t}'" for t in table_names)
        clauses.append(f"(table_id IN ({names}) OR target_table_name IN ({names}))")

    where = " AND ".join(clauses)
    rows = spark.sql(
        f"SELECT * FROM {METADATA_DB}.cdl_table_config WHERE {where} ORDER BY table_id"
    ).collect()

    log("INFO", f"Loaded {len(rows)} config(s)", opco=opco, layer=layer, table_names=table_names)
    return [_to_config(r) for r in rows]


def _to_config(row) -> TableConfig:
    d = row.asDict()
    parse_json = lambda v, default: json.loads(v) if v else default
    return TableConfig(
        table_id             = d["table_id"],
        source_system        = d["source_system"],
        source_table_name    = d["source_table_name"],
        source_filter        = d.get("source_filter"),
        target_system        = d["target_system"],
        target_table_name    = d["target_table_name"],
        target_dataset_layer = d["target_dataset_layer"],
        opco                 = d["opco"],
        ingestion_mode       = d["ingestion_mode"],
        load_frequency       = d["load_frequency"],
        watermark_column     = d.get("watermark_column"),
        last_watermark_value = d.get("last_watermark_value"),
        partition_col        = d.get("partition_col"),
        merge_keys           = d.get("merge_keys"),
        dq_rules             = parse_json(d.get("data_quality_rules"), []),
        dq_threshold_pct     = float(d.get("dq_threshold_pct") or 95.0),
        depends_on           = [x.strip() for x in (d.get("depends_on_table_ids") or "").split(",") if x.strip()],
        retry_max_attempts   = int(d.get("retry_max_attempts")     or 3),
        retry_wait_sec       = int(d.get("retry_initial_wait_sec") or 30),
        retry_backoff        = float(d.get("retry_backoff_multiplier") or 2.0),
        retry_max_wait       = int(d.get("retry_max_wait_sec")     or 300),
        alert_config         = parse_json(d.get("alert_config"), []),
        is_active            = bool(d["is_active"]),
    )


# ─────────────────────────────────────────────────────────────────────────────
# DQ gate — check upstream tables passed before running downstream ones
# ─────────────────────────────────────────────────────────────────────────────
def check_dq_gate(configs: list[TableConfig], run_date: date) -> tuple[bool, list[str]]:
    """
    For each config, check all its depends_on table_ids have dq_passed = TRUE
    in today's run log. Returns (all_clear, list_of_failed_upstream_ids).
    """
    spark = SparkSession.getActiveSession()
    needed = {tid for cfg in configs for tid in cfg.depends_on}
    if not needed:
        return True, []

    ids = ",".join(f"'{x}'" for x in needed)
    rows = spark.sql(f"""
        SELECT dataset_id, MAX(CAST(dq_passed AS INT)) AS ok
        FROM {METADATA_DB}.cdl_table_run_log
        WHERE dag_run_date = '{run_date}' AND status = 'SUCCESS' AND dataset_id IN ({ids})
        GROUP BY dataset_id
    """).collect()

    passed = {r["dataset_id"] for r in rows if r["ok"] == 1}
    failed = [x for x in needed if x not in passed]
    if failed:
        log("ERROR", "DQ gate blocked", failed_upstream=str(failed))
        return False, failed
    return True, []


# ─────────────────────────────────────────────────────────────────────────────
# DQ engine — run inline rules, tag rows, return results
# ─────────────────────────────────────────────────────────────────────────────
def run_dq(df: DataFrame, cfg: TableConfig) -> tuple[DataFrame, list[dict], bool]:
    """
    Run all DQ rules from cfg.dq_rules against df.
    Returns (df_tagged_with_dq_passed_col, per_rule_results, overall_ok).
    """
    total = df.count()
    results = [_run_one_rule(df, rule, total) for rule in cfg.dq_rules]
    for rule, result in zip(cfg.dq_rules, results):
        log("INFO", f"DQ [{rule['rule_id']}] {'PASS' if result['passed'] else 'FAIL'}",
            severity=rule.get("severity"), pct_failed=result["failure_pct"])

    crit_exprs = [
        r["rule_expression"] for r in cfg.dq_rules
        if r.get("severity") == "CRITICAL" and r.get("rule_type") not in ("ROW_COUNT", "UNIQUENESS")
    ]
    if crit_exprs:
        combined = " AND ".join(f"({e})" for e in crit_exprs)
        df = df.withColumn("dq_passed", F.when(F.expr(combined), F.lit(True)).otherwise(F.lit(False)))
    else:
        df = df.withColumn("dq_passed", F.lit(True))

    crit_ok = all(r["passed"] for r in results if r["severity"] == "CRITICAL")
    if total > 0:
        crit_failed_rows = sum(r["rows_failed"] for r in results if r["severity"] == "CRITICAL")
        threshold_ok = ((total - crit_failed_rows) / total) * 100 >= cfg.dq_threshold_pct
    else:
        threshold_ok = False

    return df, results, (crit_ok and threshold_ok)


def _run_one_rule(df: DataFrame, rule: dict, total: int) -> dict:
    rid, rtype, expr = rule["rule_id"], rule["rule_type"], rule["rule_expression"]
    sev = rule.get("severity", "WARNING")
    thr = float(rule.get("error_threshold_pct") or 0.0)

    try:
        if rtype == "ROW_COUNT":
            min_rows = json.loads(expr).get("min_rows", 1) if expr.startswith("{") else 1
            passed = total >= min_rows
            return {"rule_id": rid, "severity": sev, "passed": passed, "rows_checked": total,
                    "rows_failed": 0 if passed else 1, "failure_pct": 0.0 if passed else 100.0}

        if rtype == "UNIQUENESS":
            col  = rule.get("target_column")
            dups = total - df.select(col).distinct().count()
            pct  = (dups / total * 100) if total else 0.0
            return {"rule_id": rid, "severity": sev, "passed": pct <= thr,
                    "rows_checked": total, "rows_failed": dups, "failure_pct": round(pct, 4)}

        failed = df.filter(f"NOT ({expr})").count()
        pct = (failed / total * 100) if total else 0.0
        return {"rule_id": rid, "severity": sev, "passed": pct <= thr,
                "rows_checked": total, "rows_failed": failed, "failure_pct": round(pct, 4)}

    except Exception as exc:
        return {"rule_id": rid, "severity": sev, "passed": False, "rows_checked": total,
                "rows_failed": total, "failure_pct": 100.0, "error": str(exc)[:300]}


# ─────────────────────────────────────────────────────────────────────────────
# Run log — one upsert function handles RUNNING / SUCCESS / FAILED / HALTED
# ─────────────────────────────────────────────────────────────────────────────
def make_run_id(dag_id: str, table_id: str, run_date: date, attempt: int) -> str:
    raw = f"{dag_id}|{table_id}|{run_date}|{attempt}"
    return hashlib.sha256(raw.encode()).hexdigest()[:32]


def log_run(
    run_id: str,
    cfg: TableConfig,
    run_date: date,
    dag_id: str,
    attempt: int,
    status: str,                       # RUNNING | SUCCESS | FAILED | HALTED
    started_at: Optional[datetime] = None,
    watermark_start: Optional[datetime] = None,
    watermark_end:   Optional[datetime] = None,
    rows_read:     Optional[int] = None,
    rows_written:  Optional[int] = None,
    rows_rejected: Optional[int] = None,
    dq_results:    Optional[list] = None,
    dq_passed:     Optional[bool] = None,
    error_code:    Optional[str] = None,
    error_message: Optional[str] = None,
):
    """
    Write/refresh one row of cdl_table_run_log for (run_id, attempt_number).
    Replaces the old log_start()/log_success()/log_failure() trio with a
    single upsert — first call for a run_id inserts, later calls update it.
    """
    spark = SparkSession.getActiveSession()
    now = datetime.now(timezone.utc)
    is_terminal = status != "RUNNING"

    row = {
        "run_id": run_id, "dataset_id": cfg.table_id, "dag_run_date": str(run_date),
        "dag_id": dag_id, "task_id": cfg.table_id, "dataset_layer": cfg.target_dataset_layer,
        "opco": cfg.opco, "table_name": cfg.target_table_name,
        "status": status, "attempt_number": attempt,
        "rows_read": rows_read, "rows_written": rows_written, "rows_rejected": rows_rejected,
        "rows_merged": None, "rows_inserted": None, "rows_updated": None, "rows_deleted": None,
        "watermark_start": watermark_start.isoformat() if watermark_start else None,
        "watermark_end":   watermark_end.isoformat()   if watermark_end   else None,
        "started_at":   (started_at or now).isoformat(),
        "completed_at": now.isoformat() if is_terminal else None,
        "duration_seconds": int((now - started_at).total_seconds()) if (started_at and is_terminal) else None,
        "dq_results": json.dumps(dq_results) if dq_results is not None else None,
        "dq_passed":  dq_passed,
        "error_code": error_code,
        "error_message": (error_message[:2000] if error_message else None),
        "spark_app_id": spark.sparkContext.applicationId,
        "cluster_id": os.getenv("CLUSTER_ID", "unknown"),
        "created_at": now.isoformat(), "updated_at": now.isoformat(),
    }
    _upsert_run_log(row)


def _upsert_run_log(row: dict):
    spark = SparkSession.getActiveSession()
    try:
        df = spark.createDataFrame([row])
        (DeltaTable.forName(spark, f"{METADATA_DB}.cdl_table_run_log").alias("t")
            .merge(df.alias("s"), "t.run_id = s.run_id AND t.attempt_number = s.attempt_number")
            .whenMatchedUpdateAll()
            .whenNotMatchedInsertAll()
            .execute())
    except Exception as e:
        log("ERROR", f"Failed to write run log: {e}")


def update_watermark(table_id: str, new_value: datetime, run_date: date):
    spark = SparkSession.getActiveSession()
    now = datetime.now(timezone.utc).isoformat()
    spark.sql(f"""
        UPDATE {METADATA_DB}.cdl_table_config
        SET last_watermark_value = '{new_value.isoformat()}',
            last_successful_run  = '{run_date}',
            updated_at           = '{now}'
        WHERE table_id = '{table_id}'
    """)
    log("INFO", f"Watermark updated → {new_value}", table_id=table_id)


# ─────────────────────────────────────────────────────────────────────────────
# Transformation loader
# ─────────────────────────────────────────────────────────────────────────────
def get_transformed_df(
    opco: str,
    layer: str,
    frequency: str,
    run_date: date,
    start_date: Optional[date] = None,
    end_date:   Optional[date] = None,
) -> DataFrame:
    """
    Import transformations/{opco}/{layer}.py and call transform_daily() or
    transform_monthly(). start_date/end_date=None means incremental mode;
    both set means the transformation should read that window only (the
    caller — notebooks/02_pipeline.py — passes one calendar month at a time,
    so each Spark job here covers a single month, not the whole range).
    """
    module_path = f"transformations.{opco.lower()}.{layer.lower()}"
    log("INFO", "Loading transformer", module=module_path, frequency=frequency)

    try:
        module = importlib.import_module(module_path)
    except ModuleNotFoundError:
        raise ValueError(
            f"No transformation module at '{module_path}'.\n"
            f"Create transformations/{opco.lower()}/{layer.lower()}.py "
            f"with transform_daily() and transform_monthly() functions."
        )

    fn_name = "transform_monthly" if frequency.upper() == "MONTHLY" else "transform_daily"
    fn = getattr(module, fn_name, None)
    if fn is None:
        raise ValueError(f"Module '{module_path}' is missing function '{fn_name}'")

    spark = SparkSession.getActiveSession()
    return fn(spark, run_date, opco, start_date=start_date, end_date=end_date)


# ─────────────────────────────────────────────────────────────────────────────
# Ingestion — filter → DQ → write → watermark → audit, with retry
# ─────────────────────────────────────────────────────────────────────────────
def run_ingestion(
    df: DataFrame,
    cfg: TableConfig,
    run_date: date,
    dag_id: str,
    start_date: Optional[date] = None,
    end_date:   Optional[date] = None,
) -> bool:
    """
    Write df to the target Delta table with retry.

    Incremental mode (start_date=None, end_date=None):
      filters by watermark_column > last_watermark_value, updates the
      watermark in cdl_table_config after a successful write.

    Window mode (start_date + end_date both given):
      filters by watermark_column BETWEEN start_date AND end_date, and does
      an atomic replaceWhere overwrite of that window's partitions. The
      caller decides how big the window is — notebooks/02_pipeline.py calls
      this once per calendar month so data loads month-by-month rather than
      as one big multi-month job. Watermark is not updated in window mode
      (it's a backfill/reprocess).
    """
    is_range   = start_date is not None and end_date is not None
    mode_label = f"WINDOW({start_date}→{end_date})" if is_range else "INCREMENTAL"

    for attempt in range(1, cfg.retry_max_attempts + 1):
        started_at = datetime.now(timezone.utc)
        run_id = make_run_id(dag_id, cfg.table_id, run_date, attempt)
        log("INFO", f"Ingestion [{mode_label}] attempt {attempt}/{cfg.retry_max_attempts}",
            table=cfg.table_id, run_id=run_id)
        log_run(run_id, cfg, run_date, dag_id, attempt, "RUNNING",
                started_at=started_at, watermark_start=cfg.last_watermark_value)

        try:
            filtered = df
            if is_range and cfg.watermark_column:
                filtered = filtered.filter(
                    (F.col(cfg.watermark_column).cast("date") >= F.lit(str(start_date))) &
                    (F.col(cfg.watermark_column).cast("date") <= F.lit(str(end_date)))
                )
            elif not is_range and cfg.ingestion_mode == "INCR" and cfg.watermark_column and cfg.last_watermark_value:
                filtered = filtered.filter(F.col(cfg.watermark_column) > F.lit(cfg.last_watermark_value))

            rows_read = filtered.count()
            log("INFO", f"Rows after filter: {rows_read}", table=cfg.table_id)

            if rows_read == 0 and cfg.ingestion_mode != "FULL":
                log("INFO", "No new rows — skipping write", table=cfg.table_id)
                log_run(run_id, cfg, run_date, dag_id, attempt, "SUCCESS", started_at=started_at,
                        rows_read=0, rows_written=0, rows_rejected=0, dq_results=[], dq_passed=True)
                return True

            now_iso = datetime.now(timezone.utc).isoformat()
            filtered = (filtered
                .withColumn("run_id", F.lit(run_id))
                .withColumn("source_system", F.lit(cfg.source_system))
                .withColumn("created_at", F.coalesce(F.col("created_at"), F.lit(now_iso).cast("timestamp")))
                .withColumn("updated_at", F.lit(now_iso).cast("timestamp")))

            tagged, dq_results, dq_passed = run_dq(filtered, cfg)
            clean_df = tagged.filter("dq_passed = true")
            rejected_ct = tagged.filter("dq_passed = false").count()
            log("INFO", f"DQ {'PASS' if dq_passed else 'FAIL'} | "
                        f"clean={rows_read - rejected_ct}  rejected={rejected_ct}", table=cfg.table_id)

            target = f"{DATA_DB}.{cfg.target_table_name}"
            rows_written = _write(clean_df, cfg, target, run_date, start_date, end_date)

            wm_end = None
            if not is_range and cfg.ingestion_mode == "INCR" and cfg.watermark_column:
                wm_val = clean_df.agg(F.max(cfg.watermark_column)).collect()[0][0]
                if wm_val:
                    wm_end = wm_val
                    update_watermark(cfg.table_id, wm_val, run_date)

            log_run(run_id, cfg, run_date, dag_id, attempt, "SUCCESS", started_at=started_at,
                    rows_read=rows_read, rows_written=rows_written, rows_rejected=rejected_ct,
                    dq_results=dq_results, dq_passed=dq_passed, watermark_end=wm_end)

            if not dq_passed:
                _alerter.send(cfg, run_id, "FAILED", f"DQ threshold not met for {cfg.table_id}", "CRITICAL")
                # DQ failure is treated like a failed attempt below → retry / exhaust
            else:
                return True

        except Exception as exc:
            msg = f"{type(exc).__name__}: {exc}\n{traceback.format_exc()}"
            log("ERROR", f"Attempt {attempt} failed: {exc}", table=cfg.table_id)
            is_last = attempt == cfg.retry_max_attempts
            log_run(run_id, cfg, run_date, dag_id, attempt, "FAILED" if is_last else "RUNNING",
                    started_at=started_at, error_code="UNHANDLED_EXCEPTION", error_message=msg)
            if is_last:
                _alerter.send(cfg, run_id, "FAILED", msg, "CRITICAL")
                return False

        if attempt == cfg.retry_max_attempts:
            return False
        wait = min(cfg.retry_wait_sec * (cfg.retry_backoff ** (attempt - 1)), cfg.retry_max_wait)
        wait += random.uniform(0, wait * 0.1)
        log("INFO", f"Retrying in {wait:.0f}s …")
        time.sleep(wait)

    return False


def _write(
    df: DataFrame,
    cfg: TableConfig,
    target: str,
    run_date: date,
    start_date: Optional[date],
    end_date:   Optional[date],
) -> int:
    """
    Write df to target table. Returns row count written.

    replaceWhere scope:
      Incremental : load_date = '{run_date}'                AND opco = '{opco}'
      Window      : load_date BETWEEN '{start}' AND '{end}' AND opco = '{opco}'

    Only affected partitions are rewritten — everything else is untouched.
    """
    spark = SparkSession.getActiveSession()
    is_range = start_date is not None and end_date is not None
    opco, mode = cfg.opco, cfg.ingestion_mode.upper()

    replace_where = (
        f"load_date BETWEEN '{start_date}' AND '{end_date}' AND opco = '{opco}'"
        if is_range else
        f"load_date = '{run_date}' AND opco = '{opco}'"
    )

    if mode == "FULL":
        (df.write.format("delta").mode("overwrite")
           .option("replaceWhere", replace_where).saveAsTable(target))
        ct = df.count()
        log("INFO", f"FULL write → {target}: {ct} rows | scope: {replace_where}")
        return ct

    if not cfg.merge_keys:
        raise ValueError(f"merge_keys required for {mode} on {cfg.table_id}")
    merge_cond = " AND ".join(f"t.{k.strip()} = s.{k.strip()}" for k in cfg.merge_keys.split(","))

    if not DeltaTable.isDeltaTable(spark, target):
        df.write.format("delta").mode("append").saveAsTable(target)
        ct = df.count()
        log("INFO", f"First load → {target}: {ct} rows")
        return ct

    dt = DeltaTable.forName(spark, target)
    merge = dt.alias("t").merge(df.alias("s"), merge_cond)
    if mode == "CDC":
        (merge.whenMatchedDelete(condition="s.cdc_op = 'D'")
              .whenMatchedUpdateAll(condition="s.cdc_op != 'D'")
              .whenNotMatchedInsertAll(condition="s.cdc_op != 'D'")
              .execute())
    else:
        merge.whenMatchedUpdateAll().whenNotMatchedInsertAll().execute()

    ops = dt.history(1).select("operationMetrics").collect()[0][0]
    ins, upd, dlt = int(ops.get("numTargetRowsInserted", 0)), int(ops.get("numTargetRowsUpdated", 0)), int(ops.get("numTargetRowsDeleted", 0))
    log("INFO", f"{mode} merge → {target}: ins={ins} upd={upd} del={dlt}")
    return ins + upd
