# Databricks notebook source
# DBTITLE 1,Imports
"""
notebooks/02_pipeline.py
================================
Orchestrator. Reads parameters either from Databricks widgets (so this
notebook can be scheduled/triggered as a Databricks Job / task with
parameters) or from config/run_config.json (unchanged default behaviour).
Both paths converge on the same run_pipeline() function.

Parameters (widget name → run_config.json key):
  opco                → opco            e.g. GROUND
  table_names          → tables          comma-separated, e.g. account_daily,facility_monthly
                                         (optional — omit to run a whole layer/OPCO as before)
  start_layer          → start_layer     default ACCOUNT (ignored if table_names is set —
                                         the layers are derived from whichever tables you named)
  frequency            → frequency       DAILY | MONTHLY | BOTH (default BOTH)
  start_month/end_month → start_date/end_date  "YYYY-MM" on widgets, "YYYY-MM-DD" in JSON.
                                         Omit both for an incremental (watermark) run.
  dag_id               → dag_id

If start_date/end_date span more than one month, the pipeline loads ONE
CALENDAR MONTH AT A TIME (a separate Spark job per month) instead of the
whole range in one go — see month_chunks().

Notebook is kept to a small, flat function list:
  resolve_groups()      : which (opco, layer) pairs to process
  month_chunks()        : split a date range into per-month windows
  run_layer()            : process every active table in one (opco, layer)
  run_pipeline()          : loop months × layers for one run request
  _halt_downstream()     : mark skipped tables HALTED in the audit log
  _params_from_widgets() : read Databricks widgets, if any were set
  main()                 : entry point — widgets first, config file fallback
"""

import importlib
import json
import sys
import os
from datetime import date, timedelta
from typing import Optional

sys.path.insert(0, os.path.abspath(os.path.join(os.getcwd(), "..")))
for _mod in ["notebooks.01_framework", "config.env_config"]:
    sys.modules.pop(_mod, None)

fw = importlib.import_module("notebooks.01_framework")
from config.env_config import PIPELINE_CONFIG

log                = fw.log
read_table_configs = fw.read_table_configs
check_dq_gate      = fw.check_dq_gate
make_run_id        = fw.make_run_id
log_run            = fw.log_run
get_transformed_df = fw.get_transformed_df
run_ingestion      = fw.run_ingestion

LAYER_ORDER  = PIPELINE_CONFIG.layer_order       # e.g. ["ACCOUNT","FACILITY","COUNTRY","GLOBAL"]
CONFIG_PATH  = "../config/run_config.json"

# COMMAND ----------

# DBTITLE 1,Scope resolution — which (opco, layer) pairs to run
def resolve_groups(opco: str, table_names: Optional[list[str]], start_layer: str) -> list[tuple[str, str]]:
    """
    Return the (opco, layer) pairs to process, in dependency order.

    table_names given : look the tables up directly (feature #1 — pass table
      names, not opco/layer) and derive whichever layers they live in, so
      only those tables get touched, nothing else in their layer.
    table_names absent : behave as before — every layer from start_layer
      onward for the given opco.
    """
    if table_names:
        configs = read_table_configs(opco=opco, table_names=table_names)
        if not configs:
            return []
        pairs = {(c.opco, c.target_dataset_layer) for c in configs}
        return sorted(pairs, key=lambda p: LAYER_ORDER.index(p[1]) if p[1] in LAYER_ORDER else 99)

    sl = start_layer.upper()
    if sl not in LAYER_ORDER:
        raise ValueError(f"Invalid start_layer '{sl}'. Choose from {LAYER_ORDER}")
    return [(opco, l) for l in LAYER_ORDER[LAYER_ORDER.index(sl):]]

# COMMAND ----------

# DBTITLE 1,Month splitting — load month-wise instead of one big range
def month_chunks(start_date: date, end_date: date) -> list[tuple[date, date]]:
    """Split [start_date, end_date] into calendar-month (start, end) windows."""
    chunks = []
    cur = date(start_date.year, start_date.month, 1)
    while cur <= end_date:
        nxt = date(cur.year + cur.month // 12, cur.month % 12 + 1, 1)
        chunks.append((max(cur, start_date), min(nxt - timedelta(days=1), end_date)))
        cur = nxt
    return chunks

# COMMAND ----------

# DBTITLE 1,Run one (opco, layer) for one window
def run_layer(
    opco: str, layer: str, frequency: str, dag_id: str, run_date: date, skip_gate: bool,
    table_names: Optional[list[str]] = None,
    start_date: Optional[date] = None, end_date: Optional[date] = None,
) -> bool:
    grains = ["DAILY", "MONTHLY"] if frequency.upper() == "BOTH" else [frequency.upper()]
    all_ok = True

    for grain in grains:
        configs = read_table_configs(opco, layer, grain, table_names=table_names)
        if not configs:
            log("WARN", "No active configs", layer=layer, grain=grain, opco=opco)
            continue

        if not skip_gate:
            gate_ok, blocked_by = check_dq_gate(configs, run_date)
            if not gate_ok:
                log("ERROR", f"DQ gate blocked {layer}: upstream not ready {blocked_by}")
                return False

        for cfg in configs:
            log("INFO", f"  ► {cfg.table_id}  [{grain}]")
            tdf = get_transformed_df(opco, layer, grain, run_date, start_date, end_date)
            ok = run_ingestion(tdf, cfg, run_date, dag_id, start_date, end_date)
            log("INFO" if ok else "ERROR", f"  {'✓' if ok else '✗ FAILED'} {cfg.table_id}")
            all_ok = all_ok and ok

    return all_ok

# COMMAND ----------

# DBTITLE 1,Halt bookkeeping for tables skipped after an upstream failure
def _halt_downstream(groups: list[tuple[str, str]], ref_date: date, dag_id: str, table_names: Optional[list[str]]):
    for g_opco, g_layer in groups:
        for cfg in read_table_configs(g_opco, g_layer, table_names=table_names):
            run_id = make_run_id(dag_id, cfg.table_id, ref_date, 1)
            log_run(run_id, cfg, ref_date, dag_id, 1, "HALTED",
                    error_code="UPSTREAM_DQ_FAILED",
                    error_message=f"Halted: upstream failed — layer {g_layer} ref={ref_date}")

# COMMAND ----------

# DBTITLE 1,Single entry point — incremental, backfill, or table-scoped, all in one
def run_pipeline(
    opco: str, dag_id: str,
    table_names: Optional[list[str]] = None,
    start_layer: str = "ACCOUNT", frequency: str = "BOTH",
    start_date: Optional[date] = None, end_date: Optional[date] = None,
) -> dict:
    """
    One call handles all three request shapes:
      - no dates                → incremental (watermark) run, today
      - start_date + end_date   → backfill, looped one calendar month at a time
      - table_names             → restricts either of the above to just those tables
    """
    groups = resolve_groups(opco, table_names, start_layer)
    if not groups:
        log("WARN", "No matching tables for this run", opco=opco, table_names=table_names)
        return {"opco": opco, "period": "n/a", "mode": "none", "ok": False}

    windows = [(None, None)] if start_date is None else month_chunks(start_date, end_date)
    mode = "incremental" if start_date is None else "monthly_backfill"
    overall_ok = True

    for w_start, w_end in windows:
        run_date = date.today() if w_start is None else w_end
        label = "INCREMENTAL" if w_start is None else f"{w_start} → {w_end}"
        log("INFO", "═" * 55)
        log("INFO", f"OPCO={opco} | {label} | tables={table_names or 'ALL'} | groups={groups}")

        for i, (g_opco, g_layer) in enumerate(groups):
            log("INFO", "─" * 45)
            log("INFO", f"Layer: {g_layer}  (opco={g_opco})")
            ok = run_layer(g_opco, g_layer, frequency, dag_id, run_date,
                            skip_gate=(i == 0), table_names=table_names,
                            start_date=w_start, end_date=w_end)
            if not ok:
                remaining = groups[i + 1:]
                log("ERROR", f"{g_layer} FAILED for {label} — halting {[l for _, l in remaining]}")
                _halt_downstream(remaining, run_date, dag_id, table_names)
                overall_ok = False
                break

    period = f"{start_date}→{end_date}" if start_date else f"incr:{date.today()}"
    return {"opco": opco, "period": period, "mode": mode, "ok": overall_ok}

# COMMAND ----------

# DBTITLE 1,Widget parameters (feature #2 — pass requirements as widgets/params, not just config file)
def _month_end(yyyymm: str) -> str:
    y, m = (int(x) for x in yyyymm.split("-"))
    nxt = date(y + m // 12, m % 12 + 1, 1)
    return str(nxt - timedelta(days=1))


def _params_from_widgets(dbutils) -> Optional[dict]:
    """
    Read run parameters from Databricks widgets, if `opco` was actually set.
    Returns None (→ caller falls back to run_config.json) when no widget
    values are present, so this notebook works unchanged when triggered
    without parameters.
    """
    try:
        for name, default in [
            ("opco", ""), ("table_names", ""), ("start_layer", "ACCOUNT"),
            ("frequency", "BOTH"), ("start_month", ""), ("end_month", ""),
            ("dag_id", "cdl_master_pipeline"),
        ]:
            dbutils.widgets.text(name, default)

        opco = dbutils.widgets.get("opco").strip().upper()
        if not opco:
            return None

        table_names = [t.strip() for t in dbutils.widgets.get("table_names").split(",") if t.strip()]
        start_month = dbutils.widgets.get("start_month").strip()
        end_month   = dbutils.widgets.get("end_month").strip()

        return {
            "opco":        opco,
            "table_names": table_names or None,
            "start_layer": dbutils.widgets.get("start_layer").strip() or "ACCOUNT",
            "frequency":   dbutils.widgets.get("frequency").strip() or "BOTH",
            "start_date":  f"{start_month}-01" if start_month else None,
            "end_date":    _month_end(end_month) if end_month else None,
            "dag_id":      dbutils.widgets.get("dag_id").strip() or "cdl_master_pipeline",
        }
    except Exception as e:
        log("WARN", f"Widgets unavailable, falling back to config file: {e}")
        return None

# COMMAND ----------

# DBTITLE 1,Summary
def print_summary(results: list[dict], started: "datetime"):
    from datetime import datetime, timezone
    elapsed = (datetime.now(timezone.utc) - started).total_seconds()
    total, passed = len(results), sum(1 for r in results if r["ok"])

    log("INFO", "╔" + "═" * 60 + "╗")
    log("INFO", "║        CDL ETL — GRAND SUMMARY" + " " * 29 + "║")
    log("INFO", f"║  Runs:{total}  Pass:{passed}  Fail:{total-passed}  Elapsed:{elapsed:.0f}s" + " " * 24 + "║")
    log("INFO", "╠" + "═" * 60 + "╣")
    for r in results:
        icon = "✓" if r["ok"] else "✗"
        log("INFO", f"║  {r['opco']:<10}  {r['period']:<25}  {r['mode']:<18}  {icon}  ║")
    log("INFO", "╚" + "═" * 60 + "╝")

# COMMAND ----------

# DBTITLE 1,Entry point
def main() -> bool:
    from datetime import datetime, timezone
    dbutils = globals().get("dbutils")
    params = _params_from_widgets(dbutils) if dbutils is not None else None

    if params:
        log("INFO", "Parameters supplied via widgets — skipping run_config.json")
        run_blocks, default_dag_id = [params], params["dag_id"]
    else:
        log("INFO", "No widget parameters set — reading config/run_config.json")
        with open(CONFIG_PATH) as f:
            file_cfg = json.load(f)
        default_dag_id = file_cfg.get("dag_id", "cdl_master_pipeline")
        run_blocks = [r for r in file_cfg.get("runs", []) if set(r.keys()) != {"_comment"}]

    started = datetime.now(timezone.utc)
    results = []
    for run in run_blocks:
        results.append(run_pipeline(
            opco        = run["opco"].upper(),
            dag_id      = run.get("dag_id", default_dag_id),
            table_names = run.get("tables"),
            start_layer = run.get("start_layer", "ACCOUNT"),
            frequency   = run.get("frequency", "BOTH"),
            start_date  = date.fromisoformat(run["start_date"]) if run.get("start_date") else None,
            end_date    = date.fromisoformat(run["end_date"])   if run.get("end_date")   else None,
        ))

    print_summary(results, started)
    return all(r["ok"] for r in results)


if __name__ == "__main__":
    main()
