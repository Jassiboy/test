# Changes in this revision

## 1. Run by table name + month range, not just opco/layer
`read_table_configs()` (in `notebooks/01_framework.py`) now takes an optional
`table_names` list — pass `table_id` or `target_table_name` values and only
those tables are processed, regardless of which opco/layer they live in.

`resolve_groups()` (in `notebooks/02_pipeline.py`) auto-detects which
(opco, layer) pairs those tables belong to, so you don't need to know or
pass `start_layer` when you're targeting specific tables.

```python
run_pipeline(
    opco="GROUND",
    dag_id="adhoc_backfill",
    table_names=["account_daily", "facility_monthly"],
    start_date=date(2026, 3, 1),
    end_date=date(2026, 4, 30),
)
```
In `run_config.json`, add a `"tables": [...]` list to any run block.

## 2. Widget / parameter input, in addition to the config file
`notebooks/02_pipeline.py` now checks Databricks widgets first
(`opco`, `table_names`, `start_layer`, `frequency`, `start_month`,
`end_month`, `dag_id`). If `opco` widget is set, that run is used and
`run_config.json` is skipped; otherwise it falls back to the config file
exactly as before. This lets you drive the pipeline from a Databricks Job
with parameters instead of editing the JSON file.

Set widgets on the job/notebook, e.g.:
```
opco=GROUND
table_names=account_daily,facility_monthly
start_month=2026-01
end_month=2026-03
```

## 3. Month-wise loading instead of one big range job
Previously a date-range run (`start_date`/`end_date`) loaded the entire
window in a single Spark job. Now `month_chunks()` splits any range into
calendar-month windows and `run_pipeline()` runs each month as its own
ingestion pass (own Spark job, own audit-log rows, own retry). A 5-month
backfill now runs as 5 separate monthly loads instead of 1 big one.

## 4. Fewer notebooks, fewer functions
- 4 notebooks → 2: `01_framework.py` (config, DQ, audit log, transformation
  loader, ingestion — previously split across `01_framework_core.py`,
  `02_ingestion.py`, `03_transformation.py`) and `02_pipeline.py`
  (orchestrator — replaces the old "New Notebook..." driver).
- `log_start()` / `log_success()` / `log_failure()` / `_upsert_run_log()`
  (4 functions) collapsed into one `log_run()` upsert function.
- `run_ingestion()` / `_execute()` / `_add_meta()` / `_backoff()`
  (4 functions) collapsed into one `run_ingestion()`, keeping `_write()`
  separate since the Delta merge/overwrite logic is non-trivial.
- `run_incremental()` / `run_range()` / `run_from_config()` / `layers_from()`
  / `_halt_downstream()` collapsed into one `run_pipeline()` entry point
  (plus `resolve_groups()`, `month_chunks()`, and a slimmer `_halt_downstream()`)
  that handles incremental, backfill, and table-scoped runs the same way.

## Notes / things to double check
- `check_dq_gate()` no longer takes an `opco` argument — dependency IDs
  (`table_id`) are unique across opcos, so the gate check works the same
  for cross-opco table lists.
- `notebooks/01_framework.py` still hardcodes
  `METADATA_DB = 'f6180854'` (the line above it calling `get_metadata_db()`
  is commented out) — that was already the case in the file you uploaded;
  flip that back to `get_metadata_db()` when you're ready to move off
  whatever catalog id that is.
- `transformations/ground/*.py` were empty stub files in the upload — not
  touched here, since they contain no logic to migrate.
