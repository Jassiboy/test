"""
tests/test_framework.py
========================
Test suite for the consolidated framework (notebooks/01_framework.py) and
orchestrator (notebooks/02_pipeline.py).
Run: pytest tests/test_framework.py -v
"""

import importlib
import pytest
from datetime import date
from unittest.mock import MagicMock

_fw = importlib.import_module("notebooks.01_framework")
_pl = importlib.import_module("notebooks.02_pipeline")
TableConfig = _fw.TableConfig


# ─────────────────────────────────────────────────────────────────────────────
# Spark fixture
# ─────────────────────────────────────────────────────────────────────────────
@pytest.fixture(scope="session")
def spark():
    from pyspark.sql import SparkSession
    s = (SparkSession.builder
         .master("local[2]")
         .appName("cdl_test")
         .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension")
         .config("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog")
         .config("spark.sql.shuffle.partitions", "2")
         .getOrCreate())
    s.sparkContext.setLogLevel("ERROR")
    return s


# ─────────────────────────────────────────────────────────────────────────────
# Helper: build a minimal TableConfig
# ─────────────────────────────────────────────────────────────────────────────
def mock_cfg(**overrides):
    defaults = dict(
        table_id             = "ground_account_daily",
        source_system        = "ACCOUNT_DB",
        source_table_name    = "raw_t",
        source_filter        = None,
        target_system        = "DELTA_LAKE",
        target_table_name    = "account_daily",
        target_dataset_layer = "ACCOUNT",
        opco                 = "GROUND",
        ingestion_mode       = "FULL",
        load_frequency       = "DAILY",
        watermark_column     = None,
        last_watermark_value = None,
        partition_col        = "load_date",
        merge_keys           = "account_id,opco,effective_date",
        dq_rules = [
            {"rule_id": "not_null_id",  "rule_type": "NOT_NULL",
             "target_column": "account_id",
             "rule_expression": "account_id IS NOT NULL",
             "severity": "CRITICAL", "error_threshold_pct": 0.0},
            {"rule_id": "positive_rev", "rule_type": "RANGE",
             "target_column": "revenue",
             "rule_expression": "revenue >= 0",
             "severity": "WARNING",  "error_threshold_pct": 1.0},
        ],
        dq_threshold_pct   = 95.0,
        depends_on         = [],
        retry_max_attempts = 2,
        retry_wait_sec     = 1,
        retry_backoff      = 2.0,
        retry_max_wait     = 5,
        alert_config       = [],
        is_active          = True,
    )
    defaults.update(overrides)
    return TableConfig(**defaults)


# ===========================================================================
# DQ engine tests
# ===========================================================================
class TestDQ:

    def test_all_rules_pass(self, spark):
        df = spark.createDataFrame(
            [("A1", "GROUND", 100.0), ("A2", "GROUND", 50.0)],
            "account_id STRING, opco STRING, revenue DOUBLE")
        _, results, overall = _fw.run_dq(df, mock_cfg())
        assert overall is True
        assert all(r["passed"] for r in results if r["severity"] == "CRITICAL")

    def test_critical_null_fails_overall(self, spark):
        df = spark.createDataFrame(
            [(None, "GROUND", 100.0), ("A2", "GROUND", 50.0)],
            "account_id STRING, opco STRING, revenue DOUBLE")
        _, results, overall = _fw.run_dq(df, mock_cfg())
        assert overall is False
        crit = next(r for r in results if r["rule_id"] == "not_null_id")
        assert crit["rows_failed"] == 1

    def test_warning_does_not_block_overall(self, spark):
        df = spark.createDataFrame(
            [("A1", "GROUND", -50.0), ("A2", "GROUND", 100.0)],
            "account_id STRING, opco STRING, revenue DOUBLE")
        _, results, overall = _fw.run_dq(df, mock_cfg())
        assert overall is True
        warn = next(r for r in results if r["rule_id"] == "positive_rev")
        assert warn["passed"] is False

    def test_row_count_pass(self, spark):
        cfg = mock_cfg(dq_rules=[{
            "rule_id": "min_rows", "rule_type": "ROW_COUNT", "target_column": None,
            "rule_expression": '{"min_rows": 1}',
            "severity": "CRITICAL", "error_threshold_pct": 0.0}])
        df = spark.createDataFrame([("A1",)], "account_id STRING")
        _, _, overall = _fw.run_dq(df, cfg)
        assert overall is True

    def test_row_count_fail_on_empty(self, spark):
        from pyspark.sql.types import StructType, StructField, StringType
        cfg = mock_cfg(dq_rules=[{
            "rule_id": "min_rows", "rule_type": "ROW_COUNT", "target_column": None,
            "rule_expression": '{"min_rows": 1}',
            "severity": "CRITICAL", "error_threshold_pct": 0.0}])
        schema = StructType([StructField("account_id", StringType(), True)])
        df = spark.createDataFrame([], schema)
        _, _, overall = _fw.run_dq(df, cfg)
        assert overall is False

    def test_rows_tagged_clean_and_rejected(self, spark):
        df = spark.createDataFrame(
            [(None, "GROUND", 100.0), ("A2", "GROUND", 50.0)],
            "account_id STRING, opco STRING, revenue DOUBLE")
        df_tagged, _, _ = _fw.run_dq(df, mock_cfg())
        tags = {r["account_id"]: r["dq_passed"] for r in df_tagged.collect()}
        assert tags["A2"] is True
        assert tags[None] is False

    def test_threshold_blocks_when_too_many_failures(self, spark):
        cfg = mock_cfg(
            dq_threshold_pct=99.0,
            dq_rules=[{"rule_id": "not_null_id", "rule_type": "NOT_NULL",
                       "target_column": "account_id",
                       "rule_expression": "account_id IS NOT NULL",
                       "severity": "CRITICAL", "error_threshold_pct": 0.0}])
        df = spark.createDataFrame(
            [(None,), (None,), ("A3",), ("A4",)], "account_id STRING")
        _, _, overall = _fw.run_dq(df, cfg)
        assert overall is False


# ===========================================================================
# DQ gate tests — check_dq_gate(configs, run_date), no opco param anymore
# ===========================================================================
class TestDQGate:

    def _mock_spark(self, rows, monkeypatch):
        spark = MagicMock()
        spark.sql.return_value.collect.return_value = rows
        monkeypatch.setattr(_fw.SparkSession, "getActiveSession", staticmethod(lambda: spark))
        return spark

    def test_no_deps_always_passes(self, monkeypatch):
        self._mock_spark([], monkeypatch)
        ok, failed = _fw.check_dq_gate([mock_cfg(depends_on=[])], date(2026, 1, 31))
        assert ok is True and failed == []

    def test_upstream_present_and_passed(self, monkeypatch):
        row = {"dataset_id": "ground_account_daily", "ok": 1}
        self._mock_spark([row], monkeypatch)
        cfg = mock_cfg(depends_on=["ground_account_daily"])
        ok, failed = _fw.check_dq_gate([cfg], date(2026, 1, 31))
        assert ok is True

    def test_upstream_missing_from_log(self, monkeypatch):
        self._mock_spark([], monkeypatch)
        cfg = mock_cfg(depends_on=["ground_account_daily"])
        ok, failed = _fw.check_dq_gate([cfg], date(2026, 1, 31))
        assert ok is False
        assert "ground_account_daily" in failed


# ===========================================================================
# Run ID tests
# ===========================================================================
class TestRunId:

    def test_deterministic(self):
        r1 = _fw.make_run_id("dag", "tbl", date(2026, 1, 31), 1)
        r2 = _fw.make_run_id("dag", "tbl", date(2026, 1, 31), 1)
        assert r1 == r2

    def test_differs_by_attempt(self):
        assert _fw.make_run_id("dag", "t", date(2026, 1, 31), 1) != \
               _fw.make_run_id("dag", "t", date(2026, 1, 31), 2)

    def test_32_hex_chars(self):
        rid = _fw.make_run_id("dag", "tbl", date(2026, 1, 31), 1)
        assert len(rid) == 32
        assert all(c in "0123456789abcdef" for c in rid)


# ===========================================================================
# notebooks/02_pipeline.py — month splitting (feature #3), table scope (feature #1)
# ===========================================================================
class TestMonthChunks:

    def test_single_month(self):
        assert _pl.month_chunks(date(2026, 3, 1), date(2026, 3, 31)) == \
               [(date(2026, 3, 1), date(2026, 3, 31))]

    def test_five_months_split_individually(self):
        chunks = _pl.month_chunks(date(2026, 1, 1), date(2026, 5, 31))
        assert len(chunks) == 5
        assert chunks[0] == (date(2026, 1, 1), date(2026, 1, 31))
        assert chunks[-1] == (date(2026, 5, 1), date(2026, 5, 31))

    def test_partial_first_and_last_month_clipped(self):
        chunks = _pl.month_chunks(date(2026, 1, 15), date(2026, 2, 10))
        assert chunks == [
            (date(2026, 1, 15), date(2026, 1, 31)),
            (date(2026, 2, 1),  date(2026, 2, 10)),
        ]

    def test_cross_year_boundary(self):
        chunks = _pl.month_chunks(date(2025, 11, 1), date(2026, 2, 28))
        assert [c[0].month for c in chunks] == [11, 12, 1, 2]


class TestResolveGroups:

    def test_from_start_layer_no_table_names(self):
        pairs = _pl.resolve_groups("GROUND", None, "FACILITY")
        assert pairs == [("GROUND", "FACILITY"), ("GROUND", "COUNTRY"), ("GROUND", "GLOBAL")]

    def test_invalid_start_layer_raises(self):
        with pytest.raises(ValueError, match="Invalid start_layer"):
            _pl.resolve_groups("GROUND", None, "BRONZE")

    def test_table_names_resolve_their_own_layers(self, monkeypatch):
        cfgs = [
            mock_cfg(table_id="t1", target_table_name="account_daily", target_dataset_layer="ACCOUNT"),
            mock_cfg(table_id="t2", target_table_name="facility_monthly", target_dataset_layer="FACILITY"),
        ]
        monkeypatch.setattr(_pl, "read_table_configs", lambda **kw: cfgs)
        pairs = _pl.resolve_groups("GROUND", ["account_daily", "facility_monthly"], "ACCOUNT")
        assert pairs == [("GROUND", "ACCOUNT"), ("GROUND", "FACILITY")]

    def test_table_names_with_no_matches_returns_empty(self, monkeypatch):
        monkeypatch.setattr(_pl, "read_table_configs", lambda **kw: [])
        assert _pl.resolve_groups("GROUND", ["does_not_exist"], "ACCOUNT") == []


# ===========================================================================
# Widget parameter parsing (feature #2)
# ===========================================================================
class TestWidgetParams:

    def _fake_dbutils(self, values):
        widgets = MagicMock()
        widgets.get.side_effect = lambda name: values.get(name, "")
        dbutils = MagicMock()
        dbutils.widgets = widgets
        return dbutils

    def test_no_opco_falls_back_to_config_file(self):
        dbutils = self._fake_dbutils({})
        assert _pl._params_from_widgets(dbutils) is None

    def test_widgets_build_expected_params(self):
        dbutils = self._fake_dbutils({
            "opco": "ground", "table_names": "account_daily, facility_monthly",
            "start_layer": "ACCOUNT", "frequency": "BOTH",
            "start_month": "2026-01", "end_month": "2026-02",
            "dag_id": "adhoc_dag",
        })
        params = _pl._params_from_widgets(dbutils)
        assert params["opco"] == "GROUND"
        assert params["table_names"] == ["account_daily", "facility_monthly"]
        assert params["start_date"] == "2026-01-01"
        assert params["end_date"] == "2026-02-28"
        assert params["dag_id"] == "adhoc_dag"

    def test_no_dates_means_incremental(self):
        dbutils = self._fake_dbutils({"opco": "GROUND"})
        params = _pl._params_from_widgets(dbutils)
        assert params["start_date"] is None and params["end_date"] is None


# ===========================================================================
# Retry / backoff sanity (utility module, unchanged)
# ===========================================================================
class TestRetryHandler:

    def test_backoff_caps_at_max(self):
        from utils.retry_handler import _wait
        assert _wait(10, 30.0, 2.0, 300.0, 0.0) == 300.0

    def test_backoff_doubles_each_attempt(self):
        from utils.retry_handler import _wait
        assert abs(_wait(1, 30.0, 2.0, 9999.0, 0.0) - 30.0)  < 0.01
        assert abs(_wait(2, 30.0, 2.0, 9999.0, 0.0) - 60.0)  < 0.01
        assert abs(_wait(3, 30.0, 2.0, 9999.0, 0.0) - 120.0) < 0.01
